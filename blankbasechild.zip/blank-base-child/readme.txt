=== Blank Base Child ===

A starter child theme for Blank Base.

== Why use a child theme? ==

A child theme lets you customize Blank Base without editing the parent theme
directly, so your changes are never lost when the parent theme is updated.

== Installation ==

1. Make sure the parent theme "Blank Base" is installed in wp-content/themes/blank-base.
2. Copy this "blank-base-child" folder into wp-content/themes/.
3. In wp-admin, go to Appearance → Themes and activate "Blank Base Child".

== Customizing ==

* CSS: add rules to style.css. It loads after the parent stylesheet, so your
  rules win.
* Templates: copy any template file from the parent (e.g. single.php,
  template-parts/content.php) into this folder and edit the copy. WordPress
  loads the child's version automatically.
* PHP: add functions to functions.php. It loads BEFORE the parent's
  functions.php, so hook your code onto the appropriate actions/filters.

== Adding a screenshot ==

Drop a screenshot.png (1200x900) into this folder to give the child theme its
own thumbnail in Appearance → Themes.
