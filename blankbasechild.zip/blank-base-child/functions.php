<?php
/**
 * Blank Base Child functions.
 *
 * Add your own PHP customizations here. Anything you place in this child theme
 * survives updates to the parent Blank Base theme.
 *
 * @package Blank_Base_Child
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue the parent theme stylesheet before the child stylesheet.
 *
 * The parent enqueues the active stylesheet via get_stylesheet_uri(), which in
 * a child theme resolves to this child's style.css. Loading the parent's
 * style.css here (at the same priority, before the parent callback runs)
 * guarantees the correct cascade: parent first, child overrides after.
 */
function blank_base_child_enqueue_styles() {
	$parent = wp_get_theme( get_template() );

	wp_enqueue_style(
		'blank-base-parent-style',
		get_template_directory_uri() . '/style.css',
		array(),
		$parent->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'blank_base_child_enqueue_styles' );
