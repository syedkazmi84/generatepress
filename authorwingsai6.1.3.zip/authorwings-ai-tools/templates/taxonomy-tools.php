<?php
/**
 * Front-end archive for a Tool Category (Model 2).
 *
 * Opens as a standalone page at /tool-category/<slug>/, styled with the active
 * theme's header/footer, and lists every published tool in the category. Each
 * card links to the WordPress Page that hosts that tool's [awg_generator]
 * shortcode (detected automatically). A tool whose shortcode isn't on any
 * published page yet is simply skipped, so there are never dead links.
 *
 * No plan gating happens here by design — this is a public, indexable listing.
 * Access limits are enforced when the visitor actually generates, on the tool
 * page itself.
 *
 * @package AuthorWings
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

use AWG_AIG\Public_Pages;

get_header();

$awg_term = get_queried_object();

// Shared hub CSS so the cards match the [awg_tools] hub look, when available.
if ( function_exists( 'awg_aig_mem_tools_styles' ) ) {
	echo awg_aig_mem_tools_styles(); // phpcs:ignore WordPress.Security.EscapeOutput
}

// A short accent/description helper for the tool cards.
$awg_default_desc = '';
if ( class_exists( '\\AWG_AIG\\Plugin' ) ) {
	$awg_plugin = \AWG_AIG\Plugin::instance();
	if ( isset( $awg_plugin->renderer ) && is_object( $awg_plugin->renderer ) && method_exists( $awg_plugin->renderer, 'template_defaults' ) ) {
		$awg_defs         = $awg_plugin->renderer->template_defaults();
		$awg_default_desc = trim( (string) ( $awg_defs['form_description'] ?? '' ) );
	}
}

?>
<div class="awg-tools awg-tools--archive" style="max-width:1080px;margin:0 auto;padding:32px 16px;">
	<div class="awg-tools__cathead" style="margin-bottom:20px;">
		<h1 class="awg-tools__cattitle"><?php echo esc_html( $awg_term instanceof WP_Term ? $awg_term->name : __( 'Tools', 'authorwings-ai-tools' ) ); ?></h1>
		<?php if ( $awg_term instanceof WP_Term && trim( (string) $awg_term->description ) !== '' ) : ?>
			<p class="awg-tools__catdesc"><?php echo esc_html( wp_strip_all_tags( (string) $awg_term->description ) ); ?></p>
		<?php endif; ?>
	</div>

	<?php
	// Build the visible cards first: a tool is shown only when its shortcode
	// lives on a published page (Public_Pages::tool_url()). Tools with no page
	// yet are skipped entirely, so the grid never contains a dead link.
	$awg_cards = '';
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			$awg_tool_id = get_the_ID();
			$awg_title   = get_the_title();

			// Resolve the tool's own page (the page hosting its shortcode).
			// No page yet -> skip this tool.
			$awg_url = class_exists( '\\AWG_AIG\\Public_Pages' ) ? Public_Pages::tool_url( (int) $awg_tool_id ) : '';
			if ( $awg_url === '' ) {
				continue;
			}

			ob_start();

				// Per-tool description (skip the shared placeholder default). The
				// tool config is stored as an array under _awg_aig_template.
				$awg_cfg  = get_post_meta( $awg_tool_id, '_awg_aig_template', true );
				$awg_desc = is_array( $awg_cfg ) ? trim( (string) ( $awg_cfg['form_description'] ?? '' ) ) : '';
				if ( $awg_desc === '' || ( $awg_default_desc !== '' && $awg_desc === $awg_default_desc ) ) {
					$awg_desc = '';
				} else {
					$awg_desc = wp_trim_words( $awg_desc, 20, '…' );
				}

				$awg_thumb = get_the_post_thumbnail_url( $awg_tool_id, 'medium' );
				?>
				<a class="awg-tools-card" href="<?php echo esc_url( $awg_url ); ?>">
					<?php if ( $awg_thumb ) : ?>
						<span class="awg-tools-card__thumb"><img src="<?php echo esc_url( $awg_thumb ); ?>" alt="" loading="lazy" /></span>
					<?php else : ?>
						<span class="awg-tools-card__ic" style="background:rgba(126,147,116,.13);color:#7e9374"><span class="dashicons dashicons-admin-tools" aria-hidden="true"></span></span>
					<?php endif; ?>
					<span class="awg-tools-card__name"><?php echo esc_html( $awg_title ); ?></span>
					<?php if ( $awg_desc !== '' ) : ?><span class="awg-tools-card__desc"><?php echo esc_html( $awg_desc ); ?></span><?php endif; ?>
					<span class="awg-tools-card__open"><?php esc_html_e( 'Open', 'authorwings-ai-tools' ); ?> &rarr;</span>
				</a>
				<?php
				$awg_cards .= (string) ob_get_clean();
			endwhile;
	endif;

	if ( $awg_cards !== '' ) :
		?>
		<div class="awg-tools__grid"><?php echo $awg_cards; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
	<?php else : ?>
		<p class="awg-tools__empty"><?php esc_html_e( 'No tools in this category yet.', 'authorwings-ai-tools' ); ?></p>
	<?php endif; ?>
</div>
<?php
get_footer();
