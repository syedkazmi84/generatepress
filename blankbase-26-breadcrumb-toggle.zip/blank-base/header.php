<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything
 * up until <div id="content">.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Blank_Base
 */

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'blank-base' ); ?></a>

	<?php blank_base_do_element( 'top_bar' ); ?>

	<?php blank_base_announcement_bar(); ?>

	<?php blank_base_do_element( 'before_header' ); ?>

	<?php
	$blank_base_header_layout = get_theme_mod( 'blank_base_header_layout', 'default' );
	$blank_base_header_class  = 'site-header header--' . sanitize_html_class( $blank_base_header_layout );
	if ( get_theme_mod( 'blank_base_sticky_header', false ) ) {
		$blank_base_header_class .= ' is-sticky';
	}
	?>
	<header id="masthead" class="<?php echo esc_attr( $blank_base_header_class ); ?>">
		<div class="site-header-inner">
			<div class="site-branding">
				<?php
				the_custom_logo();

				if ( is_front_page() && is_home() ) :
					?>
					<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
					<?php
				else :
					?>
					<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
					<?php
				endif;

				$blank_base_description = get_bloginfo( 'description', 'display' );
				if ( $blank_base_description || is_customize_preview() ) :
					?>
					<p class="site-description"><?php echo $blank_base_description; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
					<?php
				endif;
				?>
			</div><!-- .site-branding -->

			<div class="site-header-actions">
				<?php blank_base_primary_navigation( 'inside-header' ); ?>

				<?php blank_base_header_search(); ?>

				<?php blank_base_do_element( 'inside_header' ); ?>
			</div><!-- .site-header-actions -->
		</div><!-- .site-header-inner -->
	</header><!-- #masthead -->

	<?php blank_base_do_element( 'after_header' ); ?>

	<div id="content" class="site-content">

		<?php blank_base_do_element( 'before_content' ); ?>
