<?php
/**
 * Plugin Name: AuthorWings AI
 * Plugin URI: https://authorwings.com
 * Description: AI generator templates and conversational AI agents for publishing services (shortcode + Gutenberg block) with a built-in membership engine (free/paid tools gated by plan, Stripe subscription checkout, per-month usage limits) and a bundled book-cost pricing calculator.
 * Version: 6.1.4
 * Author: AuthorWings
 * Author URI: https://www.linkedin.com/in/syed-haider-kazmi/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: authorwings-ai-tools
 * Domain Path: /languages
 */

defined('ABSPATH') || exit;

define('AWG_AIG_VERSION', '6.1.4');
define('AWG_AIG_FILE', __FILE__);
define('AWG_AIG_PATH', plugin_dir_path(__FILE__));
define('AWG_AIG_URL', plugin_dir_url(__FILE__));

require_once AWG_AIG_PATH . 'includes/class-plugin.php';

// Embedded membership engine (plans / pricing / Stripe / usage / tool gating).
// Stays dormant if the standalone AuthorWings Membership plugin is still active.
require_once AWG_AIG_PATH . 'membership/loader.php';

// Conversational, tool-using AI agents. Reuses the provider layer (OpenAI /
// Claude / DeepSeek), the membership gate and the usage/billing engine; an
// agent's "tools" are the site's own generator templates.
require_once AWG_AIG_PATH . 'includes/agent/loader.php';

// Embedded book-cost pricing calculator (shortcodes / block / widget /
// submissions / share links). Stays dormant if the standalone AuthorWings
// Pricing Calculator plugin is still active.
require_once AWG_AIG_PATH . 'calculator/loader.php';

register_activation_hook(AWG_AIG_FILE, ['\\AWG_AIG\\Plugin', 'activate']);

// Membership engine activation (idempotent: creates tables, registers roles,
// seeds default plans only if none exist, ensures a /pricing/ page).
register_activation_hook(AWG_AIG_FILE, 'awg_aig_mem_activate');

// Calculator activation (idempotent: creates its tables and schedules its
// maintenance cron). Dormant if the standalone plugin owns the AWPC_* classes.
// No deactivation hook by design: deactivating the plugin removes nothing.
register_activation_hook(AWG_AIG_FILE, 'awg_aig_calc_activate');

add_action('plugins_loaded', function () {
    \AWG_AIG\Plugin::instance();
    \AWG_AIG\Agent\Bootstrap::init();
});
