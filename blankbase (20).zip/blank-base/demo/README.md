# Blank Base — Demo Content

`blank-base-demo.xml` is a ready-to-use demo site for the Blank Base theme,
themed as an **AI-tools directory**. It contains:

- **4 pages** — Home (a full landing page built from the theme's block
  patterns), Blog, About, Contact.
- **6 posts** — professional AI-tool reviews and round-ups, each in a
  category with tags.
- **6 categories** — AI Writing, AI Chatbots, Image Generation, Code
  Assistants, Video & Audio, Productivity.
- **1 navigation menu** — "Primary Menu" (Home, Blog, About, Contact).

All copy is polished placeholder content — edit it, or use it as-is to launch
quickly.

## How to import

1. Activate the **Blank Base** theme (Appearance → Themes).
2. Go to **Tools → Import** and install/run **WordPress** (the WordPress
   Importer plugin).
3. Upload `demo/blank-base-demo.xml`.
4. Assign the author to an existing user (or create one) and — importantly —
   tick **“Download and import file attachments.”**
5. Click **Submit**.

## After importing (3 quick steps)

The WordPress importer brings in content but not site settings, so set these
manually once:

1. **Static front page** — Settings → Reading → “A static page”, set
   *Homepage* to **Home** and *Posts page* to **Blog**.
2. **Menu location** — Appearance → Menus → *Manage Locations* → set
   **Primary Menu** as the *Primary Menu* location.
3. **Widgets** (optional) — add any widgets you want to the Sidebar and
   Footer areas.

## Regenerating

The XML is produced by `tools/generate-demo.php`:

```
php tools/generate-demo.php
```

Edit that script to change the demo copy, then re-run it.

## Note on images

The demo uses the theme's bundled SVG placeholders and colour blocks rather
than bundled photos, so the import stays small and has no licensing strings
attached. Replace them with your own media after importing.
