<?php
/**
 * The sidebar containing the main widget area(s).
 *
 * Renders the right and/or left sidebar according to the layout resolved by the
 * layout engine (see inc/layout.php). Flexbox ordering positions each column;
 * see the sidebar rules in style.css.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Blank_Base
 */

$blank_base_layout = function_exists( 'blank_base_get_layout' ) ? blank_base_get_layout() : 'right-sidebar';

// No sidebar for no-sidebar / full-width layouts.
if ( in_array( $blank_base_layout, array( 'no-sidebar', 'full-width' ), true ) ) {
	return;
}

$blank_base_has_right = in_array( $blank_base_layout, array( 'right-sidebar', 'left-sidebar', 'both-sidebars' ), true );
$blank_base_has_left  = ( 'both-sidebars' === $blank_base_layout );

// The primary widget area (sidebar-1) powers single right or left layouts, and
// the right column of the both-sidebars layout.
if ( $blank_base_has_right && is_active_sidebar( 'sidebar-1' ) ) :
	blank_base_do_element( 'before_right_sidebar' );
	?>
	<aside id="secondary" class="widget-area widget-area--primary" aria-label="<?php esc_attr_e( 'Sidebar', 'blank-base' ); ?>">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</aside><!-- #secondary -->
	<?php
	blank_base_do_element( 'after_right_sidebar' );
endif;

// The secondary widget area (sidebar-2) is the left column of both-sidebars.
if ( $blank_base_has_left && is_active_sidebar( 'sidebar-2' ) ) :
	blank_base_do_element( 'before_left_sidebar' );
	?>
	<aside id="tertiary" class="widget-area widget-area--secondary" aria-label="<?php esc_attr_e( 'Secondary Sidebar', 'blank-base' ); ?>">
		<?php dynamic_sidebar( 'sidebar-2' ); ?>
	</aside><!-- #tertiary -->
	<?php
	blank_base_do_element( 'after_left_sidebar' );
endif;
