<?php
namespace AWG_AIG;

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Public front-end pages for tools (Model 2 — simple category system).
 *
 * Categories are real, indexable archive pages (/tool-category/<slug>/) that
 * open like native WordPress categories and list the tools inside. Each tool
 * links to the ordinary WordPress Page where the site owner placed that tool's
 * [awg_generator id="N"] shortcode — so the single-tool URL is simply that
 * page's URL.
 *
 * v6.1.3: the tool → page link is now detected AUTOMATICALLY. The old manual
 * "Tool page" picker was removed. The plugin scans published pages/posts for
 * each tool's [awg_generator id="N"] shortcode and keeps a cached map
 * (tool ID → page ID), refreshed whenever a page is saved, trashed or deleted.
 * A tool with no shortcode page yet is simply hidden from the category archive
 * so there are never dead links. The old membership hub deep-links
 * (?awg_cat=, ?tool=) are gone.
 *
 * What this class owns:
 *   - the automatic tool-page index (shortcode → page),
 *   - the category-archive query + template,
 *   - a one-time rewrite-rule flush after the taxonomy became public.
 *
 * What it deliberately does NOT touch: plan gating, usage limits and pricing.
 * Those stay enforced server-side at generation time (class-ai-gate.php /
 * class-ajax.php), so exposing these pages publicly changes nothing about who
 * can actually generate.
 */
final class Public_Pages {

	/** @var string CPT slug. */
	private $cpt;
	/** @var string Taxonomy slug. */
	private $tax;

	/** Option holding the cached map of tool ID => page ID (where its shortcode lives). */
	const MAP_OPT     = 'awg_aig_tool_page_map';
	/** Version marker so the map is (re)built once after an update. */
	const MAP_VER     = '1';
	const MAP_VER_OPT = 'awg_aig_tool_page_map_ver';

	/** Bumped whenever rewrite-affecting registration changes, to trigger a flush. */
	const REWRITE_VER     = '3';
	const REWRITE_VER_OPT = 'awg_aig_pp_rewrite_ver';

	public function __construct( string $cpt, string $tax ) {
		$this->cpt = $cpt;
		$this->tax = $tax;
	}

	/** Wire all hooks. Called from Plugin::__construct(). */
	public function register(): void {
		// One-time (version-guarded) rewrite flush so /tool-category/<slug>/
		// resolves after this update, without needing a manual Settings →
		// Permalinks save. Runs after the taxonomy is registered (init:10).
		add_action( 'init', [ $this, 'maybe_flush_rewrites' ], 20 );
		add_action( 'admin_init', [ $this, 'maybe_flush_rewrites' ] );

		// One-time (version-guarded) build of the tool → page map so existing
		// shortcode pages are linked immediately after this update.
		add_action( 'init', [ $this, 'maybe_build_map' ], 21 );
		add_action( 'admin_init', [ $this, 'maybe_build_map' ] );

		// Keep the tool → page map fresh: any time a page/post is saved,
		// trashed, untrashed or deleted, its shortcodes may have changed.
		add_action( 'save_post', [ $this, 'on_content_change' ], 10, 1 );
		add_action( 'deleted_post', [ $this, 'on_content_change' ], 10, 1 );
		add_action( 'trashed_post', [ $this, 'on_content_change' ], 10, 1 );
		add_action( 'untrashed_post', [ $this, 'on_content_change' ], 10, 1 );

		// Front-end category archive: make the main query list the tools and
		// render them through the bundled template.
		add_action( 'pre_get_posts', [ $this, 'archive_query' ] );
		add_filter( 'template_include', [ $this, 'archive_template' ] );
	}

	// -----------------------------------------------------------------
	// Rewrite flush
	// -----------------------------------------------------------------

	/**
	 * Flush rewrite rules once after the taxonomy gained public archive URLs.
	 * Plugin updates delivered as a zip don't fire the activation hook, so we
	 * self-heal here: compare a stored version marker and flush on mismatch.
	 */
	public function maybe_flush_rewrites(): void {
		if ( get_option( self::REWRITE_VER_OPT ) === self::REWRITE_VER ) {
			return;
		}
		flush_rewrite_rules( false );
		update_option( self::REWRITE_VER_OPT, self::REWRITE_VER );
	}

	// -----------------------------------------------------------------
	// Automatic tool → page index (shortcode detection)
	// -----------------------------------------------------------------

	/**
	 * Rebuild the map of tool ID => page ID by scanning every published page/post
	 * for [awg_generator id="N"] shortcodes. When the same tool's shortcode
	 * appears on more than one page, the most recently published page wins.
	 */
	public function rebuild_map(): void {
		global $wpdb;

		$like = '%' . $wpdb->esc_like( '[awg_generator' ) . '%';
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT ID, post_content FROM {$wpdb->posts}
			 WHERE post_status = 'publish'
			   AND post_type IN ('page','post')
			   AND post_content LIKE %s
			 ORDER BY post_date DESC, ID DESC",
			$like
		) );

		$map = [];
		foreach ( (array) $rows as $row ) {
			foreach ( self::tool_ids_in_content( (string) $row->post_content ) as $tid ) {
				// Ordered newest-first, so keep the first (newest) page we see.
				if ( ! isset( $map[ $tid ] ) ) {
					$map[ $tid ] = (int) $row->ID;
				}
			}
		}

		update_option( self::MAP_OPT, $map, false );
	}

	/**
	 * Extract the tool IDs referenced by [awg_generator id="N"] shortcodes in a
	 * blob of post content. Tolerates single/double/no quotes and extra
	 * attributes, e.g. [awg_generator id='12'] or [awg_generator id="12" foo="bar"].
	 *
	 * @return int[] Unique, positive tool IDs.
	 */
	private static function tool_ids_in_content( string $content ): array {
		if ( strpos( $content, 'awg_generator' ) === false ) {
			return [];
		}
		if ( ! preg_match_all( '/\[awg_generator\b[^\]]*?\bid=["\']?(\d+)/i', $content, $m ) ) {
			return [];
		}
		$ids = array_map( 'intval', $m[1] );
		return array_values( array_unique( array_filter( $ids, static function ( $v ) {
			return $v > 0;
		} ) ) );
	}

	/**
	 * Refresh the map when relevant content changes. Skips revisions/autosaves
	 * (which don't change the live page content) to avoid needless rebuilds.
	 */
	public function on_content_change( $post_id ): void {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( function_exists( 'wp_is_post_revision' ) && wp_is_post_revision( $post_id ) ) {
			return;
		}
		$type = get_post_type( $post_id );
		if ( $type && ! in_array( $type, [ 'page', 'post' ], true ) ) {
			return; // Only pages/posts can host the shortcode.
		}
		$this->rebuild_map();
	}

	/**
	 * Build the map once after this version ships (or when the marker is missing),
	 * so existing shortcode pages are linked without waiting for a page save.
	 */
	public function maybe_build_map(): void {
		if ( get_option( self::MAP_VER_OPT ) === self::MAP_VER ) {
			return;
		}
		$this->rebuild_map();
		update_option( self::MAP_VER_OPT, self::MAP_VER );
	}

	/**
	 * Resolve the front-end URL for a tool: the permalink of the published page
	 * that hosts its [awg_generator] shortcode, or '' when no such page exists
	 * yet (in which case the tool is hidden from the category archive).
	 *
	 * Uses the cached map first; falls back to a live lookup so a freshly built
	 * page links even before the map has been rebuilt.
	 */
	public static function tool_url( int $tool_id ): string {
		if ( $tool_id <= 0 ) {
			return '';
		}

		$map = get_option( self::MAP_OPT );
		if ( is_array( $map ) && isset( $map[ $tool_id ] ) ) {
			$pid = (int) $map[ $tool_id ];
			if ( $pid > 0 && get_post_status( $pid ) === 'publish' ) {
				$url = get_permalink( $pid );
				if ( $url ) {
					return (string) $url;
				}
			}
		}

		// Live fallback (uncached map / brand-new page).
		$pid = self::find_page_for_tool( $tool_id );
		if ( $pid > 0 ) {
			$url = get_permalink( $pid );
			if ( $url ) {
				return (string) $url;
			}
		}
		return '';
	}

	/**
	 * Live lookup of the newest published page/post hosting a tool's shortcode.
	 * Only used as a fallback; the cached map covers the normal path.
	 */
	private static function find_page_for_tool( int $tool_id ): int {
		global $wpdb;
		$like = '%' . $wpdb->esc_like( '[awg_generator' ) . '%';
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT ID, post_content FROM {$wpdb->posts}
			 WHERE post_status = 'publish'
			   AND post_type IN ('page','post')
			   AND post_content LIKE %s
			 ORDER BY post_date DESC, ID DESC",
			$like
		) );
		foreach ( (array) $rows as $row ) {
			if ( in_array( $tool_id, self::tool_ids_in_content( (string) $row->post_content ), true ) ) {
				return (int) $row->ID;
			}
		}
		return 0;
	}

	// -----------------------------------------------------------------
	// Category archive (front end)
	// -----------------------------------------------------------------

	/**
	 * On a /tool-category/<slug>/ request, point the main query at the tool CPT
	 * so the archive resolves (200, not 404) and the loop has the tools. The CPT
	 * is non-public, so we must set the post type explicitly here.
	 */
	public function archive_query( \WP_Query $query ): void {
		if ( is_admin() || ! $query->is_main_query() ) {
			return;
		}
		if ( ! $query->is_tax( $this->tax ) ) {
			return;
		}
		$query->set( 'post_type', $this->cpt );
		$query->set( 'post_status', 'publish' );
		$query->set( 'posts_per_page', 60 );
		$query->set( 'orderby', 'menu_order title' );
		$query->set( 'order', 'ASC' );
	}

	/** Render the category archive through the bundled plugin template. */
	public function archive_template( $template ) {
		if ( is_tax( $this->tax ) ) {
			$custom = AWG_AIG_PATH . 'templates/taxonomy-tools.php';
			if ( file_exists( $custom ) ) {
				return $custom;
			}
		}
		return $template;
	}
}
