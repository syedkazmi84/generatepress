<?php
namespace AWG_AIG;

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * "Tool Categories" taxonomy for the AI template CPT.
 *
 * Replaces the legacy free-text `_awg_mem_category` meta with a proper,
 * admin-managed taxonomy:
 *   - a Categories screen under the AuthorWings AI menu,
 *   - a category box inside each tool's editor,
 *   - a Categories column on the Templates list.
 *
 * Each term can carry an optional Dashicons icon + accent colour, used to style
 * its card on the front-end [awg_tools] hub. A one-time migration seeds terms
 * from the old meta so the hub's category landing isn't empty on first load.
 */
final class Taxonomy {
	/** @var string CPT slug the taxonomy attaches to. */
	private $cpt;
	/** @var string Taxonomy slug. */
	private $tax;

	const ICON_META    = 'awg_cat_icon';
	const ACCENT_META  = 'awg_cat_accent';
	const IMAGE_META   = 'awg_cat_image';
	// Tier 1 — per-category page content. Rich HTML shown above/below the tool
	// grid on the category archive.
	const INTRO_META   = 'awg_cat_intro_html';
	const BODY_META    = 'awg_cat_body_html';
	const MIGRATED_OPT = 'awg_tool_cat_migrated';
	const UNCAT_SEEDED_OPT = 'awg_uncat_seeded';

	public function __construct( string $cpt, string $tax ) {
		$this->cpt = $cpt;
		$this->tax = $tax;
	}

	/** Register the taxonomy on `init`. */
	public function register(): void {
		register_taxonomy( $this->tax, [ $this->cpt ], [
			'labels' => [
				'name'              => __( 'Tool Categories', 'authorwings-ai-tools' ),
				'singular_name'     => __( 'Tool Category', 'authorwings-ai-tools' ),
				'menu_name'         => __( 'Categories', 'authorwings-ai-tools' ),
				'all_items'         => __( 'All Categories', 'authorwings-ai-tools' ),
				'edit_item'         => __( 'Edit Category', 'authorwings-ai-tools' ),
				'view_item'         => __( 'View Category', 'authorwings-ai-tools' ),
				'update_item'       => __( 'Update Category', 'authorwings-ai-tools' ),
				'add_new_item'      => __( 'Add New Category', 'authorwings-ai-tools' ),
				'new_item_name'     => __( 'New Category Name', 'authorwings-ai-tools' ),
				'parent_item'       => __( 'Parent Category', 'authorwings-ai-tools' ),
				'parent_item_colon' => __( 'Parent Category:', 'authorwings-ai-tools' ),
				'search_items'      => __( 'Search Categories', 'authorwings-ai-tools' ),
				'not_found'         => __( 'No categories found.', 'authorwings-ai-tools' ),
			],
			'hierarchical'       => true,
			// v6.1.0: categories are now real, indexable front-end archive pages
			// (Model 2). Each term gets a /tool-category/<slug>/ URL that opens a
			// standalone page listing its tools, exactly like a native WordPress
			// category. The membership hub ([awg_tools], ?awg_cat=) still works
			// unchanged for logged-in members; these public archives are the SEO
			// front door that link out to each tool's own shortcode page.
			'public'             => true,
			// A real default term (WP 5.5+). This makes "Uncategorized" a proper,
			// assignable term: it shows in the editor's Tool Categories box and on
			// the Categories screen, and WP auto-assigns it to any tool saved with
			// no category — so the hub never has orphaned, unfindable tools.
			'default_term'       => [
				'name' => __( 'Uncategorized', 'authorwings-ai-tools' ),
				'slug' => 'uncategorized',
			],
			'publicly_queryable' => true,
			'show_ui'            => true,
			// We add a positioned submenu in admin_menu() so the menu order
			// stays intentional (matches how this plugin places its menus).
			'show_in_menu'       => false,
			'show_in_rest'       => true,  // Block editor + REST support.
			'show_admin_column'  => true,  // Categories column on the Templates list.
			'show_in_nav_menus'  => true,  // Selectable in Appearance → Menus.
			// Pretty, front-facing archive URLs: /tool-category/<slug>/. The
			// Public_Pages class renders these through a bundled plugin template
			// and links each listed tool to the page that hosts its shortcode.
			'rewrite'            => [
				'slug'         => 'tool-category',
				'with_front'   => false,
				'hierarchical' => true,
			],
			'capabilities'       => [
				'manage_terms' => 'manage_options',
				'edit_terms'   => 'manage_options',
				'delete_terms' => 'manage_options',
				'assign_terms' => 'manage_options',
			],
		] );
	}

	/** Place the Categories screen under the AuthorWings AI menu, right after Templates. */
	public function admin_menu(): void {
		add_submenu_page(
			'edit.php?post_type=' . $this->cpt,
			__( 'Tool Categories', 'authorwings-ai-tools' ),
			__( 'Categories', 'authorwings-ai-tools' ),
			'manage_options',
			'edit-tags.php?taxonomy=' . $this->tax . '&post_type=' . $this->cpt,
			'',
			20
		);
	}

	/** Keep the AuthorWings AI menu open + "Categories" highlighted on the taxonomy screens. */
	public function fix_menu_highlight( $parent_file ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && isset( $screen->taxonomy ) && $screen->taxonomy === $this->tax ) {
			global $submenu_file;
			$submenu_file = 'edit-tags.php?taxonomy=' . $this->tax . '&post_type=' . $this->cpt;
			return 'edit.php?post_type=' . $this->cpt;
		}
		return $parent_file;
	}

	// ---- Term meta: icon + accent colour ----

	/** Fields on the "Add Category" screen. */
	public function add_fields(): void {
		wp_nonce_field( 'awg_cat_meta', 'awg_cat_meta_nonce' );
		?>
		<div class="form-field awg-cat-image-field">
			<label><?php esc_html_e( 'Card image (optional)', 'authorwings-ai-tools' ); ?></label>
			<div class="awg-cat-image-preview"></div>
			<input type="hidden" class="awg-cat-image-id" name="awg_cat_image" value="" />
			<button type="button" class="button awg-cat-image-pick"><?php esc_html_e( 'Select image', 'authorwings-ai-tools' ); ?></button>
			<button type="button" class="button-link awg-cat-image-remove" style="display:none;color:#b32d2e;margin-left:8px;"><?php esc_html_e( 'Remove', 'authorwings-ai-tools' ); ?></button>
			<p><?php esc_html_e( 'Shown on the AI Tools hub. When set, the image replaces the icon below. Leave empty to use the icon.', 'authorwings-ai-tools' ); ?></p>
		</div>
		<div class="form-field">
			<label for="awg_cat_icon"><?php esc_html_e( 'Card icon (Dashicons class)', 'authorwings-ai-tools' ); ?></label>
			<input type="text" name="awg_cat_icon" id="awg_cat_icon" value="" placeholder="dashicons-category" />
			<p><?php
				printf(
					/* translators: %s: example dashicons class */
					esc_html__( 'Optional. A Dashicons class for this category card, e.g. %s.', 'authorwings-ai-tools' ),
					'<code>dashicons-edit</code>'
				);
			?> <a href="https://developer.wordpress.org/resource/dashicons/" target="_blank" rel="noopener"><?php esc_html_e( 'Browse icons', 'authorwings-ai-tools' ); ?></a></p>
		</div>
		<div class="form-field">
			<label for="awg_cat_accent"><?php esc_html_e( 'Accent colour', 'authorwings-ai-tools' ); ?></label>
			<input type="text" name="awg_cat_accent" id="awg_cat_accent" value="" placeholder="#7e9374" />
			<p><?php esc_html_e( 'Optional. Hex colour for the icon chip, e.g. #7e9374.', 'authorwings-ai-tools' ); ?></p>
		</div>
		<div class="form-field">
			<label for="awgcatintro"><?php esc_html_e( 'Intro content (above the tools)', 'authorwings-ai-tools' ); ?></label>
			<textarea name="awgcatintro" id="awgcatintro" rows="4" class="large-text"></textarea>
			<p><?php esc_html_e( 'Optional. Shown at the top of this category page, above the tool grid. Basic HTML allowed; a full visual editor is available after you create the category.', 'authorwings-ai-tools' ); ?></p>
		</div>
		<div class="form-field">
			<label for="awgcatbody"><?php esc_html_e( 'Extra content (below the tools)', 'authorwings-ai-tools' ); ?></label>
			<textarea name="awgcatbody" id="awgcatbody" rows="4" class="large-text"></textarea>
			<p><?php esc_html_e( 'Optional. Shown at the bottom of this category page, below the tool grid — handy for an FAQ or SEO copy.', 'authorwings-ai-tools' ); ?></p>
		</div>
		<?php
	}

	/** Fields on the "Edit Category" screen (table-row layout). */
	public function edit_fields( $term ): void {
		$icon   = $term instanceof \WP_Term ? (string) get_term_meta( $term->term_id, self::ICON_META, true ) : '';
		$accent = $term instanceof \WP_Term ? (string) get_term_meta( $term->term_id, self::ACCENT_META, true ) : '';
		$img_id = $term instanceof \WP_Term ? (int) get_term_meta( $term->term_id, self::IMAGE_META, true ) : 0;
		$img_url = $img_id ? wp_get_attachment_image_url( $img_id, 'thumbnail' ) : '';
		$intro  = $term instanceof \WP_Term ? (string) get_term_meta( $term->term_id, self::INTRO_META, true ) : '';
		$body   = $term instanceof \WP_Term ? (string) get_term_meta( $term->term_id, self::BODY_META, true ) : '';
		wp_nonce_field( 'awg_cat_meta', 'awg_cat_meta_nonce' );
		?>
		<tr class="form-field awg-cat-image-field">
			<th scope="row"><label><?php esc_html_e( 'Card image', 'authorwings-ai-tools' ); ?></label></th>
			<td>
				<div class="awg-cat-image-preview"><?php if ( $img_url ) : ?><img src="<?php echo esc_url( $img_url ); ?>" alt="" style="width:60px;height:60px;object-fit:cover;border-radius:8px;display:block;margin-bottom:8px;" /><?php endif; ?></div>
				<input type="hidden" class="awg-cat-image-id" name="awg_cat_image" value="<?php echo esc_attr( $img_id ?: '' ); ?>" />
				<button type="button" class="button awg-cat-image-pick"><?php echo $img_url ? esc_html__( 'Change image', 'authorwings-ai-tools' ) : esc_html__( 'Select image', 'authorwings-ai-tools' ); ?></button>
				<button type="button" class="button-link awg-cat-image-remove" style="<?php echo $img_url ? '' : 'display:none;'; ?>color:#b32d2e;margin-left:8px;"><?php esc_html_e( 'Remove', 'authorwings-ai-tools' ); ?></button>
				<p class="description"><?php esc_html_e( 'Shown on the AI Tools hub. When set, the image replaces the icon.', 'authorwings-ai-tools' ); ?></p>
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row"><label for="awg_cat_icon"><?php esc_html_e( 'Card icon (Dashicons class)', 'authorwings-ai-tools' ); ?></label></th>
			<td>
				<input type="text" name="awg_cat_icon" id="awg_cat_icon" value="<?php echo esc_attr( $icon ); ?>" placeholder="dashicons-category" />
				<p class="description"><?php
					printf(
						/* translators: %s: example dashicons class */
						esc_html__( 'A Dashicons class, e.g. %s.', 'authorwings-ai-tools' ),
						'<code>dashicons-edit</code>'
					);
				?> <a href="https://developer.wordpress.org/resource/dashicons/" target="_blank" rel="noopener"><?php esc_html_e( 'Browse icons', 'authorwings-ai-tools' ); ?></a></p>
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row"><label for="awg_cat_accent"><?php esc_html_e( 'Accent colour', 'authorwings-ai-tools' ); ?></label></th>
			<td>
				<input type="text" name="awg_cat_accent" id="awg_cat_accent" value="<?php echo esc_attr( $accent ); ?>" placeholder="#7e9374" />
				<p class="description"><?php esc_html_e( 'Hex colour for the icon chip, e.g. #7e9374.', 'authorwings-ai-tools' ); ?></p>
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row"><label for="awgcatintro"><?php esc_html_e( 'Intro content (above the tools)', 'authorwings-ai-tools' ); ?></label></th>
			<td>
				<?php
				wp_editor(
					$intro,
					'awgcatintro',
					[
						'textarea_name' => 'awgcatintro',
						'textarea_rows' => 6,
						'media_buttons' => true,
						'teeny'         => false,
					]
				);
				?>
				<p class="description"><?php esc_html_e( 'Shown at the top of this category page, above the tool grid.', 'authorwings-ai-tools' ); ?></p>
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row"><label for="awgcatbody"><?php esc_html_e( 'Extra content (below the tools)', 'authorwings-ai-tools' ); ?></label></th>
			<td>
				<?php
				wp_editor(
					$body,
					'awgcatbody',
					[
						'textarea_name' => 'awgcatbody',
						'textarea_rows' => 6,
						'media_buttons' => true,
						'teeny'         => false,
					]
				);
				?>
				<p class="description"><?php esc_html_e( 'Shown at the bottom of this category page, below the tool grid — handy for an FAQ or SEO copy.', 'authorwings-ai-tools' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/** Persist the term-meta fields on create + edit. */
	public function save_fields( $term_id ): void {
		if ( ! isset( $_POST['awg_cat_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['awg_cat_meta_nonce'] ) ), 'awg_cat_meta' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Icon: keep only valid HTML-class tokens.
		$icon_raw = isset( $_POST['awg_cat_icon'] ) ? wp_unslash( $_POST['awg_cat_icon'] ) : '';
		$parts    = array_filter( array_map( 'sanitize_html_class', preg_split( '/\s+/', (string) $icon_raw ) ?: [] ) );
		$icon     = implode( ' ', $parts );
		update_term_meta( $term_id, self::ICON_META, $icon );

		// Accent: a 6-digit hex (with or without leading #); stored without #.
		$accent_raw = isset( $_POST['awg_cat_accent'] ) ? sanitize_text_field( wp_unslash( $_POST['awg_cat_accent'] ) ) : '';
		$accent_raw = ltrim( $accent_raw, '#' );
		$accent     = preg_match( '/^[0-9a-fA-F]{6}$/', $accent_raw ) ? strtolower( $accent_raw ) : '';
		update_term_meta( $term_id, self::ACCENT_META, $accent );

		// Card image: store the attachment ID, or clear it when none is chosen.
		$img = isset( $_POST['awg_cat_image'] ) ? absint( wp_unslash( $_POST['awg_cat_image'] ) ) : 0;
		if ( $img > 0 ) {
			update_term_meta( $term_id, self::IMAGE_META, $img );
		} else {
			delete_term_meta( $term_id, self::IMAGE_META );
		}

		// Intro / body content: rich HTML, sanitised like post content. Stored
		// only when non-empty, cleared otherwise.
		$intro = isset( $_POST['awgcatintro'] ) ? wp_kses_post( wp_unslash( $_POST['awgcatintro'] ) ) : '';
		if ( trim( $intro ) !== '' ) {
			update_term_meta( $term_id, self::INTRO_META, $intro );
		} else {
			delete_term_meta( $term_id, self::INTRO_META );
		}

		$body = isset( $_POST['awgcatbody'] ) ? wp_kses_post( wp_unslash( $_POST['awgcatbody'] ) ) : '';
		if ( trim( $body ) !== '' ) {
			update_term_meta( $term_id, self::BODY_META, $body );
		} else {
			delete_term_meta( $term_id, self::BODY_META );
		}
	}

	/** Add an icon-preview column to the category list. */
	public function columns( array $columns ): array {
		$new = [];
		foreach ( $columns as $k => $v ) {
			if ( $k === 'name' ) {
				$new['awg_cat_icon'] = __( 'Icon', 'authorwings-ai-tools' );
			}
			$new[ $k ] = $v;
		}
		return $new;
	}

	/** Render the icon-preview column. */
	public function column_content( string $content, string $column, int $term_id ): string {
		if ( $column !== 'awg_cat_icon' ) {
			return $content;
		}
		// Prefer the card image when one is set.
		$img_id = (int) get_term_meta( $term_id, self::IMAGE_META, true );
		if ( $img_id > 0 ) {
			$img_url = wp_get_attachment_image_url( $img_id, 'thumbnail' );
			if ( $img_url ) {
				return '<span style="display:inline-flex;width:30px;height:30px;border-radius:7px;overflow:hidden"><img src="' . esc_url( $img_url ) . '" alt="" style="width:30px;height:30px;object-fit:cover" /></span>';
			}
		}
		$icon   = (string) get_term_meta( $term_id, self::ICON_META, true );
		$accent = ltrim( (string) get_term_meta( $term_id, self::ACCENT_META, true ), '#' );
		if ( ! preg_match( '/^[0-9a-fA-F]{6}$/', $accent ) ) {
			$accent = '7e9374';
		}
		$parts = array_filter( array_map( 'sanitize_html_class', preg_split( '/\s+/', $icon ) ?: [] ) );
		$icon  = implode( ' ', $parts );
		if ( $icon === '' ) {
			$icon = 'dashicons dashicons-category';
		} elseif ( strpos( $icon, 'dashicons-' ) !== false && ! preg_match( '/(^|\s)dashicons(\s|$)/', $icon ) ) {
			$icon = 'dashicons ' . $icon;
		}
		return '<span style="display:inline-flex;width:30px;height:30px;border-radius:7px;align-items:center;justify-content:center;background:#' . esc_attr( $accent ) . '22;color:#' . esc_attr( $accent ) . '"><span class="' . esc_attr( $icon ) . '" aria-hidden="true"></span></span>';
	}

	/**
	 * One-time migration of the legacy `_awg_mem_category` text meta into real
	 * terms. Assigns every existing template to its meta value (or a default
	 * "AI Tools" category) so the hub's category landing isn't empty on first
	 * load. Guarded by an option, so it's safe to call on every admin request —
	 * it no-ops after the first successful run.
	 */
	public function maybe_migrate(): void {
		if ( get_option( self::MIGRATED_OPT ) ) {
			return;
		}
		if ( ! taxonomy_exists( $this->tax ) ) {
			return; // register() hasn't run yet this request.
		}

		$posts = get_posts( [
			'post_type'        => $this->cpt,
			'post_status'      => [ 'publish', 'draft', 'pending', 'private', 'future' ],
			'numberposts'      => -1,
			'fields'           => 'ids',
			'suppress_filters' => true,
		] );

		foreach ( $posts as $pid ) {
			// Skip anything already categorised (e.g. admin acted first).
			$existing = wp_get_object_terms( $pid, $this->tax, [ 'fields' => 'ids' ] );
			if ( ! is_wp_error( $existing ) && ! empty( $existing ) ) {
				continue;
			}

			$name = trim( (string) get_post_meta( $pid, '_awg_mem_category', true ) );
			if ( $name === '' ) {
				$name = 'AI Tools';
			}

			$existing_term = term_exists( $name, $this->tax );
			if ( $existing_term && ! is_wp_error( $existing_term ) ) {
				$term_id = is_array( $existing_term ) ? (int) $existing_term['term_id'] : (int) $existing_term;
			} else {
				$created = wp_insert_term( $name, $this->tax );
				if ( is_wp_error( $created ) || empty( $created['term_id'] ) ) {
					continue;
				}
				$term_id = (int) $created['term_id'];
			}

			if ( $term_id > 0 ) {
				wp_set_object_terms( $pid, $term_id, $this->tax, false );
			}
		}

		update_option( self::MIGRATED_OPT, time() );
	}

	/**
	 * Load the WordPress media frame + a tiny picker script on the category
	 * Add/Edit screens so the "Card image" field can choose from the media
	 * library. Runs only on this taxonomy's screens.
	 */
	public function enqueue_media(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ! isset( $screen->taxonomy ) || $screen->taxonomy !== $this->tax ) {
			return;
		}
		wp_enqueue_media();
		$js = <<<'JS'
(function($){
  function frameFor($field){
    var frame = wp.media({ title: 'Select card image', button: { text: 'Use image' }, library: { type: 'image' }, multiple: false });
    frame.on('select', function(){
      var a = frame.state().get('selection').first().toJSON();
      var url = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
      $field.find('.awg-cat-image-id').val(a.id);
      $field.find('.awg-cat-image-preview').html('<img src="'+url+'" alt="" style="width:60px;height:60px;object-fit:cover;border-radius:8px;display:block;margin-bottom:8px;" />');
      $field.find('.awg-cat-image-remove').show();
    });
    frame.open();
  }
  $(document).on('click', '.awg-cat-image-pick', function(e){
    e.preventDefault();
    if (typeof wp === 'undefined' || !wp.media) { return; }
    frameFor($(this).closest('.awg-cat-image-field'));
  });
  $(document).on('click', '.awg-cat-image-remove', function(e){
    e.preventDefault();
    var $f = $(this).closest('.awg-cat-image-field');
    $f.find('.awg-cat-image-id').val('');
    $f.find('.awg-cat-image-preview').empty();
    $(this).hide();
  });
  // After the Add-screen AJAX clears the form, also clear our preview/state.
  $(document).on('ajaxComplete', function(e, xhr, opts){
    if (opts && typeof opts.data === 'string' && opts.data.indexOf('action=add-tag') !== -1 && xhr.responseText && xhr.responseText.indexOf('wp_error') === -1) {
      var $f = $('.awg-cat-image-field');
      $f.find('.awg-cat-image-id').val('');
      $f.find('.awg-cat-image-preview').empty();
      $f.find('.awg-cat-image-remove').hide();
    }
  });
})(jQuery);
JS;
		wp_add_inline_script( 'jquery-core', $js );
	}

	/**
	 * One-time backfill: assign the default "Uncategorized" term to every tool
	 * that currently has no category. WP's default_term only auto-assigns on
	 * save, so existing tools created before this release would otherwise stay
	 * term-less (showing only in the hub's virtual bucket and never under the
	 * real, manageable Uncategorized term). Guarded by an option, safe to run on
	 * every admin request.
	 */
	public function maybe_seed_uncategorized(): void {
		if ( get_option( self::UNCAT_SEEDED_OPT ) ) {
			return;
		}
		if ( ! taxonomy_exists( $this->tax ) ) {
			return;
		}
		$default_id = (int) get_option( 'default_term_' . $this->tax );
		if ( $default_id <= 0 ) {
			$t = get_term_by( 'slug', 'uncategorized', $this->tax );
			if ( $t instanceof \WP_Term ) {
				$default_id = (int) $t->term_id;
			}
		}
		if ( $default_id <= 0 ) {
			return; // Default term not created yet this request; retry next load.
		}

		$untermed = get_posts( [
			'post_type'        => $this->cpt,
			'post_status'      => [ 'publish', 'draft', 'pending', 'private', 'future' ],
			'numberposts'      => -1,
			'fields'           => 'ids',
			'suppress_filters' => true,
			'tax_query'        => [ [ 'taxonomy' => $this->tax, 'operator' => 'NOT EXISTS' ] ],
		] );

		foreach ( $untermed as $pid ) {
			wp_set_object_terms( (int) $pid, $default_id, $this->tax, false );
		}

		update_option( self::UNCAT_SEEDED_OPT, time() );
	}
}
