<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Plugin {
    private static $instance = null;

    /** @var CPT */
    public $cpt;
    /** @var Settings */
    public $settings;
    /** @var Metabox */
    public $metabox;
    /** @var Renderer */
    public $renderer;
    /** @var Assets */
    public $assets;
    /** @var Ajax */
    public $ajax;
    /** @var Block */
    public $block;
    /** @var Submissions */
    public $submissions;
    /** @var Ratings */
    public $ratings;
    /** @var Port */
    public $port;
    /** @var Taxonomy */
    public $taxonomy;
    /** @var Public_Pages */
    public $public_pages;
    /** @var Cookie_Consent */
    public $cookie_consent;

    public const CPT = 'awg_ai_template';
    public const SUB_CPT = 'awg_ai_submission';
    public const TAX = 'awg_tool_category';
    public const OPT = 'awg_aig_settings';

    public static function instance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public static function activate(): void {
        require_once AWG_AIG_PATH . 'includes/class-settings.php';
        require_once AWG_AIG_PATH . 'includes/class-cpt.php';
        require_once AWG_AIG_PATH . 'includes/class-taxonomy.php';
        require_once AWG_AIG_PATH . 'includes/class-renderer.php';
        require_once AWG_AIG_PATH . 'includes/class-ratings.php';
        $settings = new Settings(self::OPT);
        if (get_option(self::OPT, null) === null) {
            add_option(self::OPT, $settings->defaults());
        }
        // Ratings: create the custom table (idempotent — safe to re-run).
        Ratings::install();
        if (!wp_next_scheduled('awg_aig_cleanup_cron')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'awg_aig_cleanup_cron');
        }
        // Register the CPT + taxonomy, then flush rewrite rules so the
        // /tool-category/<slug>/ archive URLs resolve immediately after
        // activation — otherwise they 404 until Settings → Permalinks is
        // saved by hand. (On the activation request the plugin's own init
        // hooks haven't run, so the taxonomy must be registered here first.)
        (new CPT(self::CPT))->register();
        (new Taxonomy(self::CPT, self::TAX))->register();
        flush_rewrite_rules();
    }

    public static function deactivate(): void {
        $ts = wp_next_scheduled('awg_aig_cleanup_cron');
        if ($ts) {
            wp_unschedule_event($ts, 'awg_aig_cleanup_cron');
        }
    }

    private function __construct() {
        $this->includes();

        // i18n
        add_action('init', [$this, 'load_textdomain']);

        // Core modules
        $this->settings = new Settings(self::OPT);
        $this->cpt      = new CPT(self::CPT);
        $this->taxonomy = new Taxonomy(self::CPT, self::TAX);
        $this->public_pages = new Public_Pages(self::CPT, self::TAX);
        $this->public_pages->register();
        $this->renderer = new Renderer(self::CPT, $this->settings);
        $this->metabox  = new Metabox(self::CPT, $this->renderer);
        $this->assets   = new Assets();
        $this->ajax     = new Ajax(self::CPT, $this->settings, $this->renderer);
        $this->block    = new Block($this->renderer);
        $this->submissions = new Submissions(self::SUB_CPT, self::CPT);
        $this->ratings     = new Ratings();
        $this->ratings->register();
        $this->port        = new Port();
        $this->port->register();
        // Cookie Consent / GDPR notice bar (front-end, opt-in via settings).
        $this->cookie_consent = new Cookie_Consent($this->settings);
        $this->cookie_consent->register();

        // Hooks
        add_action('init', [$this->taxonomy, 'register']);
        add_action('init', [$this->cpt, 'register']);
        add_action('init', [$this->submissions, 'register']);

        // Tool Categories taxonomy: positioned admin submenu, menu-highlight
        // fix on the term screens, icon/accent term-meta fields + list column,
        // and a one-time migration from the legacy _awg_mem_category meta.
        add_action('admin_menu', [$this->taxonomy, 'admin_menu'], 11);
        add_filter('parent_file', [$this->taxonomy, 'fix_menu_highlight']);
        add_action(self::TAX . '_add_form_fields', [$this->taxonomy, 'add_fields']);
        add_action(self::TAX . '_edit_form_fields', [$this->taxonomy, 'edit_fields']);
        add_action('created_' . self::TAX, [$this->taxonomy, 'save_fields']);
        add_action('edited_' . self::TAX, [$this->taxonomy, 'save_fields']);
        add_filter('manage_edit-' . self::TAX . '_columns', [$this->taxonomy, 'columns']);
        add_filter('manage_' . self::TAX . '_custom_column', [$this->taxonomy, 'column_content'], 10, 3);
        add_action('admin_init', [$this->taxonomy, 'maybe_migrate']);
        add_action('admin_init', [$this->taxonomy, 'maybe_seed_uncategorized']);
        add_action('admin_enqueue_scripts', [$this->taxonomy, 'enqueue_media']);
        add_action('admin_menu', [$this->settings, 'menu']);
        add_action('admin_init', [$this->settings, 'register']);
        add_action('admin_init', [$this->settings, 'maybe_migrate_palette']);

        add_action('add_meta_boxes', [$this->metabox, 'register']);
        add_action('add_meta_boxes', [$this->submissions, 'register_metabox']);
        add_action('save_post', [$this->metabox, 'save'], 10, 2);
        add_filter('manage_' . self::CPT . '_posts_columns', [$this->cpt, 'columns']);
        add_action('manage_' . self::CPT . '_posts_custom_column', [$this->cpt, 'column_data'], 10, 2);
        add_filter('manage_edit-' . self::CPT . '_sortable_columns', [$this->cpt, 'sortable_columns']);
        add_action('pre_get_posts', [$this->cpt, 'sort_columns']);
        add_filter('post_row_actions', [$this->cpt, 'row_actions'], 10, 2);
        add_action('admin_post_awg_aig_duplicate', [$this->cpt, 'handle_duplicate']);

        // Admin template preview: a hidden screen that renders a single
        // template's live front-end form, so a tool can be viewed/tested from
        // the dashboard without placing the [awg_generator] shortcode on a page.
        add_action('admin_menu', [$this->cpt, 'register_preview_page']);
        add_action('post_submitbox_misc_actions', [$this->cpt, 'submitbox_preview_link']);

        add_shortcode('awg_generator', [$this->renderer, 'shortcode']);

        // Theme-accurate template preview: a normal front-end request carrying
        // a nonce'd awg_aig_preview arg renders the tool through the active
        // theme so the admin preview iframe matches the real shortcode output.
        add_action('template_redirect', [$this->renderer, 'maybe_render_preview']);

        // Front assets (only when generator is present)
        add_action('wp_enqueue_scripts', [$this->assets, 'maybe_enqueue_front_assets']);
        add_action('admin_enqueue_scripts', [$this->assets, 'admin_assets']);

        // Block
        add_action('init', [$this->block, 'register']);

        // AJAX
        add_action('wp_ajax_awg_aig_generate', [$this->ajax, 'generate']);
        add_action('wp_ajax_nopriv_awg_aig_generate', [$this->ajax, 'generate']);
        // v5.4.61: streaming (Server-Sent Events) variant of generate(). Shares
        // the same pre-flight/validation; front.js uses it when streaming is
        // enabled and falls back to the classic action above when it can't.
        add_action('wp_ajax_awg_aig_generate_stream', [$this->ajax, 'generate_stream']);
        add_action('wp_ajax_nopriv_awg_aig_generate_stream', [$this->ajax, 'generate_stream']);
        // v5.6.4: "Run via Agent" conversational endpoints. When a tool is linked
        // to an agent, front.js opens an in-place chat and drives it through these
        // instead of generate()/generate_stream(). They run the SAME tool gating
        // (membership, rate, daily cap, usage logging) on every turn, then hand the
        // conversation to the agent's multi-step engine.
        add_action('wp_ajax_awg_aig_agent_chat', [$this->ajax, 'agent_chat']);
        add_action('wp_ajax_nopriv_awg_aig_agent_chat', [$this->ajax, 'agent_chat']);
        add_action('wp_ajax_awg_aig_agent_chat_stream', [$this->ajax, 'agent_chat_stream']);
        add_action('wp_ajax_nopriv_awg_aig_agent_chat_stream', [$this->ajax, 'agent_chat_stream']);
        add_action('wp_ajax_awg_aig_test_key', [$this->ajax, 'test_key']);
        // v5.4.69: file-upload endpoint for "file" form fields. Stores the file,
        // extracts its text, and hands back a one-time token the generate call
        // resolves server-side. Available to guests when the template allows them.
        add_action('wp_ajax_awg_aig_upload', [$this->ajax, 'upload']);
        add_action('wp_ajax_nopriv_awg_aig_upload', [$this->ajax, 'upload']);

        // Submissions: filter dropdown, CSV export, delete-all, retention cron.
        add_action('restrict_manage_posts', [$this->submissions, 'restrict_manage_posts']);
        add_action('pre_get_posts', [$this->submissions, 'filter_query']);
        add_action('admin_footer-edit.php', [$this->submissions, 'list_table_export_button']);
        add_action('admin_post_awg_aig_export_submissions', [$this->submissions, 'handle_export']);
        add_action('admin_post_awg_aig_delete_all_submissions', [$this->submissions, 'handle_delete_all']);
        add_action('awg_aig_cleanup_cron', [$this->submissions, 'cron_cleanup']);

        // v5.4.8: at-a-glance columns on the Submissions list (Template, User, Model).
        add_filter('manage_' . self::SUB_CPT . '_posts_columns', [$this->submissions, 'list_columns']);
        add_action('manage_' . self::SUB_CPT . '_posts_custom_column', [$this->submissions, 'list_column_data'], 10, 2);

        // v5.9.11: present submissions as read-only log entries — relabel/hide the
        // editor controls, print a friendly heading, tidy row actions, and drop the
        // redundant "Published" view link.
        add_action('admin_head', [$this->submissions, 'readonly_edit_screen']);
        add_action('edit_form_top', [$this->submissions, 'render_readonly_heading']);
        add_filter('post_row_actions', [$this->submissions, 'row_actions'], 10, 2);
        add_filter('views_edit-' . self::SUB_CPT, [$this->submissions, 'filter_views']);
        // v5.9.12: one-time backfill of older "Submission (Template #N)" titles.
        add_action('admin_init', [$this->submissions, 'maybe_migrate_titles']);

        // v5.4.14: self-heal the retention cron. Previously the event was
        // only scheduled in activate() — if it ever disappeared (manual
        // wp-cli cron delete, another plugin's bulk clear, corrupted cron
        // option) cleanup would silently stop until the plugin was
        // deactivated and reactivated. Checking here re-schedules on the
        // next page load if it's missing, with no impact when it's present.
        // Uses the same schedule arguments as activate() so the resulting
        // event is indistinguishable from a fresh activation.
        if (!wp_next_scheduled('awg_aig_cleanup_cron')) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', 'awg_aig_cleanup_cron');
        }
    }

    private function __clone() {
        _doing_it_wrong(__FUNCTION__, esc_html__('Cloning is not allowed for this singleton.', 'authorwings-ai-tools'), AWG_AIG_VERSION);
    }

    public function __wakeup() {
        _doing_it_wrong(__FUNCTION__, esc_html__('Unserializing is not allowed for this singleton.', 'authorwings-ai-tools'), AWG_AIG_VERSION);
    }

    public function load_textdomain(): void {
        load_plugin_textdomain('authorwings-ai-tools', false, dirname(plugin_basename(AWG_AIG_FILE)) . '/languages');
    }

    private function includes(): void {
        require_once AWG_AIG_PATH . 'includes/class-settings.php';
        require_once AWG_AIG_PATH . 'includes/class-cpt.php';
        require_once AWG_AIG_PATH . 'includes/class-taxonomy.php';
        require_once AWG_AIG_PATH . 'includes/class-public-pages.php';
        require_once AWG_AIG_PATH . 'includes/class-assets.php';
        require_once AWG_AIG_PATH . 'includes/class-renderer.php';
        require_once AWG_AIG_PATH . 'includes/class-metabox.php';
        require_once AWG_AIG_PATH . 'includes/class-ajax.php';
        require_once AWG_AIG_PATH . 'includes/class-block.php';
        require_once AWG_AIG_PATH . 'includes/class-submissions.php';
        require_once AWG_AIG_PATH . 'includes/class-ratings.php';
        require_once AWG_AIG_PATH . 'includes/class-port.php';
        require_once AWG_AIG_PATH . 'includes/class-cookie-consent.php';
    }

}
