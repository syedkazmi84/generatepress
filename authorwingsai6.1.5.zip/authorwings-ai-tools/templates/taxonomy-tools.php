<?php
/**
 * Front-end archive for a Tool Category (Model 2).
 *
 * Opens as a standalone page at /tool-category/<slug>/, styled with the active
 * theme's header/footer, and lists every published tool in the category. Each
 * card links to the WordPress Page that hosts that tool's [awg_generator]
 * shortcode (detected automatically). A tool whose shortcode isn't on any
 * published page yet is simply skipped, so there are never dead links.
 *
 * v6.1.5: the category page is now rendered inside the active theme's standard
 * page shell instead of a plugin-only standalone layout, so it looks exactly
 * like a normal Page (e.g. the one hosting the [awg_tools] shortcode): the same
 * main column and sidebar, plus a plugin-rendered breadcrumb (the theme's own
 * breadcrumb is suppressed on this surface, see Public_Pages). The tool grid is
 * wrapped in an
 * `article.entry.hentry` — the same element the theme styles as its content
 * card — so it inherits the theme's card background and padding and matches the
 * shortcode page's inner content one-to-one. The category name is shown as the
 * heading via the same `.awg-tools__head` markup the [awg_tools] shortcode uses
 * (not WordPress's "Tool Category: <name>" archive title). We keep full control
 * of the inner tool
 * grid — only the outer wrapper is delegated to the theme. Every theme-specific
 * call is guarded with function_exists(), so the template degrades to a clean,
 * generic layout on themes that don't provide those helpers (the
 * `#primary.site-main` wrapper, the `entry`/`hentry` content classes and
 * get_sidebar() are the shared "_s"/underscores convention that virtually every
 * classic theme, this one included, styles).
 *
 * No plan gating happens here by design — this is a public, indexable listing.
 * Access limits are enforced when the visitor actually generates, on the tool
 * page itself.
 *
 * @package AuthorWings
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

use AWG_AIG\Public_Pages;

get_header();

$awg_term = get_queried_object();

// Shared hub CSS so the cards match the [awg_tools] hub look, when available.
if ( function_exists( 'awg_aig_mem_tools_styles' ) ) {
	echo awg_aig_mem_tools_styles(); // phpcs:ignore WordPress.Security.EscapeOutput
}

// The shared hub CSS caps `.awg-tools` at 900px and centres it. On this page
// the theme's main column already governs the width, so let the grid fill it
// (like any other page/archive) instead of being boxed a second time.
echo '<style>.awg-tools.awg-tools--archive{max-width:none;margin:0}</style>';

// A short accent/description helper for the tool cards.
$awg_default_desc = '';
if ( class_exists( '\\AWG_AIG\\Plugin' ) ) {
	$awg_plugin = \AWG_AIG\Plugin::instance();
	if ( isset( $awg_plugin->renderer ) && is_object( $awg_plugin->renderer ) && method_exists( $awg_plugin->renderer, 'template_defaults' ) ) {
		$awg_defs         = $awg_plugin->renderer->template_defaults();
		$awg_default_desc = trim( (string) ( $awg_defs['form_description'] ?? '' ) );
	}
}

// Tier 1 — per-category page content (term meta). Intro HTML shows above the
// grid, body HTML below it.
$awg_intro = '';
$awg_body  = '';
if ( $awg_term instanceof WP_Term ) {
	$awg_intro = (string) get_term_meta( $awg_term->term_id, 'awg_cat_intro_html', true );
	$awg_body  = (string) get_term_meta( $awg_term->term_id, 'awg_cat_body_html', true );
}

?>
	<main id="primary" class="site-main">

		<?php
		// Mirror the theme's page/archive template so this page is consistent
		// with the rest of the site. These calls are theme-provided extras and
		// safely no-op on themes that don't define them.
		if ( function_exists( 'blank_base_do_element' ) ) {
			blank_base_do_element( 'before_main' );
		}
		?>

		<article class="awg-tool-category entry hentry">
		<div class="awg-tools awg-tools--archive entry-content">

			<?php
			// Plugin-rendered breadcrumb: Home › AI Tools › <Category>. The hub
			// crumb is included only when the AI Tools hub page exists; the
			// theme's own breadcrumb is suppressed on this surface (Public_Pages)
			// so this is the only trail shown.
			if ( function_exists( 'awg_aig_mem_breadcrumbs' ) ) {
				$awg_crumbs = array(
					array( 'label' => __( 'Home', 'authorwings-ai-tools' ), 'url' => home_url( '/' ) ),
				);
				$awg_hub_url = function_exists( 'awg_aig_mem_tools_url' ) ? awg_aig_mem_tools_url() : '';
				if ( $awg_hub_url !== '' ) {
					$awg_crumbs[] = array( 'label' => __( 'AI Tools', 'authorwings-ai-tools' ), 'url' => $awg_hub_url );
				}
				$awg_crumbs[] = array(
					'label' => $awg_term instanceof WP_Term ? $awg_term->name : __( 'Tools', 'authorwings-ai-tools' ),
					'url'   => '',
				);
				echo awg_aig_mem_breadcrumbs( $awg_crumbs ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			?>

			<div class="awg-tools__head">
				<div>
					<h2><?php echo esc_html( $awg_term instanceof WP_Term ? $awg_term->name : __( 'Tools', 'authorwings-ai-tools' ) ); ?></h2>
				</div>
			</div>

			<?php if ( trim( $awg_intro ) !== '' ) : ?>
				<div class="awg-tools__intro" style="margin:0 0 24px;line-height:1.6"><?php echo wp_kses_post( wpautop( $awg_intro ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
			<?php endif; ?>

			<?php
			// Build the visible cards first: a tool is shown only when its
			// shortcode lives on a published page (Public_Pages::tool_url()).
			// Tools with no page yet are skipped entirely, so the grid never
			// contains a dead link.
			$awg_cards = '';
			if ( have_posts() ) :
				while ( have_posts() ) :
					the_post();
					$awg_tool_id = get_the_ID();
					$awg_title   = get_the_title();

					// Resolve the tool's own page (the page hosting its
					// shortcode). No page yet -> skip this tool.
					$awg_url = class_exists( '\\AWG_AIG\\Public_Pages' ) ? Public_Pages::tool_url( (int) $awg_tool_id ) : '';
					if ( $awg_url === '' ) {
						continue;
					}

					ob_start();

						// Per-tool description (skip the shared placeholder
						// default). The tool config is stored as an array under
						// _awg_aig_template.
						$awg_cfg  = get_post_meta( $awg_tool_id, '_awg_aig_template', true );
						$awg_desc = is_array( $awg_cfg ) ? trim( (string) ( $awg_cfg['form_description'] ?? '' ) ) : '';
						if ( $awg_desc === '' || ( $awg_default_desc !== '' && $awg_desc === $awg_default_desc ) ) {
							$awg_desc = '';
						} else {
							$awg_desc = wp_trim_words( $awg_desc, 20, '…' );
						}

						$awg_thumb = get_the_post_thumbnail_url( $awg_tool_id, 'medium' );
						?>
						<a class="awg-tools-card" href="<?php echo esc_url( $awg_url ); ?>">
							<?php if ( $awg_thumb ) : ?>
								<span class="awg-tools-card__thumb"><img src="<?php echo esc_url( $awg_thumb ); ?>" alt="" loading="lazy" /></span>
							<?php else : ?>
								<span class="awg-tools-card__ic" style="background:rgba(126,147,116,.13);color:#7e9374"><span class="dashicons dashicons-admin-tools" aria-hidden="true"></span></span>
							<?php endif; ?>
							<span class="awg-tools-card__name"><?php echo esc_html( $awg_title ); ?></span>
							<?php if ( $awg_desc !== '' ) : ?><span class="awg-tools-card__desc"><?php echo esc_html( $awg_desc ); ?></span><?php endif; ?>
							<span class="awg-tools-card__open"><?php esc_html_e( 'Open', 'authorwings-ai-tools' ); ?> &rarr;</span>
						</a>
						<?php
						$awg_cards .= (string) ob_get_clean();
					endwhile;
			endif;

			if ( $awg_cards !== '' ) :
				?>
				<div class="awg-tools__grid"><?php echo $awg_cards; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
			<?php else : ?>
				<p class="awg-tools__empty"><?php esc_html_e( 'No tools in this category yet.', 'authorwings-ai-tools' ); ?></p>
			<?php endif; ?>

			<?php if ( trim( $awg_body ) !== '' ) : ?>
				<div class="awg-tools__body" style="margin:32px 0 0;line-height:1.6"><?php echo wp_kses_post( wpautop( $awg_body ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
			<?php endif; ?>

		</div><!-- .awg-tools--archive -->
		</article><!-- .awg-tool-category -->

		<?php
		if ( function_exists( 'blank_base_do_element' ) ) {
			blank_base_do_element( 'after_main' );
		}
		?>

	</main><!-- #primary -->

<?php
get_sidebar();
get_footer();
