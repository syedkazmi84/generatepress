<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Plans {

    /**
     * Validate a currency code against the supported list. The supported set
     * mirrors what currency_symbol() can format — anything else is rejected
     * back to USD instead of being persisted as gibberish.
     */
    public static function sanitize_currency( string $code ): string {
        $code = strtoupper( trim( $code ) );
        $allowed = [
            'USD','EUR','GBP','INR','JPY','CNY','CAD','AUD','NZD','CHF',
            'SEK','NOK','DKK','PKR','AED','SAR','BRL','ZAR','MXN','SGD',
            'HKD','KRW','TRY','RUB','PLN',
        ];
        return in_array( $code, $allowed, true ) ? $code : 'USD';
    }

    /**
     * Map an ISO currency code to a display symbol. Falls back to the code
     * itself with a trailing space (e.g. "PKR ") for currencies we don't have
     * a local symbol for, so the price still reads cleanly.
     */
    public static function currency_symbol( string $code ): string {
        $code = strtoupper( trim( $code ) );
        if ( $code === '' ) {
            return '$';
        }
        $map = [
            'USD' => '$',
            'EUR' => '€',
            'GBP' => '£',
            'INR' => '₹',
            'JPY' => '¥',
            'CNY' => '¥',
            'CAD' => 'CA$',
            'AUD' => 'A$',
            'NZD' => 'NZ$',
            'CHF' => 'CHF ',
            'SEK' => 'kr ',
            'NOK' => 'kr ',
            'DKK' => 'kr ',
            'PKR' => '₨',
            'AED' => 'د.إ ',
            'SAR' => '﷼ ',
            'BRL' => 'R$',
            'ZAR' => 'R',
            'MXN' => 'MX$',
            'SGD' => 'S$',
            'HKD' => 'HK$',
            'KRW' => '₩',
            'TRY' => '₺',
            'RUB' => '₽',
            'PLN' => 'zł ',
        ];
        return $map[ $code ] ?? ( $code . ' ' );
    }

    /**
     * Format a price for display. Strips trailing .00 (cleaner visual on round
     * amounts like $19) but preserves cents when present (so $9.99 doesn't get
     * silently rounded down to $9 — a real bug in the pre-2.5.1 build).
     */
    public static function format_amount( float $amount ): string {
        // fmod handles floating-point noise like 19.000000000003 → treat as 0.
        $has_fraction = abs( fmod( $amount, 1.0 ) ) > 0.00499;
        return number_format( $amount, $has_fraction ? 2 : 0 );
    }

    /**
     * Seed the 4 default plans on first activation.
     */
    public static function seed_defaults(): void {
        global $wpdb;
        $table = Database::plans_table();

        if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ) > 0 ) {
            return; // Already seeded
        }

        $now   = current_time( 'mysql' );
        $plans = [
            [
                'name'          => 'Free',
                'slug'          => 'free',
                'description'   => 'Get started with basic AI tools for book publishing.',
                'price_monthly' => 0.00,
                'price_yearly'  => 0.00,
                'is_free'       => 1,
                'sort_order'    => 1,
                'features'      => wp_json_encode( [
                    'Book Title Generator (5/month)',
                    'Book Description Writer (3/month)',
                    'Genre & Comp Title Finder',
                    'Publishing Guides Library',
                    'Interactive Checklists',
                ] ),
                'limits' => wp_json_encode( [
                    'ai_generations_per_month' => 10,
                    'tools_access'             => 'free',
                ] ),
            ],
            [
                'name'          => 'Basic',
                'slug'          => 'basic',
                'description'   => 'More AI tools and unlimited downloads for growing authors.',
                'price_monthly' => 19.00,
                'price_yearly'  => 179.00,
                'is_free'       => 0,
                'sort_order'    => 2,
                'features'      => wp_json_encode( [
                    'Everything in Free',
                    'AI Generations (100/month)',
                    'Book Synopsis Generator',
                    'Author Bio Generator (unlimited)',
                    'Social Media Caption Pack',
                    'ARC Outreach Email Writer',
                    'Amazon Listing Optimizer',
                    'Download all outputs',
                    'Submission history',
                    'Monthly webinars',
                    'Member community forum',
                ] ),
                'limits' => wp_json_encode( [
                    'ai_generations_per_month' => 100,
                    'tools_access'             => 'basic',
                ] ),
            ],
            [
                'name'          => 'Pro',
                'slug'          => 'pro',
                'description'   => 'Full suite of AI tools and priority support for serious authors.',
                'price_monthly' => 49.00,
                'price_yearly'  => 449.00,
                'is_free'       => 0,
                'is_popular'    => 1,
                'sort_order'    => 3,
                'features'      => wp_json_encode( [
                    'Everything in Basic',
                    'Unlimited AI Generations',
                    'Chapter Outline Generator',
                    'Query Letter Writer',
                    'Book Series Planner',
                    'Character Profile Builder',
                    'Dialogue Coach',
                    'Launch Email Sequence',
                    'Book Marketing Plan',
                    'Press Release Generator (unlimited)',
                    'Priority generation queue',
                    'Service discounts (10%)',
                    'Self-Publishing Masterclass',
                ] ),
                'limits' => wp_json_encode( [
                    'ai_generations_per_month' => -1, // unlimited
                    'tools_access'             => 'pro',
                ] ),
            ],
            [
                'name'          => 'Publisher',
                'slug'          => 'publisher',
                'description'   => 'Agency-grade tools and white-label outputs.',
                'price_monthly' => 149.00,
                'price_yearly'  => 1349.00,
                'is_free'       => 0,
                'sort_order'    => 4,
                'features'      => wp_json_encode( [
                    'Everything in Pro',
                    'Unlimited AI Generations',
                    'Bulk generation tools',
                    'White-label outputs',
                    'Dedicated account manager',
                    'Custom AI template creation',
                    'Service discounts (20%)',
                    'Priority email support',
                ] ),
                'limits' => wp_json_encode( [
                    'ai_generations_per_month' => -1,
                    'tools_access'             => 'publisher',
                ] ),
            ],
        ];

        foreach ( $plans as $plan ) {
            $plan['created_at'] = $now;
            $wpdb->insert( $table, $plan );
        }
    }

    /**
     * Get all active plans ordered by sort_order.
     */
    public function get_all(): array {
        global $wpdb;
        $table = Database::plans_table();
        $rows  = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE is_active = 1 ORDER BY sort_order ASC",
            ARRAY_A
        );
        if ( ! $rows ) {
            return [];
        }
        return array_map( [ $this, 'decode_plan' ], $rows );
    }



    /**
     * Get all plans including inactive ones ordered by sort_order.
     */
    public function get_all_for_admin(): array {
        global $wpdb;
        $table = Database::plans_table();
        $rows  = $wpdb->get_results(
            "SELECT * FROM {$table} ORDER BY sort_order ASC, id ASC",
            ARRAY_A
        );
        if ( ! $rows ) {
            return [];
        }
        return array_map( [ $this, 'decode_plan' ], $rows );
    }

    /**
     * Normalize plan limits into a stable structure.
     */
    public function normalize_limits( array $limits ): array {
        $access = sanitize_key( (string) ( $limits['tools_access'] ?? 'free' ) );
        if ( ! in_array( $access, [ 'free', 'basic', 'pro', 'publisher' ], true ) ) {
            $access = 'free';
        }

        $ai_limit = isset( $limits['ai_generations_per_month'] ) ? (int) $limits['ai_generations_per_month'] : 0;
        if ( $ai_limit < 0 ) {
            $ai_limit = -1;
        }

        $normalized = [
            'ai_generations_per_month' => $ai_limit,
            'tools_access'             => $access,
        ];

        if ( isset( $limits['trial_days'] ) ) {
            $normalized['trial_days'] = max( 0, min( 365, (int) $limits['trial_days'] ) );
        }

        if ( ! empty( $limits['inherits_from'] ) ) {
            $normalized['inherits_from'] = sanitize_key( (string) $limits['inherits_from'] );
        }

        foreach ( $limits as $key => $value ) {
            if ( isset( $normalized[ $key ] ) ) {
                continue;
            }

            if ( is_scalar( $value ) || is_null( $value ) ) {
                $normalized[ sanitize_key( (string) $key ) ] = $value;
            }
        }

        return $normalized;
    }

    /**
     * Validate a plan payload before saving.
     *
     * @return array{valid:bool,errors:array,data:array}
     */
    public function validate_plan_input( array $plan ): array {
        $name  = sanitize_text_field( (string) ( $plan['name'] ?? '' ) );
        $slug  = sanitize_title( (string) ( $plan['slug'] ?? '' ) );
        $monthly = round( (float) ( $plan['price_monthly'] ?? 0 ), 2 );
        $yearly  = round( (float) ( $plan['price_yearly'] ?? 0 ), 2 );
        $limits  = $this->normalize_limits( (array) ( $plan['limits'] ?? [] ) );
        $errors  = [];

        if ( '' === $name ) {
            $errors[] = __( 'Plan name is required.', 'authorwings-ai-tools' );
        }

        if ( '' === $slug ) {
            $errors[] = __( 'Plan slug is required.', 'authorwings-ai-tools' );
        }

        $existing_id = ! empty( $plan['id'] ) ? (int) $plan['id'] : 0;
        $existing    = $slug ? $this->get_by_slug( $slug ) : null;
        if ( $existing && (int) $existing['id'] !== $existing_id ) {
            $errors[] = __( 'Plan slug must be unique.', 'authorwings-ai-tools' );
        }

        if ( $monthly < 0 ) {
            $errors[] = __( 'Monthly price cannot be negative.', 'authorwings-ai-tools' );
        }

        if ( $yearly < 0 ) {
            $errors[] = __( 'Yearly price cannot be negative.', 'authorwings-ai-tools' );
        }

        if ( ! isset( $plan['limits']['ai_generations_per_month'] ) || ( $limits['ai_generations_per_month'] < -1 ) ) {
            $errors[] = __( 'Usage limit is invalid.', 'authorwings-ai-tools' );
        }

        if ( 0.0 === $monthly && 0.0 === $yearly ) {
            $plan['is_free'] = 1;
        }

        $plan['name'] = $name;
        $plan['slug'] = $slug;
        $plan['price_monthly'] = $monthly;
        $plan['price_yearly'] = $yearly;
        $plan['limits'] = $limits;
        $plan['is_free'] = ! empty( $plan['is_free'] ) ? 1 : 0;

        return [
            'valid'  => empty( $errors ),
            'errors' => $errors,
            'data'   => $plan,
        ];
    }

    /**
     * Insert or update a plan.
     */
    public function save_plan( array $plan ): int {
        global $wpdb;
        $table = Database::plans_table();
        $now   = current_time( 'mysql' );

        $existing_id = ! empty( $plan['id'] ) ? (int) $plan['id'] : 0;
        $existing    = $existing_id > 0 ? $this->get( $existing_id ) : null;

        $raw_features = array_key_exists( 'features', $plan )
            ? (array) ( $plan['features'] ?? [] )
            : (array) ( $existing['features'] ?? [] );

        $limits_source = array_key_exists( 'limits', $plan )
            ? (array) ( $plan['limits'] ?? [] )
            : (array) ( $existing['limits'] ?? [] );

        if ( $existing ) {
            $limits_source = array_merge( (array) $existing['limits'], $limits_source );
        }

        $data = [
            'name'                    => sanitize_text_field( $plan['name'] ?? ( $existing['name'] ?? '' ) ),
            'slug'                    => sanitize_title( $plan['slug'] ?? ( $existing['slug'] ?? '' ) ),
            'description'             => sanitize_textarea_field( $plan['description'] ?? ( $existing['description'] ?? '' ) ),
            'price_monthly'           => round( (float) ( $plan['price_monthly'] ?? ( $existing['price_monthly'] ?? 0 ) ), 2 ),
            'price_yearly'            => round( (float) ( $plan['price_yearly'] ?? ( $existing['price_yearly'] ?? 0 ) ), 2 ),
            'currency'                => self::sanitize_currency( $plan['currency'] ?? ( $existing['currency'] ?? 'USD' ) ),
            'is_free'                 => ! empty( $plan['is_free'] ) ? 1 : 0,
            'is_popular'              => array_key_exists( 'is_popular', $plan ) ? ( ! empty( $plan['is_popular'] ) ? 1 : 0 ) : (int) ( $existing['is_popular'] ?? 0 ),
            'is_active'               => array_key_exists( 'is_active', $plan ) ? ( ! empty( $plan['is_active'] ) ? 1 : 0 ) : (int) ( $existing['is_active'] ?? 0 ),
            'sort_order'              => (int) ( $plan['sort_order'] ?? ( $existing['sort_order'] ?? 0 ) ),
            'features'                => wp_json_encode( array_values( array_filter( $raw_features, static function ( $feature ) {
                return '' !== trim( (string) $feature );
            } ) ) ),
            'limits'                  => wp_json_encode( $this->normalize_limits( $limits_source ) ),
            'stripe_monthly_price_id' => sanitize_text_field( $plan['stripe_monthly_price_id'] ?? ( $existing['stripe_monthly_price_id'] ?? '' ) ),
            'stripe_yearly_price_id'  => sanitize_text_field( $plan['stripe_yearly_price_id'] ?? ( $existing['stripe_yearly_price_id'] ?? '' ) ),
        ];

        if ( empty( $data['currency'] ) ) {
            $data['currency'] = 'USD';
        }

        if ( $existing_id > 0 ) {
            $wpdb->update( $table, $data, [ 'id' => $existing_id ] );
            return $existing_id;
        }

        $data['created_at'] = $now;
        $wpdb->insert( $table, $data );
        return (int) $wpdb->insert_id;
    }

    /**
     * Get a single plan by ID.
     */
    public function get( int $plan_id ): ?array {
        global $wpdb;
        $table = Database::plans_table();
        $row   = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", $plan_id ),
            ARRAY_A
        );
        return $row ? $this->decode_plan( $row ) : null;
    }

    /**
     * Get a plan by slug.
     */
    public function get_by_slug( string $slug ): ?array {
        global $wpdb;
        $table = Database::plans_table();
        $row   = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE slug = %s LIMIT 1", $slug ),
            ARRAY_A
        );
        return $row ? $this->decode_plan( $row ) : null;
    }

    /**
     * Get limits for a plan.
     */
    public function get_limits( int $plan_id ): array {
        $plan = $this->get( $plan_id );
        return $plan ? (array) $plan['limits'] : [];
    }



    /**
     * Count memberships assigned to a plan.
     */
    public function count_members_assigned( int $plan_id ): int {
        global $wpdb;
        $table = Database::mems_table();
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(DISTINCT user_id) FROM {$table} WHERE plan_id = %d AND status IN ('active','trialing')",
                $plan_id
            )
        );
    }

    /**
     * Delete a plan when it is safe to do so.
     */
    public function delete_plan( int $plan_id ): bool {
        global $wpdb;
        $table = Database::plans_table();
        if ( $plan_id <= 0 || $this->count_members_assigned( $plan_id ) > 0 ) {
            return false;
        }
        return false !== $wpdb->delete( $table, [ 'id' => $plan_id ], [ '%d' ] );
    }

    /**
     * Decode JSON columns.
     */
    private function decode_plan( array $row ): array {
        $row['features'] = json_decode( $row['features'] ?? '[]', true ) ?: [];
        $row['limits']   = $this->normalize_limits( json_decode( $row['limits'] ?? '{}', true ) ?: [] );
        return $row;
    }

    /**
     * Render the [awg_pricing] shortcode.
     */
    public function render_pricing_page( array $atts ): string {
        $plans = $this->get_all();

        // Show the monthly/yearly switch only when at least one paid plan
        // actually has a yearly price to switch to.
        $has_yearly = false;
        foreach ( $plans as $p ) {
            if ( empty( $p['is_free'] ) && (float) ( $p['price_yearly'] ?? 0 ) > 0 ) {
                $has_yearly = true;
                break;
            }
        }

        // Logged-in member's current plan + billing cycle, so the matching card
        // can be marked "Current plan" and the others can offer Upgrade /
        // Downgrade / Switch instead of "Get started". Effectively-free members
        // (no active paid row) resolve to the free plan's slug.
        $member_slug     = '';
        $member_cycle    = '';
        $pending_plan_id = 0; // Plan the member has a Stripe-scheduled switch to.
        if ( is_user_logged_in() && class_exists( '\\AWG_MEM\\Plugin', false ) ) {
            $mp = \AWG_MEM\Plugin::instance()->memberships;
            if ( $mp ) {
                $eff = $mp->get_effective_membership( get_current_user_id() );
                if ( is_array( $eff ) ) {
                    $member_slug  = (string) ( $eff['plan_slug'] ?? '' );
                    $member_cycle = empty( $eff['is_free'] ) ? (string) ( $eff['billing_cycle'] ?? '' ) : '';
                }
                $pending         = $mp->get_pending_change( get_current_user_id() );
                $pending_plan_id = is_array( $pending ) ? (int) ( $pending['plan_id'] ?? 0 ) : 0;
            }
            if ( $member_slug === '' ) {
                foreach ( $plans as $fp ) {
                    if ( ! empty( $fp['is_free'] ) ) { $member_slug = (string) $fp['slug']; break; }
                }
                if ( $member_slug === '' ) { $member_slug = 'free'; }
            }
        }

        // Tier rank by display order (plans are ordered by sort_order asc), used
        // to label other plans as Upgrade vs Downgrade relative to the member's.
        $rank_by_slug = [];
        $rk = 0;
        foreach ( $plans as $rp ) {
            $rank_by_slug[ (string) $rp['slug'] ] = $rk++;
        }

        ob_start();
        ?>
        <div class="awg-mem-pricing" id="awg-pricing">
            <?php
            if ( function_exists( 'awg_aig_mem_breadcrumbs' ) ) {
                echo awg_aig_mem_breadcrumbs( array( // phpcs:ignore WordPress.Security.EscapeOutput
                    array( 'label' => __( 'Home', 'authorwings-ai-tools' ), 'url' => home_url( '/' ) ),
                    array( 'label' => __( 'Pricing', 'authorwings-ai-tools' ), 'url' => '' ),
                ) );
            }
            ?>
            <style>
                .awg-mem-pricing__badge--current{background:#16a34a;color:#fff;}
                .awg-mem-pricing__card--current{border-color:#16a34a;border-width:2px;}
                .awg-mem-pricing__cta--current{background:#f1f5f9;color:#64748b;border-color:#e2e8f0;cursor:default;pointer-events:none;}
                .awg-mem-pricing__cta--current:hover{background:#f1f5f9;}
            </style>
            <?php if ( $has_yearly ) : ?>
                <style>
                    .awg-mem-pricing__billing-toggle{display:flex;justify-content:center;gap:0;margin:0 auto 28px;background:#eef1f5;border-radius:999px;padding:4px;width:max-content;}
                    .awg-mem-pricing__billing-toggle label{position:relative;cursor:pointer;margin:0;}
                    .awg-mem-pricing__billing-toggle input{position:absolute;opacity:0;width:0;height:0;}
                    .awg-mem-pricing__billing-toggle span{display:inline-block;padding:8px 22px;border-radius:999px;font:600 14px/1 inherit;color:#475569;transition:background .15s,color .15s,box-shadow .15s;}
                    .awg-mem-pricing__billing-toggle input:checked + span{background:#fff;color:#0f172a;box-shadow:0 1px 3px rgba(0,0,0,.12);}
                    .awg-mem-pricing__billing-toggle input:focus-visible + span{outline:2px solid #2563eb;outline-offset:2px;}
                    .awg-mem-pricing__save-pill{margin-left:6px;font-size:12px;font-weight:700;color:#15803d;}
                </style>
                <div class="awg-mem-pricing__billing-toggle" role="radiogroup" aria-label="<?php esc_attr_e( 'Billing period', 'authorwings-ai-tools' ); ?>">
                    <label>
                        <input type="radio" name="awg_mem_billing" value="monthly" checked>
                        <span><?php esc_html_e( 'Monthly', 'authorwings-ai-tools' ); ?></span>
                    </label>
                    <label>
                        <input type="radio" name="awg_mem_billing" value="yearly">
                        <span><?php esc_html_e( 'Yearly', 'authorwings-ai-tools' ); ?></span>
                    </label>
                </div>
            <?php endif; ?>
            <div class="awg-mem-pricing__grid">
                <?php foreach ( $plans as $plan ) : ?>
                    <?php
                    // Use the explicit is_popular flag set in admin. Falls back
                    // to slug='pro' for sites that haven't run the 2.5.2 dbDelta
                    // migration yet — keeps the badge visible on existing setups
                    // until the admin re-saves the plan once.
                    $is_popular = ! empty( $plan['is_popular'] )
                        || ( ! isset( $plan['is_popular'] ) && $plan['slug'] === 'pro' );
                    $monthly    = (float) $plan['price_monthly'];
                    $yearly     = (float) $plan['price_yearly'];
                    $is_free    = (bool) $plan['is_free'];
                    $sym        = self::currency_symbol( (string) ( $plan['currency'] ?? 'USD' ) );

                    // Relationship of this card to the logged-in member's plan.
                    $logged_in = is_user_logged_in();
                    $is_current = $logged_in && ( (string) $plan['slug'] === $member_slug );
                    // This card is the target of a Stripe-scheduled switch (e.g.
                    // a downgrade queued for period end) — but not the live plan.
                    $is_pending = $logged_in && ! $is_current && $pending_plan_id > 0 && (int) ( $plan['id'] ?? 0 ) === $pending_plan_id;
                    // The member's own plan takes the badge slot from "Most Popular".
                    $show_popular = $is_popular && ! $is_current && ! $is_pending;

                    $cta_label    = $is_free ? __( 'Get Started Free', 'authorwings-ai-tools' ) : __( 'Get Started', 'authorwings-ai-tools' );
                    $cta_is_inert = false;
                    $cta_primary  = $show_popular;
                    if ( $logged_in ) {
                        if ( $is_current ) {
                            // Initial render assumes the monthly view (the radio
                            // checked by default). lean-pricing.js re-evaluates
                            // this on load and whenever the toggle changes.
                            if ( ! $is_free && $member_cycle !== '' && $member_cycle !== 'monthly' ) {
                                $cta_label = __( 'Switch to monthly', 'authorwings-ai-tools' );
                            } else {
                                $cta_label    = __( 'Current plan', 'authorwings-ai-tools' );
                                $cta_is_inert = true;
                            }
                        } elseif ( $is_pending ) {
                            // Already queued to switch here — show it as scheduled
                            // rather than offering the change again.
                            $cta_label    = __( 'Scheduled', 'authorwings-ai-tools' );
                            $cta_is_inert = true;
                        } elseif ( $is_free ) {
                            $cta_label = __( 'Switch to Free', 'authorwings-ai-tools' );
                        } else {
                            $this_rank   = $rank_by_slug[ (string) $plan['slug'] ] ?? 0;
                            $member_rank = $rank_by_slug[ $member_slug ] ?? 0;
                            $cta_label   = ( $this_rank > $member_rank )
                                ? __( 'Upgrade', 'authorwings-ai-tools' )
                                : __( 'Downgrade', 'authorwings-ai-tools' );
                        }
                    }

                    $card_classes = 'awg-mem-pricing__card';
                    if ( $is_current ) {
                        $card_classes .= ' awg-mem-pricing__card--current';
                    } elseif ( $is_popular ) {
                        $card_classes .= ' awg-mem-pricing__card--popular';
                    }
                    ?>
                    <div class="<?php echo esc_attr( $card_classes ); ?>">
                        <?php if ( $is_current ) : ?>
                            <div class="awg-mem-pricing__badge awg-mem-pricing__badge--current"><?php esc_html_e( 'Current plan', 'authorwings-ai-tools' ); ?></div>
                        <?php elseif ( $is_pending ) : ?>
                            <div class="awg-mem-pricing__badge"><?php esc_html_e( 'Scheduled', 'authorwings-ai-tools' ); ?></div>
                        <?php elseif ( $is_popular ) : ?>
                            <div class="awg-mem-pricing__badge"><?php esc_html_e( 'Most Popular', 'authorwings-ai-tools' ); ?></div>
                        <?php endif; ?>

                        <h3 class="awg-mem-pricing__plan-name"><?php echo esc_html( $plan['name'] ); ?></h3>
                        <p class="awg-mem-pricing__desc"><?php echo esc_html( $plan['description'] ); ?></p>

                        <div class="awg-mem-pricing__price">
                            <?php if ( $is_free ) : ?>
                                <span class="awg-mem-pricing__amount">
                                    <?php esc_html_e( 'Free', 'authorwings-ai-tools' ); ?>
                                </span>
                            <?php else : ?>
                                <?php
                                // Actual yearly saving vs. paying monthly for a
                                // year — recomputed from the admin's real prices.
                                $yearly_full  = $monthly * 12;
                                $savings_pct  = $yearly_full > 0 && $yearly > 0 ? (int) round( ( 1 - ( $yearly / $yearly_full ) ) * 100 ) : 0;
                                $monthly_equiv = $yearly > 0 ? ( $yearly / 12 ) : 0;
                                ?>

                                <span class="awg-mem-pricing__view" data-billing-view="monthly">
                                    <span class="awg-mem-pricing__amount">
                                        <?php echo esc_html( $sym . self::format_amount( $monthly ) ); ?>
                                    </span>
                                    <span class="awg-mem-pricing__period">
                                        / <?php esc_html_e( 'month', 'authorwings-ai-tools' ); ?>
                                    </span>
                                    <?php if ( $yearly > 0 ) : ?>
                                        <p class="awg-mem-pricing__yearly">
                                            <?php if ( $savings_pct > 0 ) : ?>
                                                <?php
                                                printf(
                                                    /* translators: 1: yearly price including currency symbol, 2: saving percentage */
                                                    esc_html__( 'or %1$s/year — save %2$d%%', 'authorwings-ai-tools' ),
                                                    esc_html( $sym . self::format_amount( $yearly ) ),
                                                    (int) $savings_pct
                                                );
                                                ?>
                                            <?php else : ?>
                                                <?php
                                                printf(
                                                    /* translators: %s: yearly price including currency symbol */
                                                    esc_html__( 'or %s/year', 'authorwings-ai-tools' ),
                                                    esc_html( $sym . self::format_amount( $yearly ) )
                                                );
                                                ?>
                                            <?php endif; ?>
                                        </p>
                                    <?php endif; ?>
                                </span>

                                <?php if ( $yearly > 0 ) : ?>
                                    <span class="awg-mem-pricing__view" data-billing-view="yearly" hidden>
                                        <span class="awg-mem-pricing__amount">
                                            <?php echo esc_html( $sym . self::format_amount( $yearly ) ); ?>
                                        </span>
                                        <span class="awg-mem-pricing__period">
                                            / <?php esc_html_e( 'year', 'authorwings-ai-tools' ); ?>
                                        </span>
                                        <p class="awg-mem-pricing__yearly">
                                            <?php
                                            printf(
                                                /* translators: %s: per-month equivalent price including currency symbol */
                                                esc_html__( '%s/mo billed annually', 'authorwings-ai-tools' ),
                                                esc_html( $sym . self::format_amount( $monthly_equiv ) )
                                            );
                                            ?>
                                            <?php if ( $savings_pct > 0 ) : ?>
                                                <span class="awg-mem-pricing__save-pill">
                                                    <?php
                                                    printf(
                                                        /* translators: %d: saving percentage */
                                                        esc_html__( 'save %d%%', 'authorwings-ai-tools' ),
                                                        (int) $savings_pct
                                                    );
                                                    ?>
                                                </span>
                                            <?php endif; ?>
                                        </p>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <?php
                        // v3.1.6 — send logged-out visitors to registration (with a
                        // redirect back to the upgrade flow) instead of dropping them
                        // on the dashboard login prompt. Logged-in users go straight
                        // to the in-dashboard upgrade modal via the upgrade URL.
                        $cta_url = \AWG_MEM\URLs::upgrade( (string) $plan['slug'] );
                        if ( ! is_user_logged_in() ) {
                            $register_url = wp_registration_url();
                            // add_query_arg() URL-encodes the value, so pass the raw URL.
                            $cta_url = $register_url ? add_query_arg( 'redirect_to', $cta_url, $register_url ) : \AWG_MEM\URLs::login( $cta_url );
                        }

                        $cta_classes = 'awg-mem-pricing__cta';
                        if ( $cta_primary )  { $cta_classes .= ' awg-mem-pricing__cta--primary'; }
                        if ( $cta_is_inert ) { $cta_classes .= ' awg-mem-pricing__cta--current'; }

                        // For the member's own *paid* plan, expose data so the
                        // front-end can flip the button between "Current plan" and
                        // "Switch to monthly/yearly" as the billing toggle changes.
                        $cta_data = '';
                        if ( $is_current && ! $is_free ) {
                            $cta_data = ' data-awg-current="1"'
                                . ' data-awg-current-cycle="' . esc_attr( $member_cycle !== '' ? $member_cycle : 'monthly' ) . '"'
                                . ' data-awg-has-yearly="' . ( $yearly > 0 ? '1' : '0' ) . '"'
                                . ' data-awg-href="' . esc_url( $cta_url ) . '"';
                        }
                        ?>
                        <a <?php echo $cta_is_inert ? '' : 'href="' . esc_url( $cta_url ) . '" '; ?>class="<?php echo esc_attr( $cta_classes ); ?>"<?php echo $cta_data; // phpcs:ignore WordPress.Security.EscapeOutput -- each attribute escaped above ?><?php echo $cta_is_inert ? ' aria-disabled="true"' : ''; ?>>
                            <?php echo esc_html( $cta_label ); ?>
                        </a>

                        <ul class="awg-mem-pricing__features">
                            <?php foreach ( (array) $plan['features'] as $feature ) : ?>
                                <li><?php echo esc_html( $feature ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>

        </div>
        <?php
        return ob_get_clean();
    }

}
