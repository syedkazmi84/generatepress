<?php
/**
 * Block patterns and pattern categories for Blank Base.
 *
 * Ships a library of production-ready, editable patterns. Placeholder imagery
 * is bundled as lightweight SVG in assets/images, so every pattern looks
 * complete the moment it is inserted — the site owner then swaps in their own
 * copy and media.
 *
 * @package Blank_Base
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register block pattern categories.
 */
function blank_base_register_pattern_categories() {
	if ( ! function_exists( 'register_block_pattern_category' ) ) {
		return;
	}

	register_block_pattern_category(
		'blank-base',
		array( 'label' => esc_html__( 'Blank Base', 'blank-base' ) )
	);

	register_block_pattern_category(
		'blank-base-pages',
		array( 'label' => esc_html__( 'Blank Base: Pages', 'blank-base' ) )
	);
}
add_action( 'init', 'blank_base_register_pattern_categories' );

/**
 * URL for a bundled placeholder image.
 *
 * @param string $file File name in assets/images.
 * @return string
 */
function blank_base_img_url( $file ) {
	return esc_url( get_theme_file_uri( '/assets/images/' . $file ) );
}

/**
 * Wrap an inline SVG in a feature-icon span (as a core/html block).
 *
 * @param string $svg SVG markup.
 * @return string
 */
function blank_base_feature_icon( $svg ) {
	return '<!-- wp:html -->
<span class="bb-feature-icon">' . $svg . '</span>
<!-- /wp:html -->
';
}

/**
 * Register all block patterns.
 */
function blank_base_register_block_patterns() {
	if ( ! function_exists( 'register_block_pattern' ) ) {
		return;
	}

	$section = 'blank-base';
	$pages   = 'blank-base-pages';

	$patterns = array(
		'hero'          => array( esc_html__( 'Hero', 'blank-base' ), esc_html__( 'A full-width hero with a headline, supporting line and two buttons.', 'blank-base' ), $section, blank_base_pb_hero() ),
		'features'      => array( esc_html__( 'Three features with icons', 'blank-base' ), esc_html__( 'A three-column feature row, each with an icon, heading and description.', 'blank-base' ), $section, blank_base_pb_features() ),
		'stats'         => array( esc_html__( 'Stats row', 'blank-base' ), esc_html__( 'Four key numbers with labels.', 'blank-base' ), $section, blank_base_pb_stats() ),
		'pricing'       => array( esc_html__( 'Pricing table (3 tiers)', 'blank-base' ), esc_html__( 'Three pricing plans with a highlighted popular tier.', 'blank-base' ), $section, blank_base_pb_pricing() ),
		'testimonial'   => array( esc_html__( 'Testimonial', 'blank-base' ), esc_html__( 'A centered customer quote with attribution.', 'blank-base' ), $section, blank_base_pb_testimonial() ),
		'cta'           => array( esc_html__( 'Call to action', 'blank-base' ), esc_html__( 'A centered heading, supporting line and button.', 'blank-base' ), $section, blank_base_pb_cta() ),
		'about'         => array( esc_html__( 'About section', 'blank-base' ), esc_html__( 'An image beside an introductory story block.', 'blank-base' ), $section, blank_base_pb_about() ),
		'content-image' => array( esc_html__( 'Content + image', 'blank-base' ), esc_html__( 'A text block beside an image, image on the right.', 'blank-base' ), $section, blank_base_pb_content_image() ),
		'faq'           => array( esc_html__( 'FAQ', 'blank-base' ), esc_html__( 'A list of expandable questions and answers.', 'blank-base' ), $section, blank_base_pb_faq() ),
		'team'          => array( esc_html__( 'Team grid', 'blank-base' ), esc_html__( 'A four-column grid of team members with photo, name and role.', 'blank-base' ), $section, blank_base_pb_team() ),
		'page-header'   => array( esc_html__( 'Page header', 'blank-base' ), esc_html__( 'A centered page title and introductory sentence.', 'blank-base' ), $section, blank_base_pb_page_header( esc_html__( 'Page title', 'blank-base' ), esc_html__( 'A short introduction that sets up what this page is about.', 'blank-base' ) ) ),
		'logos'         => array( esc_html__( 'Logo cloud', 'blank-base' ), esc_html__( 'A "trusted by" row of logos.', 'blank-base' ), $section, blank_base_pb_logos() ),
		'newsletter'    => array( esc_html__( 'Newsletter signup', 'blank-base' ), esc_html__( 'A call to subscribe with a button.', 'blank-base' ), $section, blank_base_pb_newsletter() ),
		'contact'       => array( esc_html__( 'Contact section', 'blank-base' ), esc_html__( 'Contact details beside a short message.', 'blank-base' ), $section, blank_base_pb_contact() ),
		'latest-posts'  => array( esc_html__( 'Latest posts', 'blank-base' ), esc_html__( 'A three-column grid of your most recent posts (Query Loop).', 'blank-base' ), $section, blank_base_pb_latest_posts() ),
		'steps'         => array( esc_html__( 'How it works (steps)', 'blank-base' ), esc_html__( 'Three numbered steps explaining a process.', 'blank-base' ), $section, blank_base_pb_steps() ),
		'stats-counter' => array( esc_html__( 'Animated stats counter', 'blank-base' ), esc_html__( 'Four numbers that count up when scrolled into view.', 'blank-base' ), $section, blank_base_pb_stats_animated() ),
		'skills'        => array( esc_html__( 'Skill bars', 'blank-base' ), esc_html__( 'Labelled progress bars that animate to their value on scroll.', 'blank-base' ), $section, blank_base_pb_skills() ),
		'slider'        => array( esc_html__( 'Testimonial slider', 'blank-base' ), esc_html__( 'A swipeable carousel with previous/next controls.', 'blank-base' ), $section, blank_base_pb_slider() ),
	);

	foreach ( $patterns as $slug => $data ) {
		register_block_pattern(
			'blank-base/' . $slug,
			array(
				'title'       => $data[0],
				'description' => $data[1],
				'categories'  => array( $data[2] ),
				'content'     => $data[3],
			)
		);
	}

	// Full-page patterns (offered in the pattern picker when creating a Page).
	$page_patterns = array(
		'page-landing' => array(
			esc_html__( 'Page: Landing', 'blank-base' ),
			esc_html__( 'A complete landing page: hero, features, stats, testimonial and a call to action.', 'blank-base' ),
			blank_base_pb_hero() . blank_base_pb_features() . blank_base_pb_stats() . blank_base_pb_testimonial() . blank_base_pb_cta(),
		),
		'page-about'   => array(
			esc_html__( 'Page: About', 'blank-base' ),
			esc_html__( 'A complete about page: header, story, stats and team.', 'blank-base' ),
			blank_base_pb_page_header( esc_html__( 'About us', 'blank-base' ), esc_html__( 'The short version of who we are and what we care about.', 'blank-base' ) ) . blank_base_pb_about() . blank_base_pb_stats() . blank_base_pb_team(),
		),
		'page-contact' => array(
			esc_html__( 'Page: Contact', 'blank-base' ),
			esc_html__( 'A complete contact page: header and contact section.', 'blank-base' ),
			blank_base_pb_page_header( esc_html__( 'Get in touch', 'blank-base' ), esc_html__( 'We usually reply within one business day.', 'blank-base' ) ) . blank_base_pb_contact(),
		),
	);

	foreach ( $page_patterns as $slug => $data ) {
		register_block_pattern(
			'blank-base/' . $slug,
			array(
				'title'       => $data[0],
				'description' => $data[1],
				'categories'  => array( $pages ),
				'blockTypes'  => array( 'core/post-content' ),
				'postTypes'   => array( 'page' ),
				'content'     => $data[2],
			)
		);
	}
}
add_action( 'init', 'blank_base_register_block_patterns' );

/*
 * ---------------------------------------------------------------------------
 * Section builders. Each returns valid, production-ready block markup.
 * ---------------------------------------------------------------------------
 */

/**
 * Hero cover.
 *
 * @return string
 */
function blank_base_pb_hero() {
	return '<!-- wp:cover {"customOverlayColor":"#0073aa","isUserOverlayColor":true,"minHeight":460,"align":"full","style":{"spacing":{"padding":{"top":"5rem","bottom":"5rem","left":"1.5rem","right":"1.5rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull" style="padding-top:5rem;padding-right:1.5rem;padding-bottom:5rem;padding-left:1.5rem;min-height:460px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-100 has-background-dim" style="background-color:#0073aa"></span><div class="wp-block-cover__inner-container"><!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"3.25rem","lineHeight":"1.1"},"color":{"text":"#ffffff"}}} -->
<h1 class="wp-block-heading has-text-align-center has-text-color" style="color:#ffffff;font-size:3.25rem;line-height:1.1">' . esc_html__( 'A clear, confident headline', 'blank-base' ) . '</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.25rem"},"color":{"text":"#ffffff"},"spacing":{"margin":{"top":"1rem"}}}} -->
<p class="has-text-align-center has-text-color" style="color:#ffffff;margin-top:1rem;font-size:1.25rem">' . esc_html__( 'Introduce your product or service in one sentence that tells visitors exactly what you offer and why it matters.', 'blank-base' ) . '</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"2rem"}}}} -->
<div class="wp-block-buttons" style="margin-top:2rem"><!-- wp:button {"backgroundColor":"white","textColor":"foreground","style":{"spacing":{"padding":{"left":"1.6rem","right":"1.6rem","top":"0.75rem","bottom":"0.75rem"}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-foreground-color has-white-background-color has-text-color has-background wp-element-button" style="padding-top:0.75rem;padding-right:1.6rem;padding-bottom:0.75rem;padding-left:1.6rem">' . esc_html__( 'Get started', 'blank-base' ) . '</a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"white","className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-white-color has-text-color wp-element-button">' . esc_html__( 'Learn more', 'blank-base' ) . '</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:cover -->';
}

/**
 * Three features with icons.
 *
 * @return string
 */
function blank_base_pb_features() {
	$icon_open  = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="40" height="40" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">';
	$bolt       = $icon_open . '<path d="M13 2 L4 14 h6 l-1 8 L20 10 h-6 z"/></svg>';
	$sliders    = $icon_open . '<line x1="4" y1="8" x2="20" y2="8"/><line x1="4" y1="16" x2="20" y2="16"/><circle cx="9" cy="8" r="2.4"/><circle cx="15" cy="16" r="2.4"/></svg>';
	$shield     = $icon_open . '<path d="M12 3 l7 3 v5 c0 4.6 -3.1 7.1 -7 8 c-3.9 -0.9 -7 -3.4 -7 -8 V6 z"/><path d="M9 12 l2 2 l4 -4"/></svg>';

	$columns =
		blank_base_pb_feature_column( $bolt, esc_html__( 'Fast &amp; lightweight', 'blank-base' ), esc_html__( 'Built for speed with clean, minimal code so your pages load quickly on every device.', 'blank-base' ) ) .
		blank_base_pb_feature_column( $sliders, esc_html__( 'Fully customizable', 'blank-base' ), esc_html__( 'Shape colours, fonts and layout from the Customizer and block editor — no code required.', 'blank-base' ) ) .
		blank_base_pb_feature_column( $shield, esc_html__( 'Accessible by default', 'blank-base' ), esc_html__( 'Semantic markup, keyboard navigation and strong contrast, right out of the box.', 'blank-base' ) );

	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"3.5rem","bottom":"3.5rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:3.5rem;padding-bottom:3.5rem"><!-- wp:columns -->
<div class="wp-block-columns">' . $columns . '</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->';
}

/**
 * A single feature column with icon.
 *
 * @param string $icon  SVG markup.
 * @param string $title Heading.
 * @param string $text  Description.
 * @return string
 */
function blank_base_pb_feature_column( $icon, $title, $text ) {
	return '<!-- wp:column -->
<div class="wp-block-column">' . blank_base_feature_icon( $icon ) . '<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"1.35rem"}}} -->
<h3 class="wp-block-heading" style="font-size:1.35rem">' . $title . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"color":{"text":"#6c6c6c"}}} -->
<p class="has-text-color" style="color:#6c6c6c">' . $text . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->';
}

/**
 * A single stat column.
 *
 * @param string $num   Number.
 * @param string $label Label.
 * @return string
 */
function blank_base_pb_stat( $num, $label ) {
	return '<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontSize":"2.75rem"},"color":{"text":"#0073aa"}}} -->
<h3 class="wp-block-heading has-text-align-center has-text-color" style="color:#0073aa;font-size:2.75rem">' . esc_html( $num ) . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#6c6c6c"}}} -->
<p class="has-text-align-center has-text-color" style="color:#6c6c6c">' . esc_html( $label ) . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->';
}

/**
 * Four-column stats row.
 *
 * @return string
 */
function blank_base_pb_stats() {
	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:3rem;padding-bottom:3rem"><!-- wp:columns -->
<div class="wp-block-columns">' .
		blank_base_pb_stat( '10k+', esc_html__( 'Active users', 'blank-base' ) ) .
		blank_base_pb_stat( '4.9/5', esc_html__( 'Average rating', 'blank-base' ) ) .
		blank_base_pb_stat( '120+', esc_html__( 'Countries served', 'blank-base' ) ) .
		blank_base_pb_stat( '99.9%', esc_html__( 'Uptime', 'blank-base' ) ) .
		'</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->';
}

/**
 * Pricing table with a highlighted tier.
 *
 * @return string
 */
function blank_base_pb_pricing() {
	$starter = blank_base_pricing_column(
		esc_html__( 'Starter', 'blank-base' ),
		'$9',
		esc_html__( '/mo', 'blank-base' ),
		array( esc_html__( 'Up to 3 projects', 'blank-base' ), esc_html__( 'Basic analytics', 'blank-base' ), esc_html__( 'Email support', 'blank-base' ) ),
		esc_html__( 'Choose Starter', 'blank-base' ),
		false
	);
	$pro     = blank_base_pricing_column(
		esc_html__( 'Pro', 'blank-base' ),
		'$29',
		esc_html__( '/mo', 'blank-base' ),
		array( esc_html__( 'Unlimited projects', 'blank-base' ), esc_html__( 'Advanced analytics', 'blank-base' ), esc_html__( 'Priority support', 'blank-base' ) ),
		esc_html__( 'Choose Pro', 'blank-base' ),
		true
	);
	$team    = blank_base_pricing_column(
		esc_html__( 'Team', 'blank-base' ),
		'$79',
		esc_html__( '/mo', 'blank-base' ),
		array( esc_html__( 'Everything in Pro', 'blank-base' ), esc_html__( 'Team collaboration', 'blank-base' ), esc_html__( 'Dedicated manager', 'blank-base' ) ),
		esc_html__( 'Choose Team', 'blank-base' ),
		false
	);

	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:3rem;padding-bottom:3rem"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">' . esc_html__( 'Simple, transparent pricing', 'blank-base' ) . '</h2>
<!-- /wp:heading -->

<!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">' . $starter . $pro . $team . '</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->';
}

/**
 * A single pricing column.
 *
 * @param string $plan     Plan name.
 * @param string $price    Price.
 * @param string $per      Billing period suffix.
 * @param array  $features Feature strings.
 * @param string $button   Button label.
 * @param bool   $featured Whether this tier is highlighted.
 * @return string
 */
function blank_base_pricing_column( $plan, $price, $per, $features, $button, $featured = false ) {
	$items = '';
	foreach ( $features as $feature ) {
		$items .= '<!-- wp:list-item --><li>' . esc_html( $feature ) . '</li><!-- /wp:list-item -->
';
	}

	$col_attr = $featured
		? '{"verticalAlignment":"center","style":{"border":{"width":"2px","color":"#0073aa","radius":"10px"},"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"1.5rem","right":"1.5rem"}}}}'
		: '{"verticalAlignment":"center","style":{"border":{"width":"1px","radius":"10px"},"color":{"border":"#e2e2e2"},"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"1.5rem","right":"1.5rem"}}}}';

	$col_class = $featured
		? 'wp-block-column is-vertically-aligned-center has-border-color" style="border-color:#0073aa;border-width:2px;border-radius:10px;padding-top:2rem;padding-right:1.5rem;padding-bottom:2rem;padding-left:1.5rem'
		: 'wp-block-column is-vertically-aligned-center has-border-color" style="border-color:#e2e2e2;border-width:1px;border-radius:10px;padding-top:2rem;padding-right:1.5rem;padding-bottom:2rem;padding-left:1.5rem';

	$badge = $featured
		? '<!-- wp:paragraph {"align":"center","style":{"typography":{"textTransform":"uppercase","letterSpacing":"1px","fontSize":"0.72rem","fontStyle":"normal","fontWeight":"700"},"color":{"text":"#0073aa"}}} -->
<p class="has-text-align-center has-text-color" style="color:#0073aa;font-size:0.72rem;font-style:normal;font-weight:700;letter-spacing:1px;text-transform:uppercase">' . esc_html__( 'Most popular', 'blank-base' ) . '</p>
<!-- /wp:paragraph -->
'
		: '';

	return '<!-- wp:column ' . $col_attr . ' -->
<div class="' . $col_class . '">' . $badge . '<!-- wp:heading {"textAlign":"center","level":3} -->
<h3 class="wp-block-heading has-text-align-center">' . esc_html( $plan ) . '</h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"typography":{"fontSize":"2.5rem"}}} -->
<h4 class="wp-block-heading has-text-align-center" style="font-size:2.5rem">' . esc_html( $price ) . '<span style="font-size:1rem;color:#6c6c6c">' . esc_html( $per ) . '</span></h4>
<!-- /wp:heading -->

<!-- wp:list {"className":"is-style-none bb-check-list"} -->
<ul class="wp-block-list is-style-none bb-check-list">' . $items . '</ul>
<!-- /wp:list -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"' . ( $featured ? '' : 'is-style-outline' ) . '"} -->
<div class="wp-block-button ' . ( $featured ? '' : 'is-style-outline' ) . '"><a class="wp-block-button__link wp-element-button">' . esc_html( $button ) . '</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column -->';
}

/**
 * Testimonial.
 *
 * @return string
 */
function blank_base_pb_testimonial() {
	return '<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:3rem;padding-bottom:3rem"><!-- wp:quote {"className":"is-style-large"} -->
<blockquote class="wp-block-quote is-style-large"><!-- wp:paragraph -->
<p>' . esc_html__( '“This is exactly what we needed — simple to set up and a pleasure to use every single day. It has quietly become part of how our whole team works.”', 'blank-base' ) . '</p>
<!-- /wp:paragraph --><cite>' . esc_html__( 'Alex Rivera, Product Lead at Northwind', 'blank-base' ) . '</cite></blockquote>
<!-- /wp:quote --></div>
<!-- /wp:group -->';
}

/**
 * Call to action.
 *
 * @return string
 */
function blank_base_pb_cta() {
	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"3.5rem","bottom":"3.5rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:3.5rem;padding-bottom:3.5rem"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">' . esc_html__( 'Ready to get started?', 'blank-base' ) . '</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#6c6c6c"}}} -->
<p class="has-text-align-center has-text-color" style="color:#6c6c6c">' . esc_html__( 'Join thousands of others already using our product to do their best work.', 'blank-base' ) . '</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"style":{"spacing":{"padding":{"left":"1.8rem","right":"1.8rem","top":"0.8rem","bottom":"0.8rem"}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" style="padding-top:0.8rem;padding-right:1.8rem;padding-bottom:0.8rem;padding-left:1.8rem">' . esc_html__( 'Get started', 'blank-base' ) . '</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->';
}

/**
 * About section (image + story).
 *
 * @return string
 */
function blank_base_pb_about() {
	return '<!-- wp:media-text {"mediaType":"image","mediaWidth":48,"align":"wide","style":{"spacing":{"padding":{"top":"1rem","bottom":"1rem"}}}} -->
<div class="wp-block-media-text alignwide is-stacked-on-mobile" style="grid-template-columns:48% auto;padding-top:1rem;padding-bottom:1rem"><figure class="wp-block-media-text__media"><img src="' . blank_base_img_url( 'placeholder-square.svg' ) . '" alt=""/></figure><div class="wp-block-media-text__content"><!-- wp:heading -->
<h2 class="wp-block-heading">' . esc_html__( 'About us', 'blank-base' ) . '</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>' . esc_html__( 'We started with a simple idea: make great tools that get out of your way. Today we help teams of every size do their best work, from first draft to finished product.', 'blank-base' ) . '</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button">' . esc_html__( 'Read our story', 'blank-base' ) . '</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:media-text -->';
}

/**
 * Content beside an image (image on the right).
 *
 * @return string
 */
function blank_base_pb_content_image() {
	return '<!-- wp:media-text {"mediaPosition":"right","mediaType":"image","mediaWidth":48,"align":"wide","style":{"spacing":{"padding":{"top":"1rem","bottom":"1rem"}}}} -->
<div class="wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile" style="grid-template-columns:auto 48%;padding-top:1rem;padding-bottom:1rem"><div class="wp-block-media-text__content"><!-- wp:heading -->
<h2 class="wp-block-heading">' . esc_html__( 'Designed around your workflow', 'blank-base' ) . '</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>' . esc_html__( 'Explain a single idea here and pair it with a supporting image. Keep the text focused on one clear takeaway for the reader.', 'blank-base' ) . '</p>
<!-- /wp:paragraph --></div><figure class="wp-block-media-text__media"><img src="' . blank_base_img_url( 'placeholder-wide.svg' ) . '" alt=""/></figure></div>
<!-- /wp:media-text -->';
}

/**
 * FAQ (expandable details).
 *
 * @return string
 */
function blank_base_pb_faq() {
	return '<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:3rem;padding-bottom:3rem"><!-- wp:heading -->
<h2 class="wp-block-heading">' . esc_html__( 'Frequently asked questions', 'blank-base' ) . '</h2>
<!-- /wp:heading -->' .
		blank_base_faq_item( esc_html__( 'How does the free trial work?', 'blank-base' ), esc_html__( 'Start with a 14-day trial — no credit card required. Cancel any time before it ends and you will not be charged.', 'blank-base' ) ) .
		blank_base_faq_item( esc_html__( 'Can I change plans later?', 'blank-base' ), esc_html__( 'Yes. Upgrade or downgrade whenever you like; changes are prorated automatically.', 'blank-base' ) ) .
		blank_base_faq_item( esc_html__( 'Do you offer support?', 'blank-base' ), esc_html__( 'Every plan includes support. Pro and Team plans get priority responses from our team.', 'blank-base' ) ) .
		'</div>
<!-- /wp:group -->';
}

/**
 * A single FAQ item.
 *
 * @param string $question Question.
 * @param string $answer   Answer.
 * @return string
 */
function blank_base_faq_item( $question, $answer ) {
	return '<!-- wp:details -->
<details class="wp-block-details"><summary>' . esc_html( $question ) . '</summary><!-- wp:paragraph -->
<p>' . esc_html( $answer ) . '</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->';
}

/**
 * Team grid.
 *
 * @return string
 */
function blank_base_pb_team() {
	$members =
		blank_base_team_member( esc_html__( 'Alex Rivera', 'blank-base' ), esc_html__( 'Founder &amp; CEO', 'blank-base' ) ) .
		blank_base_team_member( esc_html__( 'Sam Chen', 'blank-base' ), esc_html__( 'Head of Design', 'blank-base' ) ) .
		blank_base_team_member( esc_html__( 'Jordan Blake', 'blank-base' ), esc_html__( 'Engineering Lead', 'blank-base' ) ) .
		blank_base_team_member( esc_html__( 'Taylor Kim', 'blank-base' ), esc_html__( 'Customer Success', 'blank-base' ) );

	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:3rem;padding-bottom:3rem"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">' . esc_html__( 'Meet the team', 'blank-base' ) . '</h2>
<!-- /wp:heading -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">' . $members . '</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->';
}

/**
 * A single team-member column.
 *
 * @param string $name Name.
 * @param string $role Role.
 * @return string
 */
function blank_base_team_member( $name, $role ) {
	return '<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"align":"center","width":"120px","height":"120px","scale":"cover","sizeSlug":"large","style":{"border":{"radius":"100%"}}} -->
<figure class="wp-block-image aligncenter size-large is-resized has-custom-border"><img src="' . blank_base_img_url( 'avatar.svg' ) . '" alt="" style="border-radius:100%;object-fit:cover;width:120px;height:120px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":3,"style":{"typography":{"fontSize":"1.15rem"}}} -->
<h3 class="wp-block-heading has-text-align-center" style="font-size:1.15rem">' . $name . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#6c6c6c"}}} -->
<p class="has-text-align-center has-text-color" style="color:#6c6c6c">' . $role . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->';
}

/**
 * Page header.
 *
 * @param string $title Escaped title.
 * @param string $sub   Escaped subtitle.
 * @return string
 */
function blank_base_pb_page_header( $title, $sub ) {
	return '<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"4.5rem","bottom":"3.5rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull" style="padding-top:4.5rem;padding-bottom:3.5rem"><!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"2.75rem"}}} -->
<h1 class="wp-block-heading has-text-align-center" style="font-size:2.75rem">' . $title . '</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.15rem"},"color":{"text":"#6c6c6c"}}} -->
<p class="has-text-align-center has-text-color" style="color:#6c6c6c;font-size:1.15rem">' . $sub . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->';
}

/**
 * Logo cloud.
 *
 * @return string
 */
function blank_base_pb_logos() {
	$logo = '<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:image {"align":"center","width":"140px","sizeSlug":"large","className":"bb-logo"} -->
<figure class="wp-block-image aligncenter size-large is-resized bb-logo"><img src="' . blank_base_img_url( 'logo-placeholder.svg' ) . '" alt="" style="width:140px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->';

	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:3rem;padding-bottom:3rem"><!-- wp:paragraph {"align":"center","style":{"typography":{"textTransform":"uppercase","letterSpacing":"1px","fontSize":"0.8rem"},"color":{"text":"#6c6c6c"}}} -->
<p class="has-text-align-center has-text-color" style="color:#6c6c6c;font-size:0.8rem;letter-spacing:1px;text-transform:uppercase">' . esc_html__( 'Trusted by teams at companies of every size', 'blank-base' ) . '</p>
<!-- /wp:paragraph -->

<!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center">' . str_repeat( $logo, 5 ) . '</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->';
}

/**
 * Newsletter signup band.
 *
 * @return string
 */
function blank_base_pb_newsletter() {
	return '<!-- wp:group {"align":"full","backgroundColor":"border","style":{"spacing":{"padding":{"top":"3.5rem","bottom":"3.5rem","left":"1.5rem","right":"1.5rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-border-background-color has-background" style="padding-top:3.5rem;padding-right:1.5rem;padding-bottom:3.5rem;padding-left:1.5rem"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">' . esc_html__( 'Join our newsletter', 'blank-base' ) . '</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">' . esc_html__( 'Get product updates, articles and resources in your inbox. No spam — unsubscribe anytime.', 'blank-base' ) . '</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">' . esc_html__( 'Subscribe', 'blank-base' ) . '</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->';
}

/**
 * Contact section.
 *
 * @return string
 */
function blank_base_pb_contact() {
	return '<!-- wp:columns {"align":"wide","style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem"}}}} -->
<div class="wp-block-columns alignwide" style="padding-top:2rem;padding-bottom:2rem"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">' . esc_html__( 'Contact details', 'blank-base' ) . '</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item --><li>' . esc_html__( 'hello@example.com', 'blank-base' ) . '</li><!-- /wp:list-item -->
<!-- wp:list-item --><li>' . esc_html__( '+1 (555) 000-0000', 'blank-base' ) . '</li><!-- /wp:list-item -->
<!-- wp:list-item --><li>' . esc_html__( '123 Example Street, City', 'blank-base' ) . '</li><!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">' . esc_html__( 'Send a message', 'blank-base' ) . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>' . esc_html__( 'Add your favourite contact-form block or plugin here. Tell visitors how you will use their details and when to expect a reply.', 'blank-base' ) . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->';
}

/**
 * Latest posts (Query Loop).
 *
 * @return string
 */
function blank_base_pb_latest_posts() {
	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:3rem;padding-bottom:3rem"><!-- wp:heading -->
<h2 class="wp-block-heading">' . esc_html__( 'Latest posts', 'blank-base' ) . '</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":10,"query":{"perPage":3,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","inherit":false},"align":"wide"} -->
<div class="wp-block-query alignwide"><!-- wp:post-template {"layout":{"type":"grid","columnCount":3}} -->
<!-- wp:post-featured-image {"isLink":true,"aspectRatio":"16/9"} /-->

<!-- wp:post-title {"isLink":true,"level":3,"style":{"typography":{"fontSize":"1.2rem"}}} /-->

<!-- wp:post-excerpt {"excerptLength":18} /-->
<!-- /wp:post-template --></div>
<!-- /wp:query --></div>
<!-- /wp:group -->';
}

/**
 * A single numbered step.
 *
 * @param string $num   Number.
 * @param string $title Title.
 * @param string $text  Description.
 * @return string
 */
function blank_base_pb_step( $num, $title, $text ) {
	return '<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"2.25rem"},"color":{"text":"#0073aa"}}} -->
<h3 class="wp-block-heading has-text-color" style="color:#0073aa;font-size:2.25rem">' . esc_html( $num ) . '</h3>
<!-- /wp:heading -->

<!-- wp:heading {"level":4,"style":{"typography":{"fontSize":"1.25rem"}}} -->
<h4 class="wp-block-heading" style="font-size:1.25rem">' . esc_html( $title ) . '</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"color":{"text":"#6c6c6c"}}} -->
<p class="has-text-color" style="color:#6c6c6c">' . esc_html( $text ) . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->';
}

/**
 * Three-step "how it works" row.
 *
 * @return string
 */
function blank_base_pb_steps() {
	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:3rem;padding-bottom:3rem"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">' . esc_html__( 'How it works', 'blank-base' ) . '</h2>
<!-- /wp:heading -->

<!-- wp:columns -->
<div class="wp-block-columns">' .
		blank_base_pb_step( '1', esc_html__( 'Sign up', 'blank-base' ), esc_html__( 'Create your account in under a minute — no credit card required.', 'blank-base' ) ) .
		blank_base_pb_step( '2', esc_html__( 'Set things up', 'blank-base' ), esc_html__( 'Follow the guided steps to tailor everything to how you work.', 'blank-base' ) ) .
		blank_base_pb_step( '3', esc_html__( 'Launch', 'blank-base' ), esc_html__( 'Go live with confidence and start seeing results right away.', 'blank-base' ) ) .
		'</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->';
}

/**
 * A single animated counter column (rendered via an HTML block so the
 * data-* attributes survive; JS animates it into view).
 *
 * @param string $target   Numeric target (e.g. "4.9").
 * @param string $suffix   Suffix appended after the number (e.g. "%", "k+").
 * @param int    $decimals Decimal places to display.
 * @param string $label    Label under the number.
 * @return string
 */
function blank_base_pb_counter( $target, $suffix, $decimals, $label ) {
	// The number is a normal, editable Heading block. The animation script
	// reads the target straight from the heading text the user types
	// (e.g. "4.9/5", "10k+", "500+"), so values are changed in the editor.
	$display = number_format_i18n( (float) $target, $decimals ) . $suffix;

	return '<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"className":"bb-counter","style":{"typography":{"fontSize":"2.75rem"}}} -->
<h3 class="wp-block-heading has-text-align-center bb-counter" style="font-size:2.75rem">' . esc_html( $display ) . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#6c6c6c"}}} -->
<p class="has-text-align-center has-text-color" style="color:#6c6c6c">' . esc_html( $label ) . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->';
}

/**
 * Animated stats counter row.
 *
 * @return string
 */
function blank_base_pb_stats_animated() {
	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:3rem;padding-bottom:3rem"><!-- wp:columns -->
<div class="wp-block-columns">' .
		blank_base_pb_counter( '10', 'k+', 0, esc_html__( 'Active users', 'blank-base' ) ) .
		blank_base_pb_counter( '4.9', '/5', 1, esc_html__( 'Average rating', 'blank-base' ) ) .
		blank_base_pb_counter( '120', '+', 0, esc_html__( 'Countries served', 'blank-base' ) ) .
		blank_base_pb_counter( '99.9', '%', 1, esc_html__( 'Uptime', 'blank-base' ) ) .
		'</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->';
}

/**
 * A single skill/progress bar row.
 *
 * @param string $label Skill label.
 * @param int    $pct   Percentage (0-100).
 * @return string
 */
function blank_base_pb_skill( $label, $pct ) {
	$pct = max( 0, min( 100, (int) $pct ) );

	// A normal, editable Paragraph. The script reads the label and the
	// trailing percentage from the text, then builds and animates the bar.
	// Edit the text (e.g. "Design 92%") right in the editor to change it.
	return '<!-- wp:paragraph {"className":"bb-skill"} -->
<p class="bb-skill">' . esc_html( $label ) . ' ' . esc_html( $pct ) . '%</p>
<!-- /wp:paragraph -->
';
}

/**
 * Skill bars pattern.
 *
 * @return string
 */
function blank_base_pb_skills() {
	return '<!-- wp:group {"style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:3rem;padding-bottom:3rem"><!-- wp:heading -->
<h2 class="wp-block-heading">' . esc_html__( 'What we do best', 'blank-base' ) . '</h2>
<!-- /wp:heading -->' .
		blank_base_pb_skill( esc_html__( 'Design', 'blank-base' ), 92 ) .
		blank_base_pb_skill( esc_html__( 'Development', 'blank-base' ), 85 ) .
		blank_base_pb_skill( esc_html__( 'Marketing', 'blank-base' ), 78 ) .
		blank_base_pb_skill( esc_html__( 'Support', 'blank-base' ), 96 ) .
		'</div>
<!-- /wp:group -->';
}

/**
 * A single slider slide (testimonial).
 *
 * @param string $quote Quote text.
 * @param string $cite  Attribution.
 * @return string
 */
function blank_base_pb_slide( $quote, $cite ) {
	return '<div class="bb-slider__slide"><blockquote class="bb-slider__quote"><p>' . esc_html( $quote ) . '</p><cite>' . esc_html( $cite ) . '</cite></blockquote></div>';
}

/**
 * Testimonial slider (CSS scroll-snap carousel with JS controls).
 *
 * @return string
 */
function blank_base_pb_slider() {
	$slides =
		blank_base_pb_slide( esc_html__( '“Simple to set up and a pleasure to use every day. It has quietly become part of how our whole team works.”', 'blank-base' ), esc_html__( 'Alex Rivera, Product Lead at Northwind', 'blank-base' ) ) .
		blank_base_pb_slide( esc_html__( '“We shipped our new site in a weekend. The patterns gave us a professional starting point out of the box.”', 'blank-base' ), esc_html__( 'Sam Chen, Designer at Loft', 'blank-base' ) ) .
		blank_base_pb_slide( esc_html__( '“Fast, accessible and easy to customise. Exactly what we were looking for in a theme.”', 'blank-base' ), esc_html__( 'Jordan Blake, Engineer at Fielding', 'blank-base' ) );

	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"3rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:3rem;padding-bottom:3rem"><!-- wp:html -->
<div class="bb-slider" data-autoplay="0">
<div class="bb-slider__track">' . $slides . '</div>
<button class="bb-slider__nav bb-slider__prev" type="button" aria-label="' . esc_attr__( 'Previous slide', 'blank-base' ) . '">&#8249;</button>
<button class="bb-slider__nav bb-slider__next" type="button" aria-label="' . esc_attr__( 'Next slide', 'blank-base' ) . '">&#8250;</button>
</div>
<!-- /wp:html --></div>
<!-- /wp:group -->';
}
