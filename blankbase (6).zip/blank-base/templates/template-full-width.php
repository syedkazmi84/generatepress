<?php
/**
 * Template Name: Full Width (No Sidebar)
 *
 * A custom page template with no sidebar. The whole content area is used for a
 * full-width layout. Select it from the Page Attributes → Template dropdown.
 *
 * @link https://developer.wordpress.org/themes/template-files-section/page-template-files/
 *
 * @package Blank_Base
 */

get_header();
?>

	<main id="primary" class="site-main site-main--full-width">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile;
		?>

	</main><!-- #primary -->

<?php
get_footer();
