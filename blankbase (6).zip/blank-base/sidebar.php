<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Blank_Base
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}

// Respect the "No sidebar (full width)" Customizer option.
if ( 'none' === get_theme_mod( 'blank_base_sidebar_position', 'right' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area" aria-label="<?php esc_attr_e( 'Sidebar', 'blank-base' ); ?>">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- #secondary -->
