<?php
/**
 * "Blank Base Help" admin page.
 *
 * A built-in reference under Appearance → Blank Base so the animation classes,
 * mega-menu class, patterns and demo import are documented right in the
 * dashboard — no need to memorise anything.
 *
 * @package Blank_Base
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the help page under the Appearance menu.
 */
function blank_base_register_help_page() {
	add_theme_page(
		esc_html__( 'Blank Base Help', 'blank-base' ),
		esc_html__( 'Blank Base', 'blank-base' ),
		'edit_theme_options',
		'blank-base-help',
		'blank_base_render_help_page'
	);
}
add_action( 'admin_menu', 'blank_base_register_help_page' );

/**
 * Add a "Help" action link on the Themes screen for quick access.
 *
 * @param array $actions Existing action links.
 * @return array
 */
function blank_base_theme_action_link( $actions ) {
	$url  = admin_url( 'themes.php?page=blank-base-help' );
	$link = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Help', 'blank-base' ) . '</a>';
	array_unshift( $actions, $link );
	return $actions;
}
add_filter( 'theme_action_links_' . get_template(), 'blank_base_theme_action_link' );

/**
 * Render a simple two-column reference table.
 *
 * @param string $heading Section heading.
 * @param array  $rows    Array of [ code, description ] pairs.
 */
function blank_base_help_table( $heading, $rows ) {
	echo '<h2>' . esc_html( $heading ) . '</h2>';
	echo '<table class="widefat striped" style="max-width:820px;margin-bottom:2em">';
	echo '<thead><tr><th style="width:230px">' . esc_html__( 'Class / name', 'blank-base' ) . '</th><th>' . esc_html__( 'What it does', 'blank-base' ) . '</th></tr></thead><tbody>';
	foreach ( $rows as $row ) {
		echo '<tr><td><code>' . esc_html( $row[0] ) . '</code></td><td>' . esc_html( $row[1] ) . '</td></tr>';
	}
	echo '</tbody></table>';
}

/**
 * Render the help page.
 */
function blank_base_render_help_page() {
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Blank Base — Help &amp; Reference', 'blank-base' ); ?></h1>
		<p style="max-width:820px">
			<?php esc_html_e( 'Everything below is optional. The quickest way to animate a block is to select it and choose an "Animate: …" option from the Styles panel — no classes to remember. The classes here are for finer control via a block\'s Advanced → Additional CSS class(es) field.', 'blank-base' ); ?>
		</p>

		<?php
		blank_base_help_table(
			esc_html__( 'Scroll animations — one-click (Styles panel)', 'blank-base' ),
			array(
				array( 'Animate: Rise up', esc_html__( 'Fades and rises into view.', 'blank-base' ) ),
				array( 'Animate: Fade in', esc_html__( 'Fades in with no movement.', 'blank-base' ) ),
				array( 'Animate: Zoom in', esc_html__( 'Scales up into view.', 'blank-base' ) ),
				array( 'Animate: Slide from left', esc_html__( 'Slides in from the left.', 'blank-base' ) ),
				array( 'Animate: Slide from right', esc_html__( 'Slides in from the right.', 'blank-base' ) ),
			)
		);

		blank_base_help_table(
			esc_html__( 'Scroll animations — utility classes (any block)', 'blank-base' ),
			array(
				array( 'bb-animate', esc_html__( 'Required. Fades and rises in (the default).', 'blank-base' ) ),
				array( 'bb-fade', esc_html__( 'Fade only, no movement. Combine with bb-animate.', 'blank-base' ) ),
				array( 'bb-from-top', esc_html__( 'Comes down from above.', 'blank-base' ) ),
				array( 'bb-from-left', esc_html__( 'Slides in from the left.', 'blank-base' ) ),
				array( 'bb-from-right', esc_html__( 'Slides in from the right.', 'blank-base' ) ),
				array( 'bb-zoom', esc_html__( 'Scales up into view.', 'blank-base' ) ),
				array( 'bb-delay-1 / bb-delay-2 / bb-delay-3', esc_html__( 'Adds a 0.15 / 0.3 / 0.45s delay (for staggering).', 'blank-base' ) ),
			)
		);
		?>
		<p style="max-width:820px;margin-bottom:2em">
			<em><?php esc_html_e( 'Example: add "bb-animate bb-from-left bb-delay-2" to a block. Animations respect the visitor\'s reduced-motion setting and never hide content if JavaScript is off.', 'blank-base' ); ?></em>
		</p>

		<?php
		blank_base_help_table(
			esc_html__( 'Navigation', 'blank-base' ),
			array(
				array( 'mega-menu', esc_html__( 'Add to a top-level menu item (enable CSS Classes via Screen Options in Appearance → Menus) to make its submenu span full width in columns.', 'blank-base' ) ),
			)
		);

		blank_base_help_table(
			esc_html__( 'Interactive patterns', 'blank-base' ),
			array(
				array( 'Animated stats counter', esc_html__( 'Edit the number as a normal Heading, e.g. "4.9/5" or "10k+".', 'blank-base' ) ),
				array( 'Skill bars', esc_html__( 'Edit each bar as a normal Paragraph, e.g. "Design 92%".', 'blank-base' ) ),
				array( 'Testimonial slider', esc_html__( 'A swipeable carousel with previous/next controls.', 'blank-base' ) ),
			)
		);
		?>

		<h2><?php esc_html_e( 'Patterns &amp; demo content', 'blank-base' ); ?></h2>
		<p style="max-width:820px">
			<?php esc_html_e( 'Insert any of the 22 patterns from the block inserter (look under the "Blank Base" and "Blank Base: Pages" categories). To populate a whole demo site, import the bundled demo/blank-base-demo.xml via Tools → Import → WordPress.', 'blank-base' ); ?>
		</p>
		<p>
			<a class="button button-primary" href="<?php echo esc_url( admin_url( 'customize.php' ) ); ?>"><?php esc_html_e( 'Open the Customizer', 'blank-base' ); ?></a>
			<a class="button" href="<?php echo esc_url( admin_url( 'import.php' ) ); ?>"><?php esc_html_e( 'Import demo content', 'blank-base' ); ?></a>
		</p>
	</div>
	<?php
}
