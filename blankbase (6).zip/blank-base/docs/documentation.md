# Blank Base — Documentation

Blank Base is a clean, standards-compliant blank starter theme. It ships with
no hard-coded content — you add everything dynamically — but includes every
option a production theme needs.

- **Requires:** WordPress 6.0+, PHP 7.4+
- **Text domain:** `blank-base`
- **License:** GPLv2 or later

---

## 1. Installation

1. Go to **Appearance → Themes → Add New → Upload Theme**.
2. Upload `blank-base.zip` and click **Install Now**, then **Activate**.
3. On a fresh site, open **Appearance → Customize** — the theme's **starter
   content** (sample pages, menus, widgets and a static front page) appears in
   the preview. It is only saved if you click **Publish**.

For customizations, install the bundled **Blank Base Child** theme (see
`blank-base-child/readme.txt`) so your changes survive parent updates.

---

## 2. Customizer options

All options live in **Appearance → Customize**.

### Site Identity
- Logo (with a **Logo Max Height** control under *Header*), site title,
  tagline, site icon.

### Typography
- **Body Font** and **Heading Font** — system stacks plus Google Fonts
  (Inter, Poppins, Roboto, Montserrat, Playfair Display, Lora, Merriweather).
  Google Fonts are only requested when selected.
- **Base Font Size** (12–24px) with live preview.

### Colors & Dark Mode
- **Color Preset** — Classic Blue, Ocean, Forest, Sunset, Royal, Slate, or
  Custom (uses the accent color picker).
- **Dark Mode** — Disabled, Toggle button (default light), or Auto + toggle
  (follows the visitor's OS). Choice is remembered per-visitor, with a
  no-flash loader.

### Header
- **Header Layout** — Branding left / Centered / Minimal.
- **Sticky Header**, **Announcement Bar Text** (dismissible bar),
  **Show Search in Header**, **Logo Max Height**.

### Blog & Posts
- **Blog Layout** — List / Grid / Masonry.
- Toggles: Reading Time, Reading Progress Bar, Table of Contents,
  Related Posts, Author Box, Social Share.

### Theme Options
- Sidebar Position (right / left / none), Content Width, Sticky Sidebar,
  Breadcrumbs, Back-to-Top button, Footer Text, Accent Color.

---

## 3. Menus

Three menu locations (**Appearance → Menus**):

| Location | Purpose |
| --- | --- |
| Primary Menu | Main header navigation (supports dropdowns) |
| Footer Menu | Simple footer links |
| Social Links Menu | Rendered as pill links in the footer |

**Mega menu:** add the CSS class `mega-menu` to a top-level menu item (enable
*CSS Classes* via Screen Options in the Menus screen) to display its submenu
full-width in columns.

---

## 4. Widget areas

- **Sidebar** — main sidebar.
- **Footer 1 / 2 / 3** — three footer columns.

Add widgets in **Appearance → Widgets**.

---

## 5. Page templates

Set via **Page → Page Attributes → Template**:

- **Default** — content with sidebar (per Customizer).
- **Full Width (No Sidebar)** — content spans the full container.
- **Blank Canvas (No Header/Footer)** — bare content for landing / coming-soon
  pages; ideal with the block editor.

---

## 6. Block patterns

19 production-ready patterns with professional default copy and bundled
placeholder imagery — just insert and edit.

- **Blank Base** category (sections): Hero, Three features with icons,
  Stats row, Pricing (highlighted tier), Testimonial, Call to action, About,
  Content + image, FAQ, Team, Page header, Logo cloud, Newsletter, Contact,
  Latest posts (Query Loop), How it works (steps).
- **Interactive** (lightweight vanilla JS, respects reduced-motion):
  Animated stats counter, Skill bars, Testimonial slider. These are edited
  like any other block — the counter is a **Heading** (type e.g. `4.9/5`,
  `10k+`, `500+`) and each skill bar is a **Paragraph** (type e.g.
  `Design 92%`). The script reads the value from the text you type, so there
  is no HTML to edit and you can duplicate a block to add more.
- **Blank Base: Pages** category (full-page layouts, also offered in the
  pattern picker when you create a Page): Landing, About, Contact.

Interactive patterns are enhanced by `assets/js/theme.js` using
`IntersectionObserver` — no jQuery or third-party libraries.

Placeholder images live in `assets/images/` — replace them with your own.

## 7. Block styles

Extra variations in the block toolbar: Image → *Framed* / *Rounded*,
Button → *Pill*, Paragraph → *Lead*, Separator → *Thick*.

## 7a. Scroll animations (any block)

Reveal any block as it scrolls into view. Two ways:

1. **One click** — select a block, open the **Styles** panel and choose
   *Animate: Rise up*, *Animate: Fade in* or *Animate: Zoom in* (available on
   paragraphs, headings, images, groups, columns, buttons, cover, quote, list
   and media-text).
2. **Any block** — open **Advanced → Additional CSS class(es)** and add:
   - `bb-animate` — fade + rise (default)
   - direction: `bb-from-top`, `bb-from-left`, `bb-from-right`, `bb-zoom`,
     or `bb-fade` (fade only)
   - delay: `bb-delay-1`, `bb-delay-2`, `bb-delay-3`
   - e.g. `bb-animate bb-from-left bb-delay-2`

Animations honour *prefers-reduced-motion* and never hide content when
JavaScript is disabled (the hidden start state is scoped to `html.js`).

---

## 7b. Demo content

A ready-to-use demo site (themed as an AI-tools directory) ships in
`demo/blank-base-demo.xml`. Import it via **Tools → Import → WordPress**, then
set the static front page and menu location. Full steps are in
`demo/README.md`. Regenerate it with `php tools/generate-demo.php`.

## 8. Translation

The theme is translation-ready (`blank-base` text domain). A template lives at
`languages/blank-base.pot`. After changing strings, regenerate it with
`wp i18n make-pot . languages/blank-base.pot`.

---

## 9. File map

```
blank-base/
├── *.php                    Template hierarchy (index, single, page, archive, …)
├── template-parts/          Reusable content partials
├── templates/               Custom page templates
├── inc/                     Setup, customizer, dynamic CSS, features, patterns
├── assets/js/               navigation, theme (dark mode / back-to-top / …), customizer
├── assets/css/              editor-style, print
├── languages/               Translation template
└── theme.json               Block editor presets
```
