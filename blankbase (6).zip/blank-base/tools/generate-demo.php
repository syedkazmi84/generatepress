<?php
/**
 * Demo content (WXR) generator for Blank Base.
 *
 * Produces demo/blank-base-demo.xml — an AI-tools-directory demo site that can
 * be imported via Tools → Import → WordPress. Run from the CLI:
 *
 *     php tools/generate-demo.php
 *
 * This is a development helper; it is not loaded by the theme at runtime.
 *
 * @package Blank_Base
 */

$site = 'https://example.com';
$now  = time();

/** CDATA-wrap a string, escaping any accidental terminator. */
function bb_cdata( $s ) {
	return '<![CDATA[' . str_replace( ']]>', ']]]]><![CDATA[>', (string) $s ) . ']]>';
}
/** Escape text for XML element content. */
function bb_x( $s ) {
	return htmlspecialchars( (string) $s, ENT_QUOTES | ENT_XML1, 'UTF-8' );
}
/** Date helpers. */
function bb_pub( $ts ) {
	return gmdate( 'D, d M Y H:i:s +0000', $ts );
}
function bb_date( $ts ) {
	return gmdate( 'Y-m-d H:i:s', $ts );
}

/* ---------------------------------------------------------------------------
 * Taxonomy: categories for an AI-tools directory.
 * ------------------------------------------------------------------------- */
$categories = array(
	array( 100, 'ai-writing', 'AI Writing' ),
	array( 101, 'chatbots', 'AI Chatbots' ),
	array( 102, 'image-generation', 'Image Generation' ),
	array( 103, 'code-assistants', 'Code Assistants' ),
	array( 104, 'video-ai', 'Video &amp; Audio' ),
	array( 105, 'productivity', 'Productivity' ),
);

/* ---------------------------------------------------------------------------
 * Reusable block-markup builders (AI-tools themed).
 * ------------------------------------------------------------------------- */
function bb_hero() {
	return '<!-- wp:cover {"customOverlayColor":"#0073aa","isUserOverlayColor":true,"minHeight":440,"align":"full","layout":{"type":"constrained"}} -->
<div class="wp-block-cover alignfull" style="min-height:440px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-100 has-background-dim" style="background-color:#0073aa"></span><div class="wp-block-cover__inner-container"><!-- wp:heading {"textAlign":"center","level":1,"style":{"typography":{"fontSize":"3.25rem","lineHeight":"1.1"},"color":{"text":"#ffffff"}}} -->
<h1 class="wp-block-heading has-text-align-center has-text-color" style="color:#ffffff;font-size:3.25rem;line-height:1.1">Discover the best AI tools</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"1.25rem"},"color":{"text":"#ffffff"}}} -->
<p class="has-text-align-center has-text-color" style="color:#ffffff;font-size:1.25rem">A hand-picked directory of AI tools for writing, images, code and more — reviewed and updated every week.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"white","textColor":"foreground"} -->
<div class="wp-block-button"><a class="wp-block-button__link has-foreground-color has-white-background-color has-text-color has-background wp-element-button">Browse tools</a></div>
<!-- /wp:button -->

<!-- wp:button {"textColor":"white","className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-white-color has-text-color wp-element-button">Submit a tool</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:cover -->';
}

function bb_categories_grid() {
	$cats = array(
		array( 'AI Writing', 'Assistants that draft, edit and polish your copy.' ),
		array( 'Image Generation', 'Turn a prompt into original artwork and photos.' ),
		array( 'Code Assistants', 'Autocomplete, review and ship code faster.' ),
		array( 'AI Chatbots', 'Conversational assistants for every task.' ),
	);
	$cols = '';
	foreach ( $cats as $c ) {
		$cols .= '<!-- wp:column {"style":{"border":{"width":"1px","radius":"8px"},"color":{"border":"#e2e2e2"},"spacing":{"padding":{"top":"1.25rem","bottom":"1.25rem","left":"1.25rem","right":"1.25rem"}}}} -->
<div class="wp-block-column has-border-color" style="border-color:#e2e2e2;border-width:1px;border-radius:8px;padding-top:1.25rem;padding-right:1.25rem;padding-bottom:1.25rem;padding-left:1.25rem"><!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"1.2rem"}}} -->
<h3 class="wp-block-heading" style="font-size:1.2rem">' . $c[0] . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"color":{"text":"#6c6c6c"}}} -->
<p class="has-text-color" style="color:#6c6c6c">' . $c[1] . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->';
	}

	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"3.5rem","bottom":"1rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:3.5rem;padding-bottom:1rem"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Browse by category</h2>
<!-- /wp:heading -->

<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide">' . $cols . '</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->';
}

function bb_stats() {
	$stat = function ( $display, $label ) {
		return '<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":3,"className":"bb-counter","style":{"typography":{"fontSize":"2.75rem"}}} -->
<h3 class="wp-block-heading has-text-align-center bb-counter" style="font-size:2.75rem">' . $display . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#6c6c6c"}}} -->
<p class="has-text-align-center has-text-color" style="color:#6c6c6c">' . $label . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->';
	};

	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"2rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:2rem;padding-bottom:3rem"><!-- wp:columns -->
<div class="wp-block-columns">' .
		$stat( '500+', 'Tools listed' ) .
		$stat( '40+', 'Categories' ) .
		$stat( '4.8/5', 'Average rating' ) .
		$stat( '12k+', 'Monthly readers' ) .
		'</div>
<!-- /wp:columns --></div>
<!-- /wp:group -->';
}

function bb_latest() {
	return '<!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"2rem","bottom":"3rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignwide" style="padding-top:2rem;padding-bottom:3rem"><!-- wp:heading -->
<h2 class="wp-block-heading">Latest reviews</h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":20,"query":{"perPage":3,"pages":0,"offset":0,"postType":"post","order":"desc","orderBy":"date","inherit":false},"align":"wide"} -->
<div class="wp-block-query alignwide"><!-- wp:post-template {"layout":{"type":"grid","columnCount":3}} -->
<!-- wp:post-title {"isLink":true,"level":3,"style":{"typography":{"fontSize":"1.2rem"}}} /-->
<!-- wp:post-excerpt {"excerptLength":18} /-->
<!-- /wp:post-template --></div>
<!-- /wp:query --></div>
<!-- /wp:group -->';
}

function bb_cta() {
	return '<!-- wp:group {"align":"full","backgroundColor":"border","style":{"spacing":{"padding":{"top":"3.5rem","bottom":"3.5rem"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group alignfull has-border-background-color has-background" style="padding-top:3.5rem;padding-bottom:3.5rem"><!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Know a great AI tool?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Submit it to the directory and help thousands of readers discover it.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Submit a tool</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->';
}

/* ---------------------------------------------------------------------------
 * Pages.
 * ------------------------------------------------------------------------- */
$home_content = bb_hero() . bb_categories_grid() . bb_stats() . bb_latest() . bb_cta();

$about_content = '<!-- wp:paragraph {"style":{"typography":{"fontSize":"1.2rem"}}} -->
<p style="font-size:1.2rem">We help people cut through the noise and find the right AI tool for the job — without the hype.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Every week our editors test new AI tools across writing, images, code, audio and productivity. We publish honest, hands-on reviews and keep our directory current so you always have a trustworthy starting point.</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What we look for</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item --><li>Real usefulness on everyday tasks, not just demos.</li><!-- /wp:list-item -->
<!-- wp:list-item --><li>Transparent, fair pricing.</li><!-- /wp:list-item -->
<!-- wp:list-item --><li>Privacy and data handling you can trust.</li><!-- /wp:list-item -->
<!-- wp:list-item --><li>Active development and responsive support.</li><!-- /wp:list-item --></ul>
<!-- /wp:list -->';

$contact_content = '<!-- wp:paragraph -->
<p>Have a question, a correction or a tool to suggest? We usually reply within one business day.</p>
<!-- /wp:paragraph -->

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Get in touch</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item --><li>hello@example.com</li><!-- /wp:list-item -->
<!-- wp:list-item --><li>@exampleaitools</li><!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Submit a tool</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Add your favourite contact-form block or plugin here to collect tool submissions.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->';

$pages = array(
	array( 'id' => 2001, 'title' => 'Home', 'slug' => 'home', 'content' => $home_content, 'order' => 0 ),
	array( 'id' => 2004, 'title' => 'Blog', 'slug' => 'blog', 'content' => '', 'order' => 0 ),
	array( 'id' => 2002, 'title' => 'About', 'slug' => 'about', 'content' => $about_content, 'order' => 0 ),
	array( 'id' => 2003, 'title' => 'Contact', 'slug' => 'contact', 'content' => $contact_content, 'order' => 0 ),
);

/* ---------------------------------------------------------------------------
 * Posts (AI-tool reviews / round-ups).
 * ------------------------------------------------------------------------- */
function bb_post_body( $intro, $listTitle, $items, $closing ) {
	$li = '';
	foreach ( $items as $it ) {
		$li .= '<!-- wp:list-item --><li><strong>' . $it[0] . '</strong> — ' . $it[1] . '</li><!-- /wp:list-item -->
';
	}
	return '<!-- wp:paragraph -->
<p>' . $intro . '</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">' . $listTitle . '</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list">' . $li . '</ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>' . $closing . '</p>
<!-- /wp:paragraph -->';
}

$posts = array(
	array(
		'id' => 3001, 'title' => 'The 8 best AI writing assistants in 2025', 'slug' => 'best-ai-writing-assistants-2025',
		'cat' => array( 'ai-writing', 'AI Writing' ), 'tags' => array( 'writing', 'copywriting', 'round-up' ),
		'excerpt' => 'From long-form drafting to quick rewrites, these are the AI writing tools worth your time this year.',
		'body' => bb_post_body(
			'AI writing tools have gone from novelty to daily driver. We tested the leading options on real briefs — blog posts, emails and product copy — and ranked them on quality, control and value.',
			'Our top picks',
			array(
				array( 'Best overall', 'balanced quality and control for most writers.' ),
				array( 'Best for long-form', 'keeps tone consistent across thousands of words.' ),
				array( 'Best free option', 'surprisingly capable without a subscription.' ),
			),
			'Whichever you choose, treat AI as a first-draft partner: it accelerates the blank page, but your judgement still ships the work.'
		),
	),
	array(
		'id' => 3002, 'title' => 'ChatGPT vs Claude vs Gemini: which AI chatbot wins?', 'slug' => 'chatgpt-vs-claude-vs-gemini',
		'cat' => array( 'chatbots', 'AI Chatbots' ), 'tags' => array( 'comparison', 'chatbot', 'assistant' ),
		'excerpt' => 'We put the three leading AI chatbots head-to-head on reasoning, writing and everyday tasks.',
		'body' => bb_post_body(
			'The big three chatbots each have a personality and a sweet spot. We ran the same prompts through all of them to see where each one pulls ahead.',
			'How they compare',
			array(
				array( 'Reasoning', 'strong across the board, with clear edges on complex prompts.' ),
				array( 'Writing', 'noticeable differences in tone and length control.' ),
				array( 'Everyday help', 'speed and availability matter as much as raw quality.' ),
			),
			'There is no single winner — the best chatbot is the one that fits how you actually work.'
		),
	),
	array(
		'id' => 3003, 'title' => 'Best AI image generators, compared', 'slug' => 'best-ai-image-generators',
		'cat' => array( 'image-generation', 'Image Generation' ), 'tags' => array( 'images', 'design', 'round-up' ),
		'excerpt' => 'Photoreal, illustrative or logo-ready — the right AI image generator depends on what you are making.',
		'body' => bb_post_body(
			'Image models have matured fast. We compared the most popular generators on prompt accuracy, style range and licensing.',
			'What to look for',
			array(
				array( 'Prompt accuracy', 'how closely the output matches your description.' ),
				array( 'Style range', 'from photorealism to clean vector illustration.' ),
				array( 'Licensing', 'check commercial-use terms before you ship.' ),
			),
			'Start with a free tier to learn each model’s quirks, then upgrade only for the one that fits your style.'
		),
	),
	array(
		'id' => 3004, 'title' => '5 AI coding assistants that actually save time', 'slug' => 'ai-coding-assistants',
		'cat' => array( 'code-assistants', 'Code Assistants' ), 'tags' => array( 'coding', 'developers', 'productivity' ),
		'excerpt' => 'Autocomplete is table stakes. These AI coding assistants help with reviews, tests and refactors too.',
		'body' => bb_post_body(
			'The best AI coding tools do more than finish your line — they explain code, suggest tests and catch bugs before review.',
			'Where they help most',
			array(
				array( 'In-editor completion', 'fast, context-aware suggestions as you type.' ),
				array( 'Code review', 'a helpful second pair of eyes on every change.' ),
				array( 'Tests &amp; refactors', 'scaffold coverage and modernise old code.' ),
			),
			'Keep a human in the loop: AI is a fast junior pair, not a replacement for understanding your codebase.'
		),
	),
	array(
		'id' => 3005, 'title' => 'A practical guide to AI video and audio tools', 'slug' => 'ai-video-audio-tools',
		'cat' => array( 'video-ai', 'Video &amp; Audio' ), 'tags' => array( 'video', 'audio', 'guide' ),
		'excerpt' => 'From transcription to talking-head video, here is how to pick AI media tools that fit your workflow.',
		'body' => bb_post_body(
			'AI video and audio tools can cut hours from editing — if you pick the right one. We break the field down by job to be done.',
			'Match the tool to the task',
			array(
				array( 'Transcription', 'fast, accurate text from any recording.' ),
				array( 'Voice &amp; dubbing', 'natural narration in many languages.' ),
				array( 'Video generation', 'turn a script into a polished clip.' ),
			),
			'Always review AI media before publishing — a quick human pass keeps quality and trust high.'
		),
	),
	array(
		'id' => 3006, 'title' => 'The rise of AI productivity tools', 'slug' => 'rise-of-ai-productivity-tools',
		'cat' => array( 'productivity', 'Productivity' ), 'tags' => array( 'productivity', 'workflow', 'automation' ),
		'excerpt' => 'AI is quietly moving into your notes, inbox and calendar. Here is how to adopt it without the chaos.',
		'body' => bb_post_body(
			'Beyond chatbots, AI is embedding itself into the everyday apps you already use — summarising notes, triaging email and planning your day.',
			'Adopt it sensibly',
			array(
				array( 'Start small', 'automate one annoying task before ten.' ),
				array( 'Keep control', 'review AI suggestions before they act.' ),
				array( 'Protect data', 'know what leaves your device and where it goes.' ),
			),
			'The goal is not to do more things — it is to spend your attention on the ones that matter.'
		),
	),
);

/* ---------------------------------------------------------------------------
 * Primary navigation menu.
 * ------------------------------------------------------------------------- */
$menu_items = array(
	array( 4001, 'Home', 2001 ),
	array( 4002, 'Blog', 2004 ),
	array( 4003, 'About', 2002 ),
	array( 4004, 'Contact', 2003 ),
);

/* ---------------------------------------------------------------------------
 * Build the WXR.
 * ------------------------------------------------------------------------- */
$out  = '<?xml version="1.0" encoding="UTF-8" ?>' . "\n";
$out .= '<rss version="2.0"' . "\n";
$out .= '	xmlns:excerpt="http://wordpress.org/export/1.2/excerpt/"' . "\n";
$out .= '	xmlns:content="http://purl.org/rss/1.0/modules/content/"' . "\n";
$out .= '	xmlns:wfw="http://wellformedweb.org/CommentAPI/"' . "\n";
$out .= '	xmlns:dc="http://purl.org/dc/elements/1.1/"' . "\n";
$out .= '	xmlns:wp="http://wordpress.org/export/1.2/">' . "\n";
$out .= "<channel>\n";
$out .= '	<title>Blank Base Demo — AI Tools Directory</title>' . "\n";
$out .= '	<link>' . bb_x( $site ) . "</link>\n";
$out .= '	<description>Professional demo content for the Blank Base theme, themed as an AI-tools directory.</description>' . "\n";
$out .= '	<pubDate>' . bb_pub( $now ) . "</pubDate>\n";
$out .= "	<language>en-US</language>\n";
$out .= "	<wp:wxr_version>1.2</wp:wxr_version>\n";
$out .= '	<wp:base_site_url>' . bb_x( $site ) . "</wp:base_site_url>\n";
$out .= '	<wp:base_blog_url>' . bb_x( $site ) . "</wp:base_blog_url>\n";
$out .= "	<wp:author><wp:author_id>1</wp:author_id><wp:author_login>" . bb_cdata( 'editor' ) . '</wp:author_login><wp:author_email>' . bb_cdata( 'editor@example.com' ) . '</wp:author_email><wp:author_display_name>' . bb_cdata( 'Editor' ) . '</wp:author_display_name><wp:author_first_name>' . bb_cdata( '' ) . '</wp:author_first_name><wp:author_last_name>' . bb_cdata( '' ) . "</wp:author_last_name></wp:author>\n";

foreach ( $categories as $c ) {
	$out .= '	<wp:category><wp:term_id>' . $c[0] . '</wp:term_id><wp:category_nicename>' . bb_cdata( $c[1] ) . '</wp:category_nicename><wp:category_parent>' . bb_cdata( '' ) . '</wp:category_parent><wp:cat_name>' . bb_cdata( html_entity_decode( $c[2] ) ) . "</wp:cat_name></wp:category>\n";
}

// Nav menu term.
$out .= '	<wp:term><wp:term_id>5001</wp:term_id><wp:term_taxonomy>' . bb_cdata( 'nav_menu' ) . '</wp:term_taxonomy><wp:term_slug>' . bb_cdata( 'primary-menu' ) . '</wp:term_slug><wp:term_name>' . bb_cdata( 'Primary Menu' ) . "</wp:term_name></wp:term>\n";

/** Emit a page or post item. */
function bb_item( $args ) {
	global $site;
	$ts    = $args['ts'];
	$out   = "	<item>\n";
	$out  .= '		<title>' . bb_x( html_entity_decode( $args['title'] ) ) . "</title>\n";
	$out  .= '		<link>' . bb_x( $site . '/' . $args['slug'] . '/' ) . "</link>\n";
	$out  .= '		<pubDate>' . bb_pub( $ts ) . "</pubDate>\n";
	$out  .= '		<dc:creator>' . bb_cdata( 'editor' ) . "</dc:creator>\n";
	$out  .= '		<guid isPermaLink="false">' . bb_x( $site . '/?p=' . $args['id'] ) . "</guid>\n";
	$out  .= "		<description></description>\n";
	$out  .= '		<content:encoded>' . bb_cdata( $args['content'] ) . "</content:encoded>\n";
	$out  .= '		<excerpt:encoded>' . bb_cdata( isset( $args['excerpt'] ) ? $args['excerpt'] : '' ) . "</excerpt:encoded>\n";
	$out  .= '		<wp:post_id>' . $args['id'] . "</wp:post_id>\n";
	$out  .= '		<wp:post_date>' . bb_cdata( bb_date( $ts ) ) . "</wp:post_date>\n";
	$out  .= '		<wp:post_date_gmt>' . bb_cdata( bb_date( $ts ) ) . "</wp:post_date_gmt>\n";
	$out  .= '		<wp:comment_status>' . bb_cdata( 'post' === $args['type'] ? 'open' : 'closed' ) . "</wp:comment_status>\n";
	$out  .= '		<wp:ping_status>' . bb_cdata( 'closed' ) . "</wp:ping_status>\n";
	$out  .= '		<wp:post_name>' . bb_cdata( $args['slug'] ) . "</wp:post_name>\n";
	$out  .= '		<wp:status>' . bb_cdata( 'publish' ) . "</wp:status>\n";
	$out  .= '		<wp:post_parent>0</wp:post_parent>' . "\n";
	$out  .= '		<wp:menu_order>' . ( isset( $args['order'] ) ? (int) $args['order'] : 0 ) . "</wp:menu_order>\n";
	$out  .= '		<wp:post_type>' . bb_cdata( $args['type'] ) . "</wp:post_type>\n";
	$out  .= '		<wp:post_password>' . bb_cdata( '' ) . "</wp:post_password>\n";
	$out  .= "		<wp:is_sticky>0</wp:is_sticky>\n";
	if ( isset( $args['template'] ) && $args['template'] ) {
		$out .= '		<wp:postmeta><wp:meta_key>' . bb_cdata( '_wp_page_template' ) . '</wp:meta_key><wp:meta_value>' . bb_cdata( $args['template'] ) . "</wp:meta_value></wp:postmeta>\n";
	}
	if ( isset( $args['cat'] ) ) {
		$out .= '		<category domain="category" nicename="' . bb_x( $args['cat'][0] ) . '">' . bb_cdata( html_entity_decode( $args['cat'][1] ) ) . "</category>\n";
	}
	if ( isset( $args['tags'] ) ) {
		foreach ( $args['tags'] as $tag ) {
			$slug = sanitize_slug( $tag );
			$out .= '		<category domain="post_tag" nicename="' . bb_x( $slug ) . '">' . bb_cdata( $tag ) . "</category>\n";
		}
	}
	$out .= "	</item>\n";
	return $out;
}

/** Minimal slug helper (avoids depending on WP). */
function sanitize_slug( $s ) {
	$s = strtolower( trim( $s ) );
	$s = preg_replace( '/[^a-z0-9]+/', '-', $s );
	return trim( $s, '-' );
}

// Pages.
$i = 0;
foreach ( $pages as $p ) {
	$out .= bb_item(
		array(
			'type'     => 'page',
			'id'       => $p['id'],
			'title'    => $p['title'],
			'slug'     => $p['slug'],
			'content'  => $p['content'],
			'order'    => $p['order'],
			'ts'       => $now - ( 30 * 86400 ),
			'template' => 'home' === $p['slug'] ? 'templates/template-full-width.php' : '',
		)
	);
	$i++;
}

// Posts.
$i = 0;
foreach ( $posts as $p ) {
	$out .= bb_item(
		array(
			'type'    => 'post',
			'id'      => $p['id'],
			'title'   => $p['title'],
			'slug'    => $p['slug'],
			'content' => $p['body'],
			'excerpt' => $p['excerpt'],
			'cat'     => $p['cat'],
			'tags'    => $p['tags'],
			'ts'      => $now - ( ( $i + 1 ) * 5 * 86400 ),
		)
	);
	$i++;
}

// Menu items.
$pos = 1;
foreach ( $menu_items as $m ) {
	$out .= "	<item>\n";
	$out .= '		<title>' . bb_x( $m[1] ) . "</title>\n";
	$out .= '		<link>' . bb_x( $site ) . "</link>\n";
	$out .= '		<pubDate>' . bb_pub( $now ) . "</pubDate>\n";
	$out .= '		<dc:creator>' . bb_cdata( 'editor' ) . "</dc:creator>\n";
	$out .= '		<guid isPermaLink="false">' . bb_x( $site . '/?p=' . $m[0] ) . "</guid>\n";
	$out .= "		<description></description>\n";
	$out .= '		<content:encoded>' . bb_cdata( '' ) . "</content:encoded>\n";
	$out .= '		<excerpt:encoded>' . bb_cdata( '' ) . "</excerpt:encoded>\n";
	$out .= '		<wp:post_id>' . $m[0] . "</wp:post_id>\n";
	$out .= '		<wp:post_date>' . bb_cdata( bb_date( $now ) ) . "</wp:post_date>\n";
	$out .= '		<wp:post_date_gmt>' . bb_cdata( bb_date( $now ) ) . "</wp:post_date_gmt>\n";
	$out .= '		<wp:comment_status>' . bb_cdata( 'closed' ) . "</wp:comment_status>\n";
	$out .= '		<wp:ping_status>' . bb_cdata( 'closed' ) . "</wp:ping_status>\n";
	$out .= '		<wp:post_name>' . bb_cdata( sanitize_slug( $m[1] ) ) . "</wp:post_name>\n";
	$out .= '		<wp:status>' . bb_cdata( 'publish' ) . "</wp:status>\n";
	$out .= '		<wp:post_parent>0</wp:post_parent>' . "\n";
	$out .= '		<wp:menu_order>' . $pos . "</wp:menu_order>\n";
	$out .= '		<wp:post_type>' . bb_cdata( 'nav_menu_item' ) . "</wp:post_type>\n";
	$out .= '		<wp:post_password>' . bb_cdata( '' ) . "</wp:post_password>\n";
	$out .= "		<wp:is_sticky>0</wp:is_sticky>\n";
	$out .= '		<category domain="nav_menu" nicename="primary-menu">' . bb_cdata( 'Primary Menu' ) . "</category>\n";
	$out .= '		<wp:postmeta><wp:meta_key>' . bb_cdata( '_menu_item_type' ) . '</wp:meta_key><wp:meta_value>' . bb_cdata( 'post_type' ) . "</wp:meta_value></wp:postmeta>\n";
	$out .= '		<wp:postmeta><wp:meta_key>' . bb_cdata( '_menu_item_menu_item_parent' ) . '</wp:meta_key><wp:meta_value>' . bb_cdata( '0' ) . "</wp:meta_value></wp:postmeta>\n";
	$out .= '		<wp:postmeta><wp:meta_key>' . bb_cdata( '_menu_item_object_id' ) . '</wp:meta_key><wp:meta_value>' . bb_cdata( (string) $m[2] ) . "</wp:meta_value></wp:postmeta>\n";
	$out .= '		<wp:postmeta><wp:meta_key>' . bb_cdata( '_menu_item_object' ) . '</wp:meta_key><wp:meta_value>' . bb_cdata( 'page' ) . "</wp:meta_value></wp:postmeta>\n";
	$out .= '		<wp:postmeta><wp:meta_key>' . bb_cdata( '_menu_item_target' ) . '</wp:meta_key><wp:meta_value>' . bb_cdata( '' ) . "</wp:meta_value></wp:postmeta>\n";
	$out .= '		<wp:postmeta><wp:meta_key>' . bb_cdata( '_menu_item_classes' ) . '</wp:meta_key><wp:meta_value>' . bb_cdata( 'a:1:{i:0;s:0:"";}' ) . "</wp:meta_value></wp:postmeta>\n";
	$out .= '		<wp:postmeta><wp:meta_key>' . bb_cdata( '_menu_item_xfn' ) . '</wp:meta_key><wp:meta_value>' . bb_cdata( '' ) . "</wp:meta_value></wp:postmeta>\n";
	$out .= '		<wp:postmeta><wp:meta_key>' . bb_cdata( '_menu_item_url' ) . '</wp:meta_key><wp:meta_value>' . bb_cdata( '' ) . "</wp:meta_value></wp:postmeta>\n";
	$out .= "	</item>\n";
	$pos++;
}

$out .= "</channel>\n</rss>\n";

$target = dirname( __DIR__ ) . '/demo/blank-base-demo.xml';
file_put_contents( $target, $out );
echo 'Wrote ' . strlen( $out ) . " bytes to $target\n";
