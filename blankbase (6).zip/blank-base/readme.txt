=== Blank Base ===

Contributors: blankbase
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.9.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: blog, one-column, two-columns, right-sidebar, left-sidebar, custom-background, custom-logo, custom-menu, custom-header, featured-images, footer-widgets, sticky-post, threaded-comments, translation-ready, block-styles, wide-blocks, accessibility-ready, editor-style, full-width-template, rtl-language-support, theme-options

A clean, lightweight and fully standards-compliant blank starter theme for WordPress.

== Description ==

Blank Base is an intentionally blank WordPress theme: it ships with no hard-coded
content. Every piece of data — the logo, menus, widgets, colors, footer text and
all posts and pages — is added dynamically by the site owner through the
WordPress admin, the Customizer and widgets.

Even though it starts blank, Blank Base includes every option and template a
production theme needs:

* The full WordPress template hierarchy (index, single, page, archive, search,
  404, home, front-page, comments and template parts).
* Custom logo, custom header and custom background support.
* Three navigation menu locations (Primary, Footer and Social).
* A sidebar widget area plus three footer widget columns.
* A Customizer "Theme Options" section with sidebar position, accent color and
  footer text — all with live preview.
* theme.json with color palette, typography and spacing presets for the block
  editor, including wide/full alignment and editor styles.
* Accessibility-ready markup: skip links, screen-reader text, keyboard-friendly
  dropdown menus and proper landmark roles.
* Translation-ready with a bundled .pot file, and RTL language support.
* Block editor and block styles support.

== Installation ==

1. In your admin panel, go to Appearance → Themes and click the Add New button.
2. Click Upload Theme and choose the blank-base.zip file, then click Install Now.
3. Click Activate to use the theme.
4. Navigate to Appearance → Customize to configure your options, set a logo,
   choose menus and add widgets.

== Frequently Asked Questions ==

= Does it include demo content? =

The theme itself activates blank — nothing is forced onto your site. If you
want a head start, an optional AI-tools-directory demo is bundled at
demo/blank-base-demo.xml; import it via Tools → Import → WordPress. See
demo/README.md.

= Does it support the block editor? =

Yes. The theme ships a theme.json file, editor styles, block styles and support
for wide and full-width alignments.

= Is it translation ready? =

Yes. All strings use the `blank-base` text domain and a languages/blank-base.pot
file is bundled. RTL layouts are supported via rtl.css.

== Changelog ==

= 1.9.1 =
* Added a design-token layer (font-size, weight, line-height, spacing, radius and motion scales) as CSS variables, and wired the base typography, links, buttons and form fields to it — consistent values, easy to retune in one place.
* Polish: semibold buttons with hover transitions, form-field focus rings, and a visible keyboard focus ring on all interactive elements (accessibility).

= 1.9.0 =
* Added a full typographic scale: explicit sizes and weights for h1–h6 (h1/h2 fluid via clamp), balanced headings, and styling for small, mark, sub/sup, abbr, dl/dt/dd, address, figcaption, ins/del and kbd. Mirrored in the editor.

= 1.8.2 =
* Responsive hardening: wide tables now scroll within their own container, long words/URLs wrap, and embeds/media stay within the content column on small screens (without breaking the sticky header/sidebar).

= 1.8.1 =
* Added a built-in reference page at Appearance → Blank Base (and a "Help" link on the Themes screen) documenting the animation classes, mega-menu class and interactive patterns — so nothing needs to be memorised.
* Added one-click "Animate: Slide from left/right" block styles.

= 1.8.0 =
* Added scroll-reveal animations you can apply to any block: one-click "Animate: Rise up / Fade in / Zoom in" styles on common blocks, or utility classes (bb-animate, bb-from-left, bb-zoom, bb-delay-2, …) via Advanced → Additional CSS class(es). Uses IntersectionObserver, respects prefers-reduced-motion, and never hides content when JavaScript is off.

= 1.7.1 =
* Animated stats and Skill bars are now edited directly in the block editor: the counter is a normal Heading block (type any value like "4.9/5" or "10k+") and each skill bar is a normal Paragraph (type e.g. "Design 92%"). The script reads the value from the text — no HTML editing needed.

= 1.7.0 =
* Added importable demo content (demo/blank-base-demo.xml) themed as an AI-tools directory: a full landing Home page, Blog, About and Contact pages, six AI-tool review posts across six categories, and a primary menu. Includes import instructions (demo/README.md) and a generator (tools/generate-demo.php).

= 1.6.0 =
* Added three interactive patterns (built with lightweight vanilla JS, no libraries): Animated stats counter, Skill bars, and a Testimonial slider.
* All animations respect prefers-reduced-motion and use IntersectionObserver.

= 1.5.0 =
* Reworked all block patterns to be production-ready: professional default copy, bundled SVG placeholder imagery (no empty images), consistent spacing, feature icons, and a highlighted "Most popular" pricing tier.
* Added a separate "Blank Base: Pages" pattern category for the full-page layouts.
* Added pattern helper styles (feature icons, check-mark pricing lists) to the front end and editor.

= 1.4.0 =
* Expanded the block pattern library to 19 patterns.
* New section patterns: Page header, Stats row, Logo cloud, Newsletter signup, Contact section, Latest posts (Query Loop), How it works (steps), Content + image.
* New full-page patterns shown when creating a Page: Landing, About, Contact.

= 1.3.0 =
* Added a bundled child theme (blank-base-child) and a docs/documentation.md guide.
* Added a print stylesheet for clean printed articles.
* Registered custom block styles: Image (Framed, Rounded), Button (Pill), Paragraph (Lead), Separator (Thick).
* Added Sticky Sidebar and Logo Max Height Customizer options.
* Regenerated the translation template (languages/blank-base.pot).

= 1.2.0 =
* Reading experience: blog layout options (list/grid/masonry), reading time, reading-progress bar, auto table of contents, related posts, author box, and social share buttons.
* Navigation: dismissible announcement bar, off-canvas mobile drawer, header search, social-links menu output, and mega-menu support (add the "mega-menu" class to a menu item).
* Pages & onboarding: Blank Canvas page template, starter content for fresh installs, and new About, Pricing, FAQ and Team block patterns.

= 1.1.0 =
* Added a Typography section (body/heading font choices incl. Google Fonts, base font size).
* Added Colors & Dark Mode section: color presets, custom accent, and a light/dark toggle (with auto/OS mode and no-flash loading).
* Added Header section: header layouts (default, centered, minimal) and a sticky header option.
* Added content width, breadcrumbs and back-to-top controls to Theme Options.
* Added schema.org breadcrumbs, a back-to-top button, and new Hero, Features and Testimonial block patterns.

= 1.0.0 =
* Initial release.

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2024 Automattic, Inc.,
  [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2018 Nicolas
  Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
