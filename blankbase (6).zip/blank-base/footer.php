<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Blank_Base
 */

?>
	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
		<?php
		if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) ) :
			?>
			<div class="footer-widgets">
				<?php for ( $blank_base_footer = 1; $blank_base_footer <= 3; $blank_base_footer++ ) : ?>
					<?php if ( is_active_sidebar( 'footer-' . $blank_base_footer ) ) : ?>
						<div class="footer-widget-column footer-widget-column-<?php echo esc_attr( $blank_base_footer ); ?>">
							<?php dynamic_sidebar( 'footer-' . $blank_base_footer ); ?>
						</div>
					<?php endif; ?>
				<?php endfor; ?>
			</div><!-- .footer-widgets -->
			<?php
		endif;

		if ( has_nav_menu( 'menu-2' ) ) :
			?>
			<nav class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer Menu', 'blank-base' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'menu-2',
						'menu_id'        => 'footer-menu',
						'depth'          => 1,
						'container'      => false,
					)
				);
				?>
			</nav>
			<?php
		endif;
		?>

		<?php blank_base_social_menu( 'social-navigation--footer' ); ?>

		<div class="site-info">
			<?php
			$blank_base_copyright = get_theme_mod( 'blank_base_footer_text' );
			if ( $blank_base_copyright ) {
				echo wp_kses_post( $blank_base_copyright );
			} else {
				printf(
					/* translators: 1: Current year, 2: Site name. */
					esc_html__( '&copy; %1$s %2$s. All rights reserved.', 'blank-base' ),
					esc_html( gmdate( 'Y' ) ),
					esc_html( get_bloginfo( 'name' ) )
				);
				echo ' ';
				printf(
					/* translators: %s: WordPress. */
					esc_html__( 'Proudly powered by %s.', 'blank-base' ),
					'<a href="' . esc_url( __( 'https://wordpress.org/', 'blank-base' ) ) . '">WordPress</a>'
				);
			}
			?>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php if ( get_theme_mod( 'blank_base_back_to_top', true ) ) : ?>
	<button class="back-to-top" type="button" aria-label="<?php esc_attr_e( 'Back to top', 'blank-base' ); ?>" title="<?php esc_attr_e( 'Back to top', 'blank-base' ); ?>">
		<span aria-hidden="true">&uarr;</span>
	</button>
<?php endif; ?>

<?php wp_footer(); ?>

</body>
</html>
