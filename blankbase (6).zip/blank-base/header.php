<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything
 * up until <div id="content">.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Blank_Base
 */

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'blank-base' ); ?></a>

	<?php blank_base_announcement_bar(); ?>

	<?php
	$blank_base_header_layout = get_theme_mod( 'blank_base_header_layout', 'default' );
	$blank_base_header_class  = 'site-header header--' . sanitize_html_class( $blank_base_header_layout );
	if ( get_theme_mod( 'blank_base_sticky_header', false ) ) {
		$blank_base_header_class .= ' is-sticky';
	}
	?>
	<header id="masthead" class="<?php echo esc_attr( $blank_base_header_class ); ?>">
		<div class="site-header-inner">
			<div class="site-branding">
				<?php
				the_custom_logo();

				if ( is_front_page() && is_home() ) :
					?>
					<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
					<?php
				else :
					?>
					<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
					<?php
				endif;

				$blank_base_description = get_bloginfo( 'description', 'display' );
				if ( $blank_base_description || is_customize_preview() ) :
					?>
					<p class="site-description"><?php echo $blank_base_description; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
					<?php
				endif;
				?>
			</div><!-- .site-branding -->

			<div class="site-header-actions">
				<?php if ( has_nav_menu( 'menu-1' ) ) : ?>
					<nav id="site-navigation" class="main-navigation">
						<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
							<span class="menu-toggle__bars" aria-hidden="true"></span>
							<span class="menu-toggle__label"><?php esc_html_e( 'Menu', 'blank-base' ); ?></span>
						</button>
						<?php
						wp_nav_menu(
							array(
								'theme_location' => 'menu-1',
								'menu_id'        => 'primary-menu',
								'container'      => false,
							)
						);
						?>
					</nav><!-- #site-navigation -->
				<?php endif; ?>

				<?php blank_base_header_search(); ?>

				<?php if ( blank_base_show_theme_toggle() ) : ?>
					<button class="theme-toggle" type="button" aria-pressed="false" aria-label="<?php esc_attr_e( 'Toggle dark mode', 'blank-base' ); ?>" title="<?php esc_attr_e( 'Toggle dark mode', 'blank-base' ); ?>">
						<span class="theme-toggle__icon theme-toggle__icon--sun" aria-hidden="true">&#9788;</span>
						<span class="theme-toggle__icon theme-toggle__icon--moon" aria-hidden="true">&#9789;</span>
					</button>
				<?php endif; ?>
			</div><!-- .site-header-actions -->
		</div><!-- .site-header-inner -->
	</header><!-- #masthead -->

	<div id="content" class="site-content">
