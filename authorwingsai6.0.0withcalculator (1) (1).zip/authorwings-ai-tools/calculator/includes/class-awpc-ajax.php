<?php
/**
 * AJAX handler for emailing an estimate to the site owner (and optionally the lead).
 *
 * @package AuthorWings_Pricing_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AWPC_Ajax
 */
class AWPC_Ajax {

	/**
	 * Plain-text alternative for the message currently being sent.
	 *
	 * Populated immediately before wp_mail() and consumed by the scoped
	 * phpmailer_init callback so each HTML message ships as multipart
	 * (HTML + text) for deliverability and text-only clients.
	 *
	 * @var string
	 */
	private $alt_body = '';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_ajax_awpc_send_quote', array( $this, 'send_quote' ) );
		add_action( 'wp_ajax_nopriv_awpc_send_quote', array( $this, 'send_quote' ) );
	}

	/**
	 * Handle the quote email request.
	 */
	public function send_quote() {
		check_ajax_referer( 'awpc_quote', 'nonce' );

		// Honeypot — silently succeed for bots.
		if ( ! empty( $_POST['website'] ) ) {
			wp_send_json_success( array( 'message' => __( 'Thanks!', 'authorwings-calculator' ) ) );
		}

		// Rate limit per IP. This endpoint is public (wp_ajax_nopriv) and can send
		// a branded "copy to the lead" email to an attacker-supplied address, so
		// throttle it to curb mail-bombing / spam relay and unbounded submission
		// growth. Default 5 requests / 10 minutes; filterable.
		$rl_max = (int) apply_filters( 'awpc_send_quote_rate_limit', 5 );
		if ( $rl_max > 0 ) {
			$rl_key  = 'awpc_rl_' . md5( $this->client_ip() );
			$rl_hits = (int) get_transient( $rl_key );
			if ( $rl_hits >= $rl_max ) {
				wp_send_json_error( array( 'message' => __( 'Too many requests. Please try again in a little while.', 'authorwings-calculator' ) ), 429 );
			}
			set_transient( $rl_key, $rl_hits + 1, 10 * MINUTE_IN_SECONDS );
		}

		$name     = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$email    = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$phone    = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$ptype    = isset( $_POST['project_type'] ) ? sanitize_text_field( wp_unslash( $_POST['project_type'] ) ) : '';
		$pref_dt  = isset( $_POST['date'] ) ? sanitize_text_field( wp_unslash( $_POST['date'] ) ) : '';
		$pref_tm  = isset( $_POST['time'] ) ? sanitize_text_field( wp_unslash( $_POST['time'] ) ) : '';
		$tz       = isset( $_POST['timezone'] ) ? sanitize_text_field( wp_unslash( $_POST['timezone'] ) ) : '';
		$message  = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
		$summary  = isset( $_POST['summary'] ) ? sanitize_textarea_field( wp_unslash( $_POST['summary'] ) ) : '';
		$total    = isset( $_POST['total'] ) ? sanitize_text_field( wp_unslash( $_POST['total'] ) ) : '';
		$est_url  = isset( $_POST['estimate_url'] ) ? esc_url_raw( wp_unslash( $_POST['estimate_url'] ) ) : '';

		if ( ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => __( 'Please enter a valid email address.', 'authorwings-calculator' ) ) );
		}

		// All fields except the notes are required (mirrors the front-end form).
		if ( '' === trim( $name ) || '' === $phone || '' === $ptype || '' === $pref_dt || '' === $pref_tm || '' === $tz ) {
			wp_send_json_error( array( 'message' => __( 'Please fill in all required fields.', 'authorwings-calculator' ) ) );
		}

		// Combine the preferred consultation date/time/zone into one readable line.
		$preferred = trim( $pref_dt . ' ' . $pref_tm );
		if ( '' !== $preferred && '' !== $tz ) {
			$preferred .= ' (' . $tz . ')';
		}

		// Store the submission first, so the lead is captured on the "AuthorWings
		// Leads" dashboard even if email delivery later fails.
		if ( class_exists( 'AWPC_Submissions' ) ) {
			AWPC_Submissions::insert(
				array(
					'name'         => $name,
					'email'        => $email,
					'phone'        => $phone,
					'project_type' => $ptype,
					'preferred'    => $preferred,
					'message'      => $message,
					'summary'      => $summary,
					'total'        => $total,
					'estimate_url' => $est_url,
					'ip'           => $this->client_ip(),
				)
			);
		}

		$site  = get_bloginfo( 'name' );
		$to    = get_option( 'awpc_notify_email', get_option( 'admin_email' ) );
		$lines = array();

		$lines[] = sprintf( __( 'New book cost estimate from %s', 'authorwings-calculator' ), $site );
		$lines[] = '';
		$lines[] = sprintf( __( 'Name: %s', 'authorwings-calculator' ), $name ? $name : '—' );
		$lines[] = sprintf( __( 'Email: %s', 'authorwings-calculator' ), $email );
		if ( $phone ) {
			$lines[] = sprintf( __( 'Phone: %s', 'authorwings-calculator' ), $phone );
		}
		if ( $ptype ) {
			$lines[] = sprintf( __( 'Project type: %s', 'authorwings-calculator' ), $ptype );
		}
		if ( '' !== $preferred ) {
			$lines[] = sprintf( __( 'Preferred consultation: %s', 'authorwings-calculator' ), $preferred );
		}
		if ( $message ) {
			$lines[] = sprintf( __( 'Notes: %s', 'authorwings-calculator' ), $message );
		}
		$lines[] = '';
		$lines[] = __( '--- Estimate ---', 'authorwings-calculator' );
		$lines[] = $summary;
		$lines[] = '';
		$lines[] = sprintf( __( 'Estimated total: %s', 'authorwings-calculator' ), $total );
		if ( $est_url ) {
			$lines[] = '';
			$lines[] = sprintf( __( 'Reopen this estimate: %s', 'authorwings-calculator' ), $est_url );
		}

		$text_body = implode( "\n", $lines );

		// Send from an address on the site's own domain so the message has a
		// consistent, branded sender (e.g. "AuthorWings <noreply@authorwings.com>")
		// instead of WordPress' default "wordpress@" address. Both values are
		// filterable so a real mailbox can be plugged in once SMTP is set up.
		$domain     = wp_parse_url( home_url(), PHP_URL_HOST );
		$domain     = $domain ? preg_replace( '/^www\./', '', $domain ) : '';
		$from_name  = apply_filters( 'awpc_from_name', $site ? $site : get_bloginfo( 'name' ) );
		$from_email = apply_filters( 'awpc_from_email', $domain ? 'noreply@' . $domain : $to );

		// Build the branded HTML version of the owner notification.
		$template     = new AWPC_Email_Template();
		$subject_vars = array(
			'{site}'  => $site,
			'{name}'  => $name ? $name : $email,
			'{total}' => $total,
		);
		$subject      = $template->subject_owner( $subject_vars );
		$html_body    = $template->render_notification(
			array(
				'site'      => $site,
				'name'      => $name,
				'email'     => $email,
				'phone'     => $phone,
				'ptype'     => $ptype,
				'preferred' => $preferred,
				'message'   => $message,
				'summary'   => $summary,
				'total'     => $total,
				'est_url'   => $est_url,
			)
		);

		$headers = array(
			'Content-Type: text/html; charset=UTF-8',
			sprintf( 'From: %s <%s>', $from_name, $from_email ),
			sprintf( 'Reply-To: %s <%s>', $name ? $name : $email, $email ),
		);

		$sent = $this->send_html( $to, $subject, $html_body, $text_body, $headers );

		// Optional copy to the lead.
		if ( $sent && 'yes' === get_option( 'awpc_copy_lead', 'yes' ) ) {
			$lead_subject = $template->subject_lead( $subject_vars );
			$lead_lines   = array();
			$lead_lines[] = sprintf( __( 'Hi %s,', 'authorwings-calculator' ), $name ? $name : __( 'there', 'authorwings-calculator' ) );
			$lead_lines[] = '';
			$lead_lines[] = sprintf( __( 'Here is the estimate you built on %s:', 'authorwings-calculator' ), $site );
			$lead_lines[] = '';
			$lead_lines[] = $summary;
			$lead_lines[] = '';
			$lead_lines[] = sprintf( __( 'Estimated total: %s', 'authorwings-calculator' ), $total );
			if ( $est_url ) {
				$lead_lines[] = '';
				$lead_lines[] = sprintf( __( 'Reopen or tweak your estimate: %s', 'authorwings-calculator' ), $est_url );
			}
			$lead_lines[] = '';
			$lead_lines[] = __( 'This is an estimate within ~10–15% of a final quote. Reply to this email and we will help you lock in your plan.', 'authorwings-calculator' );
			$lead_text    = implode( "\n", $lead_lines );

			// Branded HTML version of the lead's confirmation.
			$lead_html = $template->render_lead(
				array(
					'site'      => $site,
					'name'      => $name,
					'summary'   => $summary,
					'total'     => $total,
					'est_url'   => $est_url,
					'preferred' => $preferred,
				)
			);

			// Same branded sender; the lead's reply should reach the site owner.
			$lead_headers = array(
				'Content-Type: text/html; charset=UTF-8',
				sprintf( 'From: %s <%s>', $from_name, $from_email ),
				sprintf( 'Reply-To: %s <%s>', $from_name, $to ),
			);
			$this->send_html( $email, $lead_subject, $lead_html, $lead_text, $lead_headers );
		}

		if ( $sent ) {
			wp_send_json_success( array( 'message' => __( 'Sent! Check your inbox — we will be in touch shortly.', 'authorwings-calculator' ) ) );
		}

		wp_send_json_error( array( 'message' => __( 'Sorry, the email could not be sent. Please try again or contact us directly.', 'authorwings-calculator' ) ) );
	}

	/**
	 * Best-effort client IP for the stored submission (audit/context only).
	 *
	 * @return string
	 */
	private function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return ( '' !== $ip && filter_var( $ip, FILTER_VALIDATE_IP ) ) ? $ip : '';
	}

	/**
	 * Send an HTML email with a plain-text alternative part (multipart/alternative).
	 *
	 * WordPress' wp_mail() sends a single part, so the text fallback is attached
	 * by setting PHPMailer's AltBody through a phpmailer_init hook that is added
	 * for this one send and removed immediately afterwards.
	 *
	 * @param string   $to        Recipient.
	 * @param string   $subject   Subject line.
	 * @param string   $html      HTML body.
	 * @param string   $text      Plain-text alternative.
	 * @param string[] $headers   Mail headers (must set an HTML Content-Type).
	 * @return bool Whether the mail was accepted for delivery.
	 */
	private function send_html( $to, $subject, $html, $text, $headers ) {
		$this->alt_body = (string) $text;
		add_action( 'phpmailer_init', array( $this, 'set_alt_body' ) );

		$sent = wp_mail( $to, $subject, $html, $headers );

		remove_action( 'phpmailer_init', array( $this, 'set_alt_body' ) );
		$this->alt_body = '';

		return $sent;
	}

	/**
	 * Attach the current plain-text alternative to the outgoing message.
	 *
	 * @param PHPMailer\PHPMailer\PHPMailer|object $phpmailer PHPMailer instance.
	 */
	public function set_alt_body( $phpmailer ) {
		if ( '' !== $this->alt_body ) {
			$phpmailer->AltBody = $this->alt_body;
		}
	}
}
