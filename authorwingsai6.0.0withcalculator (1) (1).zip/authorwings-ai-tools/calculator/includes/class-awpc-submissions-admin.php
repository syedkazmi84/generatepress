<?php
/**
 * "AuthorWings Leads" dashboard — list, view, manage and export the estimate
 * submissions stored by AWPC_Submissions.
 *
 * @package AuthorWings_Pricing_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AWPC_Submissions_Admin
 */
class AWPC_Submissions_Admin {

	/**
	 * Admin page slug.
	 */
	const PAGE = 'awpc-leads';

	/**
	 * Rows per page in the list.
	 */
	const PER_PAGE = 20;

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_post_awpc_export_leads', array( $this, 'handle_export' ) );
		// Handle status/delete/bulk actions before any output, so the redirects
		// they issue don't run into "headers already sent".
		add_action( 'admin_init', array( $this, 'maybe_handle_actions' ) );
	}

	/**
	 * Register the "Leads" submenu under the "AuthorWings Calculator" parent,
	 * with a bubble showing the number of unread leads.
	 */
	public function menu() {
		$new   = AWPC_Submissions::count( 'new' );
		$title = __( 'Leads', 'authorwings-calculator' );
		$label = $title;
		if ( $new > 0 ) {
			$label .= ' <span class="awaiting-mod"><span class="pending-count">' . number_format_i18n( $new ) . '</span></span>';
		}

		// When bundled inside another plugin the calculator settings screen
		// nests under that plugin's menu (see AWPC_Admin::menu()); the Leads
		// screen must attach to the SAME host parent to stay visible. Default
		// '' → the standalone plugin's own 'awpc-settings' top-level menu.
		$host   = (string) apply_filters( 'awpc_admin_parent_slug', '' );
		$parent = '' !== $host ? $host : 'awpc-settings';

		add_submenu_page(
			$parent,
			__( 'AuthorWings Leads', 'authorwings-calculator' ),
			$label,
			'manage_options',
			self::PAGE,
			array( $this, 'render' ),
			82
		);
	}

	/**
	 * Route to the detail view or the list, handling any actions first.
	 */
	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$view = isset( $_GET['view'] ) ? (int) $_GET['view'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $view ) {
			$this->render_detail( $view );
			return;
		}

		$this->render_list();
	}

	/**
	 * On our admin page only, run action handling early (admin_init) so any
	 * redirect happens before output begins.
	 */
	public function maybe_handle_actions() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( self::PAGE !== $page ) {
			return;
		}
		$this->handle_actions();
	}

	/**
	 * Handle status changes, deletes and bulk actions (all nonce-guarded).
	 */
	private function handle_actions() {
		// Single-row actions carry an `awpc_action` + `id` + nonce.
		if ( isset( $_GET['awpc_action'], $_GET['id'], $_GET['_wpnonce'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$action = sanitize_key( wp_unslash( $_GET['awpc_action'] ) );
			$id     = (int) $_GET['id'];
			$nonce  = sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) );

			if ( wp_verify_nonce( $nonce, 'awpc_lead_' . $action . '_' . $id ) ) {
				if ( 'delete' === $action ) {
					AWPC_Submissions::delete( $id );
					$this->redirect_notice( 'deleted' );
				} elseif ( 'read' === $action ) {
					AWPC_Submissions::update_status( $id, 'read' );
					$this->redirect_notice( 'updated' );
				} elseif ( 'unread' === $action ) {
					AWPC_Submissions::update_status( $id, 'new' );
					$this->redirect_notice( 'updated' );
				}
			}
		}

		// Bulk delete from the list table.
		if ( isset( $_POST['awpc_bulk_action'] ) && check_admin_referer( 'awpc_bulk_leads' ) ) {
			$bulk = sanitize_key( wp_unslash( $_POST['awpc_bulk_action'] ) );
			$ids  = isset( $_POST['leads'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['leads'] ) ) : array();
			if ( $ids ) {
				foreach ( $ids as $id ) {
					if ( 'delete' === $bulk ) {
						AWPC_Submissions::delete( $id );
					} elseif ( 'read' === $bulk ) {
						AWPC_Submissions::update_status( $id, 'read' );
					} elseif ( 'unread' === $bulk ) {
						AWPC_Submissions::update_status( $id, 'new' );
					}
				}
				$this->redirect_notice( 'delete' === $bulk ? 'deleted' : 'updated' );
			}
		}
	}

	/**
	 * Redirect back to the list with a result notice (avoids resubmits on reload).
	 *
	 * @param string $notice Notice key.
	 */
	private function redirect_notice( $notice ) {
		$args = array(
			'page'        => self::PAGE,
			'awpc_notice' => $notice,
		);
		// Preserve the current status filter / search / page on redirect.
		foreach ( array( 'status', 's', 'paged' ) as $keep ) {
			if ( isset( $_REQUEST[ $keep ] ) && '' !== $_REQUEST[ $keep ] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				$args[ $keep ] = sanitize_text_field( wp_unslash( $_REQUEST[ $keep ] ) );
			}
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Print a result notice based on the `awpc_notice` query arg.
	 */
	private function maybe_notice() {
		if ( empty( $_GET['awpc_notice'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$notice = sanitize_key( wp_unslash( $_GET['awpc_notice'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$map    = array(
			'deleted' => __( 'Submission(s) deleted.', 'authorwings-calculator' ),
			'updated' => __( 'Submission(s) updated.', 'authorwings-calculator' ),
		);
		if ( isset( $map[ $notice ] ) ) {
			printf( '<div class="notice notice-success is-dismissible"><p>%s</p></div>', esc_html( $map[ $notice ] ) );
		}
	}

	/**
	 * Render the submissions list.
	 */
	private function render_list() {
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$status = in_array( $status, array( 'new', 'read' ), true ) ? $status : '';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$paged  = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$total       = AWPC_Submissions::count( $status, $search );
		$total_pages = (int) ceil( $total / self::PER_PAGE );
		$rows        = AWPC_Submissions::query(
			array(
				'status'   => $status,
				'search'   => $search,
				'per_page' => self::PER_PAGE,
				'paged'    => $paged,
			)
		);

		$count_all  = AWPC_Submissions::count();
		$count_new  = AWPC_Submissions::count( 'new' );
		$count_read = AWPC_Submissions::count( 'read' );
		$base_url   = admin_url( 'admin.php?page=' . self::PAGE );
		?>
		<div class="wrap">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'AuthorWings Leads', 'authorwings-calculator' ); ?></h1>
			<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'awpc_export_leads', 'status' => $status, 's' => $search ), admin_url( 'admin-post.php' ) ), 'awpc_export_leads' ) ); ?>" class="page-title-action"><?php esc_html_e( 'Export to Excel', 'authorwings-calculator' ); ?></a>
			<hr class="wp-header-end">

			<?php $this->maybe_notice(); ?>

			<?php if ( 0 === $count_all ) : ?>
				<p><?php esc_html_e( 'No estimate submissions yet. When a visitor submits the built-in estimate form, their request will appear here.', 'authorwings-calculator' ); ?></p>
			<?php else : ?>

			<ul class="subsubsub">
				<li class="all"><a href="<?php echo esc_url( $base_url ); ?>" class="<?php echo '' === $status ? 'current' : ''; ?>"><?php esc_html_e( 'All', 'authorwings-calculator' ); ?> <span class="count">(<?php echo (int) $count_all; ?>)</span></a> |</li>
				<li class="new"><a href="<?php echo esc_url( add_query_arg( 'status', 'new', $base_url ) ); ?>" class="<?php echo 'new' === $status ? 'current' : ''; ?>"><?php esc_html_e( 'New', 'authorwings-calculator' ); ?> <span class="count">(<?php echo (int) $count_new; ?>)</span></a> |</li>
				<li class="read"><a href="<?php echo esc_url( add_query_arg( 'status', 'read', $base_url ) ); ?>" class="<?php echo 'read' === $status ? 'current' : ''; ?>"><?php esc_html_e( 'Read', 'authorwings-calculator' ); ?> <span class="count">(<?php echo (int) $count_read; ?>)</span></a></li>
			</ul>

			<form method="get">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE ); ?>">
				<?php if ( '' !== $status ) : ?>
					<input type="hidden" name="status" value="<?php echo esc_attr( $status ); ?>">
				<?php endif; ?>
				<p class="search-box">
					<label class="screen-reader-text" for="awpc-lead-search"><?php esc_html_e( 'Search leads', 'authorwings-calculator' ); ?></label>
					<input type="search" id="awpc-lead-search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search name, email, phone…', 'authorwings-calculator' ); ?>">
					<?php submit_button( __( 'Search', 'authorwings-calculator' ), '', '', false ); ?>
				</p>
			</form>

			<form method="post">
				<?php wp_nonce_field( 'awpc_bulk_leads' ); ?>
				<div class="tablenav top">
					<div class="alignleft actions bulkactions">
						<label for="awpc-bulk" class="screen-reader-text"><?php esc_html_e( 'Bulk actions', 'authorwings-calculator' ); ?></label>
						<select name="awpc_bulk_action" id="awpc-bulk">
							<option value=""><?php esc_html_e( 'Bulk actions', 'authorwings-calculator' ); ?></option>
							<option value="read"><?php esc_html_e( 'Mark as read', 'authorwings-calculator' ); ?></option>
							<option value="unread"><?php esc_html_e( 'Mark as new', 'authorwings-calculator' ); ?></option>
							<option value="delete"><?php esc_html_e( 'Delete', 'authorwings-calculator' ); ?></option>
						</select>
						<?php submit_button( __( 'Apply', 'authorwings-calculator' ), 'action', '', false ); ?>
					</div>
					<?php $this->pagination( $total, $total_pages, $paged ); ?>
				</div>

				<table class="wp-list-table widefat fixed striped">
					<thead>
						<tr>
							<td class="manage-column column-cb check-column"><input type="checkbox" onclick="var c=this.checked;this.closest('table').querySelectorAll('input[name=\'leads[]\']').forEach(function(b){b.checked=c;});"></td>
							<th scope="col"><?php esc_html_e( 'Name', 'authorwings-calculator' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Contact', 'authorwings-calculator' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Project', 'authorwings-calculator' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Total', 'authorwings-calculator' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Received', 'authorwings-calculator' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( empty( $rows ) ) : ?>
							<tr><td colspan="6"><?php esc_html_e( 'No submissions found.', 'authorwings-calculator' ); ?></td></tr>
						<?php else : ?>
							<?php foreach ( $rows as $row ) : ?>
								<?php $this->render_row( $row, $base_url ); ?>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>

				<div class="tablenav bottom">
					<?php $this->pagination( $total, $total_pages, $paged ); ?>
				</div>
			</form>

			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Render a single list row.
	 *
	 * @param array  $row      Submission row.
	 * @param string $base_url List page base URL.
	 */
	private function render_row( $row, $base_url ) {
		$id       = (int) $row['id'];
		$is_new   = ( 'new' === $row['status'] );
		$view_url = add_query_arg( 'view', $id, $base_url );

		$del_url    = wp_nonce_url( add_query_arg( array( 'awpc_action' => 'delete', 'id' => $id ), $base_url ), 'awpc_lead_delete_' . $id );
		$toggle     = $is_new ? 'read' : 'unread';
		$toggle_lbl = $is_new ? __( 'Mark read', 'authorwings-calculator' ) : __( 'Mark new', 'authorwings-calculator' );
		$toggle_url = wp_nonce_url( add_query_arg( array( 'awpc_action' => $toggle, 'id' => $id ), $base_url ), 'awpc_lead_' . $toggle . '_' . $id );

		$name = '' !== trim( $row['name'] ) ? $row['name'] : __( '(no name)', 'authorwings-calculator' );
		?>
		<tr<?php echo $is_new ? ' style="font-weight:600;"' : ''; ?>>
			<th scope="row" class="check-column"><input type="checkbox" name="leads[]" value="<?php echo esc_attr( $id ); ?>"></th>
			<td>
				<a href="<?php echo esc_url( $view_url ); ?>"><?php echo esc_html( $name ); ?></a>
				<?php if ( $is_new ) : ?>
					<span class="awpc-badge" style="display:inline-block;margin-left:6px;padding:0 6px;border-radius:9px;background:#d63638;color:#fff;font-size:10px;font-weight:600;vertical-align:middle;"><?php esc_html_e( 'NEW', 'authorwings-calculator' ); ?></span>
				<?php endif; ?>
				<div class="row-actions">
					<span class="view"><a href="<?php echo esc_url( $view_url ); ?>"><?php esc_html_e( 'View', 'authorwings-calculator' ); ?></a> | </span>
					<span class="toggle"><a href="<?php echo esc_url( $toggle_url ); ?>"><?php echo esc_html( $toggle_lbl ); ?></a> | </span>
					<span class="trash"><a href="<?php echo esc_url( $del_url ); ?>" class="submitdelete" onclick="return confirm('<?php echo esc_js( __( 'Delete this submission?', 'authorwings-calculator' ) ); ?>');"><?php esc_html_e( 'Delete', 'authorwings-calculator' ); ?></a></span>
				</div>
			</td>
			<td>
				<?php if ( '' !== $row['email'] ) : ?>
					<a href="mailto:<?php echo esc_attr( $row['email'] ); ?>"><?php echo esc_html( $row['email'] ); ?></a><br>
				<?php endif; ?>
				<?php echo esc_html( $row['phone'] ); ?>
			</td>
			<td>
				<?php echo esc_html( $row['project_type'] ); ?>
				<?php if ( '' !== $row['preferred'] ) : ?>
					<br><span class="description"><?php echo esc_html( $row['preferred'] ); ?></span>
				<?php endif; ?>
			</td>
			<td><?php echo esc_html( $row['total'] ); ?></td>
			<td><?php echo esc_html( $this->format_date( $row['created_at'] ) ); ?></td>
		</tr>
		<?php
	}

	/**
	 * Render the single-submission detail view.
	 *
	 * Organised into two branded cards — "Lead details" (contact rows) and
	 * "Estimate" (itemised line items, savings, a highlighted total and payment
	 * options) — echoing how the estimate emails are laid out, but built with
	 * native admin markup.
	 *
	 * @param int $id Submission ID.
	 */
	private function render_detail( $id ) {
		$row = AWPC_Submissions::get( $id );

		// Mark as read on first open.
		if ( $row && 'new' === $row['status'] ) {
			AWPC_Submissions::update_status( $id, 'read' );
			$row['status'] = 'read';
		}

		$base_url = admin_url( 'admin.php?page=' . self::PAGE );
		?>
		<div class="wrap awpc-lead-detail">
			<h1 class="wp-heading-inline"><?php esc_html_e( 'Lead details', 'authorwings-calculator' ); ?></h1>
			<a href="<?php echo esc_url( $base_url ); ?>" class="page-title-action"><?php esc_html_e( '← Back to leads', 'authorwings-calculator' ); ?></a>
			<hr class="wp-header-end">

			<?php if ( ! $row ) : ?>
				<p><?php esc_html_e( 'That submission could not be found.', 'authorwings-calculator' ); ?></p>
			<?php else : ?>
				<?php
				$this->print_detail_styles();
				$del_url = wp_nonce_url( add_query_arg( array( 'awpc_action' => 'delete', 'id' => (int) $row['id'] ), $base_url ), 'awpc_lead_delete_' . (int) $row['id'] );
				$parsed  = $this->parse_summary( $row['summary'] );
				?>

				<div class="awpc-cards">

					<!-- Lead details card -->
					<div class="awpc-card">
						<div class="awpc-card-head"><?php esc_html_e( 'Lead details', 'authorwings-calculator' ); ?></div>
						<table class="awpc-kv">
							<tr>
								<th><?php esc_html_e( 'Received', 'authorwings-calculator' ); ?></th>
								<td><?php echo esc_html( $this->format_date( $row['created_at'] ) ); ?></td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Name', 'authorwings-calculator' ); ?></th>
								<td><?php echo esc_html( '' !== trim( $row['name'] ) ? $row['name'] : '—' ); ?></td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Email', 'authorwings-calculator' ); ?></th>
								<td><?php echo '' !== $row['email'] ? '<a href="mailto:' . esc_attr( $row['email'] ) . '">' . esc_html( $row['email'] ) . '</a>' : '—'; ?></td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Phone', 'authorwings-calculator' ); ?></th>
								<td><?php echo '' !== $row['phone'] ? '<a href="tel:' . esc_attr( preg_replace( '/[^\d+]/', '', $row['phone'] ) ) . '">' . esc_html( $row['phone'] ) . '</a>' : '—'; ?></td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Project type', 'authorwings-calculator' ); ?></th>
								<td><?php echo esc_html( '' !== $row['project_type'] ? $row['project_type'] : '—' ); ?></td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Preferred consultation', 'authorwings-calculator' ); ?></th>
								<td><?php echo esc_html( '' !== $row['preferred'] ? $row['preferred'] : '—' ); ?></td>
							</tr>
							<tr>
								<th><?php esc_html_e( 'Notes', 'authorwings-calculator' ); ?></th>
								<td><?php echo '' !== trim( $row['message'] ) ? nl2br( esc_html( $row['message'] ) ) : '—'; ?></td>
							</tr>
						</table>
					</div>

					<!-- Estimate card -->
					<div class="awpc-card">
						<div class="awpc-card-head"><?php esc_html_e( 'Estimate', 'authorwings-calculator' ); ?></div>
						<table class="awpc-estimate">
							<?php if ( ! empty( $parsed['items'] ) ) : ?>
								<?php foreach ( $parsed['items'] as $item ) : ?>
									<tr>
										<td class="awpc-est-label"><?php echo esc_html( $item['label'] ); ?></td>
										<td class="awpc-est-amount"><?php echo esc_html( $item['amount'] ); ?></td>
									</tr>
								<?php endforeach; ?>
							<?php else : ?>
								<tr><td colspan="2" class="awpc-est-raw"><?php echo nl2br( esc_html( trim( $parsed['raw'] ) ) ); ?></td></tr>
							<?php endif; ?>

							<?php if ( '' !== $parsed['saves'] ) : ?>
								<tr class="awpc-est-saves">
									<td colspan="2">&#10003; <?php echo esc_html( $parsed['saves'] ); ?></td>
								</tr>
							<?php endif; ?>

							<tr class="awpc-est-total">
								<td><?php esc_html_e( 'Estimated total', 'authorwings-calculator' ); ?></td>
								<td class="awpc-est-amount"><?php echo esc_html( '' !== $row['total'] ? $row['total'] : ( '' !== $parsed['total'] ? $parsed['total'] : '—' ) ); ?></td>
							</tr>
						</table>

						<?php if ( '' !== $parsed['plan'] ) : ?>
							<p class="awpc-est-plan"><strong><?php esc_html_e( 'Payment options:', 'authorwings-calculator' ); ?></strong> <?php echo esc_html( $parsed['plan'] ); ?></p>
						<?php endif; ?>

						<?php if ( '' !== $parsed['rush'] ) : ?>
							<p class="awpc-est-rush"><?php echo esc_html( $parsed['rush'] ); ?></p>
						<?php endif; ?>

						<?php if ( '' !== $row['estimate_url'] ) : ?>
							<p class="awpc-est-reopen"><a href="<?php echo esc_url( $row['estimate_url'] ); ?>" class="button" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Reopen this estimate →', 'authorwings-calculator' ); ?></a></p>
						<?php endif; ?>
					</div>

				</div>

				<p class="awpc-lead-actions">
					<?php if ( '' !== $row['email'] ) : ?>
						<a href="mailto:<?php echo esc_attr( $row['email'] ); ?>" class="button button-primary"><?php esc_html_e( 'Reply by email', 'authorwings-calculator' ); ?></a>
					<?php endif; ?>
					<a href="<?php echo esc_url( $del_url ); ?>" class="button button-link-delete" onclick="return confirm('<?php echo esc_js( __( 'Delete this submission?', 'authorwings-calculator' ) ); ?>');"><?php esc_html_e( 'Delete', 'authorwings-calculator' ); ?></a>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Inline styles for the two-card detail layout (brand palette, admin-native).
	 */
	private function print_detail_styles() {
		?>
		<style>
			.awpc-lead-detail .awpc-cards { display:flex; flex-wrap:wrap; gap:20px; align-items:flex-start; margin-top:16px; }
			.awpc-lead-detail .awpc-card { flex:1 1 340px; min-width:300px; background:#fff; border:1px solid #e7ddc9; border-radius:12px; overflow:hidden; box-shadow:0 1px 2px rgba(0,0,0,.04); }
			.awpc-lead-detail .awpc-card-head { padding:12px 18px; font-size:11px; font-weight:600; letter-spacing:1.2px; text-transform:uppercase; color:#5d6675; background:#f6f1e8; border-bottom:1px solid #e7ddc9; }
			.awpc-lead-detail .awpc-kv { width:100%; border-collapse:collapse; }
			.awpc-lead-detail .awpc-kv th, .awpc-lead-detail .awpc-kv td { text-align:left; padding:11px 18px; vertical-align:top; border-bottom:1px solid #f0ece2; font-size:14px; line-height:20px; }
			.awpc-lead-detail .awpc-kv tr:last-child th, .awpc-lead-detail .awpc-kv tr:last-child td { border-bottom:none; }
			.awpc-lead-detail .awpc-kv th { width:40%; font-size:11px; font-weight:600; letter-spacing:.4px; text-transform:uppercase; color:#5d6675; }
			.awpc-lead-detail .awpc-kv td { color:#1c2439; }
			.awpc-lead-detail .awpc-estimate { width:100%; border-collapse:collapse; }
			.awpc-lead-detail .awpc-estimate td { padding:11px 18px; font-size:14px; line-height:20px; color:#1c2439; border-bottom:1px solid #f0ece2; }
			.awpc-lead-detail .awpc-est-amount { text-align:right; font-weight:600; white-space:nowrap; }
			.awpc-lead-detail .awpc-est-raw { white-space:pre-wrap; }
			.awpc-lead-detail .awpc-est-saves td { color:#4a6459; font-weight:600; background:#eef5f0; }
			.awpc-lead-detail .awpc-est-total td { background:#f6f1e8; color:#1c2439; font-size:15px; font-weight:700; border-top:2px solid #5c7a6b; border-bottom:none; }
			.awpc-lead-detail .awpc-est-total .awpc-est-amount { font-size:18px; color:#4a6459; }
			.awpc-lead-detail .awpc-est-plan { margin:12px 18px; font-size:13px; color:#5d6675; }
			.awpc-lead-detail .awpc-est-rush { margin:12px 18px; font-size:12px; line-height:18px; color:#8a5a12; background:#fbf3e2; border-radius:6px; padding:8px 10px; }
			.awpc-lead-detail .awpc-est-reopen { margin:0 18px 16px; }
			.awpc-lead-detail .awpc-lead-actions { margin-top:20px; display:flex; gap:10px; align-items:center; }
		</style>
		<?php
	}

	/**
	 * Turn the stored plain-text estimate summary into structured rows.
	 *
	 * Recognises the bullet formats the calculator emits ("• Label: $X",
	 * "- Label: $X"), the "You save…", "Estimated total…" and "Payment options…"
	 * lines, and skips decorative rules/headings — so the admin can render a tidy
	 * itemised table instead of a raw text blob.
	 *
	 * @param string $summary Raw summary text.
	 * @return array { items:[[label,amount]...], saves:string, plan:string, total:string, raw:string }
	 */
	private function parse_summary( $summary ) {
		$out = array(
			'items' => array(),
			'saves' => '',
			'plan'  => '',
			'rush'  => '',
			'total' => '',
			'raw'   => (string) $summary,
		);

		$lines = preg_split( '/\r\n|\r|\n/', (string) $summary );
		foreach ( $lines as $line ) {
			$clean = trim( preg_replace( '/^[\s]*[•\-\*\x{2013}\x{2014}\x{00B7}\x{25AA}]+\s*/u', '', $line ) );

			if ( '' === $clean || preg_match( '/^[-=_]{3,}$/', $clean ) || preg_match( '/^my book cost estimate$/i', $clean ) ) {
				continue;
			}

			if ( preg_match( '/^you save\s+(.+?)\s*$/i', $clean, $m ) ) {
				$out['saves'] = trim( $m[1] );
				continue;
			}
			if ( preg_match( '/^payment options?\s*:\s*(.+)$/i', $clean, $m ) ) {
				$out['plan'] = trim( $m[1] );
				continue;
			}
			if ( preg_match( '/^rush delivery adds\b/i', $clean ) ) {
				$out['rush'] = trim( $clean );
				continue;
			}
			if ( preg_match( '/^estimated total\s*:\s*(.+)$/i', $clean, $m ) ) {
				$out['total'] = trim( $m[1] );
				continue;
			}

			$pos = strrpos( $clean, ':' );
			if ( false !== $pos ) {
				$label  = trim( substr( $clean, 0, $pos ) );
				$amount = trim( substr( $clean, $pos + 1 ) );
				if ( '' !== $label && '' !== $amount ) {
					$out['items'][] = array(
						'label'  => $label,
						'amount' => $amount,
					);
					continue;
				}
			}

			$out['items'][] = array(
				'label'  => $clean,
				'amount' => '',
			);
		}

		return $out;
	}

	/**
	 * Render pagination controls.
	 *
	 * @param int $total       Total rows.
	 * @param int $total_pages Total pages.
	 * @param int $paged       Current page.
	 */
	private function pagination( $total, $total_pages, $paged ) {
		if ( $total_pages < 2 ) {
			printf( '<div class="tablenav-pages one-page"><span class="displaying-num">%s</span></div>', esc_html( sprintf( _n( '%s item', '%s items', $total, 'authorwings-calculator' ), number_format_i18n( $total ) ) ) );
			return;
		}

		$base = remove_query_arg( 'paged' );
		echo '<div class="tablenav-pages">';
		printf( '<span class="displaying-num">%s</span>', esc_html( sprintf( _n( '%s item', '%s items', $total, 'authorwings-calculator' ), number_format_i18n( $total ) ) ) );
		echo '<span class="pagination-links">';
		for ( $i = 1; $i <= $total_pages; $i++ ) {
			if ( $i === $paged ) {
				printf( '<span class="tablenav-pages-navspan button disabled">%d</span> ', (int) $i );
			} else {
				printf( '<a class="button" href="%s">%d</a> ', esc_url( add_query_arg( 'paged', $i, $base ) ), (int) $i );
			}
		}
		echo '</span></div>';
	}

	/**
	 * Format a stored MySQL datetime using the site's date/time format.
	 *
	 * @param string $mysql_date Stored datetime.
	 * @return string
	 */
	private function format_date( $mysql_date ) {
		$ts = strtotime( $mysql_date );
		if ( ! $ts ) {
			return $mysql_date;
		}
		return sprintf(
			/* translators: 1: date, 2: time */
			__( '%1$s at %2$s', 'authorwings-calculator' ),
			date_i18n( get_option( 'date_format' ), $ts ),
			date_i18n( get_option( 'time_format' ), $ts )
		);
	}

	/**
	 * Column definitions for the leads export (label, pixel width, cell kind).
	 *
	 * Shared by both the native .xlsx writer and the HTML fallback so the two
	 * exports stay identical. 'kind' drives per-column formatting: 'text' keeps
	 * the value verbatim (dates, phones — never reparsed as numbers), 'total'
	 * is right-aligned text, 'status' gets a coloured New/Read label, and 'wrap'
	 * is a normal text-wrapping cell.
	 *
	 * @return array
	 */
	private function export_columns() {
		// 'width' (pixels) drives the HTML fallback; 'min'/'max' (Excel character
		// units) bound the .xlsx auto-fit, which sizes each column to its actual
		// content so short columns stay tight, empty ones (e.g. Notes) collapse to
		// their header, and long ones (breakdown) cap at a readable width and wrap.
		return array(
			array( 'label' => __( 'Date', 'authorwings-calculator' ), 'width' => 150, 'min' => 18, 'max' => 26, 'kind' => 'text', 'key' => 'date' ),
			array( 'label' => __( 'Name', 'authorwings-calculator' ), 'width' => 160, 'min' => 12, 'max' => 26, 'kind' => 'wrap', 'key' => 'name' ),
			array( 'label' => __( 'Email', 'authorwings-calculator' ), 'width' => 220, 'min' => 16, 'max' => 36, 'kind' => 'wrap', 'key' => 'email' ),
			array( 'label' => __( 'Phone', 'authorwings-calculator' ), 'width' => 140, 'min' => 12, 'max' => 18, 'kind' => 'text', 'key' => 'phone' ),
			array( 'label' => __( 'Project type', 'authorwings-calculator' ), 'width' => 150, 'min' => 12, 'max' => 26, 'kind' => 'wrap', 'key' => 'project_type' ),
			array( 'label' => __( 'Preferred consultation', 'authorwings-calculator' ), 'width' => 180, 'min' => 16, 'max' => 30, 'kind' => 'wrap', 'key' => 'preferred' ),
			array( 'label' => __( 'Notes', 'authorwings-calculator' ), 'width' => 300, 'min' => 12, 'max' => 40, 'kind' => 'wrap', 'key' => 'message' ),
			array( 'label' => __( 'Total', 'authorwings-calculator' ), 'width' => 100, 'min' => 8, 'max' => 12, 'kind' => 'total', 'key' => 'total' ),
			array( 'label' => __( 'Estimate breakdown', 'authorwings-calculator' ), 'width' => 340, 'min' => 20, 'max' => 48, 'kind' => 'wrap', 'key' => 'breakdown' ),
			array( 'label' => __( 'Estimate URL', 'authorwings-calculator' ), 'width' => 240, 'min' => 16, 'max' => 42, 'kind' => 'wrap', 'key' => 'estimate_url' ),
			array( 'label' => __( 'Status', 'authorwings-calculator' ), 'width' => 100, 'min' => 8, 'max' => 10, 'kind' => 'status', 'key' => 'status' ),
		);
	}

	/**
	 * Turn a stored row into the display values used across both exporters.
	 *
	 * @param array $row Raw submission row.
	 * @return array Map of column key => display string.
	 */
	private function export_row_values( $row ) {
		$is_new = 'new' === $row['status'];
		return array(
			'date'         => $this->format_date( $row['created_at'] ),
			'name'         => $row['name'],
			'email'        => $row['email'],
			'phone'        => $row['phone'],
			'project_type' => $row['project_type'],
			'preferred'    => $row['preferred'],
			'message'      => $row['message'],
			'total'        => $row['total'],
			'breakdown'    => $this->format_breakdown( $row['summary'] ),
			'estimate_url' => $row['estimate_url'],
			'status'       => $is_new ? __( 'New', 'authorwings-calculator' ) : __( 'Read', 'authorwings-calculator' ),
		);
	}

	/**
	 * The subtitle line describing the current filter, count and export moment.
	 *
	 * @param array  $rows   Rows being exported.
	 * @param string $status Active status filter.
	 * @param string $search Active search term.
	 * @return string
	 */
	private function export_meta_line( $rows, $status, $search ) {
		$scope = '' !== $status ? ucfirst( $status ) : __( 'All', 'authorwings-calculator' );
		$meta  = sprintf(
			/* translators: 1: scope (All/New/Read), 2: number of leads, 3: export date/time */
			__( '%1$s leads · %2$d records · exported %3$s', 'authorwings-calculator' ),
			$scope,
			count( $rows ),
			$this->format_date( current_time( 'mysql' ) )
		);
		if ( '' !== $search ) {
			/* translators: %s: search term */
			$meta .= ' · ' . sprintf( __( 'search: “%s”', 'authorwings-calculator' ), $search );
		}
		return $meta;
	}

	/**
	 * Stream a styled Excel workbook of the (optionally filtered) submissions.
	 *
	 * Excel opens plain CSVs raw: phone numbers turn into scientific notation,
	 * dates overflow the column, and the long "Notes"/breakdown fields spill into
	 * one unreadable cell. We instead emit a native .xlsx workbook (a real
	 * OpenXML file, so no "format and extension don't match" warning and no
	 * number reformatting), with fixed column widths, a branded frozen header,
	 * wrapped text, zebra striping and coloured status labels. Hosts without the
	 * Zip extension fall back to an Excel-readable HTML workbook (.xls).
	 */
	public function handle_export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'authorwings-calculator' ) );
		}
		check_admin_referer( 'awpc_export_leads' );

		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$status = in_array( $status, array( 'new', 'read' ), true ) ? $status : '';
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';

		$rows = AWPC_Submissions::query(
			array(
				'status'   => $status,
				'search'   => $search,
				'per_page' => 100000,
				'paged'    => 1,
			)
		);

		$basename = 'authorwings-leads-' . gmdate( 'Y-m-d' );

		// Preferred path: a genuine .xlsx file (needs the Zip extension).
		$xlsx = $this->build_xlsx_workbook( $rows, $status, $search );
		if ( false !== $xlsx ) {
			nocache_headers();
			header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
			header( 'Content-Disposition: attachment; filename=' . $basename . '.xlsx' );
			header( 'Content-Length: ' . strlen( $xlsx ) );
			echo $xlsx; // phpcs:ignore WordPress.Security.EscapingOutput.OutputNotEscaped
			exit;
		}

		// Fallback: Excel-readable HTML workbook.
		nocache_headers();
		header( 'Content-Type: application/vnd.ms-excel; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=' . $basename . '.xls' );
		echo "\xEF\xBB\xBF"; // UTF-8 BOM so Excel reads accented characters correctly.
		echo $this->build_export_workbook( $rows, $status, $search ); // phpcs:ignore WordPress.Security.EscapingOutput.OutputNotEscaped

		exit;
	}

	/**
	 * Build a native .xlsx (OpenXML) workbook for the given rows.
	 *
	 * Every cell is written as an inline string, so values like phone numbers and
	 * totals are always treated as text and never reformatted by Excel. Returns
	 * the binary file contents, or false if the Zip extension is unavailable.
	 *
	 * @param array  $rows   Submission rows.
	 * @param string $status Active status filter.
	 * @param string $search Active search term.
	 * @return string|false
	 */
	private function build_xlsx_workbook( $rows, $status, $search ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return false;
		}

		$tmp = wp_tempnam( 'awpc-leads-xlsx' );
		if ( ! $tmp ) {
			return false;
		}

		$zip = new ZipArchive();
		if ( true !== $zip->open( $tmp, ZipArchive::OVERWRITE ) ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return false;
		}

		$columns = $this->export_columns();

		$zip->addFromString( '[Content_Types].xml', $this->xlsx_content_types() );
		$zip->addFromString( '_rels/.rels', $this->xlsx_root_rels() );
		$zip->addFromString( 'xl/workbook.xml', $this->xlsx_workbook_xml() );
		$zip->addFromString( 'xl/_rels/workbook.xml.rels', $this->xlsx_workbook_rels() );
		$zip->addFromString( 'xl/styles.xml', $this->xlsx_styles_xml() );
		$zip->addFromString( 'xl/worksheets/sheet1.xml', $this->xlsx_sheet_xml( $rows, $columns, $status, $search ) );

		$zip->close();

		$data = file_get_contents( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		return false === $data ? false : $data;
	}

	/**
	 * OpenXML [Content_Types].xml part.
	 *
	 * @return string
	 */
	private function xlsx_content_types() {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
			. '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
			. '<Default Extension="xml" ContentType="application/xml"/>'
			. '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
			. '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
			. '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
			. '</Types>';
	}

	/**
	 * OpenXML package root relationships.
	 *
	 * @return string
	 */
	private function xlsx_root_rels() {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
			. '</Relationships>';
	}

	/**
	 * OpenXML workbook part (single "Leads" sheet).
	 *
	 * @return string
	 */
	private function xlsx_workbook_xml() {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
			. '<sheets><sheet name="Leads" sheetId="1" r:id="rId1"/></sheets>'
			. '</workbook>';
	}

	/**
	 * OpenXML workbook relationships (worksheet + styles).
	 *
	 * @return string
	 */
	private function xlsx_workbook_rels() {
		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
			. '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
			. '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
			. '</Relationships>';
	}

	/**
	 * OpenXML styles part — fonts, fills, borders and the cell format records
	 * (indices) referenced by the sheet. numFmtId 49 is the built-in text format,
	 * so text cells are never reinterpreted as numbers.
	 *
	 * @return string
	 */
	private function xlsx_styles_xml() {
		$fonts = '<fonts count="6">'
			. '<font><sz val="11"/><color rgb="FF1C2439"/><name val="Calibri"/></font>'
			. '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
			. '<font><b/><sz val="16"/><color rgb="FF4A6459"/><name val="Calibri"/></font>'
			. '<font><sz val="10"/><color rgb="FF5D6675"/><name val="Calibri"/></font>'
			. '<font><b/><sz val="11"/><color rgb="FF8A5A12"/><name val="Calibri"/></font>'
			. '<font><b/><sz val="11"/><color rgb="FF4A6459"/><name val="Calibri"/></font>'
			. '</fonts>';

		$fills = '<fills count="4">'
			. '<fill><patternFill patternType="none"/></fill>'
			. '<fill><patternFill patternType="gray125"/></fill>'
			. '<fill><patternFill patternType="solid"><fgColor rgb="FF4A6459"/></patternFill></fill>'
			. '<fill><patternFill patternType="solid"><fgColor rgb="FFFAF7F0"/></patternFill></fill>'
			. '</fills>';

		$edge    = '<left style="thin"><color rgb="FFD8CFBB"/></left><right style="thin"><color rgb="FFD8CFBB"/></right><top style="thin"><color rgb="FFD8CFBB"/></top><bottom style="thin"><color rgb="FFD8CFBB"/></bottom><diagonal/>';
		$borders = '<borders count="2">'
			. '<border><left/><right/><top/><bottom/><diagonal/></border>'
			. '<border>' . $edge . '</border>'
			. '</borders>';

		// cellXfs — index order must match the constants used in xlsx_sheet_xml().
		$cellxfs = '<cellXfs count="14">'
			. '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' // 0 default
			. '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>' // 1 header
			. '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>' // 2 title
			. '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>' // 3 subtitle
			. '<xf numFmtId="49" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>' // 4 wrap white
			. '<xf numFmtId="49" fontId="0" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>' // 5 wrap zebra
			. '<xf numFmtId="49" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>' // 6 text white
			. '<xf numFmtId="49" fontId="0" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>' // 7 text zebra
			. '<xf numFmtId="49" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf>' // 8 total white
			. '<xf numFmtId="49" fontId="0" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="top"/></xf>' // 9 total zebra
			. '<xf numFmtId="0" fontId="4" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>' // 10 new white
			. '<xf numFmtId="0" fontId="4" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>' // 11 new zebra
			. '<xf numFmtId="0" fontId="5" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>' // 12 read white
			. '<xf numFmtId="0" fontId="5" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>' // 13 read zebra
			. '</cellXfs>';

		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
			. '<numFmts count="0"/>'
			. $fonts . $fills . $borders
			. '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
			. $cellxfs
			. '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
			. '</styleSheet>';
	}

	/**
	 * OpenXML worksheet part: title/subtitle banner, frozen header row and one
	 * styled row per lead.
	 *
	 * @param array  $rows    Submission rows.
	 * @param array  $columns Column definitions from export_columns().
	 * @param string $status  Active status filter.
	 * @param string $search  Active search term.
	 * @return string
	 */
	private function xlsx_sheet_xml( $rows, $columns, $status, $search ) {
		$last_index = count( $columns ) - 1;
		$last_col   = $this->xlsx_col_letter( $last_index );

		// Uniform data-row height (points): tall enough to preview a few wrapped
		// lines of the breakdown, so the grid stays even and scannable.
		$data_row_height = 45;

		// Build the data rows first, measuring the widest line in each column so
		// the columns can be auto-fitted afterwards.
		$maxlen    = array_fill( 0, count( $columns ), 0 );
		$body_rows = '';
		$r = 5;
		$n = 0;
		foreach ( $rows as $row ) {
			$values = $this->export_row_values( $row );
			$zebra  = ( 1 === $n % 2 );
			$is_new = 'new' === $row['status'];

			$cells = '<row r="' . $r . '" ht="' . $data_row_height . '" customHeight="1">';
			foreach ( $columns as $i => $col ) {
				$val = $values[ $col['key'] ];
				$len = $this->xlsx_longest_line( $val );
				if ( $len > $maxlen[ $i ] ) {
					$maxlen[ $i ] = $len;
				}
				$style  = $this->xlsx_style_index( $col['kind'], $zebra, $is_new );
				$ref    = $this->xlsx_col_letter( $i ) . $r;
				$cells .= $this->xlsx_cell( $ref, $style, $val );
			}
			$cells .= '</row>';
			$body_rows .= $cells;

			$r++;
			$n++;
		}

		if ( empty( $rows ) ) {
			$body_rows .= '<row r="5">' . $this->xlsx_cell( 'A5', 4, __( 'No leads match the current filter.', 'authorwings-calculator' ) ) . '</row>';
		}

		// Auto-fit each column between its min/max from the measured content
		// (and always wide enough for its header label).
		$cols = '<cols>';
		foreach ( $columns as $i => $col ) {
			$w = min( $maxlen[ $i ], (int) $col['max'] ) + 2;   // content, capped
			$w = max( $w, strlen( $col['label'] ) + 1 );        // header must fit
			$w = max( $w, (int) $col['min'] );                  // not below min
			$w = min( $w, (int) $col['max'] );                  // not above max
			$n = $i + 1;
			$cols .= '<col min="' . $n . '" max="' . $n . '" width="' . round( $w, 2 ) . '" customWidth="1"/>';
		}
		$cols .= '</cols>';

		// Banner (row 1 title, row 2 subtitle), row 3 blank, row 4 header, then data.
		$body  = '<row r="1" ht="24" customHeight="1">' . $this->xlsx_cell( 'A1', 2, __( 'AuthorWings Leads', 'authorwings-calculator' ) ) . '</row>';
		$body .= '<row r="2" ht="16" customHeight="1">' . $this->xlsx_cell( 'A2', 3, $this->export_meta_line( $rows, $status, $search ) ) . '</row>';
		$header = '<row r="4" ht="22" customHeight="1">';
		foreach ( $columns as $i => $col ) {
			$header .= $this->xlsx_cell( $this->xlsx_col_letter( $i ) . '4', 1, $col['label'] );
		}
		$header .= '</row>';
		$body  .= $header . $body_rows;

		$merges = '<mergeCells count="2"><mergeCell ref="A1:' . $last_col . '1"/><mergeCell ref="A2:' . $last_col . '2"/></mergeCells>';

		return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
			. '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
			. '<sheetViews><sheetView workbookViewId="0"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
			. '<sheetFormatPr defaultRowHeight="15"/>'
			. $cols
			. '<sheetData>' . $body . '</sheetData>'
			. $merges
			. '</worksheet>';
	}

	/**
	 * Map a column kind + row parity + status to a cellXfs style index.
	 *
	 * @param string $kind   Column kind (text|wrap|total|status).
	 * @param bool   $zebra  Whether this is a shaded (alternate) row.
	 * @param bool   $is_new Whether the lead is unread.
	 * @return int
	 */
	private function xlsx_style_index( $kind, $zebra, $is_new ) {
		switch ( $kind ) {
			case 'text':
				return $zebra ? 7 : 6;
			case 'total':
				return $zebra ? 9 : 8;
			case 'status':
				if ( $is_new ) {
					return $zebra ? 11 : 10;
				}
				return $zebra ? 13 : 12;
			case 'wrap':
			default:
				return $zebra ? 5 : 4;
		}
	}

	/**
	 * Render one worksheet cell. Empty values still emit a styled (bordered) cell.
	 *
	 * @param string $ref   A1-style cell reference.
	 * @param int    $style cellXfs index.
	 * @param string $value Display value.
	 * @return string
	 */
	private function xlsx_cell( $ref, $style, $value ) {
		$value = (string) $value;
		if ( '' === $value ) {
			return '<c r="' . $ref . '" s="' . (int) $style . '"/>';
		}
		return '<c r="' . $ref . '" s="' . (int) $style . '" t="inlineStr"><is><t xml:space="preserve">' . $this->xlsx_escape( $value ) . '</t></is></c>';
	}

	/**
	 * XML-escape a value for an inline-string cell (line breaks preserved).
	 *
	 * @param string $value Raw value.
	 * @return string
	 */
	private function xlsx_escape( $value ) {
		$value = str_replace( array( "\r\n", "\r" ), "\n", (string) $value );
		return str_replace( array( '&', '<', '>' ), array( '&amp;', '&lt;', '&gt;' ), $value );
	}

	/**
	 * Length (in characters) of the longest single line in a value — used to
	 * auto-fit column widths. Wrapped cells break on newlines, so the widest
	 * line, not the total length, is what a column needs to accommodate.
	 *
	 * @param string $value Raw value.
	 * @return int
	 */
	private function xlsx_longest_line( $value ) {
		$value = (string) $value;
		if ( '' === $value ) {
			return 0;
		}
		$best = 0;
		foreach ( explode( "\n", str_replace( array( "\r\n", "\r" ), "\n", $value ) ) as $line ) {
			$len = function_exists( 'mb_strlen' ) ? mb_strlen( $line ) : strlen( $line );
			if ( $len > $best ) {
				$best = $len;
			}
		}
		return $best;
	}

	/**
	 * Convert a 0-based column index to its A1 column letters.
	 *
	 * @param int $index 0-based column index.
	 * @return string
	 */
	private function xlsx_col_letter( $index ) {
		$letters = '';
		$index++;
		while ( $index > 0 ) {
			$mod     = ( $index - 1 ) % 26;
			$letters = chr( 65 + $mod ) . $letters;
			$index   = intdiv( $index - 1, 26 );
		}
		return $letters;
	}

	/**
	 * Build the full Excel-readable HTML workbook string for the given rows.
	 *
	 * @param array  $rows   Submission rows.
	 * @param string $status Active status filter ('' for all).
	 * @param string $search Active search term.
	 * @return string
	 */
	private function build_export_workbook( $rows, $status, $search ) {
		// Column definitions: label, pixel width, and how the cell behaves.
		$columns = array(
			array(
				'label' => __( 'Date', 'authorwings-calculator' ),
				'width' => 150,
			),
			array(
				'label' => __( 'Name', 'authorwings-calculator' ),
				'width' => 160,
			),
			array(
				'label' => __( 'Email', 'authorwings-calculator' ),
				'width' => 220,
			),
			array(
				'label' => __( 'Phone', 'authorwings-calculator' ),
				'width' => 140,
			),
			array(
				'label' => __( 'Project type', 'authorwings-calculator' ),
				'width' => 150,
			),
			array(
				'label' => __( 'Preferred consultation', 'authorwings-calculator' ),
				'width' => 180,
			),
			array(
				'label' => __( 'Notes', 'authorwings-calculator' ),
				'width' => 300,
			),
			array(
				'label' => __( 'Total', 'authorwings-calculator' ),
				'width' => 100,
			),
			array(
				'label' => __( 'Estimate breakdown', 'authorwings-calculator' ),
				'width' => 340,
			),
			array(
				'label' => __( 'Estimate URL', 'authorwings-calculator' ),
				'width' => 240,
			),
			array(
				'label' => __( 'Status', 'authorwings-calculator' ),
				'width' => 100,
			),
		);
		$col_count = count( $columns );

		// Subtitle describing the current filter/search and export moment.
		$scope = '' !== $status ? ucfirst( $status ) : __( 'All', 'authorwings-calculator' );
		$meta  = sprintf(
			/* translators: 1: scope (All/New/Read), 2: number of leads, 3: export date/time */
			__( '%1$s leads · %2$d records · exported %3$s', 'authorwings-calculator' ),
			$scope,
			count( $rows ),
			$this->format_date( current_time( 'mysql' ) )
		);
		if ( '' !== $search ) {
			/* translators: %s: search term */
			$meta .= ' · ' . sprintf( __( 'search: “%s”', 'authorwings-calculator' ), $search );
		}

		$html  = "<html xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\">\n";
		$html .= "<head><meta charset=\"utf-8\">\n";
		$html .= '<style type="text/css">' . $this->export_styles() . "</style>\n";
		$html .= "</head>\n<body>\n";

		$html .= '<table cellspacing="0" cellpadding="0">' . "\n";

		// Column widths — Excel honours the width set on the first row's cells.
		$html .= "<colgroup>\n";
		foreach ( $columns as $col ) {
			$html .= '<col style="width:' . (int) $col['width'] . 'px;" />' . "\n";
		}
		$html .= "</colgroup>\n";

		// Title + subtitle banner rows spanning every column.
		$html .= '<tr><td class="title" colspan="' . $col_count . '">' . esc_html__( 'AuthorWings Leads', 'authorwings-calculator' ) . "</td></tr>\n";
		$html .= '<tr><td class="subtitle" colspan="' . $col_count . '">' . esc_html( $meta ) . "</td></tr>\n";
		$html .= '<tr><td class="spacer" colspan="' . $col_count . '"></td></tr>' . "\n";

		// Header row.
		$html .= "<tr>\n";
		foreach ( $columns as $col ) {
			$html .= '<th style="width:' . (int) $col['width'] . 'px;">' . esc_html( $col['label'] ) . "</th>\n";
		}
		$html .= "</tr>\n";

		// Inline number-format attribute: Excel reliably honours mso-number-format
		// when it sits on the cell itself (a shared CSS class is ignored), so this
		// is what actually stops long phone numbers becoming scientific notation.
		$txt = ' style="mso-number-format:\'\@\';"';

		// Data rows.
		$i = 0;
		foreach ( $rows as $row ) {
			$zebra  = ( 0 === $i % 2 ) ? '' : ' alt';
			$is_new = 'new' === $row['status'];

			$status_label = $is_new ? __( 'New', 'authorwings-calculator' ) : __( 'Read', 'authorwings-calculator' );
			$status_class = $is_new ? 'status-new' : 'status-read';

			$html .= "<tr>\n";
			// Date — forced text so Excel keeps the readable label.
			$html .= '<td class="nowrap' . $zebra . '"' . $txt . '>' . esc_html( $this->format_date( $row['created_at'] ) ) . "</td>\n";
			$html .= '<td class="wrap' . $zebra . '">' . esc_html( $row['name'] ) . "</td>\n";
			$html .= '<td class="wrap' . $zebra . '">' . esc_html( $row['email'] ) . "</td>\n";
			// Phone — forced text so it never renders as scientific notation.
			$html .= '<td class="nowrap' . $zebra . '"' . $txt . '>' . esc_html( $row['phone'] ) . "</td>\n";
			$html .= '<td class="wrap' . $zebra . '">' . esc_html( $row['project_type'] ) . "</td>\n";
			$html .= '<td class="wrap' . $zebra . '">' . esc_html( $row['preferred'] ) . "</td>\n";
			$html .= '<td class="wrap' . $zebra . '">' . $this->xls_multiline( $row['message'] ) . "</td>\n";
			// Total — forced text so "$5,495" is preserved verbatim, right-aligned.
			$html .= '<td class="nowrap right' . $zebra . '"' . $txt . '>' . esc_html( $row['total'] ) . "</td>\n";
			$html .= '<td class="wrap' . $zebra . '">' . $this->xls_multiline( $this->format_breakdown( $row['summary'] ) ) . "</td>\n";
			$html .= '<td class="wrap link' . $zebra . '">' . esc_html( $row['estimate_url'] ) . "</td>\n";
			$html .= '<td class="nowrap ' . $status_class . $zebra . '">' . esc_html( $status_label ) . "</td>\n";
			$html .= "</tr>\n";

			$i++;
		}

		if ( empty( $rows ) ) {
			$html .= '<tr><td class="wrap" colspan="' . $col_count . '">' . esc_html__( 'No leads match the current filter.', 'authorwings-calculator' ) . "</td></tr>\n";
		}

		$html .= "</table>\n</body>\n</html>";

		return $html;
	}

	/**
	 * Inline stylesheet for the exported workbook (brand palette, Excel-friendly).
	 *
	 * @return string
	 */
	private function export_styles() {
		// Single-quoted so the mso number-format backslash survives untouched.
		return 'table { border-collapse:collapse; font-family:Calibri, Arial, sans-serif; font-size:11pt; color:#1c2439; }'
			. ' td, th { border:1px solid #d8cfbb; padding:6px 12px; vertical-align:top; }'
			. ' th { background:#4a6459; color:#ffffff; font-weight:bold; text-align:left; white-space:nowrap; border-color:#3c5145; }'
			. ' .title { font-size:18pt; font-weight:bold; color:#4a6459; border:none; padding:2px 0 0; }'
			. ' .subtitle { color:#5d6675; font-size:10pt; border:none; padding:2px 0 8px; }'
			. ' .spacer { border:none; height:6px; }'
			. ' .wrap { mso-data-placement:same-cell; }'
			. ' .nowrap { white-space:nowrap; }'
			. ' .right { text-align:right; }'
			. ' .txt { mso-number-format:"\@"; }'
			. ' .link { color:#4a6459; }'
			. ' .alt { background:#faf7f0; }'
			. ' .status-new { color:#8a5a12; font-weight:bold; }'
			. ' .status-read { color:#4a6459; font-weight:bold; }';
	}

	/**
	 * Escape a value for a workbook cell and preserve its line breaks in-cell.
	 *
	 * @param string $text Raw text.
	 * @return string
	 */
	private function xls_multiline( $text ) {
		$text = esc_html( (string) $text );
		return str_replace( array( "\r\n", "\r", "\n" ), '<br style="mso-data-placement:same-cell;" />', $text );
	}

	/**
	 * Turn the stored estimate summary into a clean, itemised breakdown string.
	 *
	 * Reuses parse_summary() so the export matches the tidy detail-view layout:
	 * one "Label: amount" line per item, followed by savings and payment lines.
	 *
	 * @param string $summary Raw summary text.
	 * @return string Newline-separated breakdown, or the trimmed raw text.
	 */
	private function format_breakdown( $summary ) {
		$parsed = $this->parse_summary( $summary );
		$lines  = array();

		foreach ( $parsed['items'] as $item ) {
			$lines[] = '' !== $item['amount'] ? $item['label'] . ': ' . $item['amount'] : $item['label'];
		}
		if ( '' !== $parsed['saves'] ) {
			/* translators: %s: savings amount */
			$lines[] = sprintf( __( 'You save %s', 'authorwings-calculator' ), $parsed['saves'] );
		}
		if ( '' !== $parsed['plan'] ) {
			/* translators: %s: payment plan */
			$lines[] = sprintf( __( 'Payment options: %s', 'authorwings-calculator' ), $parsed['plan'] );
		}
		if ( '' !== $parsed['rush'] ) {
			$lines[] = $parsed['rush'];
		}

		if ( empty( $lines ) ) {
			return trim( $parsed['raw'] );
		}

		return implode( "\n", $lines );
	}
}
