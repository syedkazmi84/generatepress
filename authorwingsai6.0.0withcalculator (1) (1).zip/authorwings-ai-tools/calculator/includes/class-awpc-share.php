<?php
/**
 * Short shareable estimate links.
 *
 * The calculator normally encodes the whole build into the URL so a link can
 * reopen it anywhere with no server lookup — but that link is very long. This
 * class stores a build server-side and hands back a short code, so "Copy
 * estimate link" (and the emailed reopen link) can be a tidy
 * "?awpc=ab12cd9" instead of a multi-hundred-character blob.
 *
 * @package AuthorWings_Pricing_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AWPC_Share
 */
class AWPC_Share {

	/**
	 * Schema version — bump when the table structure changes.
	 */
	const DB_VERSION = '1';

	/**
	 * Option storing the installed schema version.
	 */
	const DB_VERSION_OPTION = 'awpc_share_db_version';

	/**
	 * Maximum accepted serialised-state length (bytes). Generous but bounded so
	 * the endpoint can't be used to store arbitrary large blobs.
	 */
	const MAX_STATE = 8000;

	/**
	 * Cron hook that prunes expired share links.
	 */
	const CRON_HOOK = 'awpc_prune_shares';

	/**
	 * How long a short link is kept before the daily cron removes it (days).
	 * Share rows hold only calculator selections (no personal data), so old,
	 * unused ones can be expired safely.
	 */
	const PRUNE_DAYS = 90;

	/**
	 * Constructor — register the create/resolve AJAX endpoints (front end too)
	 * and the daily prune handler.
	 */
	public function __construct() {
		add_action( 'wp_ajax_awpc_share_create', array( $this, 'ajax_create' ) );
		add_action( 'wp_ajax_nopriv_awpc_share_create', array( $this, 'ajax_create' ) );
		add_action( 'wp_ajax_awpc_share_resolve', array( $this, 'ajax_resolve' ) );
		add_action( 'wp_ajax_nopriv_awpc_share_resolve', array( $this, 'ajax_resolve' ) );
		add_action( self::CRON_HOOK, array( __CLASS__, 'prune' ) );
	}

	/**
	 * Ensure the daily prune event is scheduled (idempotent).
	 */
	public static function ensure_schedule() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time(), 'daily', self::CRON_HOOK );
		}
	}

	/**
	 * Remove the scheduled prune event (called on deactivation).
	 */
	public static function clear_schedule() {
		$timestamp = wp_next_scheduled( self::CRON_HOOK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::CRON_HOOK );
		}
	}

	/**
	 * Delete share links older than PRUNE_DAYS. Runs daily via WP-Cron.
	 */
	public static function prune() {
		global $wpdb;
		$table  = self::table_name();
		$cutoff = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - ( self::PRUNE_DAYS * DAY_IN_SECONDS ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE created_at < %s", $cutoff ) );
	}

	/**
	 * Fully-qualified shares table name.
	 *
	 * @return string
	 */
	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'awpc_shares';
	}

	/**
	 * Create/upgrade the table when the stored schema version is out of date.
	 */
	public static function maybe_install() {
		if ( get_option( self::DB_VERSION_OPTION ) === self::DB_VERSION ) {
			return;
		}
		self::install();
	}

	/**
	 * Create or update the shares table via dbDelta().
	 */
	public static function install() {
		global $wpdb;

		$table           = self::table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			code VARCHAR(16) NOT NULL DEFAULT '',
			state_hash CHAR(40) NOT NULL DEFAULT '',
			state LONGTEXT NOT NULL,
			created_at DATETIME NOT NULL,
			hits BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY code (code),
			KEY state_hash (state_hash)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
	}

	/**
	 * AJAX: store the posted build and return a short code.
	 */
	public function ajax_create() {
		check_ajax_referer( 'awpc_quote', 'nonce' );

		$state = isset( $_POST['state'] ) ? (string) wp_unslash( $_POST['state'] ) : ''; // phpcs:ignore WordPress.Sanitization -- validated as JSON below.

		if ( '' === $state || strlen( $state ) > self::MAX_STATE ) {
			wp_send_json_error( array( 'message' => 'invalid' ) );
		}

		// Accept only well-formed JSON, then re-encode canonically so we never
		// store anything but a clean object.
		$decoded = json_decode( $state, true );
		if ( null === $decoded || ! is_array( $decoded ) ) {
			wp_send_json_error( array( 'message' => 'invalid' ) );
		}
		$canonical = wp_json_encode( $decoded );
		if ( ! is_string( $canonical ) ) {
			wp_send_json_error( array( 'message' => 'invalid' ) );
		}

		$code = self::save( $canonical );
		if ( '' === $code ) {
			wp_send_json_error( array( 'message' => 'failed' ) );
		}

		wp_send_json_success( array( 'code' => $code ) );
	}

	/**
	 * AJAX: resolve a short code back to its stored build.
	 */
	public function ajax_resolve() {
		check_ajax_referer( 'awpc_quote', 'nonce' );

		$code = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
		if ( ! preg_match( '/^[A-Za-z0-9]{4,16}$/', $code ) ) {
			wp_send_json_error( array( 'message' => 'invalid' ) );
		}

		$state = self::resolve( $code );
		if ( null === $state ) {
			wp_send_json_error( array( 'message' => 'not_found' ) );
		}

		wp_send_json_success( array( 'state' => $state ) );
	}

	/**
	 * Store a canonical state string and return its (possibly reused) code.
	 *
	 * Identical builds share one code (deduped by a hash) so repeated copies of
	 * the same estimate don't fill the table.
	 *
	 * @param string $state Canonical JSON state.
	 * @return string Short code, or '' on failure.
	 */
	public static function save( $state ) {
		global $wpdb;
		$table = self::table_name();
		$hash  = sha1( $state );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT code FROM $table WHERE state_hash = %s LIMIT 1", $hash ) );
		if ( $existing ) {
			return (string) $existing;
		}

		// Try a few times in case of a rare code collision (UNIQUE key).
		for ( $i = 0; $i < 6; $i++ ) {
			$code = self::generate_code();
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$ok = $wpdb->insert(
				$table,
				array(
					'code'       => $code,
					'state_hash' => $hash,
					'state'      => $state,
					'created_at' => current_time( 'mysql' ),
					'hits'       => 0,
				)
			);
			if ( $ok ) {
				return $code;
			}
		}

		return '';
	}

	/**
	 * Resolve a code to its stored state, bumping the hit counter.
	 *
	 * @param string $code Short code.
	 * @return string|null Stored JSON state, or null if unknown.
	 */
	public static function resolve( $code ) {
		global $wpdb;
		$table = self::table_name();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, state FROM $table WHERE code = %s LIMIT 1", $code ), ARRAY_A );
		if ( ! $row ) {
			return null;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( $wpdb->prepare( "UPDATE $table SET hits = hits + 1 WHERE id = %d", (int) $row['id'] ) );

		return (string) $row['state'];
	}

	/**
	 * Generate a short lowercase alphanumeric code (e.g. "a1b9c2d").
	 *
	 * @return string
	 */
	private static function generate_code() {
		return strtolower( wp_generate_password( 7, false, false ) );
	}
}
