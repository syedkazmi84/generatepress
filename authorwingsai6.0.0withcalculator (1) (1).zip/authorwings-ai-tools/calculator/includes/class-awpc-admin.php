<?php
/**
 * Admin settings: email notifications + fully editable prices.
 *
 * Price fields are auto-generated from the pricing structure, so every plan,
 * package, tier, add-on and bundle is editable — and new items added to the
 * data file appear here automatically.
 *
 * @package AuthorWings_Pricing_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AWPC_Admin
 */
class AWPC_Admin {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_post_awpc_test_email', array( $this, 'handle_test_email' ) );
		add_action( 'admin_post_awpc_test_estimate', array( $this, 'handle_test_estimate' ) );
		add_action( 'admin_post_awpc_reset_pricing', array( $this, 'handle_reset_pricing' ) );
	}

	/**
	 * Editable service sections and the pricing model each one uses.
	 *
	 * The model decides which numeric fields an item shows, so every service is
	 * arranged the same way — name, then only the fields its model needs, then
	 * its feature bullets — with one "Add item" flow per section.
	 *
	 * @return array
	 */
	private function sections() {
		return array(
			'ghostwriting'       => array(
				'title'     => __( 'Ghostwriting', 'authorwings-calculator' ),
				'model'     => 'flat_words',
				'booktype'  => true,
				'popular'   => true,
				'add_label' => __( 'Add ghostwriting tier', 'authorwings-calculator' ),
			),
			'editing'            => array(
				'title'     => __( 'Editing (tiers)', 'authorwings-calculator' ),
				'model'     => 'perword_min',
				'popular'   => true,
				'add_label' => __( 'Add editing tier', 'authorwings-calculator' ),
			),
			'editing_individual' => array(
				'title'     => __( 'Editing (per-word services)', 'authorwings-calculator' ),
				'model'     => 'base_allowance_rate',
				'add_label' => __( 'Add per-word service', 'authorwings-calculator' ),
			),
			'cover'              => array(
				'title'     => __( 'Cover design', 'authorwings-calculator' ),
				'model'     => 'flat',
				'popular'   => true,
				'has_none'  => true,
				'add_label' => __( 'Add cover option', 'authorwings-calculator' ),
			),
			'interior'           => array(
				'title'     => __( 'Interior formatting', 'authorwings-calculator' ),
				'model'     => 'flat',
				'has_none'  => true,
				'add_label' => __( 'Add formatting option', 'authorwings-calculator' ),
			),
			'illustration'       => array(
				'title'     => __( 'Illustration', 'authorwings-calculator' ),
				'model'     => 'flat_unit',
				'has_none'  => true,
				'add_label' => __( 'Add illustration option', 'authorwings-calculator' ),
			),
			'publishing'         => array(
				'title'     => __( 'Publishing', 'authorwings-calculator' ),
				'model'     => 'flat',
				'popular'   => true,
				'has_none'  => true,
				'add_label' => __( 'Add publishing tier', 'authorwings-calculator' ),
			),
			'marketing'          => array(
				'title'     => __( 'Marketing', 'authorwings-calculator' ),
				'model'     => 'flat',
				'popular'   => true,
				'has_none'  => true,
				'add_label' => __( 'Add marketing tier', 'authorwings-calculator' ),
			),
			'coaching'           => array(
				'title'     => __( 'Coaching', 'authorwings-calculator' ),
				'model'     => 'flat',
				'popular'   => true,
				'has_none'  => true,
				'add_label' => __( 'Add coaching tier', 'authorwings-calculator' ),
			),
			'addons'             => array(
				'title'     => __( 'Add-ons', 'authorwings-calculator' ),
				'model'     => 'addon',
				'add_label' => __( 'Add add-on', 'authorwings-calculator' ),
			),
		);
	}

	/**
	 * Fields shown for a given pricing model: key => array( label, input-type ).
	 *
	 * Input types: 'number' (integer price), 'rate' (per-word, 3-decimal step),
	 * 'text' (short label such as a per-unit noun).
	 *
	 * @param string $model Model key from sections().
	 * @return array
	 */
	private function model_fields( $model ) {
		switch ( $model ) {
			case 'flat_words':
				return array(
					'price' => array( __( 'Price', 'authorwings-calculator' ), 'number' ),
					'words' => array( __( 'Words included', 'authorwings-calculator' ), 'number' ),
				);
			case 'perword_min':
				return array(
					'rate' => array( __( 'Per word', 'authorwings-calculator' ), 'rate' ),
					'min'  => array( __( 'Minimum price', 'authorwings-calculator' ), 'number' ),
				);
			case 'base_allowance_rate':
				return array(
					'base'  => array( __( 'Base price', 'authorwings-calculator' ), 'number' ),
					'words' => array( __( 'Words included', 'authorwings-calculator' ), 'number' ),
					'rate'  => array( __( 'Per word beyond', 'authorwings-calculator' ), 'rate' ),
				);
			case 'flat_unit':
				return array(
					'price' => array( __( 'Price', 'authorwings-calculator' ), 'number' ),
					'unit'  => array( __( 'Per-unit noun (blank = flat)', 'authorwings-calculator' ), 'text' ),
				);
			case 'flat':
			default:
				return array(
					'price' => array( __( 'Price', 'authorwings-calculator' ), 'number' ),
				);
		}
	}

	/**
	 * Register the top-level "AuthorWings Calculator" menu and its "Settings"
	 * submenu. The "Leads" submenu is added by AWPC_Submissions_Admin against the
	 * same parent slug. A count bubble on the parent flags unread leads.
	 */
	public function menu() {
		$title = __( 'AuthorWings Calculator', 'authorwings-calculator' );
		$label = $title;
		if ( class_exists( 'AWPC_Submissions' ) ) {
			$new = AWPC_Submissions::count( 'new' );
			if ( $new > 0 ) {
				$label .= ' <span class="awaiting-mod"><span class="pending-count">' . number_format_i18n( $new ) . '</span></span>';
			}
		}

		// When bundled inside another plugin (e.g. AuthorWings AI) the parent
		// slug is set via this filter so the calculator nests under that menu
		// instead of adding its own top-level item. Default '' keeps the
		// standalone plugin's own top-level "AuthorWings Calculator" menu.
		$parent = (string) apply_filters( 'awpc_admin_parent_slug', '' );

		if ( '' !== $parent ) {
			// Nested: a single submenu entry under the host plugin's menu. Its
			// own submissions "Leads" screen attaches to the same host parent
			// (see AWPC_Submissions_Admin::menu()).
			add_submenu_page(
				$parent,
				$title,
				$label,
				'manage_options',
				'awpc-settings',
				array( $this, 'render_page' ),
				80
			);
			return;
		}

		add_menu_page(
			$title,
			$label,
			'manage_options',
			'awpc-settings',
			array( $this, 'render_page' ),
			'dashicons-calculator',
			26
		);

		// Rename the auto-created first submenu entry to "Settings".
		add_submenu_page(
			'awpc-settings',
			__( 'Settings', 'authorwings-calculator' ),
			__( 'Settings', 'authorwings-calculator' ),
			'manage_options',
			'awpc-settings',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Register settings + handle saving.
	 */
	public function register_settings() {
		register_setting( 'awpc_settings', 'awpc_notify_email', array( 'sanitize_callback' => 'sanitize_email' ) );
		register_setting( 'awpc_settings', 'awpc_copy_lead', array( 'sanitize_callback' => array( $this, 'sanitize_yesno' ) ) );
		register_setting( 'awpc_settings', 'awpc_forminator_form', array( 'sanitize_callback' => array( $this, 'sanitize_forminator' ) ) );
		register_setting( 'awpc_settings', 'awpc_project_types', array( 'sanitize_callback' => array( $this, 'sanitize_project_types' ) ) );
		register_setting( 'awpc_settings', 'awpc_success_message', array( 'sanitize_callback' => array( $this, 'sanitize_success_message' ) ) );
		register_setting( 'awpc_settings', 'awpc_form_intro_title', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'awpc_settings', 'awpc_form_intro_subtitle', array( 'sanitize_callback' => 'sanitize_textarea_field' ) );
		register_setting( 'awpc_settings', 'awpc_important_notes', array( 'sanitize_callback' => array( $this, 'sanitize_success_message' ) ) );
		register_setting( 'awpc_settings', 'awpc_cta_label', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'awpc_settings', 'awpc_submit_label', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'awpc_settings', 'awpc_mobile_label', array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'awpc_settings', AWPC_Email_Template::OPTION_KEY, array( 'sanitize_callback' => array( $this, 'sanitize_email_tpl' ) ) );
		register_setting( 'awpc_settings', AWPC_Mailer::OPTION_KEY, array( 'sanitize_callback' => array( $this, 'sanitize_smtp' ) ) );
		register_setting(
			'awpc_settings',
			AWPC_Pricing_Data::CATALOGUE_KEY,
			array( 'sanitize_callback' => array( $this, 'sanitize_catalogue' ) )
		);
	}

	/**
	 * Sanitize a yes/no option.
	 *
	 * @param string $value Raw value.
	 * @return string
	 */
	public function sanitize_yesno( $value ) {
		return ( 'yes' === $value ) ? 'yes' : 'no';
	}

	/**
	 * Sanitize the Forminator estimate-form setting.
	 *
	 * Accepts either a bare numeric form ID (e.g. "53788") or a pasted
	 * Forminator shortcode (e.g. [forminator_form id="53788"]) and always
	 * stores a clean [forminator_form id="…"] shortcode. Anything else is
	 * discarded so only a valid Forminator shortcode is ever rendered.
	 *
	 * @param string $value Raw value.
	 * @return string Normalised shortcode or empty string.
	 */
	public function sanitize_forminator( $value ) {
		$value = is_string( $value ) ? trim( $value ) : '';
		if ( '' === $value ) {
			return '';
		}

		// A bare numeric ID — build the shortcode around it.
		if ( ctype_digit( $value ) ) {
			return '[forminator_form id="' . $value . '"]';
		}

		// A pasted shortcode — keep just the [forminator_form …] tag.
		if ( preg_match( '/\[forminator_form\b[^\]]*\]/i', $value, $m ) ) {
			return $m[0];
		}

		return '';
	}

	/**
	 * Sanitize the SMTP settings array.
	 *
	 * @param mixed $input Raw posted settings.
	 * @return array
	 */
	public function sanitize_smtp( $input ) {
		$in  = is_array( $input ) ? $input : array();
		$out = AWPC_Mailer::defaults();

		$out['enabled']    = ( isset( $in['enabled'] ) && 'yes' === $in['enabled'] ) ? 'yes' : 'no';
		$out['host']       = isset( $in['host'] ) ? sanitize_text_field( $in['host'] ) : '';
		$out['port']       = isset( $in['port'] ) ? max( 0, (int) $in['port'] ) : 587;
		$enc               = isset( $in['encryption'] ) ? $in['encryption'] : 'tls';
		$out['encryption'] = in_array( $enc, array( 'none', 'ssl', 'tls' ), true ) ? $enc : 'tls';
		$out['auth']       = ( isset( $in['auth'] ) && 'yes' === $in['auth'] ) ? 'yes' : 'no';
		$out['username']   = isset( $in['username'] ) ? sanitize_text_field( $in['username'] ) : '';
		$out['from_email'] = isset( $in['from_email'] ) ? sanitize_email( $in['from_email'] ) : '';
		$out['from_name']  = isset( $in['from_name'] ) ? sanitize_text_field( $in['from_name'] ) : '';
		$out['force_from'] = ( isset( $in['force_from'] ) && 'yes' === $in['force_from'] ) ? 'yes' : 'no';

		// Keep the stored password when the field is submitted blank, so it is
		// not wiped just because the admin didn't re-type it. The rendered field
		// is always blank and shows a placeholder when a password already exists.
		$posted_pw = isset( $in['password'] ) ? (string) $in['password'] : '';
		if ( '' === $posted_pw ) {
			$existing        = get_option( AWPC_Mailer::OPTION_KEY, array() );
			$out['password'] = ( is_array( $existing ) && ! empty( $existing['password'] ) ) ? $existing['password'] : '';
		} else {
			$out['password'] = $posted_pw;
		}

		return $out;
	}

	/**
	 * Sanitize the editable estimate-email content array.
	 *
	 * Text/subject/label fields are single-line; intro & note fields keep line
	 * breaks; the logo is a URL and the accent a hex colour. Any field left
	 * blank is stored blank, which makes the template fall back to its default.
	 *
	 * @param mixed $input Raw posted settings.
	 * @return array
	 */
	public function sanitize_email_tpl( $input ) {
		$in  = is_array( $input ) ? $input : array();
		$out = array();

		$single = array( 'brand', 'tagline', 'footer', 'lead_subject', 'lead_button', 'owner_subject', 'owner_heading', 'owner_button' );
		foreach ( $single as $key ) {
			$out[ $key ] = isset( $in[ $key ] ) ? sanitize_text_field( $in[ $key ] ) : '';
		}

		$multi = array( 'lead_intro', 'lead_note', 'owner_intro' );
		foreach ( $multi as $key ) {
			$out[ $key ] = isset( $in[ $key ] ) ? sanitize_textarea_field( $in[ $key ] ) : '';
		}

		$out['logo'] = isset( $in['logo'] ) ? esc_url_raw( trim( $in['logo'] ) ) : '';

		// Accent: accept a #hex colour; fall back to the template default.
		$accent = isset( $in['accent'] ) ? trim( $in['accent'] ) : '';
		if ( function_exists( 'sanitize_hex_color' ) ) {
			$accent = sanitize_hex_color( $accent );
		} elseif ( ! preg_match( '/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $accent ) ) {
			$accent = '';
		}
		$out['accent'] = $accent ? $accent : '';

		return $out;
	}

	/**
	 * Sanitize the "Project type" options textarea (one option per line).
	 *
	 * @param string $value Raw newline-separated list.
	 * @return string Cleaned newline-separated list.
	 */
	public function sanitize_project_types( $value ) {
		$value = is_string( $value ) ? $value : '';
		$lines = preg_split( '/\r\n|\r|\n/', $value );
		$out   = array();
		foreach ( $lines as $line ) {
			$line = trim( sanitize_text_field( $line ) );
			if ( '' !== $line ) {
				$out[] = $line;
			}
		}
		return implode( "\n", $out );
	}

	/**
	 * Sanitize the built-in form's confirmation message (multi-line text).
	 *
	 * @param string $value Raw value.
	 * @return string
	 */
	public function sanitize_success_message( $value ) {
		$value = is_string( $value ) ? $value : '';
		return sanitize_textarea_field( $value );
	}

	/**
	 * Turn a newline textarea into a clean list of feature bullets.
	 *
	 * @param string $raw Raw textarea value.
	 * @return array
	 */
	private function sanitize_features( $raw ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
			$line = trim( sanitize_text_field( $line ) );
			if ( '' !== $line ) {
				$out[] = $line;
			}
		}
		return $out;
	}

	/**
	 * Derive a stable slug key for an item.
	 *
	 * Existing slug-shaped keys are kept as-is so overrides/popular badges stay
	 * attached; JS "new_*" placeholders and anything non-slug are derived from
	 * the item's name instead.
	 *
	 * @param string $raw   Posted array key.
	 * @param string $label Item name.
	 * @return string
	 */
	private function slug_key( $raw, $label ) {
		$raw = is_string( $raw ) ? $raw : (string) $raw;
		if ( '' !== $raw && ! preg_match( '/^new[-_]/', $raw ) && preg_match( '/^[a-z0-9_]+$/', $raw ) ) {
			return $raw;
		}
		$slug = strtolower( (string) $label );
		$slug = preg_replace( '/[^a-z0-9]+/', '_', $slug );
		$slug = trim( (string) $slug, '_' );
		return '' !== $slug ? $slug : 'item';
	}

	/**
	 * Ensure a key is unique within a set of already-used keys.
	 *
	 * @param string $key  Candidate key.
	 * @param array  $used Map of used keys.
	 * @return string
	 */
	private function unique_key( $key, $used ) {
		if ( ! isset( $used[ $key ] ) ) {
			return $key;
		}
		$i = 2;
		while ( isset( $used[ $key . '_' . $i ] ) ) {
			$i++;
		}
		return $key . '_' . $i;
	}

	/**
	 * Build the full catalogue snapshot from the posted manager form.
	 *
	 * The form nests everything under the single AWPC_Pricing_Data::CATALOGUE_KEY
	 * option; this maps that form shape back onto the real pricing shape the
	 * calculator consumes, preserving control sections (currency, etc.) that the
	 * manager does not edit.
	 *
	 * @param mixed $input Posted option subtree.
	 * @return array
	 */
	public function sanitize_catalogue( $input ) {
		$in  = is_array( $input ) ? $input : array();
		$cat = AWPC_Pricing_Data::current();

		// GUARD: only rebuild the catalogue when the pricing manager actually
		// posted its fields. WordPress saves every option in the 'awpc_settings'
		// group on each save (calling this sanitizer even when these fields are
		// absent), and PHP silently drops fields past `max_input_vars` on this
		// large form — either way $in arrives empty/partial. Without this guard
		// every service section below would be overwritten with an empty array,
		// wiping the whole price list. The manager always emits a hidden
		// [sections_present] marker, so its absence means "not submitted" →
		// keep the stored catalogue untouched. (Bundles and payment plans are
		// already protected the same way further down.)
		if ( empty( $in['sections_present'] ) ) {
			return $cat;
		}

		$sections_in = ( isset( $in['sections'] ) && is_array( $in['sections'] ) ) ? $in['sections'] : array();
		$popular_in  = ( isset( $in['popular'] ) && is_array( $in['popular'] ) ) ? $in['popular'] : array();
		$popular     = isset( $cat['popular'] ) && is_array( $cat['popular'] ) ? $cat['popular'] : array();

		foreach ( $this->sections() as $section => $schema ) {
			$model   = $schema['model'];
			$fields  = $this->model_fields( $model );
			$rebuilt = array();

			// Per-section guard: if this section did not arrive in the POST (e.g.
			// dropped when the request exceeded max_input_vars), keep the stored
			// version instead of overwriting it with an empty array.
			if ( ! isset( $sections_in[ $section ] ) ) {
				continue;
			}

			// Preserve the structural "none" option (No cover / No formatting …).
			if ( ! empty( $schema['has_none'] ) ) {
				$rebuilt['none'] = isset( $cat[ $section ]['none'] )
					? $cat[ $section ]['none']
					: array( 'label' => __( 'None', 'authorwings-calculator' ), 'price' => 0 );
			}

			$items = ( isset( $sections_in[ $section ] ) && is_array( $sections_in[ $section ] ) ) ? $sections_in[ $section ] : array();
			$used  = array_fill_keys( array_keys( $rebuilt ), true );

			foreach ( $items as $raw_key => $item ) {
				if ( ! is_array( $item ) ) {
					continue;
				}
				$label = isset( $item['label'] ) ? sanitize_text_field( wp_unslash( $item['label'] ) ) : '';
				if ( '' === $label ) {
					continue; // Skip blank rows.
				}

				$key = $this->slug_key( $raw_key, $label );

				// Ghostwriting book-type maps onto the "childrens" key prefix.
				if ( ! empty( $schema['booktype'] ) ) {
					$is_child   = ( isset( $item['booktype'] ) && 'childrens' === $item['booktype'] );
					$has_prefix = ( 0 === strpos( $key, 'childrens' ) );
					if ( $is_child && ! $has_prefix ) {
						$key = 'childrens_' . $key;
					} elseif ( ! $is_child && $has_prefix ) {
						$key = preg_replace( '/^childrens_?/', '', $key );
						if ( '' === $key ) {
							$key = 'tier';
						}
					}
				}

				$key          = $this->unique_key( $key, $used );
				$used[ $key ] = true;

				if ( 'addon' === $model ) {
					$entry = array( 'label' => $label );
					$ptype = ( isset( $item['ptype'] ) && 'perword' === $item['ptype'] ) ? 'perword' : 'flat';
					if ( 'perword' === $ptype ) {
						$entry['rate'] = ( isset( $item['rate'] ) && is_numeric( $item['rate'] ) ) ? (float) $item['rate'] : 0;
					} else {
						$entry['price'] = ( isset( $item['price'] ) && is_numeric( $item['price'] ) ) ? ( 0 + $item['price'] ) : 0;
					}
					$group = isset( $item['group'] ) ? sanitize_text_field( wp_unslash( $item['group'] ) ) : '';
					if ( '' !== $group ) {
						$entry['group'] = $group;
					}
					$unit = isset( $item['unit'] ) ? sanitize_text_field( wp_unslash( $item['unit'] ) ) : '';
					if ( '' !== $unit ) {
						$entry['unit'] = $unit;
					}
				} else {
					$entry = array( 'label' => $label );
					foreach ( $fields as $fkey => $fmeta ) {
						$ftype = $fmeta[1];
						$rawv  = isset( $item[ $fkey ] ) ? wp_unslash( $item[ $fkey ] ) : '';
						if ( 'text' === $ftype ) {
							$v = sanitize_text_field( $rawv );
							if ( '' !== $v ) {
								$entry[ $fkey ] = $v; // e.g. illustration unit (blank = flat).
							}
						} elseif ( 'rate' === $ftype ) {
							$entry[ $fkey ] = is_numeric( $rawv ) ? (float) $rawv : 0;
						} else {
							$entry[ $fkey ] = is_numeric( $rawv ) ? ( 0 + $rawv ) : 0;
						}
					}
					$feat = isset( $item['features'] ) ? $this->sanitize_features( wp_unslash( $item['features'] ) ) : array();
					if ( ! empty( $feat ) ) {
						$entry['features'] = $feat;
					}
					// Preserve an additive per-tier "Most Popular" flag (e.g. children's
					// Growth) so it survives dashboard saves; the section radio only
					// tracks one badge per section.
					if ( ! empty( $item['popular'] ) ) {
						$entry['popular'] = true;
					}
				}

				$rebuilt[ $key ] = $entry;

				if ( ! empty( $schema['popular'] ) && isset( $popular_in[ $section ] ) && (string) $popular_in[ $section ] === (string) $raw_key ) {
					$popular[ $section ] = $key;
				}
			}

			$cat[ $section ] = $rebuilt;
		}

		$cat['popular'] = $popular;
		$cat            = $this->sanitize_bundles( $in, $cat );

		// Payment-plan thresholds.
		if ( isset( $in['plans'] ) && is_array( $in['plans'] ) ) {
			$plans = array();
			foreach ( $in['plans'] as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$label = isset( $row['label'] ) ? sanitize_text_field( wp_unslash( $row['label'] ) ) : '';
				if ( '' === $label ) {
					continue;
				}
				$plans[] = array(
					'max'   => ( isset( $row['max'] ) && is_numeric( $row['max'] ) ) ? (int) $row['max'] : 0,
					'label' => $label,
				);
			}
			if ( ! empty( $plans ) ) {
				$cat['payment_plans'] = $plans;
			}
		}

		// Rush surcharge multiplier.
		if ( isset( $in['misc']['rush_multiplier'] ) && is_numeric( $in['misc']['rush_multiplier'] ) ) {
			$cat['rush_multiplier'] = (float) $in['misc']['rush_multiplier'];
		}

		return $cat;
	}

	/**
	 * Rebuild the two-level bundles structure (+ popular bundle map) from POST.
	 *
	 * @param array $in  Posted option subtree.
	 * @param array $cat Catalogue being built.
	 * @return array Catalogue with bundles applied.
	 */
	private function sanitize_bundles( $in, $cat ) {
		// The manager always posts this marker, so an intentionally-empty bundle
		// list (every group deleted) persists, while a no-JS submit that never
		// rendered the section leaves existing bundles untouched.
		if ( empty( $in['bundles_present'] ) ) {
			return $cat;
		}
		$groups_in = ( isset( $in['bundles'] ) && is_array( $in['bundles'] ) ) ? $in['bundles'] : array();
		$pop_in       = ( isset( $in['bundles_popular'] ) && is_array( $in['bundles_popular'] ) ) ? $in['bundles_popular'] : array();
		$bundles      = array();
		$popular      = array();
		$used_groups  = array();

		foreach ( $groups_in as $graw => $g ) {
			if ( ! is_array( $g ) ) {
				continue;
			}
			$glabel = isset( $g['group'] ) ? sanitize_text_field( wp_unslash( $g['group'] ) ) : '';
			if ( '' === $glabel ) {
				continue;
			}
			$gkey                 = $this->unique_key( $this->slug_key( $graw, $glabel ), $used_groups );
			$used_groups[ $gkey ] = true;

			$tiers      = array();
			$used_tiers = array();
			$tiers_in   = ( isset( $g['tiers'] ) && is_array( $g['tiers'] ) ) ? $g['tiers'] : array();
			foreach ( $tiers_in as $traw => $t ) {
				if ( ! is_array( $t ) ) {
					continue;
				}
				$tlabel = isset( $t['label'] ) ? sanitize_text_field( wp_unslash( $t['label'] ) ) : '';
				if ( '' === $tlabel ) {
					continue;
				}
				$tkey                = $this->unique_key( $this->slug_key( $traw, $tlabel ), $used_tiers );
				$used_tiers[ $tkey ] = true;
				$tiers[ $tkey ]      = array(
					'label'    => $tlabel,
					'price'    => ( isset( $t['price'] ) && is_numeric( $t['price'] ) ) ? ( 0 + $t['price'] ) : 0,
					'saves'    => ( isset( $t['saves'] ) && is_numeric( $t['saves'] ) ) ? ( 0 + $t['saves'] ) : 0,
					'features' => isset( $t['features'] ) ? $this->sanitize_features( wp_unslash( $t['features'] ) ) : array(),
				);
				if ( isset( $pop_in[ $graw ] ) && (string) $pop_in[ $graw ] === (string) $traw ) {
					$popular[ $gkey ] = $tkey;
				}
			}
			if ( empty( $tiers ) ) {
				continue;
			}
			$bundles[ $gkey ] = array(
				'group' => $glabel,
				'tiers' => $tiers,
			);
		}

		$cat['bundles']         = $bundles;
		$cat['popular_bundles'] = $popular;
		return $cat;
	}

	/**
	 * Render one numeric/text/features field inside an item.
	 *
	 * @param string $name  Full input name.
	 * @param string $label Field label.
	 * @param string $type  'number' | 'rate' | 'text' | 'features'.
	 * @param mixed  $value Current value.
	 * @param array  $extra Optional: 'placeholder', 'class', 'hidden' (bool).
	 * @return string
	 */
	private function field( $name, $label, $type, $value, $extra = array() ) {
		$ph    = isset( $extra['placeholder'] ) ? $extra['placeholder'] : '';
		$cls   = isset( $extra['class'] ) ? ' ' . $extra['class'] : '';
		$hide  = ! empty( $extra['hidden'] ) ? ' style="display:none"' : '';
		$full  = ( 'features' === $type ) ? ' awpc-f-full' : '';
		ob_start();
		?>
		<label class="awpc-f<?php echo esc_attr( $full . $cls ); ?>"<?php echo $hide; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static markup. ?>>
			<span class="awpc-f-label"><?php echo esc_html( $label ); ?></span>
			<?php if ( 'features' === $type ) : ?>
				<textarea name="<?php echo esc_attr( $name ); ?>" rows="<?php echo (int) max( 2, count( (array) $value ) ); ?>" placeholder="<?php esc_attr_e( 'One feature per line', 'authorwings-calculator' ); ?>"><?php echo esc_textarea( implode( "\n", (array) $value ) ); ?></textarea>
			<?php elseif ( 'text' === $type ) : ?>
				<input type="text" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( (string) $value ); ?>" placeholder="<?php echo esc_attr( $ph ); ?>">
			<?php else : ?>
				<input type="number" step="<?php echo ( 'rate' === $type ) ? '0.001' : '1'; ?>" min="0" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( (string) $value ); ?>">
			<?php endif; ?>
		</label>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render one editable service item (name + model fields + features + controls).
	 *
	 * @param string $section     Section key.
	 * @param array  $schema      Section schema.
	 * @param string $key         Item key (or '__KEY__' for a JS template).
	 * @param array  $item        Item data.
	 * @param string $popular_key Currently-popular key in this section.
	 * @return string
	 */
	private function render_service_item( $section, $schema, $key, $item, $popular_key ) {
		$ns    = AWPC_Pricing_Data::CATALOGUE_KEY;
		$model = $schema['model'];
		$base  = $ns . '[sections][' . $section . '][' . $key . ']';
		$get   = function ( $k, $d = '' ) use ( $item ) {
			return isset( $item[ $k ] ) ? $item[ $k ] : $d;
		};
		$title = ( '__KEY__' === $key ) ? __( 'New item', 'authorwings-calculator' ) : (string) $get( 'label', $section );

		ob_start();
		?>
		<div class="awpc-item" data-item data-search="<?php echo esc_attr( strtolower( $title . ' ' . $schema['title'] ) ); ?>">
			<div class="awpc-item-head">
				<span class="awpc-item-drag" title="<?php esc_attr_e( 'Drag to reorder', 'authorwings-calculator' ); ?>">⋮⋮</span>
				<span class="awpc-item-title" data-title><?php echo esc_html( $title ); ?></span>
				<button type="button" class="button-link awpc-del-item" data-del title="<?php esc_attr_e( 'Delete this item', 'authorwings-calculator' ); ?>"><?php esc_html_e( 'Delete', 'authorwings-calculator' ); ?></button>
			</div>
			<div class="awpc-item-grid">
				<?php
				echo $this->field( $base . '[label]', __( 'Name', 'authorwings-calculator' ), 'text', $get( 'label' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- field() escapes.

				if ( ! empty( $schema['booktype'] ) ) {
					$is_child = ( '__KEY__' !== $key && 0 === strpos( $key, 'childrens' ) );
					?>
					<label class="awpc-f">
						<span class="awpc-f-label"><?php esc_html_e( 'Book type', 'authorwings-calculator' ); ?></span>
						<select name="<?php echo esc_attr( $base . '[booktype]' ); ?>">
							<option value="standard" <?php selected( ! $is_child ); ?>><?php esc_html_e( 'Standard', 'authorwings-calculator' ); ?></option>
							<option value="childrens" <?php selected( $is_child ); ?>><?php esc_html_e( "Children's", 'authorwings-calculator' ); ?></option>
						</select>
					</label>
					<?php
				}

				if ( 'addon' === $model ) {
					$is_rate = isset( $item['rate'] );
					?>
					<label class="awpc-f">
						<span class="awpc-f-label"><?php esc_html_e( 'Pricing', 'authorwings-calculator' ); ?></span>
						<select name="<?php echo esc_attr( $base . '[ptype]' ); ?>" data-addon-ptype>
							<option value="flat" <?php selected( ! $is_rate ); ?>><?php esc_html_e( 'Flat price', 'authorwings-calculator' ); ?></option>
							<option value="perword" <?php selected( $is_rate ); ?>><?php esc_html_e( 'Per word', 'authorwings-calculator' ); ?></option>
						</select>
					</label>
					<?php
					echo $this->field( $base . '[price]', __( 'Price', 'authorwings-calculator' ), 'number', $get( 'price', 0 ), array( 'class' => 'awpc-addon-flat', 'hidden' => $is_rate ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo $this->field( $base . '[rate]', __( 'Per word', 'authorwings-calculator' ), 'rate', $get( 'rate', 0 ), array( 'class' => 'awpc-addon-rate', 'hidden' => ! $is_rate ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo $this->field( $base . '[group]', __( 'Group', 'authorwings-calculator' ), 'text', $get( 'group' ), array( 'placeholder' => __( 'e.g. Marketing', 'authorwings-calculator' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo $this->field( $base . '[unit]', __( 'Per-unit noun (blank = one-off)', 'authorwings-calculator' ), 'text', $get( 'unit' ), array( 'placeholder' => __( 'e.g. region', 'authorwings-calculator' ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				} else {
					foreach ( $this->model_fields( $model ) as $fkey => $fmeta ) {
						$default = ( 'text' === $fmeta[1] ) ? '' : 0;
						echo $this->field( $base . '[' . $fkey . ']', $fmeta[0], $fmeta[1], $get( $fkey, $default ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					}
					echo $this->field( $base . '[features]', __( 'Features', 'authorwings-calculator' ), 'features', $get( 'features', array() ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				?>
			</div>
			<?php if ( ! empty( $schema['popular'] ) ) : ?>
				<label class="awpc-pop">
					<input type="radio" name="<?php echo esc_attr( $ns . '[popular][' . $section . ']' ); ?>" value="<?php echo esc_attr( $key ); ?>" <?php checked( '__KEY__' !== $key && (string) $popular_key === (string) $key ); ?>>
					<?php esc_html_e( 'Mark as “Most popular”', 'authorwings-calculator' ); ?>
				</label>
			<?php endif; ?>
			<?php if ( ! empty( $get( 'popular' ) ) ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $base . '[popular]' ); ?>" value="1">
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render one bundle tier row.
	 *
	 * @param string $gkey        Bundle group key (or '__GKEY__').
	 * @param string $tkey        Tier key (or '__TKEY__').
	 * @param array  $tier        Tier data.
	 * @param string $popular_key Popular tier key in this group.
	 * @return string
	 */
	private function render_bundle_tier( $gkey, $tkey, $tier, $popular_key ) {
		$ns   = AWPC_Pricing_Data::CATALOGUE_KEY;
		$base = $ns . '[bundles][' . $gkey . '][tiers][' . $tkey . ']';
		$get  = function ( $k, $d = '' ) use ( $tier ) {
			return isset( $tier[ $k ] ) ? $tier[ $k ] : $d;
		};
		ob_start();
		?>
		<div class="awpc-item" data-bundle-tier>
			<div class="awpc-item-head">
				<span class="awpc-item-title" data-title><?php echo esc_html( ( '__TKEY__' === $tkey ) ? __( 'New tier', 'authorwings-calculator' ) : (string) $get( 'label', __( 'Tier', 'authorwings-calculator' ) ) ); ?></span>
				<button type="button" class="button-link awpc-del-item" data-del-tier><?php esc_html_e( 'Delete tier', 'authorwings-calculator' ); ?></button>
			</div>
			<div class="awpc-item-grid">
				<?php
				echo $this->field( $base . '[label]', __( 'Name', 'authorwings-calculator' ), 'text', $get( 'label' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo $this->field( $base . '[price]', __( 'Price', 'authorwings-calculator' ), 'number', $get( 'price', 0 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo $this->field( $base . '[saves]', __( 'Saving vs individual pricing', 'authorwings-calculator' ), 'number', $get( 'saves', 0 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo $this->field( $base . '[features]', __( 'Features', 'authorwings-calculator' ), 'features', $get( 'features', array() ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
			</div>
			<label class="awpc-pop">
				<input type="radio" name="<?php echo esc_attr( $ns . '[bundles_popular][' . $gkey . ']' ); ?>" value="<?php echo esc_attr( $tkey ); ?>" <?php checked( '__TKEY__' !== $tkey && (string) $popular_key === (string) $tkey ); ?>>
				<?php esc_html_e( 'Mark as “Most popular”', 'authorwings-calculator' ); ?>
			</label>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render one bundle group (label + its tiers + add-tier).
	 *
	 * @param string $gkey        Group key (or '__GKEY__').
	 * @param array  $group       Group data.
	 * @param string $popular_key Popular tier key for this group.
	 * @return string
	 */
	private function render_bundle_group( $gkey, $group, $popular_key ) {
		$ns    = AWPC_Pricing_Data::CATALOGUE_KEY;
		$label = isset( $group['group'] ) ? $group['group'] : '';
		$tiers = ( isset( $group['tiers'] ) && is_array( $group['tiers'] ) ) ? $group['tiers'] : array();
		ob_start();
		?>
		<div class="awpc-bundle-group" data-bundle-group>
			<div class="awpc-item-head awpc-bundle-head">
				<input type="text" class="awpc-bundle-name" name="<?php echo esc_attr( $ns . '[bundles][' . $gkey . '][group]' ); ?>" value="<?php echo esc_attr( $label ); ?>" placeholder="<?php esc_attr_e( 'Bundle group name', 'authorwings-calculator' ); ?>">
				<button type="button" class="button-link awpc-del-item" data-del-group><?php esc_html_e( 'Delete group', 'authorwings-calculator' ); ?></button>
			</div>
			<div class="awpc-bundle-tiers" data-tiers>
				<?php
				foreach ( $tiers as $tkey => $tier ) {
					echo $this->render_bundle_tier( $gkey, (string) $tkey, $tier, $popular_key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				?>
			</div>
			<p><button type="button" class="button button-small awpc-add-tier"><?php esc_html_e( 'Add tier', 'authorwings-calculator' ); ?></button></p>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Render the whole "Plans & prices" manager (services, bundles, plans, rush).
	 *
	 * @param array $pricing Current effective catalogue.
	 * @return void
	 */
	private function render_pricing_manager( $pricing ) {
		$ns = AWPC_Pricing_Data::CATALOGUE_KEY;
		?>
		<input type="hidden" name="<?php echo esc_attr( $ns . '[sections_present]' ); ?>" value="1">
		<p class="description awpc-manager-intro">
			<?php esc_html_e( 'Add, edit, reorder or delete any service, add-on or bundle. Each service shows only the price fields its pricing model needs. Changes go live on the calculator as soon as you save. Use “Reset to defaults” at the bottom to restore the built-in catalogue.', 'authorwings-calculator' ); ?>
		</p>
		<div class="awpc-admin">
			<p class="awpc-admin-tools">
				<input type="search" class="awpc-admin-filter" placeholder="<?php esc_attr_e( 'Filter services & add-ons…', 'authorwings-calculator' ); ?>">
				<button type="button" class="button button-small awpc-admin-expand"><?php esc_html_e( 'Expand all', 'authorwings-calculator' ); ?></button>
				<button type="button" class="button button-small awpc-admin-collapse"><?php esc_html_e( 'Collapse all', 'authorwings-calculator' ); ?></button>
			</p>

			<?php foreach ( $this->sections() as $section => $schema ) :
				$items       = ( isset( $pricing[ $section ] ) && is_array( $pricing[ $section ] ) ) ? $pricing[ $section ] : array();
				$popular_key = isset( $pricing['popular'][ $section ] ) ? (string) $pricing['popular'][ $section ] : '';
				$count       = 0;
				foreach ( $items as $k => $v ) {
					if ( 'none' !== $k ) {
						$count++;
					}
				}
				?>
				<details class="awpc-acc" data-section="<?php echo esc_attr( $section ); ?>" data-model="<?php echo esc_attr( $schema['model'] ); ?>">
					<summary><?php echo esc_html( $schema['title'] ); ?> <span class="awpc-acc-count"><?php echo (int) $count; ?></span></summary>
					<div class="awpc-acc-body">
						<?php if ( ! empty( $schema['popular'] ) ) : ?>
							<p class="awpc-pop-none">
								<label><input type="radio" name="<?php echo esc_attr( $ns . '[popular][' . $section . ']' ); ?>" value="" <?php checked( '' === $popular_key ); ?>> <?php esc_html_e( 'No “Most popular” badge in this group', 'authorwings-calculator' ); ?></label>
							</p>
						<?php endif; ?>
						<div class="awpc-items" data-items>
							<?php
							foreach ( $items as $key => $item ) {
								if ( 'none' === $key ) {
									continue;
								}
								echo $this->render_service_item( $section, $schema, (string) $key, (array) $item, $popular_key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							}
							?>
						</div>
						<p><button type="button" class="button awpc-add-item" data-add-item><?php echo esc_html( $schema['add_label'] ); ?></button></p>
						<script type="text/html" class="awpc-tmpl-item" data-tmpl-section="<?php echo esc_attr( $section ); ?>"><?php echo $this->render_service_item( $section, $schema, '__KEY__', array(), '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
					</div>
				</details>
			<?php endforeach; ?>

			<details class="awpc-acc" data-section="bundles">
				<summary><?php esc_html_e( 'Bundles', 'authorwings-calculator' ); ?> <span class="awpc-acc-count"><?php echo (int) ( isset( $pricing['bundles'] ) ? count( (array) $pricing['bundles'] ) : 0 ); ?></span></summary>
				<div class="awpc-acc-body">
					<input type="hidden" name="<?php echo esc_attr( $ns . '[bundles_present]' ); ?>" value="1">
					<p class="description"><?php esc_html_e( 'Ready-made packages sold at a fixed price with an advertised saving. Each group holds one or more tiers.', 'authorwings-calculator' ); ?></p>
					<div class="awpc-bundle-groups" data-bundle-groups>
						<?php
						$bundles = ( isset( $pricing['bundles'] ) && is_array( $pricing['bundles'] ) ) ? $pricing['bundles'] : array();
						foreach ( $bundles as $gkey => $group ) {
							$pk = isset( $pricing['popular_bundles'][ $gkey ] ) ? (string) $pricing['popular_bundles'][ $gkey ] : '';
							echo $this->render_bundle_group( (string) $gkey, (array) $group, $pk ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						}
						?>
					</div>
					<p><button type="button" class="button awpc-add-group" data-add-group><?php esc_html_e( 'Add bundle group', 'authorwings-calculator' ); ?></button></p>
					<script type="text/html" class="awpc-tmpl-group"><?php echo $this->render_bundle_group( '__GKEY__', array(), '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
					<script type="text/html" class="awpc-tmpl-tier"><?php echo $this->render_bundle_tier( '__GKEY__', '__TKEY__', array(), '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
				</div>
			</details>

			<details class="awpc-acc" data-section="plans">
				<summary><?php esc_html_e( 'Payment plans', 'authorwings-calculator' ); ?> <span class="awpc-acc-count"><?php echo (int) ( isset( $pricing['payment_plans'] ) ? count( (array) $pricing['payment_plans'] ) : 0 ); ?></span></summary>
				<div class="awpc-acc-body">
					<p class="description"><?php esc_html_e( 'The payment guidance shown as the running total grows. “Up to” is the estimate ceiling for that row; set it to 0 for the final “no ceiling” row. Rows are matched from the top down.', 'authorwings-calculator' ); ?></p>
					<div class="awpc-plans" data-plans>
						<?php
						$plans = ( isset( $pricing['payment_plans'] ) && is_array( $pricing['payment_plans'] ) ) ? $pricing['payment_plans'] : array();
						foreach ( $plans as $i => $row ) {
							echo $this->render_plan_row( (int) $i, (array) $row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						}
						?>
					</div>
					<p><button type="button" class="button awpc-add-plan" data-add-plan><?php esc_html_e( 'Add payment-plan row', 'authorwings-calculator' ); ?></button></p>
					<script type="text/html" class="awpc-tmpl-plan"><?php echo $this->render_plan_row( '__I__', array() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></script>
				</div>
			</details>

			<details class="awpc-acc" data-section="misc">
				<summary><?php esc_html_e( 'Other', 'authorwings-calculator' ); ?></summary>
				<div class="awpc-acc-body">
					<div class="awpc-item">
						<div class="awpc-item-grid">
							<label class="awpc-f">
								<span class="awpc-f-label"><?php esc_html_e( 'Rush surcharge (e.g. 0.25 = 25%)', 'authorwings-calculator' ); ?></span>
								<input type="number" step="0.001" min="0" name="<?php echo esc_attr( $ns . '[misc][rush_multiplier]' ); ?>" value="<?php echo esc_attr( (string) ( isset( $pricing['rush_multiplier'] ) ? $pricing['rush_multiplier'] : 0 ) ); ?>">
							</label>
						</div>
					</div>
				</div>
			</details>
		</div>
		<?php
		$this->print_manager_script();
	}

	/**
	 * Render one payment-plan row.
	 *
	 * @param int|string $i   Row index (or '__I__' for a template).
	 * @param array      $row Row data.
	 * @return string
	 */
	private function render_plan_row( $i, $row ) {
		$ns   = AWPC_Pricing_Data::CATALOGUE_KEY;
		$base = $ns . '[plans][' . $i . ']';
		$max  = isset( $row['max'] ) ? $row['max'] : '';
		$lab  = isset( $row['label'] ) ? $row['label'] : '';
		ob_start();
		?>
		<div class="awpc-item awpc-plan-row" data-plan-row>
			<div class="awpc-item-grid">
				<?php
				echo $this->field( $base . '[max]', __( 'Up to ($, 0 = no ceiling)', 'authorwings-calculator' ), 'number', $max ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo $this->field( $base . '[label]', __( 'Guidance shown', 'authorwings-calculator' ), 'text', $lab ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
				<button type="button" class="button-link awpc-del-item" data-del-plan title="<?php esc_attr_e( 'Delete row', 'authorwings-calculator' ); ?>"><?php esc_html_e( 'Delete', 'authorwings-calculator' ); ?></button>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Inline styles for the compact, collapsible admin layout.
	 */
	private function print_admin_styles() {
		?>
		<style>
			.awpc-admin { max-width: 940px; }
			.awpc-admin-tools { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; margin: 14px 0; }
			.awpc-admin-filter { flex: 1 1 220px; max-width: 340px; padding: 6px 10px; }
			.awpc-acc { border: 1px solid #dcdcde; border-radius: 6px; margin: 8px 0; background: #fff; }
			.awpc-acc > summary { cursor: pointer; padding: 12px 14px; font-weight: 600; font-size: 14px; list-style: none; user-select: none; }
			.awpc-acc > summary::-webkit-details-marker { display: none; }
			.awpc-acc > summary::before { content: "\25B8"; margin-right: 8px; color: #787c82; }
			.awpc-acc[open] > summary::before { content: "\25BE"; }
			.awpc-acc-count { display: inline-block; margin-left: 6px; background: #f0f0f1; color: #646970; border-radius: 10px; padding: 0 8px; font-size: 11px; font-weight: 600; }
			.awpc-acc-body { padding: 4px 14px 12px; border-top: 1px solid #f0f0f1; }
			.awpc-item { padding: 10px 0; border-bottom: 1px solid #f0f0f1; }
			.awpc-item:last-child { border-bottom: none; }
			.awpc-item-title { font-weight: 600; margin-bottom: 6px; color: #1d2327; }
			.awpc-item-grid { display: flex; flex-wrap: wrap; gap: 8px 16px; align-items: flex-start; }
			.awpc-f { display: flex; flex-direction: column; gap: 3px; }
			.awpc-f-label { font-size: 11px; color: #646970; text-transform: uppercase; letter-spacing: .02em; }
			.awpc-f input[type="number"] { width: 92px; }
			.awpc-f input[type="text"] { width: 230px; }
			.awpc-f select { min-width: 120px; }
			.awpc-f-full { flex-basis: 100%; }
			.awpc-f-full textarea { width: 100%; max-width: 600px; }
			.awpc-item-head { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
			.awpc-item-head .awpc-item-title { margin-bottom: 0; flex: 1 1 auto; }
			.awpc-item-drag { color: #a7aaad; cursor: grab; font-size: 12px; letter-spacing: -2px; }
			.awpc-item.is-dragging { opacity: .5; }
			.awpc-del-item { color: #b32d2e !important; text-decoration: none; }
			.awpc-del-item:hover { color: #8a2424 !important; text-decoration: underline; }
			.awpc-pop { display: inline-flex; align-items: center; gap: 6px; margin-top: 6px; font-size: 12px; color: #50575e; }
			.awpc-pop-none { margin: 2px 0 10px; font-size: 12px; color: #646970; }
			.awpc-add-item, .awpc-add-group, .awpc-add-tier, .awpc-add-plan { margin-top: 4px; }
			.awpc-bundle-group { border: 1px solid #e0e0e2; border-radius: 6px; padding: 10px 12px; margin: 10px 0; background: #fbfbfc; }
			.awpc-bundle-head { gap: 10px; }
			.awpc-bundle-name { flex: 1 1 auto; max-width: 420px; font-weight: 600; }
			.awpc-bundle-tiers { padding-left: 6px; border-left: 3px solid #f0f0f1; }
			.awpc-plan-row .awpc-item-grid { align-items: flex-end; }
			.awpc-reset-wrap { margin: 18px 0 4px; }
			.awpc-reset { color: #b32d2e !important; border-color: #b32d2e !important; }
		</style>
		<?php
	}

	/**
	 * Inline script: filter + expand/collapse controls.
	 */
	private function print_admin_script() {
		?>
		<script>
		( function () {
			var filter = document.querySelector( '.awpc-admin-filter' );
			if ( ! filter ) { return; }
			var items = [].slice.call( document.querySelectorAll( '.awpc-admin .awpc-item' ) );
			var accs = [].slice.call( document.querySelectorAll( '.awpc-admin .awpc-acc' ) );

			filter.addEventListener( 'input', function () {
				var q = filter.value.trim().toLowerCase();
				items.forEach( function ( it ) {
					var ds = it.getAttribute( 'data-search' );
					var hit = ! q || ( ds && ds.indexOf( q ) !== -1 );
					it.style.display = hit ? '' : 'none';
				} );
				accs.forEach( function ( acc ) {
					var visible = [].slice.call( acc.querySelectorAll( '.awpc-item' ) ).some( function ( it ) {
						return it.style.display !== 'none';
					} );
					acc.style.display = visible ? '' : 'none';
					if ( q ) { acc.open = visible; }
				} );
			} );

			var expand = document.querySelector( '.awpc-admin-expand' );
			var collapse = document.querySelector( '.awpc-admin-collapse' );
			if ( expand ) { expand.addEventListener( 'click', function () { accs.forEach( function ( a ) { a.open = true; } ); } ); }
			if ( collapse ) { collapse.addEventListener( 'click', function () { accs.forEach( function ( a ) { a.open = false; } ); } ); }
		} )();
		</script>
		<?php
	}

	/**
	 * Inline script powering the add / delete / reorder manager.
	 */
	private function print_manager_script() {
		?>
		<script>
		( function () {
			var admin = document.querySelector( '.awpc-admin' );
			if ( ! admin ) { return; }
			var seq = 1;
			function uid() { return 'new_' + Date.now().toString( 36 ) + '_' + ( seq++ ); }

			// Clone a <script type="text/html"> template, swapping a placeholder key.
			function fromTemplate( tmpl, map ) {
				var html = tmpl.innerHTML;
				Object.keys( map ).forEach( function ( ph ) {
					html = html.split( ph ).join( map[ ph ] );
				} );
				var wrap = document.createElement( 'div' );
				wrap.innerHTML = html.trim();
				return wrap.firstElementChild;
			}

			function refreshCount( acc ) {
				var badge = acc.querySelector( '.awpc-acc-count' );
				if ( ! badge ) { return; }
				var box = acc.querySelector( '[data-items]' ) || acc.querySelector( '[data-bundle-groups]' ) || acc.querySelector( '[data-plans]' );
				if ( ! box ) { return; }
				var sel = box.hasAttribute( 'data-items' ) ? '[data-item]' : ( box.hasAttribute( 'data-bundle-groups' ) ? '[data-bundle-group]' : '[data-plan-row]' );
				badge.textContent = box.querySelectorAll( sel ).length;
			}

			function toggleAddon( sel ) {
				var item = sel.closest( '[data-item]' );
				if ( ! item ) { return; }
				var perword = ( sel.value === 'perword' );
				var flat = item.querySelector( '.awpc-addon-flat' );
				var rate = item.querySelector( '.awpc-addon-rate' );
				if ( flat ) { flat.style.display = perword ? 'none' : ''; }
				if ( rate ) { rate.style.display = perword ? '' : 'none'; }
			}

			// --- Delegated clicks (add / delete across all sections) ---
			admin.addEventListener( 'click', function ( e ) {
				var t = e.target;

				if ( t.closest( '[data-add-item]' ) ) {
					var acc = t.closest( '.awpc-acc' );
					var tmpl = acc.querySelector( '.awpc-tmpl-item' );
					var box = acc.querySelector( '[data-items]' );
					if ( tmpl && box ) {
						box.appendChild( fromTemplate( tmpl, { '__KEY__': uid() } ) );
						refreshCount( acc );
					}
					return;
				}
				if ( t.closest( '[data-del]' ) ) {
					var it = t.closest( '[data-item]' );
					var a1 = t.closest( '.awpc-acc' );
					if ( it ) { it.remove(); refreshCount( a1 ); }
					return;
				}
				if ( t.closest( '[data-add-group]' ) ) {
					var gacc = t.closest( '.awpc-acc' );
					var gtmpl = admin.querySelector( '.awpc-tmpl-group' );
					var gbox = gacc.querySelector( '[data-bundle-groups]' );
					if ( gtmpl && gbox ) {
						gbox.appendChild( fromTemplate( gtmpl, { '__GKEY__': uid() } ) );
						refreshCount( gacc );
					}
					return;
				}
				if ( t.closest( '[data-del-group]' ) ) {
					var grp = t.closest( '[data-bundle-group]' );
					var gacc2 = t.closest( '.awpc-acc' );
					if ( grp ) { grp.remove(); refreshCount( gacc2 ); }
					return;
				}
				if ( t.closest( '.awpc-add-tier' ) ) {
					var group = t.closest( '[data-bundle-group]' );
					var nameInput = group.querySelector( '.awpc-bundle-name' );
					var m = nameInput ? nameInput.getAttribute( 'name' ).match( /\[bundles\]\[([^\]]+)\]/ ) : null;
					var gkey = m ? m[1] : uid();
					var ttmpl = admin.querySelector( '.awpc-tmpl-tier' );
					var tbox = group.querySelector( '[data-tiers]' );
					if ( ttmpl && tbox ) {
						tbox.appendChild( fromTemplate( ttmpl, { '__GKEY__': gkey, '__TKEY__': uid() } ) );
					}
					return;
				}
				if ( t.closest( '[data-del-tier]' ) ) {
					var tier = t.closest( '[data-bundle-tier]' );
					if ( tier ) { tier.remove(); }
					return;
				}
				if ( t.closest( '[data-add-plan]' ) ) {
					var pacc = t.closest( '.awpc-acc' );
					var ptmpl = admin.querySelector( '.awpc-tmpl-plan' );
					var pbox = pacc.querySelector( '[data-plans]' );
					if ( ptmpl && pbox ) {
						pbox.appendChild( fromTemplate( ptmpl, { '__I__': uid() } ) );
						refreshCount( pacc );
					}
					return;
				}
				if ( t.closest( '[data-del-plan]' ) ) {
					var prow = t.closest( '[data-plan-row]' );
					var pacc2 = t.closest( '.awpc-acc' );
					if ( prow ) { prow.remove(); refreshCount( pacc2 ); }
					return;
				}
			} );

			// --- Live: addon pricing toggle + item title mirror ---
			admin.addEventListener( 'change', function ( e ) {
				if ( e.target.matches( '[data-addon-ptype]' ) ) { toggleAddon( e.target ); }
			} );
			admin.addEventListener( 'input', function ( e ) {
				var inp = e.target;
				if ( inp.name && /\[label\]$/.test( inp.name ) ) {
					var item = inp.closest( '[data-item],[data-bundle-tier]' );
					var title = item && item.querySelector( '[data-title]' );
					if ( title ) { title.textContent = inp.value || title.textContent; }
				}
			} );

			// Initialise addon toggles already on the page.
			[].slice.call( admin.querySelectorAll( '[data-addon-ptype]' ) ).forEach( toggleAddon );

			// --- Drag-to-reorder items within their own list ---
			var dragEl = null;
			admin.addEventListener( 'mousedown', function ( e ) {
				var handle = e.target.closest( '.awpc-item-drag' );
				if ( handle ) {
					var it = handle.closest( '[data-item]' );
					if ( it ) { it.setAttribute( 'draggable', 'true' ); }
				}
			} );
			admin.addEventListener( 'dragstart', function ( e ) {
				dragEl = e.target.closest( '[data-item]' );
				if ( dragEl ) { dragEl.classList.add( 'is-dragging' ); }
			} );
			admin.addEventListener( 'dragover', function ( e ) {
				if ( ! dragEl ) { return; }
				var over = e.target.closest( '[data-item]' );
				if ( ! over || over === dragEl ) { return; }
				var box = dragEl.parentNode;
				if ( over.parentNode !== box ) { return; } // only within the same list
				e.preventDefault();
				var rect = over.getBoundingClientRect();
				var after = ( e.clientY - rect.top ) > ( rect.height / 2 );
				box.insertBefore( dragEl, after ? over.nextSibling : over );
			} );
			admin.addEventListener( 'dragend', function () {
				if ( dragEl ) { dragEl.classList.remove( 'is-dragging' ); dragEl.removeAttribute( 'draggable' ); }
				dragEl = null;
			} );
		} )();
		</script>
		<?php
	}

	/**
	 * Send a test email to verify mail delivery.
	 */
	public function handle_test_email() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'authorwings-calculator' ) );
		}
		check_admin_referer( 'awpc_test_email' );

		$to   = get_option( 'awpc_notify_email', get_option( 'admin_email' ) );
		$sent = wp_mail(
			$to,
			sprintf( __( '[%s] AuthorWings Calculator test email', 'authorwings-calculator' ), get_bloginfo( 'name' ) ),
			__( "This is a test from the AuthorWings Pricing Calculator.\n\nIf you received this, the \"Email me this estimate\" form can deliver mail from your site.", 'authorwings-calculator' )
		);

		$status = $sent ? 'sent' : 'failed';
		wp_safe_redirect( add_query_arg( array( 'page' => 'awpc-settings', 'awpc_test' => $status ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Send a sample of both branded estimate emails to the notification address,
	 * using the current (saved) design/wording so admins can preview changes.
	 */
	public function handle_test_estimate() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'authorwings-calculator' ) );
		}
		check_admin_referer( 'awpc_test_estimate' );

		$site = get_bloginfo( 'name' );
		$to   = get_option( 'awpc_notify_email', get_option( 'admin_email' ) );

		// Representative sample data covering multiple line items and a saving.
		$sample = array(
			'site'      => $site,
			'name'      => __( 'Jane Author', 'authorwings-calculator' ),
			'email'     => $to,
			'phone'     => '+1 555 0142',
			'ptype'     => __( 'Full self-publishing', 'authorwings-calculator' ),
			'preferred' => '2026-07-15 14:00 (GMT-5)',
			'message'   => __( 'Excited to get my manuscript ready for launch!', 'authorwings-calculator' ),
			'summary'   => "• Editing — Comprehensive (60,000 words): \$1,800\n• Cover design — Growth: \$1,200\n• Publishing & distribution — Growth: \$950\n\nYou save \$300 vs. individual pricing\nEstimated total: \$4,250\nPayment options: 4 monthly payments of \$1,062",
			'total'     => '$4,250',
			'est_url'   => home_url( '/' ),
		);

		$template = new AWPC_Email_Template();
		$vars     = array(
			'{site}'  => $site,
			'{name}'  => $sample['name'],
			'{total}' => $sample['total'],
		);

		$domain     = wp_parse_url( home_url(), PHP_URL_HOST );
		$domain     = $domain ? preg_replace( '/^www\./', '', $domain ) : '';
		$from_name  = apply_filters( 'awpc_from_name', $site ? $site : get_bloginfo( 'name' ) );
		$from_email = apply_filters( 'awpc_from_email', $domain ? 'noreply@' . $domain : $to );
		$headers    = array(
			'Content-Type: text/html; charset=UTF-8',
			sprintf( 'From: %s <%s>', $from_name, $from_email ),
		);

		$owner_subject = '[' . __( 'SAMPLE', 'authorwings-calculator' ) . '] ' . $template->subject_owner( $vars );
		$lead_subject  = '[' . __( 'SAMPLE', 'authorwings-calculator' ) . '] ' . $template->subject_lead( $vars );

		$sent1 = wp_mail( $to, $owner_subject, $template->render_notification( $sample ), $headers );
		$sent2 = wp_mail( $to, $lead_subject, $template->render_lead( $sample ), $headers );

		$status = ( $sent1 && $sent2 ) ? 'sent' : 'failed';
		wp_safe_redirect( add_query_arg( array( 'page' => 'awpc-settings', 'awpc_sample' => $status ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Discard the saved catalogue and any legacy overrides, restoring defaults.
	 */
	public function handle_reset_pricing() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'authorwings-calculator' ) );
		}
		check_admin_referer( 'awpc_reset_pricing' );
		AWPC_Pricing_Data::reset();
		wp_safe_redirect( add_query_arg( array( 'page' => 'awpc-settings', 'awpc_reset' => '1' ), admin_url( 'admin.php' ) ) . '#pricing' );
		exit;
	}

	/**
	 * Render the settings page.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$pricing   = AWPC_Pricing_Data::get();
		$notify    = get_option( 'awpc_notify_email', get_option( 'admin_email' ) );
		$copy_lead = get_option( 'awpc_copy_lead', 'yes' );
		$fminator  = get_option( 'awpc_forminator_form', '' );
		$ptypes    = get_option( 'awpc_project_types', '' );
		$smsg      = get_option( 'awpc_success_message', '' );
		$intro_t   = get_option( 'awpc_form_intro_title', '' );
		$intro_s   = get_option( 'awpc_form_intro_subtitle', '' );
		$imp_notes = get_option( 'awpc_important_notes', '' );
		$cta_lbl   = get_option( 'awpc_cta_label', '' );
		$sub_lbl   = get_option( 'awpc_submit_label', '' );
		$mob_lbl   = get_option( 'awpc_mobile_label', '' );
		$smtp      = get_option( AWPC_Mailer::OPTION_KEY, array() );
		$smtp      = wp_parse_args( is_array( $smtp ) ? $smtp : array(), AWPC_Mailer::defaults() );

		// Editable estimate-email content: saved values (may be blank) shown over
		// their defaults as placeholders, so a blank field means "use default".
		$email_saved = get_option( AWPC_Email_Template::OPTION_KEY, array() );
		$email_saved = is_array( $email_saved ) ? $email_saved : array();
		$email_def   = AWPC_Email_Template::defaults();
		$eget        = function ( $key ) use ( $email_saved ) {
			return isset( $email_saved[ $key ] ) ? (string) $email_saved[ $key ] : '';
		};
		$ekey        = AWPC_Email_Template::OPTION_KEY;

		// Reset-to-defaults notice.
		if ( isset( $_GET['awpc_reset'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			printf(
				'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
				esc_html__( 'Prices, services and bundles have been reset to the built-in defaults.', 'authorwings-calculator' )
			);
		}

		// Test-email result notice.
		if ( isset( $_GET['awpc_test'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$ok = ( 'sent' === $_GET['awpc_test'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			printf(
				'<div class="notice %1$s is-dismissible"><p>%2$s</p></div>',
				esc_attr( $ok ? 'notice-success' : 'notice-error' ),
				$ok
					? esc_html__( 'Test email sent (wp_mail succeeded). Check the inbox & spam. On local dev (Local/MAMP) mail is usually trapped by a catcher like Mailpit/MailHog — open that instead. On a live site, if it never arrives, turn on “Send via SMTP” above and enter your mail server details.', 'authorwings-calculator' )
					: esc_html__( 'wp_mail() returned an error — your site cannot send mail. Turn on “Send via SMTP” above and enter valid SMTP details, then try again.', 'authorwings-calculator' )
			);
		}

		// Sample estimate-email result notice.
		if ( isset( $_GET['awpc_sample'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$ok = ( 'sent' === $_GET['awpc_sample'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			printf(
				'<div class="notice %1$s is-dismissible"><p>%2$s</p></div>',
				esc_attr( $ok ? 'notice-success' : 'notice-error' ),
				$ok
					? esc_html__( 'Sample estimate emails sent to your notification address — check the inbox (and spam) to preview your design and wording. Save your changes first if you just edited them.', 'authorwings-calculator' )
					: esc_html__( 'The sample emails could not be sent (wp_mail returned an error). Turn on “Send via SMTP” above and enter valid SMTP details, then try again.', 'authorwings-calculator' )
			);
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'AuthorWings Calculator', 'authorwings-calculator' ); ?></h1>

			<details class="awpc-howto">
				<summary><?php esc_html_e( 'How to use — shortcodes & setup', 'authorwings-calculator' ); ?></summary>

				<p style="margin:.2em 0;"><strong><?php esc_html_e( '1) Show the calculator directly on a page', 'authorwings-calculator' ); ?></strong><br>
					<?php esc_html_e( 'Add this shortcode to any page or post:', 'authorwings-calculator' ); ?>
					<code>[authorwings_calculator]</code>
					— <?php esc_html_e( 'or use the "AuthorWings Calculator" block / widget.', 'authorwings-calculator' ); ?>
				</p>

				<p style="margin:.6em 0 .2em;"><strong><?php esc_html_e( '2) Open the calculator in a popup from a button', 'authorwings-calculator' ); ?></strong><br>
					<?php esc_html_e( 'Add this where you want the button to appear. Clicking it opens the calculator in a popup on the same page:', 'authorwings-calculator' ); ?>
					<code>[authorwings_calculator_button label="Open the Cost Calculator"]</code>
				</p>

				<p style="margin:.6em 0 .2em;"><strong><?php esc_html_e( '3) Open the popup from your own link or menu item', 'authorwings-calculator' ); ?></strong><br>
					<?php esc_html_e( 'Place this shortcode once on the page (it shows nothing on its own):', 'authorwings-calculator' ); ?>
					<code>[authorwings_calculator_modal]</code><br>
					<?php
					printf(
						/* translators: 1: the #awpc-calculator anchor, 2: Appearance → Menus path. */
						esc_html__( 'Then point any link at %1$s. For a navigation menu, go to %2$s, add a Custom Link with that URL, and give it a label.', 'authorwings-calculator' ),
						'<code>#awpc-calculator</code>',
						'<em>' . esc_html__( 'Appearance → Menus', 'authorwings-calculator' ) . '</em>'
					);
					// phpcs:ignore — the two placeholders above are escaped/static markup.
					?>
				</p>

				<p class="description" style="margin:.6em 0 0;">
					<?php esc_html_e( 'The popup closes with the × button, a click outside it, or the Esc key, and opens automatically if someone lands on the page with #awpc-calculator in the URL. The button/modal shortcodes also accept the same title, subtitle and show_quote options as the main shortcode.', 'authorwings-calculator' ); ?>
				</p>
			</details>

			<style>
				.awpc-howto { margin:12px 0; padding:10px 14px; border:1px solid #dcdcde; border-radius:6px; background:#fff; }
				.awpc-howto > summary { font-weight:600; cursor:pointer; }
				.awpc-tab-nav { margin:16px 0 0; }
				.awpc-panel { display:none; }
				.awpc-panel.is-active { display:block; }
			</style>

			<h2 class="nav-tab-wrapper awpc-tab-nav">
				<a href="#leads" class="nav-tab" data-tab="leads"><?php esc_html_e( 'Leads & form', 'authorwings-calculator' ); ?></a>
				<a href="#emails" class="nav-tab" data-tab="emails"><?php esc_html_e( 'Emails', 'authorwings-calculator' ); ?></a>
				<a href="#pricing" class="nav-tab" data-tab="pricing"><?php esc_html_e( 'Plans & prices', 'authorwings-calculator' ); ?></a>
			</h2>

			<form method="post" action="options.php">
				<?php settings_fields( 'awpc_settings' ); ?>

				<div class="awpc-panel" data-panel="leads">
				<h2><?php esc_html_e( 'Lead notifications', 'authorwings-calculator' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="awpc_notify_email"><?php esc_html_e( 'Notification email', 'authorwings-calculator' ); ?></label></th>
						<td>
							<input type="email" id="awpc_notify_email" name="awpc_notify_email" value="<?php echo esc_attr( $notify ); ?>" class="regular-text">
							<p class="description"><?php esc_html_e( 'Where "Email me this estimate" submissions are sent.', 'authorwings-calculator' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Copy the lead', 'authorwings-calculator' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="awpc_copy_lead" value="yes" <?php checked( 'yes', $copy_lead ); ?>>
								<?php esc_html_e( 'Also email a copy of the estimate to the person who requested it.', 'authorwings-calculator' ); ?>
							</label>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Estimate request form (Forminator)', 'authorwings-calculator' ); ?></h2>
					<p class="description">
						<?php esc_html_e( 'Optional. Paste a Forminator form shortcode here to use your own Forminator form for the “Email me this estimate” button instead of the built-in email form. When set, clicking that button opens your Forminator form in a popup.', 'authorwings-calculator' ); ?>
					</p>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="awpc_forminator_form"><?php esc_html_e( 'Forminator form', 'authorwings-calculator' ); ?></label></th>
							<td>
								<input type="text" id="awpc_forminator_form" name="awpc_forminator_form" value="<?php echo esc_attr( $fminator ); ?>" class="regular-text" placeholder="[forminator_form id=&quot;53788&quot;]">
								<p class="description">
									<?php esc_html_e( 'Paste the full shortcode (e.g. [forminator_form id="53788"]) or just the form ID (e.g. 53788). Leave blank to keep the built-in “Email me this estimate” form.', 'authorwings-calculator' ); ?>
									<?php if ( ! defined( 'FORMINATOR_VERSION' ) && ! class_exists( 'Forminator' ) ) : ?>
										<br><strong><?php esc_html_e( 'Note:', 'authorwings-calculator' ); ?></strong>
										<?php esc_html_e( 'The Forminator plugin does not appear to be active. Install and activate Forminator for this form to display.', 'authorwings-calculator' ); ?>
									<?php endif; ?>
								</p>
							</td>
						</tr>
					</table>

					<h2><?php esc_html_e( 'Button labels', 'authorwings-calculator' ); ?></h2>
					<p class="description">
						<?php esc_html_e( 'Wording for the calculator’s call-to-action buttons. Leave any field blank to use the default shown in its placeholder.', 'authorwings-calculator' ); ?>
					</p>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="awpc_cta_label"><?php esc_html_e( 'Main button', 'authorwings-calculator' ); ?></label></th>
							<td>
								<input type="text" id="awpc_cta_label" name="awpc_cta_label" value="<?php echo esc_attr( $cta_lbl ); ?>" class="regular-text" placeholder="<?php echo esc_attr( AWPC_Calculator::default_cta_label() ); ?>">
								<p class="description"><?php esc_html_e( 'Shown in the estimate panel; opens the request form (or your Forminator form).', 'authorwings-calculator' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_submit_label"><?php esc_html_e( 'Submit button', 'authorwings-calculator' ); ?></label></th>
							<td>
								<input type="text" id="awpc_submit_label" name="awpc_submit_label" value="<?php echo esc_attr( $sub_lbl ); ?>" class="regular-text" placeholder="<?php echo esc_attr( AWPC_Calculator::default_submit_label() ); ?>">
								<p class="description"><?php esc_html_e( 'The built-in form’s send button. (Not used when a Forminator form is set — that form has its own button.)', 'authorwings-calculator' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_mobile_label"><?php esc_html_e( 'Mobile bar button', 'authorwings-calculator' ); ?></label></th>
							<td>
								<input type="text" id="awpc_mobile_label" name="awpc_mobile_label" value="<?php echo esc_attr( $mob_lbl ); ?>" class="regular-text" placeholder="<?php echo esc_attr( AWPC_Calculator::default_mobile_label() ); ?>">
								<p class="description"><?php esc_html_e( 'The sticky bar shown on phones. Keep it short.', 'authorwings-calculator' ); ?></p>
							</td>
						</tr>
					</table>

					<h2><?php esc_html_e( 'Built-in estimate form', 'authorwings-calculator' ); ?></h2>
					<p class="description">
						<?php esc_html_e( 'Used when no Forminator form is set above. The built-in form collects name, email, phone, project type, a preferred consultation date/time and time zone, plus notes — and emails you the full estimate.', 'authorwings-calculator' ); ?>
					</p>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="awpc_form_intro_title"><?php esc_html_e( 'Intro heading', 'authorwings-calculator' ); ?></label></th>
							<td>
								<input type="text" id="awpc_form_intro_title" name="awpc_form_intro_title" value="<?php echo esc_attr( $intro_t ); ?>" class="large-text" placeholder="<?php echo esc_attr( AWPC_Calculator::default_form_intro_title() ); ?>">
								<p class="description"><?php esc_html_e( 'Shown above the built-in form. Leave blank to use the default.', 'authorwings-calculator' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_form_intro_subtitle"><?php esc_html_e( 'Intro text', 'authorwings-calculator' ); ?></label></th>
							<td>
								<textarea id="awpc_form_intro_subtitle" name="awpc_form_intro_subtitle" rows="2" class="large-text" placeholder="<?php echo esc_attr( AWPC_Calculator::default_form_intro_subtitle() ); ?>"><?php echo esc_textarea( $intro_s ); ?></textarea>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_important_notes"><?php esc_html_e( 'Important notes', 'authorwings-calculator' ); ?></label></th>
							<td>
								<textarea id="awpc_important_notes" name="awpc_important_notes" rows="5" class="large-text" placeholder="<?php echo esc_attr( AWPC_Calculator::default_important_notes() ); ?>"><?php echo esc_textarea( $imp_notes ); ?></textarea>
								<p class="description"><?php esc_html_e( 'Shown under the form. First line is the heading; each following line is a separate note line. Leave blank to use the default.', 'authorwings-calculator' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_project_types"><?php esc_html_e( 'Project type options', 'authorwings-calculator' ); ?></label></th>
							<td>
								<textarea id="awpc_project_types" name="awpc_project_types" rows="7" class="large-text code" placeholder="<?php echo esc_attr( implode( "\n", AWPC_Calculator::default_project_types() ) ); ?>"><?php echo esc_textarea( $ptypes ); ?></textarea>
								<p class="description"><?php esc_html_e( 'One option per line for the “Project type” dropdown in the built-in form. Leave blank to use the defaults shown above.', 'authorwings-calculator' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_success_message"><?php esc_html_e( 'Confirmation message', 'authorwings-calculator' ); ?></label></th>
							<td>
								<textarea id="awpc_success_message" name="awpc_success_message" rows="9" class="large-text" placeholder="<?php echo esc_attr( AWPC_Calculator::default_success_message() ); ?>"><?php echo esc_textarea( $smsg ); ?></textarea>
								<p class="description"><?php esc_html_e( 'Shown after the built-in form is submitted successfully. The first line is used as the bold heading; the rest is the body (line breaks are kept). Leave blank to use the default shown above.', 'authorwings-calculator' ); ?></p>
							</td>
						</tr>
					</table>
				</div><!-- /.awpc-panel[leads] -->

				<div class="awpc-panel" data-panel="emails">
					<h2><?php esc_html_e( 'Estimate emails (design & wording)', 'authorwings-calculator' ); ?></h2>
					<p class="description">
						<?php esc_html_e( 'Customise the two branded HTML emails: the notification you receive and the copy the visitor receives. Leave any field blank to use its default (shown greyed out). You can use these placeholders in the text fields:', 'authorwings-calculator' ); ?>
						<code>{name}</code> <code>{site}</code> <code>{total}</code> <code>{preferred}</code>.
							<?php esc_html_e( '({preferred} is the visitor\'s chosen call date, time and time zone — best used in the visitor confirmation intro.)', 'authorwings-calculator' ); ?>
						<?php esc_html_e( 'Use “Send sample estimate emails” at the bottom of this page to preview your changes in a real inbox.', 'authorwings-calculator' ); ?>
					</p>

					<h3 style="margin-bottom:0;"><?php esc_html_e( 'Branding (both emails)', 'authorwings-calculator' ); ?></h3>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="awpc_email_logo"><?php esc_html_e( 'Header logo URL', 'authorwings-calculator' ); ?></label></th>
							<td>
								<input type="url" id="awpc_email_logo" name="<?php echo esc_attr( $ekey ); ?>[logo]" value="<?php echo esc_attr( $eget( 'logo' ) ); ?>" class="regular-text" placeholder="https://yoursite.com/logo.png">
								<p class="description"><?php esc_html_e( 'Optional. A hosted image (shown ~36px tall) used in the header instead of the brand name. Leave blank to show the name as text.', 'authorwings-calculator' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_email_brand"><?php esc_html_e( 'Brand name', 'authorwings-calculator' ); ?></label></th>
							<td><input type="text" id="awpc_email_brand" name="<?php echo esc_attr( $ekey ); ?>[brand]" value="<?php echo esc_attr( $eget( 'brand' ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"></td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_email_tagline"><?php esc_html_e( 'Header tagline', 'authorwings-calculator' ); ?></label></th>
							<td><input type="text" id="awpc_email_tagline" name="<?php echo esc_attr( $ekey ); ?>[tagline]" value="<?php echo esc_attr( $eget( 'tagline' ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( $email_def['tagline'] ); ?>"></td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_email_accent"><?php esc_html_e( 'Accent colour', 'authorwings-calculator' ); ?></label></th>
							<td>
								<input type="color" id="awpc_email_accent_picker" value="<?php echo esc_attr( '' !== $eget( 'accent' ) ? $eget( 'accent' ) : $email_def['accent'] ); ?>" style="vertical-align:middle;width:44px;height:30px;padding:0;border:1px solid #ccc;" oninput="document.getElementById('awpc_email_accent').value=this.value;">
								<input type="text" id="awpc_email_accent" name="<?php echo esc_attr( $ekey ); ?>[accent]" value="<?php echo esc_attr( $eget( 'accent' ) ); ?>" class="small-text" placeholder="<?php echo esc_attr( $email_def['accent'] ); ?>" oninput="var v=this.value.trim();if(/^#([0-9a-fA-F]{6})$/.test(v)){document.getElementById('awpc_email_accent_picker').value=v;}">
								<p class="description"><?php esc_html_e( 'Header, total row and buttons. A darker shade is derived automatically. Format: #5c7a6b.', 'authorwings-calculator' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_email_footer"><?php esc_html_e( 'Footer tagline', 'authorwings-calculator' ); ?></label></th>
							<td><input type="text" id="awpc_email_footer" name="<?php echo esc_attr( $ekey ); ?>[footer]" value="<?php echo esc_attr( $eget( 'footer' ) ); ?>" class="large-text" placeholder="<?php echo esc_attr( $email_def['footer'] ); ?>"></td>
						</tr>
					</table>

					<h3 style="margin-bottom:0;"><?php esc_html_e( 'Visitor confirmation email', 'authorwings-calculator' ); ?></h3>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="awpc_email_lead_subject"><?php esc_html_e( 'Subject', 'authorwings-calculator' ); ?></label></th>
							<td><input type="text" id="awpc_email_lead_subject" name="<?php echo esc_attr( $ekey ); ?>[lead_subject]" value="<?php echo esc_attr( $eget( 'lead_subject' ) ); ?>" class="large-text" placeholder="<?php echo esc_attr( $email_def['lead_subject'] ); ?>"></td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_email_lead_intro"><?php esc_html_e( 'Intro text', 'authorwings-calculator' ); ?></label></th>
							<td><textarea id="awpc_email_lead_intro" name="<?php echo esc_attr( $ekey ); ?>[lead_intro]" rows="3" class="large-text" placeholder="<?php echo esc_attr( $email_def['lead_intro'] ); ?>"><?php echo esc_textarea( $eget( 'lead_intro' ) ); ?></textarea>
								<p class="description"><?php esc_html_e( 'Shown under the “Hi {name},” greeting.', 'authorwings-calculator' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_email_lead_button"><?php esc_html_e( 'Button label', 'authorwings-calculator' ); ?></label></th>
							<td><input type="text" id="awpc_email_lead_button" name="<?php echo esc_attr( $ekey ); ?>[lead_button]" value="<?php echo esc_attr( $eget( 'lead_button' ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( $email_def['lead_button'] ); ?>"></td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_email_lead_note"><?php esc_html_e( 'Closing note', 'authorwings-calculator' ); ?></label></th>
							<td><textarea id="awpc_email_lead_note" name="<?php echo esc_attr( $ekey ); ?>[lead_note]" rows="3" class="large-text" placeholder="<?php echo esc_attr( $email_def['lead_note'] ); ?>"><?php echo esc_textarea( $eget( 'lead_note' ) ); ?></textarea>
								<p class="description"><?php esc_html_e( 'The soft note in the box below the button. Leave blank to hide it.', 'authorwings-calculator' ); ?></p>
							</td>
						</tr>
					</table>

					<h3 style="margin-bottom:0;"><?php esc_html_e( 'Your notification email', 'authorwings-calculator' ); ?></h3>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="awpc_email_owner_subject"><?php esc_html_e( 'Subject', 'authorwings-calculator' ); ?></label></th>
							<td><input type="text" id="awpc_email_owner_subject" name="<?php echo esc_attr( $ekey ); ?>[owner_subject]" value="<?php echo esc_attr( $eget( 'owner_subject' ) ); ?>" class="large-text" placeholder="<?php echo esc_attr( $email_def['owner_subject'] ); ?>"></td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_email_owner_heading"><?php esc_html_e( 'Heading', 'authorwings-calculator' ); ?></label></th>
							<td><input type="text" id="awpc_email_owner_heading" name="<?php echo esc_attr( $ekey ); ?>[owner_heading]" value="<?php echo esc_attr( $eget( 'owner_heading' ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( $email_def['owner_heading'] ); ?>"></td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_email_owner_intro"><?php esc_html_e( 'Intro text', 'authorwings-calculator' ); ?></label></th>
							<td><textarea id="awpc_email_owner_intro" name="<?php echo esc_attr( $ekey ); ?>[owner_intro]" rows="2" class="large-text" placeholder="<?php echo esc_attr( $email_def['owner_intro'] ); ?>"><?php echo esc_textarea( $eget( 'owner_intro' ) ); ?></textarea></td>
						</tr>
						<tr>
							<th scope="row"><label for="awpc_email_owner_button"><?php esc_html_e( 'Button label', 'authorwings-calculator' ); ?></label></th>
							<td><input type="text" id="awpc_email_owner_button" name="<?php echo esc_attr( $ekey ); ?>[owner_button]" value="<?php echo esc_attr( $eget( 'owner_button' ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( $email_def['owner_button'] ); ?>"></td>
						</tr>
					</table>

					<h2><?php esc_html_e( 'Email sending (SMTP)', 'authorwings-calculator' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'Send the calculator’s emails through your own SMTP server so they actually reach the inbox — no separate SMTP plugin required. Leave this off to use WordPress’ default mailer (PHP mail()), which many hosts block or send straight to spam.', 'authorwings-calculator' ); ?>
					<br>
					<?php esc_html_e( 'Typical settings: Gmail / Google Workspace → smtp.gmail.com, port 465 (SSL) with an App Password. Brevo → smtp-relay.brevo.com, port 587 (TLS). Or use your host’s mailbox for this domain. After saving, use “Send test email” below to confirm.', 'authorwings-calculator' ); ?>
				</p>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Send via SMTP', 'authorwings-calculator' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( AWPC_Mailer::OPTION_KEY ); ?>[enabled]" value="yes" <?php checked( 'yes', $smtp['enabled'] ); ?>>
								<?php esc_html_e( 'Route all site email through the SMTP server below.', 'authorwings-calculator' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="awpc_smtp_host"><?php esc_html_e( 'SMTP host', 'authorwings-calculator' ); ?></label></th>
						<td><input type="text" id="awpc_smtp_host" name="<?php echo esc_attr( AWPC_Mailer::OPTION_KEY ); ?>[host]" value="<?php echo esc_attr( $smtp['host'] ); ?>" class="regular-text" placeholder="smtp.example.com"></td>
					</tr>
					<tr>
						<th scope="row"><label for="awpc_smtp_port"><?php esc_html_e( 'Port', 'authorwings-calculator' ); ?></label></th>
						<td>
							<input type="number" id="awpc_smtp_port" name="<?php echo esc_attr( AWPC_Mailer::OPTION_KEY ); ?>[port]" value="<?php echo esc_attr( $smtp['port'] ); ?>" min="0" class="small-text">
							<?php esc_html_e( 'Common: 587 (TLS) or 465 (SSL).', 'authorwings-calculator' ); ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="awpc_smtp_encryption"><?php esc_html_e( 'Encryption', 'authorwings-calculator' ); ?></label></th>
						<td>
							<select id="awpc_smtp_encryption" name="<?php echo esc_attr( AWPC_Mailer::OPTION_KEY ); ?>[encryption]">
								<option value="none" <?php selected( 'none', $smtp['encryption'] ); ?>><?php esc_html_e( 'None', 'authorwings-calculator' ); ?></option>
								<option value="ssl" <?php selected( 'ssl', $smtp['encryption'] ); ?>><?php esc_html_e( 'SSL', 'authorwings-calculator' ); ?></option>
								<option value="tls" <?php selected( 'tls', $smtp['encryption'] ); ?>><?php esc_html_e( 'TLS', 'authorwings-calculator' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Authentication', 'authorwings-calculator' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( AWPC_Mailer::OPTION_KEY ); ?>[auth]" value="yes" <?php checked( 'yes', $smtp['auth'] ); ?>>
								<?php esc_html_e( 'This server requires a username and password (almost always yes).', 'authorwings-calculator' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="awpc_smtp_username"><?php esc_html_e( 'SMTP username', 'authorwings-calculator' ); ?></label></th>
						<td><input type="text" id="awpc_smtp_username" name="<?php echo esc_attr( AWPC_Mailer::OPTION_KEY ); ?>[username]" value="<?php echo esc_attr( $smtp['username'] ); ?>" class="regular-text" autocomplete="off"></td>
					</tr>
					<tr>
						<th scope="row"><label for="awpc_smtp_password"><?php esc_html_e( 'SMTP password', 'authorwings-calculator' ); ?></label></th>
						<td>
							<input type="password" id="awpc_smtp_password" name="<?php echo esc_attr( AWPC_Mailer::OPTION_KEY ); ?>[password]" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo esc_attr( '' !== $smtp['password'] ? esc_html__( '•••••••• (saved — leave blank to keep)', 'authorwings-calculator' ) : '' ); ?>">
							<p class="description"><?php esc_html_e( 'Stored in your site database. For Gmail/Workspace use an App Password, not your login password.', 'authorwings-calculator' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="awpc_smtp_from_email"><?php esc_html_e( 'From email', 'authorwings-calculator' ); ?></label></th>
						<td>
							<input type="email" id="awpc_smtp_from_email" name="<?php echo esc_attr( AWPC_Mailer::OPTION_KEY ); ?>[from_email]" value="<?php echo esc_attr( $smtp['from_email'] ); ?>" class="regular-text" placeholder="noreply@yourdomain.com">
							<p class="description"><?php esc_html_e( 'Use an address on your own domain. For most providers this must match (or be authorised by) the SMTP account above.', 'authorwings-calculator' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="awpc_smtp_from_name"><?php esc_html_e( 'From name', 'authorwings-calculator' ); ?></label></th>
						<td><input type="text" id="awpc_smtp_from_name" name="<?php echo esc_attr( AWPC_Mailer::OPTION_KEY ); ?>[from_name]" value="<?php echo esc_attr( $smtp['from_name'] ); ?>" class="regular-text" placeholder="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Force sender', 'authorwings-calculator' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( AWPC_Mailer::OPTION_KEY ); ?>[force_from]" value="yes" <?php checked( 'yes', $smtp['force_from'] ); ?>>
								<?php esc_html_e( 'Apply the From name/email above to all mail this site sends.', 'authorwings-calculator' ); ?>
							</label>
						</td>
					</tr>
				</table>
				</div><!-- /.awpc-panel[emails] -->

				<div class="awpc-panel" data-panel="pricing">
				<h2><?php esc_html_e( 'Plans, packages & prices', 'authorwings-calculator' ); ?></h2>

				<?php
				$this->print_admin_styles();
				$this->render_pricing_manager( $pricing );
				?>
				</div><!-- /.awpc-panel[pricing] -->

				<?php submit_button(); ?>
				<?php $this->print_admin_script(); ?>
			</form>

			<div class="awpc-panel awpc-panel-tools" data-panel="pricing">
				<hr>
				<h2><?php esc_html_e( 'Reset prices', 'authorwings-calculator' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Discard every change made above and restore the built-in AuthorWings catalogue (all default tiers, add-ons and bundles). This cannot be undone.', 'authorwings-calculator' ); ?></p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( __( 'Reset all prices, services and bundles to the built-in defaults? This cannot be undone.', 'authorwings-calculator' ) ); ?>');">
					<input type="hidden" name="action" value="awpc_reset_pricing">
					<?php wp_nonce_field( 'awpc_reset_pricing' ); ?>
					<?php submit_button( __( 'Reset to defaults', 'authorwings-calculator' ), 'secondary awpc-reset', 'submit', false ); ?>
				</form>
			</div><!-- /.awpc-panel-tools[pricing] -->

			<div class="awpc-panel awpc-panel-tools" data-panel="emails">
			<hr>
			<h2><?php esc_html_e( 'Test email delivery', 'authorwings-calculator' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Sends a test message to the notification email above using your site’s mailer.', 'authorwings-calculator' ); ?>
				<br>
				<strong><?php esc_html_e( 'Not receiving it?', 'authorwings-calculator' ); ?></strong>
				<?php esc_html_e( 'On local dev tools (Local by WP Engine, MAMP, etc.) outgoing mail is captured by a built-in catcher (Mailpit/MailHog) rather than delivered — open that tool to view it. Addresses ending in .local are not real inboxes. On a live site, turn on “Send via SMTP” above and enter your mail server details for reliable delivery.', 'authorwings-calculator' ); ?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="awpc_test_email">
				<?php wp_nonce_field( 'awpc_test_email' ); ?>
				<?php submit_button( __( 'Send test email', 'authorwings-calculator' ), 'secondary', 'submit', false ); ?>
			</form>

			<h2><?php esc_html_e( 'Preview the estimate emails', 'authorwings-calculator' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Sends a sample of both branded emails (your notification and the visitor confirmation) to the notification email above, using the design and wording currently saved. Save your changes first, then send.', 'authorwings-calculator' ); ?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="awpc_test_estimate">
				<?php wp_nonce_field( 'awpc_test_estimate' ); ?>
				<?php submit_button( __( 'Send sample estimate emails', 'authorwings-calculator' ), 'secondary', 'submit', false ); ?>
			</form>
			</div><!-- /.awpc-panel-tools[emails] -->

			<script>
			( function () {
				var KEY = 'awpcActiveTab';
				var nav = document.querySelector( '.awpc-tab-nav' );
				if ( ! nav ) { return; }
				var tabs   = [].slice.call( nav.querySelectorAll( '.nav-tab' ) );
				var panels = [].slice.call( document.querySelectorAll( '.awpc-panel' ) );
				function activate( name ) {
					if ( ! tabs.some( function ( t ) { return t.getAttribute( 'data-tab' ) === name; } ) ) {
						name = tabs[0].getAttribute( 'data-tab' );
					}
					tabs.forEach( function ( t ) {
						t.classList.toggle( 'nav-tab-active', t.getAttribute( 'data-tab' ) === name );
					} );
					panels.forEach( function ( p ) {
						p.classList.toggle( 'is-active', p.getAttribute( 'data-panel' ) === name );
					} );
					try { window.localStorage.setItem( KEY, name ); } catch ( e ) {}
				}
				tabs.forEach( function ( t ) {
					t.addEventListener( 'click', function ( e ) {
						e.preventDefault();
						activate( t.getAttribute( 'data-tab' ) );
					} );
				} );
				var initial = ( window.location.hash || '' ).replace( '#', '' );
				if ( ! initial ) { try { initial = window.localStorage.getItem( KEY ) || ''; } catch ( e ) {} }
				activate( initial || tabs[0].getAttribute( 'data-tab' ) );
			} )();
			</script>
		</div>
		<?php
	}
}
