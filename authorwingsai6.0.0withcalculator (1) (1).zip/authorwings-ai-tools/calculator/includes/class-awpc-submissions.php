<?php
/**
 * Submission storage.
 *
 * Every estimate/consultation request submitted through the built-in form is
 * saved to a dedicated database table so leads are never lost if email delivery
 * fails, and so they can be reviewed on the "AuthorWings Leads" dashboard.
 *
 * @package AuthorWings_Pricing_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AWPC_Submissions
 */
class AWPC_Submissions {

	/**
	 * Schema version — bump when the table structure changes.
	 */
	const DB_VERSION = '1';

	/**
	 * Option storing the installed schema version.
	 */
	const DB_VERSION_OPTION = 'awpc_db_version';

	/**
	 * Fully-qualified submissions table name.
	 *
	 * @return string
	 */
	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'awpc_submissions';
	}

	/**
	 * Create/upgrade the table when the stored schema version is out of date.
	 *
	 * Runs cheaply on every admin request; the option check short-circuits once
	 * the current schema is installed, so it also covers plugin upgrades where
	 * the activation hook never fires.
	 */
	public static function maybe_install() {
		if ( get_option( self::DB_VERSION_OPTION ) === self::DB_VERSION ) {
			return;
		}
		self::install();
	}

	/**
	 * Create or update the submissions table via dbDelta().
	 */
	public static function install() {
		global $wpdb;

		$table           = self::table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			created_at DATETIME NOT NULL,
			name VARCHAR(200) NOT NULL DEFAULT '',
			email VARCHAR(200) NOT NULL DEFAULT '',
			phone VARCHAR(100) NOT NULL DEFAULT '',
			project_type VARCHAR(200) NOT NULL DEFAULT '',
			preferred VARCHAR(200) NOT NULL DEFAULT '',
			message TEXT NOT NULL,
			summary TEXT NOT NULL,
			total VARCHAR(50) NOT NULL DEFAULT '',
			estimate_url TEXT NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'new',
			ip VARCHAR(100) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY status (status)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
	}

	/**
	 * Insert a new submission.
	 *
	 * @param array $data Sanitised submission fields.
	 * @return int Inserted row ID, or 0 on failure.
	 */
	public static function insert( $data ) {
		global $wpdb;

		$row = array(
			'created_at'   => current_time( 'mysql' ),
			'name'         => isset( $data['name'] ) ? (string) $data['name'] : '',
			'email'        => isset( $data['email'] ) ? (string) $data['email'] : '',
			'phone'        => isset( $data['phone'] ) ? (string) $data['phone'] : '',
			'project_type' => isset( $data['project_type'] ) ? (string) $data['project_type'] : '',
			'preferred'    => isset( $data['preferred'] ) ? (string) $data['preferred'] : '',
			'message'      => isset( $data['message'] ) ? (string) $data['message'] : '',
			'summary'      => isset( $data['summary'] ) ? (string) $data['summary'] : '',
			'total'        => isset( $data['total'] ) ? (string) $data['total'] : '',
			'estimate_url' => isset( $data['estimate_url'] ) ? (string) $data['estimate_url'] : '',
			'status'       => 'new',
			'ip'           => isset( $data['ip'] ) ? (string) $data['ip'] : '',
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$ok = $wpdb->insert( self::table_name(), $row );

		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * Fetch a single submission.
	 *
	 * @param int $id Submission ID.
	 * @return array|null Row as an associative array, or null.
	 */
	public static function get( $id ) {
		global $wpdb;
		$table = self::table_name();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", (int) $id ), ARRAY_A );
	}

	/**
	 * Query submissions with optional status filter, search and paging.
	 *
	 * @param array $args {
	 *     @type string $status   Status filter ('' for all).
	 *     @type string $search   Free-text search over name/email/phone/project.
	 *     @type int    $per_page Rows per page.
	 *     @type int    $paged    1-based page number.
	 * }
	 * @return array List of rows (associative arrays).
	 */
	public static function query( $args = array() ) {
		global $wpdb;
		$table = self::table_name();

		$args = wp_parse_args(
			$args,
			array(
				'status'   => '',
				'search'   => '',
				'per_page' => 20,
				'paged'    => 1,
			)
		);

		list( $where, $params ) = self::build_where( $args['status'], $args['search'] );

		$per_page = max( 1, (int) $args['per_page'] );
		$paged    = max( 1, (int) $args['paged'] );
		$offset   = ( $paged - 1 ) * $per_page;

		$sql      = "SELECT * FROM $table $where ORDER BY created_at DESC, id DESC LIMIT %d OFFSET %d";
		$params[] = $per_page;
		$params[] = $offset;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		return $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
	}

	/**
	 * Count submissions matching a status filter and search.
	 *
	 * @param string $status Status filter ('' for all).
	 * @param string $search Free-text search.
	 * @return int
	 */
	public static function count( $status = '', $search = '' ) {
		global $wpdb;
		$table = self::table_name();

		list( $where, $params ) = self::build_where( $status, $search );

		$sql = "SELECT COUNT(*) FROM $table $where";
		if ( $params ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
			return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( $sql );
	}

	/**
	 * Update a submission's status.
	 *
	 * @param int    $id     Submission ID.
	 * @param string $status New status ('new' or 'read').
	 * @return bool
	 */
	public static function update_status( $id, $status ) {
		global $wpdb;
		$status = in_array( $status, array( 'new', 'read' ), true ) ? $status : 'new';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return false !== $wpdb->update( self::table_name(), array( 'status' => $status ), array( 'id' => (int) $id ) );
	}

	/**
	 * Delete a submission.
	 *
	 * @param int $id Submission ID.
	 * @return bool
	 */
	public static function delete( $id ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return false !== $wpdb->delete( self::table_name(), array( 'id' => (int) $id ) );
	}

	/**
	 * Build the shared WHERE clause + prepared params for status/search.
	 *
	 * @param string $status Status filter.
	 * @param string $search Free-text search.
	 * @return array [ string $where, array $params ]
	 */
	private static function build_where( $status, $search ) {
		$clauses = array();
		$params  = array();

		if ( '' !== $status ) {
			$clauses[] = 'status = %s';
			$params[]  = $status;
		}

		$search = trim( (string) $search );
		if ( '' !== $search ) {
			$like      = '%' . $GLOBALS['wpdb']->esc_like( $search ) . '%';
			$clauses[] = '( name LIKE %s OR email LIKE %s OR phone LIKE %s OR project_type LIKE %s )';
			array_push( $params, $like, $like, $like, $like );
		}

		$where = $clauses ? ( 'WHERE ' . implode( ' AND ', $clauses ) ) : '';
		return array( $where, $params );
	}
}
