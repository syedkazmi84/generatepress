<?php
/**
 * Central pricing data for the AuthorWings calculator.
 *
 * All figures mirror the published AuthorWings services, plans and packages
 * (ghostwriting, editing, design, publishing, marketing, coaching and bundles).
 * Site owners can override any number via the Settings screen or the
 * `awpc_pricing` filter without touching this file.
 *
 * @package AuthorWings_Pricing_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AWPC_Pricing_Data
 */
class AWPC_Pricing_Data {

	const OPTION_KEY = 'awpc_pricing_overrides';

	/**
	 * Full editable catalogue saved by the dashboard "Plans & prices" manager.
	 *
	 * When present this is the authoritative pricing snapshot: it stores every
	 * item in full (not just diffs) so that items added or deleted from the
	 * dashboard persist. The legacy OPTION_KEY (diffs merged over defaults) is
	 * still honoured for installs that pre-date the manager, until the first
	 * save seeds a catalogue.
	 *
	 * @var string
	 */
	const CATALOGUE_KEY = 'awpc_catalogue';

	/**
	 * Default pricing structure.
	 *
	 * Prices in USD. Per-word services store a base price, the word allowance the
	 * base covers, and a marginal rate applied to every word beyond that.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'currency'        => array(
				'symbol' => '$',
				'code'   => 'USD',
			),

			// Whole-book ghostwriting tiers (fixed fee, includes editing pass).
			'ghostwriting'    => array(
				'starter'    => array(
					'label'    => 'Starter',
					'price'    => 5495,
					'words'    => 20000,
					'features' => array(
						'Up to 20,000 words',
						'8–12 week timeline',
						'2–3 hours of voice-capture interviews',
						'2 revision rounds',
						'Line, copy & proofread editing included',
						'Discovery consult · mutual NDA · 100% IP & source files',
					),
				),
				'growth'     => array(
					'label'    => 'Growth',
					'price'    => 9999,
					'words'    => 50000,
					'features' => array(
						'Up to 50,000 words',
						'16–24 week timeline',
						'8–10 hours of voice-capture interviews',
						'3 revision rounds',
						'Developmental, line, copy & proof editing',
						'Chapter pacing audit + dedicated project manager',
						'Discovery consult · mutual NDA · 100% IP & source files',
					),
				),
				'authority'  => array(
					'label'    => 'Authority',
					'price'    => 24999,
					'words'    => 90000,
					'features' => array(
						'Up to 90,000 words',
						'24–36 week timeline',
						'10–12 hours of voice-capture interviews',
						'Unlimited revision rounds',
						'All four editing levels in sequence',
						'Beta-read pass + senior project manager',
						'Discovery consult · mutual NDA · 100% IP & source files',
					),
				),
				'childrens_starter'   => array(
					'label'    => "Children's — Starter",
					'price'    => 2999,
					'words'    => 800,
					'features' => array(
						'Up to 800 words · up to 10 full-colour illustrations',
						'Best for board, picture & simple early-reader books',
						'Ages 3–7 · 10–14 week timeline',
						'Story writing + age-appropriate voice & pacing',
					),
				),
				'childrens_growth'    => array(
					'label'    => "Children's — Growth",
					'price'    => 4999,
					'words'    => 2500,
					'popular'  => true,
					'features' => array(
						'Up to 2,500 words · up to 20 full-colour illustrations',
						'Best for extended picture & early chapter books',
						'Ages 5–9 · 14–20 week timeline',
						'Consistent character & style direction',
					),
				),
				'childrens_authority' => array(
					'label'    => "Children's — Authority",
					'price'    => 9999,
					'words'    => 15000,
					'features' => array(
						'Up to 15,000 words · up to 30 full-colour illustrations',
						'Best for chapter, illustrated middle-grade & series',
						'Ages 8–12 · 20–28 week timeline',
						'Full character bible & art direction',
					),
				),
			),

			// Editing tiers — priced per word with a minimum (floor) price.
			'editing'         => array(
				'polish'        => array(
					'label'    => 'Polish',
					'rate'     => 0.015,
					'min'      => 299,
					'features' => array(
						'Copy edit (grammar) + final proofread',
						'Formatting consistency check',
						'1 editing round · 5–10 business days',
					),
				),
				'standard'      => array(
					'label'    => 'Standard',
					'rate'     => 0.027,
					'min'      => 549,
					'features' => array(
						'Line + copy editing + final proofread',
						'Style sheet + tracked changes & comments',
						'2 editing rounds · 10–15 business days',
					),
				),
				'comprehensive' => array(
					'label'    => 'Comprehensive',
					'rate'     => 0.10,
					'min'      => 1995,
					'features' => array(
						'All four EFA levels (dev, line, copy, proof)',
						'Style sheet + 8–20 page editorial letter',
						'3 editing rounds · 21–30 business days',
					),
				),
			),

			// À la carte per-word editing services (base covers the word allowance,
			// then the marginal rate applies to every word beyond it).
			'editing_individual' => array(
				'developmental' => array(
					'label'    => 'Developmental edit',
					'base'     => 600,
					'words'    => 10000,
					'rate'     => 0.060,
					'features' => array( 'Structure, plot & pacing', 'Base covers 10,000 words', '$0.060 / word beyond' ),
				),
				'line'          => array(
					'label'    => 'Line editing',
					'base'     => 350,
					'words'    => 10000,
					'rate'     => 0.035,
					'features' => array( 'Sentence-level style & flow', 'Base covers 10,000 words', '$0.035 / word beyond' ),
				),
				'copy'          => array(
					'label'    => 'Copy editing',
					'base'     => 230,
					'words'    => 10000,
					'rate'     => 0.023,
					'features' => array( 'Grammar, consistency & usage', 'Base covers 10,000 words', '$0.023 / word beyond' ),
				),
				'proof'         => array(
					'label'    => 'Proofreading',
					'base'     => 140,
					'words'    => 10000,
					'rate'     => 0.014,
					'features' => array( 'Final typo & formatting pass', 'Base covers 10,000 words', '$0.014 / word beyond' ),
				),
			),

			// Cover design.
			'cover'           => array(
				'none'      => array( 'label' => 'No cover', 'price' => 0, 'note' => 'I already have a cover' ),
				'starter'   => array(
					'label'    => 'Starter',
					'price'    => 199,
					'features' => array( 'Ebook cover only', 'Source files included' ),
				),
				'growth'    => array(
					'label'    => 'Growth',
					'price'    => 399,
					'features' => array( 'Ebook, paperback & hardcover', 'Briefed against top-20 genre comps' ),
				),
				'authority' => array(
					'label'    => 'Authority',
					'price'    => 999,
					'features' => array( 'Custom illustration', 'Marketing asset set included' ),
				),
			),

			// Interior formatting.
			'interior'        => array(
				'none'     => array( 'label' => 'No formatting', 'price' => 0, 'note' => "I'll format it myself" ),
				'ebook'    => array(
					'label'    => 'Ebook only',
					'price'    => 199,
					'features' => array( 'Reflowable ebook formatting' ),
				),
				'print'    => array(
					'label'    => 'Ebook + print',
					'price'    => 599,
					'features' => array( 'Ebook + print interior', 'Validated on KDP, IngramSpark, Apple & Kobo' ),
				),
				'premium'  => array(
					'label'    => 'Print-ready (premium)',
					'price'    => 1495,
					'features' => array( 'Comprehensive print-ready files', 'Complex layouts & image-heavy interiors' ),
				),
			),

			// Book illustration.
			'illustration'    => array(
				'none'        => array( 'label' => 'No illustration', 'price' => 0, 'note' => 'No illustrations needed' ),
				'spot'        => array(
					'label'    => 'Spot',
					'price'    => 159,
					'unit'     => 'illustration',
					'features' => array( 'Best for chapter headers & scene breaks', 'Two-to-four-inch placement · 5–8 business days', '2–3 revision rounds · sketch round before colour', 'Print-ready 300 DPI CMYK PDF · full ownership' ),
				),
				'halfpage'    => array(
					'label'    => 'Half-Page',
					'price'    => 199,
					'unit'     => 'illustration',
					'features' => array( 'Best for chapter openers & feature art', 'Half-page placement · 7–10 business days', 'CMYK + RGB versions · Kindle & Apple fixed-layout specs', '2–3 revision rounds · full ownership' ),
				),
				'fullpage'    => array(
					'label'    => 'Full-Page',
					'price'    => 289,
					'unit'     => 'illustration',
					'features' => array( 'Best for picture-book & full-page spreads', 'Full-page placement · 10–15 business days', 'Bleed area for full-bleed spreads · CMYK + RGB', '2–3 revision rounds · full ownership' ),
				),
				'picturebook' => array(
					'label'    => 'Picture Book Package',
					'price'    => 2995,
					'features' => array( 'Up to 12 full-colour illustrations', 'Character design & character bible', 'Print-ready POD files · full ownership' ),
				),
				'complete'    => array(
					'label'    => 'Full Book Package',
					'price'    => 4500,
					'features' => array( 'Up to 24 illustrations', 'Character design, bible & matching cover illustration', 'Print-ready POD files · full ownership' ),
				),
			),

			// Publishing & distribution tiers.
			'publishing'      => array(
				'none'      => array( 'label' => 'No publishing', 'price' => 0, 'note' => "I'll self-publish or I'm already published" ),
				'starter'   => array(
					'label'    => 'Starter',
					'price'    => 249,
					'features' => array( 'Amazon KDP ebook · Author Central profile', '2 categories · 7 keywords', '5–10 business days' ),
				),
				'growth'    => array(
					'label'    => 'Growth',
					'price'    => 549,
					'features' => array( 'Multi-platform ebook + paperback', 'Universal Book Link · 14 keywords', '10–15 business days' ),
				),
				'authority' => array(
					'label'    => 'Authority',
					'price'    => 1299,
					'features' => array( 'Adds hardcover + audiobook setup', 'Library distribution · Goodreads & BookBub profiles', '21 keywords + A+ Content · 30-day post-launch monitoring', '15–30 business days' ),
				),
			),

			// Marketing tiers.
			'marketing'       => array(
				'none'       => array( 'label' => 'No marketing', 'price' => 0, 'note' => "I'll handle my own promotion" ),
				'foundation' => array(
					'label'    => 'Foundation',
					'price'    => 1495,
					'features' => array( 'Best for building marketing infrastructure first', '4-page author website + Amazon & Goodreads setup', 'Email list + lead magnet + 3 welcome emails · author bio', '1 launch-sequencing call · Tier 2 channel recommendation doc', '3–4 weeks setup' ),
				),
				'growth'     => array(
					'label'    => 'Growth',
					'price'    => 2495,
					'features' => array( 'Best for a 30-day Amazon Ads launch', 'Everything in Foundation + 30-day Amazon Ads management', '5–10 micro-influencers · 1 press release · ARC (BookFunnel/NetGalley)', '2 social platforms · 15 launch posts · weekly reports', '3–4 weeks setup + 30-day campaign' ),
				),
				'authority'  => array(
					'label'    => 'Authority',
					'price'    => 5995,
					'features' => array( 'Best for a 60-day multi-platform launch with PR', '60-day Amazon + Facebook/Instagram + BookBub Ads', 'PR & podcast outreach · Kirkus/BookLife review · PR wire · book trailer', '20 posts · weekly calls · dedicated account manager', '3–4 weeks setup + 60-day campaign' ),
				),
			),

			// Coaching tiers.
			'coaching'        => array(
				'none'      => array( 'label' => 'No coaching', 'price' => 0, 'note' => "I don't need coaching" ),
				'starter'   => array(
					'label'    => 'Starter',
					'price'    => 549,
					'features' => array( '2 sessions · 5,000 words reviewed (2,500/session cap)', '14 days email support · 4–6 week timeline', 'Recorded 60-min sessions · notes within 48h · line-by-line review' ),
				),
				'growth'    => array(
					'label'    => 'Growth',
					'price'    => 1199,
					'features' => array( '5 sessions · 12,500 words reviewed (2,500/session cap)', '60 days email support · 3–4 month timeline', 'Recorded 60-min sessions · notes within 48h · line-by-line review' ),
				),
				'authority' => array(
					'label'    => 'Authority',
					'price'    => 2499,
					'features' => array( '10 sessions · 30,000 words reviewed (3,000/session cap)', '6 months email support · 5–7 month timeline', 'Structural + chapter-level reviews built into early sessions' ),
				),
			),

			// Optional add-ons (checkbox line items). A 'rate' key means the price is
			// charged per word (multiplied by the manuscript length) instead of flat.
			'addons'          => array(
				// Publishing & rights.
				'copyright'      => array( 'group' => 'Publishing & rights', 'label' => 'Copyright registration (+$65 filing fee)', 'price' => 199 ),
				'isbn'           => array( 'group' => 'Publishing & rights', 'label' => 'Bowker ISBN (plus Bowker fees)', 'price' => 125 ),
				'series'         => array( 'group' => 'Publishing & rights', 'label' => 'Series setup', 'price' => 99 ),
				'addl_format'    => array( 'group' => 'Publishing & rights', 'label' => 'Additional format (hardcover / large print)', 'price' => 199, 'unit' => 'format' ),
				'audiobook'      => array( 'group' => 'Publishing & rights', 'label' => 'Audiobook production (from)', 'price' => 1500 ),
				'translation'    => array( 'group' => 'Publishing & rights', 'label' => 'Translation (from $0.10 / word, per language)', 'rate' => 0.10, 'unit' => 'language' ),
				'book_screen'    => array( 'group' => 'Publishing & rights', 'label' => 'Book-to-screen opportunity pitch', 'price' => 4995 ),
				'foreign_rights' => array( 'group' => 'Publishing & rights', 'label' => 'Foreign rights pitch (per region)', 'price' => 3495, 'unit' => 'region' ),

				// Marketing.
				'paid_review'    => array( 'group' => 'Marketing', 'label' => 'Paid book review (Kirkus / BookLife / Foreword)', 'price' => 699 ),
				'pr_wire'        => array( 'group' => 'Marketing', 'label' => 'PR wire release', 'price' => 649 ),
				'trailer'        => array( 'group' => 'Marketing', 'label' => 'Standard book trailer', 'price' => 999 ),
				'trailer_prem'   => array( 'group' => 'Marketing', 'label' => 'Premium book trailer', 'price' => 1999 ),
				'netgalley'      => array( 'group' => 'Marketing', 'label' => 'NetGalley setup', 'price' => 199 ),
				'bookfunnel'     => array( 'group' => 'Marketing', 'label' => 'BookFunnel ARC setup', 'price' => 149 ),

				// Premium / authority.
				'tv_podcast'     => array( 'group' => 'Premium / authority', 'label' => 'TV / podcast interview booking', 'price' => 1995 ),
				'national_pr'    => array( 'group' => 'Premium / authority', 'label' => 'National PR campaign', 'price' => 7495 ),
				'speaking'       => array( 'group' => 'Premium / authority', 'label' => 'Speaking engagement booking', 'price' => 2995 ),
				'awards'         => array( 'group' => 'Premium / authority', 'label' => 'Awards submission package', 'price' => 1495 ),
				'book_fair'      => array( 'group' => 'Premium / authority', 'label' => 'Book fair exhibition (per fair)', 'price' => 2495, 'unit' => 'fair' ),
				'kindle_promo'   => array( 'group' => 'Premium / authority', 'label' => 'Kindle Direct promotion campaign', 'price' => 1495 ),
				'billboard'      => array( 'group' => 'Premium / authority', 'label' => 'Billboard campaign (per market)', 'price' => 4995, 'unit' => 'market' ),
			),

			// Rush surcharge applied to production services.
			'rush_multiplier' => 0.25,

			// "Most Popular" recommended tier per group (Build Your Own).
			// Map of control => tier key. Set to '' to remove a badge.
			'popular'         => array(
				'ghostwriting' => 'growth',
				'editing'      => 'standard',
				'cover'        => 'growth',
				'illustration' => 'halfpage',
				'publishing'   => 'growth',
				'marketing'    => 'growth',
				'coaching'     => 'growth',
			),

			// "Most Popular" recommended bundle per bundle group.
			'popular_bundles' => array(
				'launch'  => 'growth',
				'editing' => 'growth',
				'publish' => 'growth',
			),

			// Ready-made bundles (fixed price + advertised saving).
			'bundles'         => array(
				'launch' => array(
					'group' => 'Launch-Ready (Ghostwriting + Design + Publishing + Marketing)',
					'tiers' => array(
						'starter'   => array( 'label' => 'Launch-Ready Starter', 'price' => 6495, 'saves' => 1342, 'features' => array( 'Starter ghostwriting', 'Cover + interior design', 'Starter publishing', 'Foundation marketing' ) ),
						'growth'    => array( 'label' => 'Launch-Ready Growth', 'price' => 12495, 'saves' => 2296, 'features' => array( 'Growth ghostwriting', 'Multi-format design', 'Growth publishing', 'Growth marketing' ) ),
						'authority' => array( 'label' => 'Launch-Ready Authority', 'price' => 28495, 'saves' => 5396, 'features' => array( 'Authority ghostwriting', 'Premium illustrated design', 'Authority publishing', 'Authority marketing' ) ),
					),
				),
				'editing' => array(
					'group' => 'Editing Bundles (Editing + Design + Publishing + Marketing)',
					'tiers' => array(
						'starter'   => array( 'label' => 'Editing Starter', 'price' => 2895, 'saves' => 696, 'features' => array( 'Standard editing', 'Cover + formatting', 'Basic publishing', 'Starter marketing', 'Up to 30,000 words' ) ),
						'growth'    => array( 'label' => 'Editing Growth', 'price' => 5795, 'saves' => 1992, 'features' => array( 'Comprehensive editing', 'Multi-format cover', 'Audiobook setup', 'Growth marketing', 'Up to 30,000 words' ) ),
						'authority' => array( 'label' => 'Editing Authority', 'price' => 9995, 'saves' => 3885, 'features' => array( 'Comprehensive editing', 'Premium illustrated cover', 'Audiobook', 'Authority marketing', 'Up to 50,000 words' ) ),
					),
				),
				'publish' => array(
					'group' => 'Publish-Ready (Cover + Formatting + Publishing)',
					'tiers' => array(
						'starter'   => array( 'label' => 'Publish-Ready Starter', 'price' => 1099, 'saves' => 448, 'features' => array( 'Starter cover', 'Ebook formatting', 'Starter publishing' ) ),
						'growth'    => array( 'label' => 'Publish-Ready Growth', 'price' => 2195, 'saves' => 452, 'features' => array( 'Growth cover', 'Ebook + print formatting', 'Growth publishing' ) ),
						'authority' => array( 'label' => 'Publish-Ready Authority', 'price' => 3295, 'saves' => 1148, 'features' => array( 'Authority cover', 'Full formatting', 'Authority publishing' ) ),
					),
				),
			),

			// Payment plan thresholds (by total estimate).
			'payment_plans'   => array(
				array( 'max' => 1000, 'label' => 'Full payment upfront' ),
				array( 'max' => 5000, 'label' => '50 / 50 split (start & midpoint)' ),
				array( 'max' => 10000, 'label' => 'Milestone payments — 25% per phase' ),
				array( 'max' => 20000, 'label' => 'Up to a 6-month payment plan' ),
				array( 'max' => 0, 'label' => 'Up to a 12-month payment plan' ),
			),
		);
	}

	/**
	 * Pricing used by the calculator: the saved catalogue if one exists, else the
	 * legacy defaults + diff-overrides, with the `awpc_pricing` filter applied.
	 *
	 * @return array
	 */
	public static function get() {
		/**
		 * Filter the full pricing array used by the calculator.
		 *
		 * @param array $pricing Pricing data.
		 */
		return apply_filters( 'awpc_pricing', self::current() );
	}

	/**
	 * The current effective catalogue WITHOUT the `awpc_pricing` filter — the
	 * exact data the dashboard manager edits and seeds from.
	 *
	 * Priority: a saved full catalogue (add/delete-aware) → otherwise the legacy
	 * defaults merged with any stored diff-overrides. Missing top-level sections
	 * are back-filled from defaults so an older catalogue still gains new control
	 * sections (currency, payment plans…) without resurrecting deleted items.
	 *
	 * @return array
	 */
	public static function current() {
		$catalogue = get_option( self::CATALOGUE_KEY, null );
		if ( is_array( $catalogue ) && ! empty( $catalogue ) && ! self::catalogue_is_blank( $catalogue ) ) {
			foreach ( self::defaults() as $key => $value ) {
				if ( ! array_key_exists( $key, $catalogue ) ) {
					$catalogue[ $key ] = $value;
				}
			}
			return $catalogue;
		}

		// Self-heal: a saved snapshot whose priced service sections are all empty
		// is a corrupt catalogue (e.g. blanked by a truncated settings save in an
		// older build). Discard it and fall back to defaults so pricing reappears
		// automatically, instead of showing an empty calculator.
		if ( is_array( $catalogue ) && ! empty( $catalogue ) && self::catalogue_is_blank( $catalogue ) ) {
			delete_option( self::CATALOGUE_KEY );
		}

		$defaults  = self::defaults();
		$overrides = get_option( self::OPTION_KEY, array() );
		if ( is_array( $overrides ) && ! empty( $overrides ) ) {
			$defaults = self::deep_merge( $defaults, $overrides );
		}
		return $defaults;
	}

	/**
	 * Whether a stored catalogue has NO priced service items at all — i.e. every
	 * service/add-on section (excluding structural "none" rows) is empty. Such a
	 * snapshot is treated as corrupt and ignored by current().
	 *
	 * Bundles and payment plans are intentionally excluded: a site can legitimately
	 * run with no bundles, and those sections survive the truncation bug anyway.
	 *
	 * @param array $catalogue Stored catalogue snapshot.
	 * @return bool
	 */
	private static function catalogue_is_blank( $catalogue ) {
		$service_keys = array(
			'ghostwriting',
			'editing',
			'editing_individual',
			'cover',
			'interior',
			'illustration',
			'publishing',
			'marketing',
			'coaching',
			'addons',
		);

		foreach ( $service_keys as $section ) {
			if ( empty( $catalogue[ $section ] ) || ! is_array( $catalogue[ $section ] ) ) {
				continue;
			}
			foreach ( $catalogue[ $section ] as $key => $item ) {
				if ( 'none' !== $key ) {
					return false; // Found at least one real priced item — not blank.
				}
			}
		}

		return true;
	}

	/**
	 * Whether a full catalogue has been saved from the dashboard manager.
	 *
	 * @return bool
	 */
	public static function has_catalogue() {
		$catalogue = get_option( self::CATALOGUE_KEY, null );
		return is_array( $catalogue ) && ! empty( $catalogue );
	}

	/**
	 * Persist a full catalogue snapshot from the dashboard manager.
	 *
	 * @param array $catalogue Full pricing array.
	 * @return void
	 */
	public static function save_catalogue( $catalogue ) {
		if ( is_array( $catalogue ) && ! empty( $catalogue ) ) {
			update_option( self::CATALOGUE_KEY, $catalogue );
		}
	}

	/**
	 * Reset to the built-in defaults by discarding the saved catalogue and any
	 * legacy diff-overrides.
	 *
	 * @return void
	 */
	public static function reset() {
		delete_option( self::CATALOGUE_KEY );
		delete_option( self::OPTION_KEY );
	}

	/**
	 * Recursively merge overrides over defaults (overrides win on scalars).
	 *
	 * @param array $base     Defaults.
	 * @param array $override Overrides.
	 * @return array
	 */
	private static function deep_merge( $base, $override ) {
		foreach ( $override as $key => $value ) {
			// Sequential lists (e.g. feature bullets) are replaced wholesale, not merged by index.
			if ( is_array( $value ) && isset( $base[ $key ] ) && is_array( $base[ $key ] ) && ! self::is_list( $value ) ) {
				$base[ $key ] = self::deep_merge( $base[ $key ], $value );
			} else {
				$base[ $key ] = $value;
			}
		}
		return $base;
	}

	/**
	 * Whether an array is a sequential list (0,1,2,…). PHP 7-compatible.
	 *
	 * @param array $arr Array.
	 * @return bool
	 */
	private static function is_list( $arr ) {
		if ( array() === $arr ) {
			return true;
		}
		return array_keys( $arr ) === range( 0, count( $arr ) - 1 );
	}
}
