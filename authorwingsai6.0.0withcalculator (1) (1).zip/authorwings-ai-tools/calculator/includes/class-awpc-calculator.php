<?php
/**
 * Front-end calculator: shortcode, block, widget, assets and markup.
 *
 * @package AuthorWings_Pricing_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AWPC_Calculator
 */
class AWPC_Calculator {

	/**
	 * Whether the shortcode has rendered on this request (so we only enqueue once).
	 *
	 * @var bool
	 */
	private $rendered = false;

	/**
	 * Whether a popup/modal version of the calculator was requested on this page.
	 *
	 * @var bool
	 */
	private $modal_needed = false;

	/**
	 * Resolved attributes for the popup/modal calculator (title, subtitle, …).
	 *
	 * @var array
	 */
	private $modal_atts = array();

	/**
	 * Whether a Forminator estimate form popup is needed on this page.
	 *
	 * Set when the calculator renders with the quote form enabled and a
	 * Forminator shortcode has been configured in the settings.
	 *
	 * @var bool
	 */
	private $forminator_needed = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_shortcode( 'authorwings_calculator', array( $this, 'render_shortcode' ) );
		add_shortcode( 'authorwings_calculator_button', array( $this, 'render_button_shortcode' ) );
		add_shortcode( 'authorwings_calculator_modal', array( $this, 'render_modal_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'init', array( $this, 'register_block' ) );
		add_action( 'widgets_init', array( $this, 'register_widget' ) );
		add_action( 'wp_footer', array( $this, 'render_footer_modal' ) );
		// Runs after render_footer_modal so a popup-only calculator has already
		// flagged that the estimate form is needed by the time this fires.
		add_action( 'wp_footer', array( $this, 'render_forminator_modal' ), 11 );
	}

	/**
	 * The configured Forminator estimate-form shortcode, if any.
	 *
	 * @return string Shortcode string (e.g. [forminator_form id="53788"]) or ''.
	 */
	private function forminator_shortcode() {
		$value = get_option( 'awpc_forminator_form', '' );
		return is_string( $value ) ? trim( $value ) : '';
	}

	/**
	 * Simple option getter with a default fallback for the built-in form copy.
	 *
	 * @param string $key     Option name.
	 * @param string $default Default when the option is empty.
	 * @return string
	 */
	private static function copy_option( $key, $default ) {
		$val = get_option( $key, '' );
		$val = is_string( $val ) ? trim( $val ) : '';
		return ( '' !== $val ) ? $val : $default;
	}

	/**
	 * Label for the main call-to-action button (opens the request form / popup).
	 *
	 * @return string
	 */
	public static function default_cta_label() {
		return __( 'Get my free quote & book a consultation', 'authorwings-calculator' );
	}

	/**
	 * Resolved main CTA label.
	 *
	 * @return string
	 */
	public static function cta_label() {
		return self::copy_option( 'awpc_cta_label', self::default_cta_label() );
	}

	/**
	 * Label for the built-in form's submit button.
	 *
	 * @return string
	 */
	public static function default_submit_label() {
		return __( 'Book my free consultation call', 'authorwings-calculator' );
	}

	/**
	 * Resolved submit-button label.
	 *
	 * @return string
	 */
	public static function submit_label() {
		return self::copy_option( 'awpc_submit_label', self::default_submit_label() );
	}

	/**
	 * Label for the mobile sticky-bar button.
	 *
	 * @return string
	 */
	public static function default_mobile_label() {
		return __( 'Get my free quote', 'authorwings-calculator' );
	}

	/**
	 * Resolved mobile-bar label.
	 *
	 * @return string
	 */
	public static function mobile_label() {
		return self::copy_option( 'awpc_mobile_label', self::default_mobile_label() );
	}

	/**
	 * Intro heading shown above the built-in form.
	 *
	 * @return string
	 */
	public static function default_form_intro_title() {
		return __( 'Book Your Free Consultation', 'authorwings-calculator' );
	}

	/**
	 * Resolved intro heading.
	 *
	 * @return string
	 */
	public static function form_intro_title() {
		return self::copy_option( 'awpc_form_intro_title', self::default_form_intro_title() );
	}

	/**
	 * Intro sub-text shown above the built-in form.
	 *
	 * @return string
	 */
	public static function default_form_intro_subtitle() {
		return __( 'Share a few details and pick a time that suits you. On a free 45-minute call, a publishing advisor will discuss your book, then send a written quote, a clear timeline, and honest guidance on the right path forward.', 'authorwings-calculator' );
	}

	/**
	 * Resolved intro sub-text.
	 *
	 * @return string
	 */
	public static function form_intro_subtitle() {
		return self::copy_option( 'awpc_form_intro_subtitle', self::default_form_intro_subtitle() );
	}

	/**
	 * Default "Important notes" block (first line = heading, rest = note lines).
	 *
	 * @return string
	 */
	public static function default_important_notes() {
		return __(
			"Good to know\n" .
			"All figures are estimates — your final quote is confirmed on your free consultation call.\n" .
			"Third-party costs (ads, platform/retailer fees, ISBN) are billed to you directly.\n" .
			"You keep 100% of your rights, copyright and royalties.",
			'authorwings-calculator'
		);
	}

	/**
	 * Resolved "Important notes" block.
	 *
	 * @return string
	 */
	public static function important_notes() {
		return self::copy_option( 'awpc_important_notes', self::default_important_notes() );
	}

	/**
	 * Render a simple note block from text (first line heading, rest plain lines).
	 *
	 * @param string $text     Raw multi-line text.
	 * @param string $extra_cls Extra CSS class for the wrapper.
	 */
	private function render_notes_block( $text, $extra_cls = '' ) {
		$text = trim( (string) $text );
		if ( '' === $text ) {
			return;
		}
		$lines   = preg_split( '/\r\n|\r|\n/', $text );
		$heading = trim( (string) array_shift( $lines ) );
		$notes   = array();
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' !== $line ) {
				$notes[] = $line;
			}
		}
		?>
		<div class="awpc-notes <?php echo esc_attr( $extra_cls ); ?>">
			<?php if ( '' !== $heading ) : ?>
				<p class="awpc-notes-title"><?php echo esc_html( $heading ); ?></p>
			<?php endif; ?>
			<?php foreach ( $notes as $n ) : ?>
				<p class="awpc-notes-line"><?php echo esc_html( $n ); ?></p>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Default confirmation message shown after the built-in form is submitted.
	 *
	 * @return string
	 */
	public static function default_success_message() {
		return __(
			"Thank you — your consultation request is in.\n\n" .
			"What's next: a publishing advisor will call at your preferred time to talk through your book, goals and timeline, and confirm the scope and a refined quote. Within 48 hours of the call, a written proposal and next steps land in your inbox.\n\n" .
			"A confirmation with your estimate is on its way now — if you don't see it, please check your spam folder.",
			'authorwings-calculator'
		);
	}

	/**
	 * Resolved confirmation message — the admin's text, or the default.
	 *
	 * @return string
	 */
	public static function success_message() {
		$msg = get_option( 'awpc_success_message', '' );
		$msg = is_string( $msg ) ? trim( $msg ) : '';
		return ( '' !== $msg ) ? $msg : self::default_success_message();
	}

	/**
	 * Default "Project type" dropdown options for the built-in form.
	 *
	 * @return array
	 */
	public static function default_project_types() {
		return array(
			__( 'Ghostwriting / book writing', 'authorwings-calculator' ),
			__( 'Editing', 'authorwings-calculator' ),
			__( 'Cover design', 'authorwings-calculator' ),
			__( 'Interior formatting', 'authorwings-calculator' ),
			__( 'Publishing & distribution', 'authorwings-calculator' ),
			__( 'Marketing', 'authorwings-calculator' ),
			__( 'Coaching', 'authorwings-calculator' ),
			__( 'Full package', 'authorwings-calculator' ),
			__( 'Not sure yet', 'authorwings-calculator' ),
		);
	}

	/**
	 * Resolved "Project type" options — the admin's list, or the defaults.
	 *
	 * @return array
	 */
	public static function project_types() {
		$raw = get_option( 'awpc_project_types', '' );
		$raw = is_string( $raw ) ? trim( $raw ) : '';
		if ( '' === $raw ) {
			return self::default_project_types();
		}
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
			$line = trim( $line );
			if ( '' !== $line ) {
				$out[] = $line;
			}
		}
		return ! empty( $out ) ? $out : self::default_project_types();
	}

	/**
	 * Time-zone options for the built-in form's "Your time zone" dropdown.
	 *
	 * A compact, human-readable list keyed by the value stored/emailed.
	 *
	 * @return array
	 */
	public static function timezones() {
		return array(
			'GMT-12:00' => __( '(GMT-12:00) Baker Island', 'authorwings-calculator' ),
			'GMT-11:00' => __( '(GMT-11:00) American Samoa', 'authorwings-calculator' ),
			'GMT-10:00' => __( '(GMT-10:00) Hawaii', 'authorwings-calculator' ),
			'GMT-09:00' => __( '(GMT-09:00) Alaska', 'authorwings-calculator' ),
			'GMT-08:00' => __( '(GMT-08:00) Pacific Time (US & Canada)', 'authorwings-calculator' ),
			'GMT-07:00' => __( '(GMT-07:00) Mountain Time (US & Canada)', 'authorwings-calculator' ),
			'GMT-06:00' => __( '(GMT-06:00) Central Time (US & Canada)', 'authorwings-calculator' ),
			'GMT-05:00' => __( '(GMT-05:00) Eastern Time (US & Canada)', 'authorwings-calculator' ),
			'GMT-04:00' => __( '(GMT-04:00) Atlantic Time (Canada)', 'authorwings-calculator' ),
			'GMT-03:00' => __( '(GMT-03:00) Buenos Aires, Brazil', 'authorwings-calculator' ),
			'GMT-01:00' => __( '(GMT-01:00) Azores, Cape Verde', 'authorwings-calculator' ),
			'GMT+00:00' => __( '(GMT+00:00) London, Dublin, Lisbon', 'authorwings-calculator' ),
			'GMT+01:00' => __( '(GMT+01:00) Berlin, Paris, Madrid, Rome', 'authorwings-calculator' ),
			'GMT+02:00' => __( '(GMT+02:00) Athens, Cairo, Johannesburg', 'authorwings-calculator' ),
			'GMT+03:00' => __( '(GMT+03:00) Moscow, Nairobi, Riyadh', 'authorwings-calculator' ),
			'GMT+03:30' => __( '(GMT+03:30) Tehran', 'authorwings-calculator' ),
			'GMT+04:00' => __( '(GMT+04:00) Dubai, Abu Dhabi', 'authorwings-calculator' ),
			'GMT+05:00' => __( '(GMT+05:00) Karachi, Tashkent', 'authorwings-calculator' ),
			'GMT+05:30' => __( '(GMT+05:30) India, Sri Lanka', 'authorwings-calculator' ),
			'GMT+06:00' => __( '(GMT+06:00) Dhaka, Almaty', 'authorwings-calculator' ),
			'GMT+07:00' => __( '(GMT+07:00) Bangkok, Jakarta, Hanoi', 'authorwings-calculator' ),
			'GMT+08:00' => __( '(GMT+08:00) Beijing, Singapore, Perth', 'authorwings-calculator' ),
			'GMT+09:00' => __( '(GMT+09:00) Tokyo, Seoul', 'authorwings-calculator' ),
			'GMT+09:30' => __( '(GMT+09:30) Adelaide, Darwin', 'authorwings-calculator' ),
			'GMT+10:00' => __( '(GMT+10:00) Sydney, Brisbane', 'authorwings-calculator' ),
			'GMT+12:00' => __( '(GMT+12:00) Auckland, Fiji', 'authorwings-calculator' ),
		);
	}

	/**
	 * Register (but do not enqueue) the front-end assets.
	 */
	public function register_assets() {
		// Brand fonts (Inter + Fraunces), matching authorwings.com. If the active
		// theme already loads them this just resolves to the cached files.
		wp_register_style(
			'awpc-fonts',
			'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600;700&display=swap',
			array(),
			null
		);

		wp_register_style(
			'awpc-calculator',
			AWPC_PLUGIN_URL . 'assets/css/awpc-calculator.css',
			array( 'awpc-fonts' ),
			AWPC_VERSION
		);

		// International phone input (country flag + dial code) for the built-in
		// form's phone field. Uses real flag images (not emoji) so the flags show
		// on every OS, including Windows. Loaded from a pinned CDN build; if it
		// fails to load, the phone field gracefully stays a plain input.
		$iti_ver = '18.2.1';
		wp_register_style(
			'awpc-intl-tel-input',
			'https://cdn.jsdelivr.net/npm/intl-tel-input@' . $iti_ver . '/build/css/intlTelInput.css',
			array(),
			$iti_ver
		);
		wp_register_script(
			'awpc-intl-tel-input',
			'https://cdn.jsdelivr.net/npm/intl-tel-input@' . $iti_ver . '/build/js/intlTelInput.min.js',
			array(),
			$iti_ver,
			true
		);

		wp_register_script(
			'awpc-calculator',
			AWPC_PLUGIN_URL . 'assets/js/awpc-calculator.js',
			array(),
			AWPC_VERSION,
			true
		);

		wp_localize_script(
			'awpc-calculator',
			'AWPC_DATA',
			array(
				'pricing'  => AWPC_Pricing_Data::get(),
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'awpc_quote' ),
				'siteName' => get_bloginfo( 'name' ),
				// Branding for the downloadable / printable quote, mirroring the
				// editable estimate-email design (logo, name, tagline, accent,
				// footer) so the PDF matches the emails.
				'brand'    => $this->quote_brand(),
				// When a Forminator form is configured, the "Email me this
				// estimate" button opens it in a popup instead of the built-in
				// inline email form.
				'forminatorEstimate' => ( '' !== $this->forminator_shortcode() ),
				// Country-flag phone input only applies to the built-in form.
				'phoneIntl'          => ( '' === $this->forminator_shortcode() ),
				'itiUtils'           => 'https://cdn.jsdelivr.net/npm/intl-tel-input@' . $iti_ver . '/build/js/utils.js',
			)
		);
	}

	/**
	 * Resolve the branding for the downloadable/printable quote from the
	 * editable estimate-email settings, falling back to their defaults (and the
	 * site name when no brand name is set), so the PDF matches the emails.
	 *
	 * @return array { name, logo, tagline, accent, footer }
	 */
	private function quote_brand() {
		$defaults = class_exists( 'AWPC_Email_Template' ) ? AWPC_Email_Template::defaults() : array();
		$saved    = get_option( 'awpc_email', array() );
		$saved    = is_array( $saved ) ? $saved : array();

		$get = function ( $key ) use ( $saved, $defaults ) {
			$val = isset( $saved[ $key ] ) ? trim( (string) $saved[ $key ] ) : '';
			if ( '' !== $val ) {
				return $val;
			}
			return isset( $defaults[ $key ] ) ? (string) $defaults[ $key ] : '';
		};

		$name = $get( 'brand' );
		if ( '' === $name ) {
			$name = get_bloginfo( 'name' );
		}

		return array(
			'name'    => $name,
			'logo'    => $get( 'logo' ),
			'tagline' => $get( 'tagline' ),
			'accent'  => $get( 'accent' ),
			'footer'  => $get( 'footer' ),
		);
	}

	/**
	 * Enqueue assets on demand.
	 */
	private function enqueue() {
		wp_enqueue_style( 'awpc-calculator' );
		wp_enqueue_script( 'awpc-calculator' );

		// The country-flag phone widget is only needed by the built-in form.
		if ( '' === $this->forminator_shortcode() ) {
			wp_enqueue_style( 'awpc-intl-tel-input' );
			wp_enqueue_script( 'awpc-intl-tel-input' );
			// Ensure intl-tel-input loads before our init script by adding it as a
			// dependency at enqueue time (kept optional so Forminator pages skip it).
			$scripts = wp_scripts();
			if ( isset( $scripts->registered['awpc-calculator'] ) &&
				! in_array( 'awpc-intl-tel-input', (array) $scripts->registered['awpc-calculator']->deps, true ) ) {
				$scripts->registered['awpc-calculator']->deps[] = 'awpc-intl-tel-input';
			}
		}
	}

	/**
	 * Shortcode handler.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function render_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'title'       => __( 'Book Cost Calculator', 'authorwings-calculator' ),
				'subtitle'    => __( 'Estimate your project within ~10–15% of a final quote. No email required to see your number.', 'authorwings-calculator' ),
				'show_quote'  => 'yes',
			),
			$atts,
			'authorwings_calculator'
		);

		$this->enqueue();

		ob_start();
		$this->render_markup( $atts );
		return ob_get_clean();
	}

	/**
	 * Flag that the page needs the popup calculator and remember its settings.
	 *
	 * The actual modal markup is printed once, in the footer, so several
	 * triggers (a button, a menu link, …) on the same page share one calculator.
	 *
	 * @param array $atts Raw shortcode attributes.
	 */
	private function request_modal( $atts ) {
		$atts = shortcode_atts(
			array(
				'title'      => __( 'Book Cost Calculator', 'authorwings-calculator' ),
				'subtitle'   => __( 'Estimate your project within ~10–15% of a final quote. No email required to see your number.', 'authorwings-calculator' ),
				'show_quote' => 'yes',
			),
			$atts,
			'authorwings_calculator_modal'
		);

		$this->enqueue();
		$this->modal_needed = true;
		// First trigger on the page wins for title/subtitle.
		if ( empty( $this->modal_atts ) ) {
			$this->modal_atts = $atts;
		}
	}

	/**
	 * Shortcode: a ready-made link/button that opens the calculator in a popup.
	 *
	 * Usage: [authorwings_calculator_button label="Open the cost calculator"]
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function render_button_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'label'      => __( 'Open the Cost Calculator', 'authorwings-calculator' ),
				'class'      => '',
				'title'      => __( 'Book Cost Calculator', 'authorwings-calculator' ),
				'subtitle'   => __( 'Estimate your project within ~10–15% of a final quote. No email required to see your number.', 'authorwings-calculator' ),
				'show_quote' => 'yes',
			),
			$atts,
			'authorwings_calculator_button'
		);

		$this->request_modal( $atts );

		$classes = trim( 'awpc-open-button ' . $atts['class'] );

		return sprintf(
			'<a class="%1$s" href="#awpc-calculator" data-awpc-open="awpc-calculator" role="button">%2$s</a>',
			esc_attr( $classes ),
			esc_html( $atts['label'] )
		);
	}

	/**
	 * Shortcode: register the popup without printing a visible button.
	 *
	 * Place it once on a page (or in a footer/widget) and then point ANY link
	 * — including a navigation-menu item — at "#awpc-calculator" to open it.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string Empty string; the modal itself is printed in the footer.
	 */
	public function render_modal_shortcode( $atts ) {
		$this->request_modal( $atts );
		return '';
	}

	/**
	 * Print the popup/modal markup once in the footer, if requested.
	 */
	public function render_footer_modal() {
		if ( ! $this->modal_needed ) {
			return;
		}

		$atts = $this->modal_atts;
		?>
		<div class="awpc-modal" id="awpc-calculator" data-awpc-modal hidden role="dialog" aria-modal="true" aria-label="<?php echo esc_attr( $atts['title'] ); ?>">
			<div class="awpc-modal__backdrop" data-awpc-close></div>
			<div class="awpc-modal__dialog" role="document">
				<button type="button" class="awpc-modal__close" data-awpc-close aria-label="<?php esc_attr_e( 'Close calculator', 'authorwings-calculator' ); ?>">&times;</button>
				<div class="awpc-modal__body">
					<?php $this->render_markup( $atts ); ?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Print the Forminator estimate-form popup once in the footer, if needed.
	 *
	 * The configured Forminator shortcode is rendered here so its own scripts
	 * and styles are enqueued, and the "Email me this estimate" button opens
	 * this popup (see the front-end JS).
	 */
	public function render_forminator_modal() {
		if ( ! $this->forminator_needed ) {
			return;
		}

		$shortcode = $this->forminator_shortcode();
		if ( '' === $shortcode ) {
			return;
		}
		?>
		<div class="awpc-modal awpc-estimate-modal" id="awpc-estimate-form" data-awpc-estimate-modal hidden role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Request your estimate', 'authorwings-calculator' ); ?>">
			<div class="awpc-modal__backdrop" data-awpc-estimate-close></div>
			<div class="awpc-modal__dialog" role="document">
				<button type="button" class="awpc-modal__close" data-awpc-estimate-close aria-label="<?php esc_attr_e( 'Close', 'authorwings-calculator' ); ?>">&times;</button>
				<div class="awpc-modal__body awpc-estimate-modal__body">
					<?php
					if ( shortcode_exists( 'forminator_form' ) ) {
						// Shortcode is normalised on save to a bare [forminator_form …] tag.
						echo do_shortcode( $shortcode ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Forminator renders trusted form markup.
					} else {
						echo '<p>' . esc_html__( 'The estimate form is unavailable because the Forminator plugin is not active.', 'authorwings-calculator' ) . '</p>';
					}
					?>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Output the calculator markup.
	 *
	 * @param array $atts Resolved attributes.
	 */
	private function render_markup( $atts ) {
		$pricing   = AWPC_Pricing_Data::get();
		$show_quote = ( 'no' !== $atts['show_quote'] );
		$uid       = 'awpc-' . wp_rand( 1000, 9999 );
		?>
		<div class="awpc-wrap" id="<?php echo esc_attr( $uid ); ?>" data-show-quote="<?php echo $show_quote ? '1' : '0'; ?>">
			<header class="awpc-header">
				<h2 class="awpc-title"><?php echo esc_html( $atts['title'] ); ?></h2>
				<p class="awpc-subtitle"><?php echo esc_html( $atts['subtitle'] ); ?></p>
			</header>

			<div class="awpc-tabs" role="tablist">
				<button type="button" class="awpc-tab is-active" data-tab="build" role="tab" aria-selected="true"><?php esc_html_e( 'Build Your Own', 'authorwings-calculator' ); ?></button>
				<button type="button" class="awpc-tab" data-tab="bundles" role="tab" aria-selected="false"><?php esc_html_e( 'Ready-Made Bundles', 'authorwings-calculator' ); ?></button>
			</div>

			<div class="awpc-layout">
				<div class="awpc-panels">

					<!-- BUILD YOUR OWN -->
					<section class="awpc-panel is-active" data-panel="build">

						<div class="awpc-stepper" data-out="stepper" role="tablist"></div>

						<div class="awpc-steps">

						<div class="awpc-step is-active" data-step="basics">
						<div class="awpc-field awpc-field--stage">
							<label class="awpc-label"><?php esc_html_e( 'Where are you in the process?', 'authorwings-calculator' ); ?></label>
							<div class="awpc-segmented" data-control="stage">
								<button type="button" class="awpc-seg is-active" data-stage="idea" aria-label="<?php esc_attr_e( 'I have an idea', 'authorwings-calculator' ); ?>"><span class="awpc-seg-full"><?php esc_html_e( 'I have an idea', 'authorwings-calculator' ); ?></span><span class="awpc-seg-short" aria-hidden="true"><?php esc_html_e( 'An idea', 'authorwings-calculator' ); ?></span></button>
								<button type="button" class="awpc-seg" data-stage="draft" aria-label="<?php esc_attr_e( 'I have a draft', 'authorwings-calculator' ); ?>"><span class="awpc-seg-full"><?php esc_html_e( 'I have a draft', 'authorwings-calculator' ); ?></span><span class="awpc-seg-short" aria-hidden="true"><?php esc_html_e( 'A draft', 'authorwings-calculator' ); ?></span></button>
								<button type="button" class="awpc-seg" data-stage="finished" aria-label="<?php esc_attr_e( 'It is finished', 'authorwings-calculator' ); ?>"><span class="awpc-seg-full"><?php esc_html_e( 'It is finished', 'authorwings-calculator' ); ?></span><span class="awpc-seg-short" aria-hidden="true"><?php esc_html_e( 'Finished', 'authorwings-calculator' ); ?></span></button>
							</div>
						</div>

						<div class="awpc-field" data-words-field hidden>
							<label class="awpc-label" for="<?php echo esc_attr( $uid ); ?>-words">
								<?php esc_html_e( 'Manuscript length', 'authorwings-calculator' ); ?>
								<span class="awpc-words-out" data-out="words">40,000</span> <?php esc_html_e( 'words', 'authorwings-calculator' ); ?>
							</label>
							<input type="range" id="<?php echo esc_attr( $uid ); ?>-words" class="awpc-range" data-input="words" min="2000" max="120000" step="1000" value="40000">
							<div class="awpc-range-scale"><span>2k</span><span>40k</span><span>80k</span><span>120k</span></div>
							<p class="awpc-hint"><?php esc_html_e( 'Used to price editing by word count.', 'authorwings-calculator' ); ?></p>
						</div>
						</div><!-- /step basics -->

						<!-- Ghostwriting (idea stage) -->
						<div class="awpc-step" data-step="writing">
						<div class="awpc-group" data-group="ghostwriting">
							<h3 class="awpc-group-title"><?php esc_html_e( 'Ghostwriting', 'authorwings-calculator' ); ?></h3>
							<?php
							// Split the book-writing tiers so children's titles don't sit
							// alongside (and visually duplicate) the standard Starter/Growth/Authority.
							$gw_standard  = array();
							$gw_childrens = array();
							foreach ( $pricing['ghostwriting'] as $gw_key => $gw_tier ) {
								if ( 0 === strpos( $gw_key, 'childrens' ) ) {
									$gw_childrens[ $gw_key ] = $gw_tier;
								} else {
									$gw_standard[ $gw_key ] = $gw_tier;
								}
							}
							?>
							<div class="awpc-segmented awpc-segmented--sub" data-control="booktype">
								<button type="button" class="awpc-seg is-active" data-booktype="standard" aria-label="<?php esc_attr_e( 'Standard book', 'authorwings-calculator' ); ?>"><span class="awpc-seg-full"><?php esc_html_e( 'Standard book', 'authorwings-calculator' ); ?></span><span class="awpc-seg-short" aria-hidden="true"><?php esc_html_e( 'Standard', 'authorwings-calculator' ); ?></span></button>
								<button type="button" class="awpc-seg" data-booktype="childrens" aria-label="<?php esc_attr_e( "Children's & illustrated", 'authorwings-calculator' ); ?>"><span class="awpc-seg-full"><?php esc_html_e( "Children's & illustrated", 'authorwings-calculator' ); ?></span><span class="awpc-seg-short" aria-hidden="true"><?php esc_html_e( "Children's", 'authorwings-calculator' ); ?></span></button>
							</div>

							<div class="awpc-booktype" data-booktype-panel="standard">
								<div class="awpc-options" data-control="ghostwriting">
									<?php $this->render_option_card( 'ghostwriting', 'none', array( 'label' => __( 'None', 'authorwings-calculator' ), 'price' => 0, 'note' => __( "I'll write it myself", 'authorwings-calculator' ) ), true ); ?>
									<?php foreach ( $gw_standard as $key => $tier ) : ?>
										<?php $this->render_option_card( 'ghostwriting', $key, $tier ); ?>
									<?php endforeach; ?>
								</div>
							</div>

							<div class="awpc-booktype" data-booktype-panel="childrens" hidden>
								<p class="awpc-hint awpc-editmode-note"><?php esc_html_e( 'Picture, illustrated and chapter books for young readers.', 'authorwings-calculator' ); ?></p>
								<div class="awpc-options" data-control="ghostwriting">
									<?php $this->render_option_card( 'ghostwriting', 'none', array( 'label' => __( 'None', 'authorwings-calculator' ), 'price' => 0, 'note' => __( "I'll write it myself", 'authorwings-calculator' ) ), false ); ?>
									<?php foreach ( $gw_childrens as $key => $tier ) : ?>
										<?php $this->render_option_card( 'ghostwriting', $key, $tier ); ?>
									<?php endforeach; ?>
								</div>
							</div>
						</div>
						</div><!-- /step writing -->

						<!-- Editing -->
						<div class="awpc-step" data-step="editing">
						<div class="awpc-group" data-group="editing">
							<h3 class="awpc-group-title"><?php esc_html_e( 'Editing', 'authorwings-calculator' ); ?> <span class="awpc-hint"><?php esc_html_e( 'priced by word count', 'authorwings-calculator' ); ?></span></h3>

							<div class="awpc-segmented awpc-segmented--sub" data-control="editmode">
								<button type="button" class="awpc-seg is-active" data-editmode="package" aria-label="<?php esc_attr_e( 'Editing package', 'authorwings-calculator' ); ?>"><span class="awpc-seg-full"><?php esc_html_e( 'Editing package', 'authorwings-calculator' ); ?></span><span class="awpc-seg-short" aria-hidden="true"><?php esc_html_e( 'Package', 'authorwings-calculator' ); ?></span></button>
								<button type="button" class="awpc-seg" data-editmode="individual" aria-label="<?php esc_attr_e( 'Individual services', 'authorwings-calculator' ); ?>"><span class="awpc-seg-full"><?php esc_html_e( 'Individual services', 'authorwings-calculator' ); ?></span><span class="awpc-seg-short" aria-hidden="true"><?php esc_html_e( 'Individual service', 'authorwings-calculator' ); ?></span></button>
							</div>

							<div class="awpc-editmode" data-editmode-panel="package">
								<div class="awpc-options" data-control="editing">
									<?php $this->render_option_card( 'editing', 'none', array( 'label' => __( 'None', 'authorwings-calculator' ), 'price' => 0, 'note' => __( 'No editing needed', 'authorwings-calculator' ) ), true ); ?>
									<?php foreach ( $pricing['editing'] as $key => $tier ) : ?>
										<?php $this->render_option_card( 'editing', $key, $tier ); ?>
									<?php endforeach; ?>
								</div>
							</div>

							<div class="awpc-editmode" data-editmode-panel="individual" hidden>
								<p class="awpc-hint awpc-editmode-note"><?php esc_html_e( 'Choose any combination — each is priced per word.', 'authorwings-calculator' ); ?></p>
								<div class="awpc-options" data-control="editservices">
									<?php foreach ( $pricing['editing_individual'] as $key => $svc ) : ?>
										<label class="awpc-card awpc-card--check" data-card="<?php echo esc_attr( $key ); ?>">
											<input type="checkbox" data-editservice="<?php echo esc_attr( $key ); ?>">
											<span class="awpc-card-head">
												<span class="awpc-card-name"><?php echo esc_html( $svc['label'] ); ?></span>
												<span class="awpc-card-price"><?php echo esc_html( sprintf( __( 'from %s', 'authorwings-calculator' ), $this->money( $svc['base'], $pricing ) ) ); ?></span>
											</span>
											<?php if ( ! empty( $svc['features'] ) ) : ?>
												<ul class="awpc-card-features">
													<?php foreach ( $svc['features'] as $f ) : ?>
														<li><?php echo esc_html( $f ); ?></li>
													<?php endforeach; ?>
												</ul>
											<?php endif; ?>
										</label>
									<?php endforeach; ?>
								</div>
							</div>
						</div>
						</div><!-- /step editing -->

						<!-- Design -->
						<div class="awpc-step" data-step="design">
						<div class="awpc-group" data-group="design">
							<details class="awpc-acc" data-acc="cover" open>
								<summary class="awpc-acc-summary">
									<span class="awpc-acc-title"><?php esc_html_e( 'Cover Design', 'authorwings-calculator' ); ?></span>
									<span class="awpc-acc-badge" data-acc-sel="cover" hidden></span>
								</summary>
								<div class="awpc-options" data-control="cover">
									<?php foreach ( $pricing['cover'] as $key => $tier ) : ?>
										<?php $this->render_option_card( 'cover', $key, $tier, 'none' === $key ); ?>
									<?php endforeach; ?>
								</div>
							</details>

							<details class="awpc-acc" data-acc="interior">
								<summary class="awpc-acc-summary">
									<span class="awpc-acc-title"><?php esc_html_e( 'Interior Formatting', 'authorwings-calculator' ); ?></span>
									<span class="awpc-acc-badge" data-acc-sel="interior" hidden></span>
								</summary>
								<div class="awpc-options" data-control="interior">
									<?php foreach ( $pricing['interior'] as $key => $tier ) : ?>
										<?php $this->render_option_card( 'interior', $key, $tier, 'none' === $key ); ?>
									<?php endforeach; ?>
								</div>
							</details>

							<details class="awpc-acc" data-acc="illustration">
								<summary class="awpc-acc-summary">
									<span class="awpc-acc-title"><?php esc_html_e( 'Illustration', 'authorwings-calculator' ); ?></span>
									<span class="awpc-acc-badge" data-acc-sel="illustration" hidden></span>
								</summary>
								<div class="awpc-options" data-control="illustration">
									<?php foreach ( $pricing['illustration'] as $key => $tier ) : ?>
										<?php $this->render_option_card( 'illustration', $key, $tier, 'none' === $key ); ?>
									<?php endforeach; ?>
								</div>
							</details>
						</div>
						</div><!-- /step design -->

						<!-- Publishing -->
						<div class="awpc-step" data-step="publishing">
						<div class="awpc-group" data-group="publishing">
							<h3 class="awpc-group-title"><?php esc_html_e( 'Publishing & Distribution', 'authorwings-calculator' ); ?></h3>
							<div class="awpc-options" data-control="publishing">
								<?php foreach ( $pricing['publishing'] as $key => $tier ) : ?>
									<?php $this->render_option_card( 'publishing', $key, $tier, 'none' === $key ); ?>
								<?php endforeach; ?>
							</div>
						</div>
						</div><!-- /step publishing -->

						<!-- Marketing -->
						<div class="awpc-step" data-step="marketing">
						<div class="awpc-group" data-group="marketing">
							<h3 class="awpc-group-title"><?php esc_html_e( 'Marketing', 'authorwings-calculator' ); ?></h3>
							<div class="awpc-options" data-control="marketing">
								<?php foreach ( $pricing['marketing'] as $key => $tier ) : ?>
									<?php $this->render_option_card( 'marketing', $key, $tier, 'none' === $key ); ?>
								<?php endforeach; ?>
							</div>
						</div>
						</div><!-- /step marketing -->

						<!-- Coaching -->
						<div class="awpc-step" data-step="coaching">
						<div class="awpc-group" data-group="coaching">
							<h3 class="awpc-group-title"><?php esc_html_e( 'Coaching', 'authorwings-calculator' ); ?></h3>
							<div class="awpc-options" data-control="coaching">
								<?php foreach ( $pricing['coaching'] as $key => $tier ) : ?>
									<?php $this->render_option_card( 'coaching', $key, $tier, 'none' === $key ); ?>
								<?php endforeach; ?>
							</div>
						</div>
						</div><!-- /step coaching -->

						<!-- Add-ons -->
						<div class="awpc-step" data-step="addons">
						<div class="awpc-group" data-group="addons">
							<h3 class="awpc-group-title"><?php esc_html_e( 'Add-ons', 'authorwings-calculator' ); ?></h3>
							<?php
							$symbol       = isset( $pricing['currency']['symbol'] ) ? $pricing['currency']['symbol'] : '$';
							$addon_groups = array();
							foreach ( $pricing['addons'] as $akey => $addon ) {
								$grp = isset( $addon['group'] ) ? $addon['group'] : __( 'Add-ons', 'authorwings-calculator' );
								$addon_groups[ $grp ][ $akey ] = $addon;
							}
							?>
							<?php foreach ( $addon_groups as $grp_label => $items ) : ?>
								<details class="awpc-acc" data-acc-group="<?php echo esc_attr( $grp_label ); ?>">
									<summary class="awpc-acc-summary">
										<span class="awpc-acc-title"><?php echo esc_html( $grp_label ); ?></span>
										<span class="awpc-acc-badge" data-acc-count="<?php echo esc_attr( $grp_label ); ?>" hidden></span>
									</summary>
									<div class="awpc-addons" data-control="addons">
									<?php
									foreach ( $items as $akey => $addon ) :
										$is_rate    = isset( $addon['rate'] );
										$price_disp = $is_rate
											? sprintf( __( 'from %1$s%2$s/word', 'authorwings-calculator' ), $symbol, number_format( (float) $addon['rate'], 2 ) )
											: $this->money( isset( $addon['price'] ) ? $addon['price'] : 0, $pricing );
										?>
										<?php $has_unit = isset( $addon['unit'] ); ?>
										<label class="awpc-addon">
											<input type="checkbox" data-addon="<?php echo esc_attr( $akey ); ?>"
												<?php if ( $is_rate ) : ?>data-rate="<?php echo esc_attr( $addon['rate'] ); ?>"<?php else : ?>value="<?php echo esc_attr( isset( $addon['price'] ) ? $addon['price'] : 0 ); ?>"<?php endif; ?>
												<?php if ( $has_unit ) : ?>data-unit="<?php echo esc_attr( $addon['unit'] ); ?>"<?php endif; ?>>
											<span class="awpc-addon-label"><?php echo esc_html( $addon['label'] ); ?></span>
											<?php if ( $has_unit ) : ?>
												<span class="awpc-addon-qtywrap">
													<input type="number" class="awpc-addon-qty" data-qty="<?php echo esc_attr( $akey ); ?>" min="1" value="1"
														aria-label="<?php echo esc_attr( sprintf( __( 'Number of %s', 'authorwings-calculator' ), $addon['unit'] ) ); ?>">
													<span class="awpc-addon-unit"><?php echo esc_html( $addon['unit'] . 's' ); ?></span>
												</span>
											<?php endif; ?>
											<span class="awpc-addon-price"><?php echo esc_html( $price_disp ); ?></span>
											<?php if ( $is_rate ) : ?>
												<span class="awpc-addon-words" data-addon-words="<?php echo esc_attr( $akey ); ?>" hidden>
													<span class="awpc-addon-words-label"><?php esc_html_e( 'Manuscript length (words)', 'authorwings-calculator' ); ?></span>
													<input type="number" class="awpc-words-input" min="2000" max="120000" step="1000" value="40000"
														aria-label="<?php esc_attr_e( 'Manuscript length in words', 'authorwings-calculator' ); ?>">
												</span>
											<?php endif; ?>
										</label>
										<?php endforeach; ?>
									</div>
								</details>
							<?php endforeach; ?>
						</div>

						<div class="awpc-field awpc-rush">
							<label class="awpc-toggle">
								<input type="checkbox" data-input="rush">
								<span><?php esc_html_e( 'Rush my project', 'authorwings-calculator' ); ?> <em>(+<?php echo esc_html( round( $pricing['rush_multiplier'] * 100 ) ); ?>% on production services)</em></span>
							</label>
						</div>
						</div><!-- /step addons -->

						<!-- Review -->
						<div class="awpc-step" data-step="review">
							<h3 class="awpc-group-title"><?php esc_html_e( 'Review your estimate', 'authorwings-calculator' ); ?></h3>
							<p class="awpc-review-intro"><?php esc_html_e( 'Here is everything you selected. Your running total and payment options are in the summary panel. Use “See your quote & schedule a free consultation” to get a tailored quote and book your free consultation.', 'authorwings-calculator' ); ?></p>
							<ul class="awpc-lines awpc-lines--review" data-out="lines-review">
								<li class="awpc-empty"><?php esc_html_e( 'No services selected yet — step back to add some.', 'authorwings-calculator' ); ?></li>
							</ul>
						</div><!-- /step review -->

						</div><!-- /steps -->

						<div class="awpc-nav">
							<button type="button" class="awpc-nav-btn awpc-nav-back" data-nav="back"><?php esc_html_e( 'Back', 'authorwings-calculator' ); ?></button>
							<span class="awpc-step-count" data-out="step-count"></span>
							<button type="button" class="awpc-nav-btn awpc-nav-next" data-nav="next"><?php esc_html_e( 'Next', 'authorwings-calculator' ); ?></button>
						</div>
					</section>

					<!-- BUNDLES -->
					<section class="awpc-panel" data-panel="bundles">
						<?php foreach ( $pricing['bundles'] as $group_key => $group ) : ?>
							<div class="awpc-bundle-group">
								<h3 class="awpc-group-title"><?php echo esc_html( $group['group'] ); ?></h3>
								<div class="awpc-options awpc-options--bundle">
									<?php foreach ( $group['tiers'] as $tier_key => $tier ) : ?>
										<?php $bundle_popular = isset( $pricing['popular_bundles'][ $group_key ] ) && $pricing['popular_bundles'][ $group_key ] === $tier_key; ?>
										<button type="button" class="awpc-bundle-card<?php echo $bundle_popular ? ' awpc-bundle-card--popular' : ''; ?>"
											data-bundle="<?php echo esc_attr( $group_key . ':' . $tier_key ); ?>"
											data-price="<?php echo esc_attr( $tier['price'] ); ?>"
											data-saves="<?php echo esc_attr( isset( $tier['saves'] ) ? $tier['saves'] : 0 ); ?>"
											data-label="<?php echo esc_attr( $tier['label'] ); ?>">
											<?php if ( $bundle_popular ) : ?>
												<span class="awpc-popular-badge"><?php esc_html_e( 'Most Popular', 'authorwings-calculator' ); ?></span>
											<?php endif; ?>
											<span class="awpc-bundle-name"><?php echo esc_html( $tier['label'] ); ?></span>
											<span class="awpc-bundle-price"><?php echo esc_html( $this->money( $tier['price'], $pricing ) ); ?></span>
											<?php if ( ! empty( $tier['saves'] ) ) : ?>
												<span class="awpc-bundle-save"><?php printf( esc_html__( 'Save %s', 'authorwings-calculator' ), esc_html( $this->money( $tier['saves'], $pricing ) ) ); ?></span>
											<?php endif; ?>
											<?php if ( ! empty( $tier['features'] ) ) : ?>
												<ul class="awpc-bundle-features">
													<?php foreach ( $tier['features'] as $f ) : ?>
														<li><?php echo esc_html( $f ); ?></li>
													<?php endforeach; ?>
												</ul>
											<?php endif; ?>
										</button>
									<?php endforeach; ?>
								</div>
							</div>
						<?php endforeach; ?>
					</section>

				</div>

				<!-- SUMMARY SIDEBAR -->
				<aside class="awpc-summary">
					<div class="awpc-summary-inner">
						<h3 class="awpc-summary-title"><?php esc_html_e( 'Your Estimate', 'authorwings-calculator' ); ?></h3>
						<ul class="awpc-lines" data-out="lines">
							<li class="awpc-empty"><?php esc_html_e( 'Select services to build your estimate.', 'authorwings-calculator' ); ?></li>
						</ul>
						<div class="awpc-savings" data-out="savings" hidden></div>
						<div class="awpc-total-row">
							<span><?php esc_html_e( 'Estimated total', 'authorwings-calculator' ); ?></span>
							<span class="awpc-total" data-out="total"><?php echo esc_html( $this->money( 0, $pricing ) ); ?></span>
						</div>
						<p class="awpc-rush-note" data-out="rush-note" hidden></p>
						<p class="awpc-plan" data-out="plan"></p>
						<p class="awpc-disclaimer"><?php esc_html_e( 'Estimates are flat, one-time fees and land within ~10–15% of a final quote.', 'authorwings-calculator' ); ?></p>

						<?php
						$use_forminator = ( $show_quote && '' !== $this->forminator_shortcode() );
						if ( $use_forminator ) {
							$this->forminator_needed = true;
						}
						?>

						<?php
						// The quote/consultation CTA starts disabled: it only becomes
						// active once the estimate is above zero (a service is selected).
						$quote_hint = esc_attr__( 'Select at least one service to get your quote.', 'authorwings-calculator' );
						?>
						<?php if ( $show_quote && $use_forminator ) : ?>
						<button type="button" class="awpc-cta awpc-cta--disabled" data-action="open-quote" disabled aria-disabled="true" title="<?php echo $quote_hint; ?>"><?php echo esc_html( self::cta_label() ); ?></button>
						<?php elseif ( $show_quote ) : ?>
						<button type="button" class="awpc-cta awpc-cta--disabled" data-action="open-quote" disabled aria-disabled="true" title="<?php echo $quote_hint; ?>"><?php echo esc_html( self::cta_label() ); ?></button>

						<form class="awpc-quote-form awpc-quote-form--full" data-form="quote" hidden>
							<?php
							$intro_title    = self::form_intro_title();
							$intro_subtitle = self::form_intro_subtitle();
							?>
							<?php if ( '' !== trim( $intro_title ) || '' !== trim( $intro_subtitle ) ) : ?>
							<div class="awpc-form-intro">
								<?php if ( '' !== trim( $intro_title ) ) : ?>
									<p class="awpc-form-intro-title"><?php echo esc_html( $intro_title ); ?></p>
								<?php endif; ?>
								<?php if ( '' !== trim( $intro_subtitle ) ) : ?>
									<p class="awpc-form-intro-subtitle"><?php echo esc_html( $intro_subtitle ); ?></p>
								<?php endif; ?>
							</div>
							<?php endif; ?>

							<div class="awpc-form-row">
								<label class="awpc-form-field">
									<span class="awpc-form-label"><?php esc_html_e( 'First name', 'authorwings-calculator' ); ?> <span class="awpc-req">*</span></span>
									<input type="text" data-field="first_name" autocomplete="given-name" required>
								</label>
								<label class="awpc-form-field">
									<span class="awpc-form-label"><?php esc_html_e( 'Last name', 'authorwings-calculator' ); ?> <span class="awpc-req">*</span></span>
									<input type="text" data-field="last_name" autocomplete="family-name" required>
								</label>
							</div>

							<label class="awpc-form-field">
								<span class="awpc-form-label"><?php esc_html_e( 'Email address', 'authorwings-calculator' ); ?> <span class="awpc-req">*</span></span>
								<input type="email" data-field="email" placeholder="you@example.com" autocomplete="email" required>
							</label>

							<label class="awpc-form-field">
								<span class="awpc-form-label"><?php esc_html_e( 'Phone', 'authorwings-calculator' ); ?> <span class="awpc-req">*</span></span>
								<input type="tel" data-field="phone" placeholder="+1 555 123 4567" autocomplete="tel" required>
							</label>

							<label class="awpc-form-field">
								<span class="awpc-form-label"><?php esc_html_e( 'Project type', 'authorwings-calculator' ); ?> <span class="awpc-req">*</span></span>
								<select data-field="project_type" required>
									<option value=""><?php esc_html_e( 'Select your project type', 'authorwings-calculator' ); ?></option>
									<?php foreach ( self::project_types() as $ptype ) : ?>
										<option value="<?php echo esc_attr( $ptype ); ?>"><?php echo esc_html( $ptype ); ?></option>
									<?php endforeach; ?>
								</select>
							</label>

							<p class="awpc-form-hint"><?php esc_html_e( 'Choose the day and time that suit you best — a publishing advisor will call you then to discuss your project. If that slot isn\'t available, we\'ll be in touch to find the nearest time.', 'authorwings-calculator' ); ?></p>

							<div class="awpc-form-row">
								<label class="awpc-form-field">
									<span class="awpc-form-label"><?php esc_html_e( 'Preferred call date', 'authorwings-calculator' ); ?> <span class="awpc-req">*</span></span>
									<input type="date" data-field="date" min="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>" autocomplete="off" required>
								</label>
								<label class="awpc-form-field">
									<span class="awpc-form-label"><?php esc_html_e( 'Preferred call time', 'authorwings-calculator' ); ?> <span class="awpc-req">*</span></span>
									<input type="time" data-field="time" autocomplete="off" required>
								</label>
							</div>

							<label class="awpc-form-field">
								<span class="awpc-form-label"><?php esc_html_e( 'Your time zone', 'authorwings-calculator' ); ?> <span class="awpc-req">*</span></span>
								<select data-field="timezone" required>
									<option value=""><?php esc_html_e( 'Select your time zone', 'authorwings-calculator' ); ?></option>
									<?php foreach ( self::timezones() as $tz_val => $tz_label ) : ?>
										<option value="<?php echo esc_attr( $tz_val ); ?>"><?php echo esc_html( $tz_label ); ?></option>
									<?php endforeach; ?>
								</select>
							</label>

							<label class="awpc-form-field">
								<span class="awpc-form-label"><?php esc_html_e( 'Additional project notes', 'authorwings-calculator' ); ?></span>
								<textarea data-field="message" rows="3" placeholder="<?php esc_attr_e( 'Tell us anything else about your project — goals, timeline, questions.', 'authorwings-calculator' ); ?>"></textarea>
							</label>

							<!-- honeypot -->
							<input type="text" data-field="website" class="awpc-hp" tabindex="-1" autocomplete="off" aria-hidden="true">
							<button type="submit" class="awpc-cta awpc-cta--submit"><?php echo esc_html( self::submit_label() ); ?></button>
							<p class="awpc-form-msg" data-out="form-msg" role="status"></p>

							<?php
							$this->render_notes_block( self::important_notes(), 'awpc-notes--important' );
							?>
						</form>

						<?php
						$success_msg   = self::success_message();
						$success_lines = preg_split( '/\r\n|\r|\n/', $success_msg );
						$success_title = array_shift( $success_lines );
						$success_body  = trim( implode( "\n", $success_lines ) );
						?>
						<div class="awpc-form-success" data-out="form-success" role="status" hidden>
							<button type="button" class="awpc-form-success-close" data-action="success-close" aria-label="<?php esc_attr_e( 'Close', 'authorwings-calculator' ); ?>">&times;</button>
							<?php if ( '' !== trim( (string) $success_title ) ) : ?>
								<p class="awpc-form-success-title"><?php echo esc_html( $success_title ); ?></p>
							<?php endif; ?>
							<?php if ( '' !== $success_body ) : ?>
								<div class="awpc-form-success-body"><?php echo nl2br( esc_html( $success_body ) ); ?></div>
							<?php endif; ?>
						</div>
						<?php endif; ?>

						<div class="awpc-summary-actions">
							<button type="button" class="awpc-tile-btn" data-action="copy-link">
								<svg class="awpc-tile-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>
								<span class="awpc-tile-label"><?php esc_html_e( 'Copy link', 'authorwings-calculator' ); ?></span>
							</button>
							<button type="button" class="awpc-tile-btn" data-action="print">
								<svg class="awpc-tile-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
								<span class="awpc-tile-label"><?php esc_html_e( 'Print / PDF', 'authorwings-calculator' ); ?></span>
							</button>
							<button type="button" class="awpc-tile-btn awpc-tile-btn--reset" data-action="reset">
								<svg class="awpc-tile-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M3 2v6h6"/><path d="M3 13a9 9 0 1 0 3-7.7L3 8"/></svg>
								<span class="awpc-tile-label"><?php esc_html_e( 'Reset', 'authorwings-calculator' ); ?></span>
							</button>
						</div>
					</div>
				</aside>
			</div>

			<!-- MOBILE STICKY TOTAL BAR -->
			<div class="awpc-mobilebar" data-out="mobilebar">
				<div class="awpc-mobilebar-total">
					<span class="awpc-mobilebar-label"><?php esc_html_e( 'Estimated total', 'authorwings-calculator' ); ?></span>
					<span class="awpc-mobilebar-amount" data-out="total-mobile"><?php echo esc_html( $this->money( 0, $pricing ) ); ?></span>
				</div>
				<button type="button" class="awpc-cta awpc-mobilebar-cta" data-action="mobile-quote">
					<?php echo $show_quote ? esc_html( self::mobile_label() ) : esc_html__( 'View estimate', 'authorwings-calculator' ); ?>
				</button>
			</div>

			<!-- PRINT HEADER (visible only when printing) -->
			<div class="awpc-print-head" aria-hidden="true">
				<p class="awpc-print-site"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></p>
				<p class="awpc-print-meta"><?php echo esc_html( sprintf( __( 'Book cost estimate — %s', 'authorwings-calculator' ), date_i18n( get_option( 'date_format' ) ) ) ); ?></p>
			</div>
		</div>
		<?php
	}

	/**
	 * Render a single selectable option card.
	 *
	 * @param string $control  Control name (group key).
	 * @param string $key      Option key.
	 * @param array  $tier     Tier data.
	 * @param bool   $selected Whether selected by default.
	 */
	private function render_option_card( $control, $key, $tier, $selected = false ) {
		$pricing  = AWPC_Pricing_Data::get();
		$label    = isset( $tier['label'] ) ? $tier['label'] : ucfirst( $key );
		$price    = isset( $tier['price'] ) ? $tier['price'] : null;
		$features = isset( $tier['features'] ) ? $tier['features'] : array();

		// Price display: per-word editing shows "from", ghostwriting/fixed shows amount.
		if ( 'editing' === $control && 'none' !== $key && isset( $tier['min'] ) ) {
			$price_label = sprintf( __( 'from %s', 'authorwings-calculator' ), $this->money( $tier['min'], $pricing ) );
		} elseif ( isset( $tier['price_max'] ) ) {
			$price_label = $this->money( $tier['price'], $pricing ) . '–' . $this->money( $tier['price_max'], $pricing );
		} elseif ( null !== $price && $price > 0 ) {
			$price_label = $this->money( $price, $pricing );
		} else {
			$price_label = ( 'none' === $key ) ? '—' : $this->money( 0, $pricing );
		}
		$is_popular = ( isset( $pricing['popular'][ $control ] ) && $pricing['popular'][ $control ] === $key ) || ! empty( $tier['popular'] );

		// Helper sub-line for a "Not included" (skip) card. Prefer any note stored
		// on the tier; otherwise fall back to a sensible per-service default so the
		// line still shows on sites running a saved catalogue (which predates it).
		$none_note = '';
		if ( 'none' === $key ) {
			$none_note = isset( $tier['note'] ) ? trim( (string) $tier['note'] ) : '';
			if ( '' === $none_note ) {
				$none_note_defaults = array(
					'ghostwriting' => __( "I'll write it myself", 'authorwings-calculator' ),
					'editing'      => __( 'No editing needed', 'authorwings-calculator' ),
					'cover'        => __( 'I already have a cover', 'authorwings-calculator' ),
					'interior'     => __( "I'll format it myself", 'authorwings-calculator' ),
					'illustration' => __( 'No illustrations needed', 'authorwings-calculator' ),
					'publishing'   => __( "I'll self-publish or I'm already published", 'authorwings-calculator' ),
					'marketing'    => __( "I'll handle my own promotion", 'authorwings-calculator' ),
					'coaching'     => __( "I don't need coaching", 'authorwings-calculator' ),
				);
				$none_note = isset( $none_note_defaults[ $control ] ) ? $none_note_defaults[ $control ] : '';
			}
		}
		?>
		<label class="awpc-card<?php echo $selected ? ' is-selected' : ''; ?><?php echo $is_popular ? ' awpc-card--popular' : ''; ?>" data-card="<?php echo esc_attr( $key ); ?>">
			<input type="radio" name="<?php echo esc_attr( $control ); ?>" value="<?php echo esc_attr( $key ); ?>" <?php checked( $selected ); ?>>
			<?php if ( $is_popular ) : ?>
				<span class="awpc-popular-badge"><?php esc_html_e( 'Most Popular', 'authorwings-calculator' ); ?></span>
			<?php endif; ?>
			<?php if ( 'none' === $key ) : ?>
				<span class="awpc-card-none">
					<svg class="awpc-card-none-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true" focusable="false">
						<circle cx="12" cy="12" r="9"></circle>
						<line x1="5.64" y1="5.64" x2="18.36" y2="18.36"></line>
					</svg>
					<span class="awpc-card-none-title"><?php echo esc_html( $label ); ?></span>
					<span class="awpc-card-none-text"><?php esc_html_e( 'Not included', 'authorwings-calculator' ); ?></span>
					<?php if ( '' !== $none_note ) : ?>
						<span class="awpc-card-none-note"><?php echo esc_html( $none_note ); ?></span>
					<?php endif; ?>
				</span>
			<?php else : ?>
			<span class="awpc-card-head">
				<span class="awpc-card-name"><?php echo esc_html( $label ); ?></span>
				<span class="awpc-card-price"><?php echo esc_html( $price_label ); ?></span>
			</span>
			<?php endif; ?>
			<?php if ( 'none' !== $key && ! empty( $features ) ) : ?>
				<ul class="awpc-card-features">
					<?php foreach ( $features as $f ) : ?>
						<li><?php echo esc_html( $f ); ?></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<?php if ( 'illustration' === $control && ! empty( $tier['unit'] ) ) : ?>
				<?php $qty_label = sprintf( __( 'Number of %ss', 'authorwings-calculator' ), $tier['unit'] ); ?>
				<span class="awpc-card-qty"<?php echo $selected ? '' : ' hidden'; ?>>
					<span class="awpc-card-qty-label"><?php echo esc_html( $qty_label ); ?></span>
					<input type="number" class="awpc-illus-qty" min="1" value="1" aria-label="<?php echo esc_attr( $qty_label ); ?>">
				</span>
			<?php endif; ?>
		</label>
		<?php
	}

	/**
	 * Format a money value for display (server side mirror of JS formatter).
	 *
	 * @param float $amount  Amount.
	 * @param array $pricing Pricing array (for currency symbol).
	 * @return string
	 */
	private function money( $amount, $pricing ) {
		$symbol = isset( $pricing['currency']['symbol'] ) ? $pricing['currency']['symbol'] : '$';
		return $symbol . number_format( (float) $amount );
	}

	/**
	 * Register a block that wraps the shortcode, with editor controls for the
	 * title, subtitle and quote-form toggle.
	 */
	public function register_block() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		// Editor script (no build step — uses the wp.* globals already in the editor).
		wp_register_script(
			'awpc-block',
			AWPC_PLUGIN_URL . 'assets/js/awpc-block.js',
			array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render', 'wp-i18n' ),
			AWPC_VERSION,
			true
		);

		// Style the live preview inside the editor (same stylesheet as the front end).
		// Brand fonts (Inter + Fraunces), matching authorwings.com. If the active
		// theme already loads them this just resolves to the cached files.
		wp_register_style(
			'awpc-fonts',
			'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Inter:wght@400;500;600;700&display=swap',
			array(),
			null
		);

		wp_register_style(
			'awpc-calculator',
			AWPC_PLUGIN_URL . 'assets/css/awpc-calculator.css',
			array( 'awpc-fonts' ),
			AWPC_VERSION
		);

		register_block_type(
			'authorwings/calculator',
			array(
				'api_version'     => 2,
				'title'           => __( 'AuthorWings Calculator', 'authorwings-calculator' ),
				'category'        => 'widgets',
				'icon'            => 'calculator',
				'editor_script'   => 'awpc-block',
				'editor_style'    => 'awpc-calculator',
				'attributes'      => array(
					'title'      => array( 'type' => 'string', 'default' => '' ),
					'subtitle'   => array( 'type' => 'string', 'default' => '' ),
					'show_quote' => array( 'type' => 'boolean', 'default' => true ),
				),
				'render_callback' => array( $this, 'render_block' ),
			)
		);
	}

	/**
	 * Block render callback. Maps block attributes onto the shortcode handler so
	 * defaults (and asset enqueueing) stay in one place.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	public function render_block( $attributes = array() ) {
		$atts = array();

		if ( ! empty( $attributes['title'] ) ) {
			$atts['title'] = $attributes['title'];
		}
		if ( ! empty( $attributes['subtitle'] ) ) {
			$atts['subtitle'] = $attributes['subtitle'];
		}
		// Only override when the editor explicitly turned the form off.
		if ( isset( $attributes['show_quote'] ) && false === $attributes['show_quote'] ) {
			$atts['show_quote'] = 'no';
		}

		return $this->render_shortcode( $atts );
	}

	/**
	 * Register the legacy widget.
	 */
	public function register_widget() {
		register_widget( 'AWPC_Widget' );
	}
}

/**
 * Classic widget wrapper.
 */
class AWPC_Widget extends WP_Widget {

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct(
			'awpc_widget',
			__( 'AuthorWings Calculator', 'authorwings-calculator' ),
			array( 'description' => __( 'Book publishing cost calculator.', 'authorwings-calculator' ) )
		);
	}

	/**
	 * Output the widget.
	 *
	 * @param array $args     Widget args.
	 * @param array $instance Saved instance.
	 */
	public function widget( $args, $instance ) {
		echo wp_kses_post( $args['before_widget'] );
		echo do_shortcode( '[authorwings_calculator]' );
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Back-end form (no options).
	 *
	 * @param array $instance Saved instance.
	 */
	public function form( $instance ) {
		echo '<p>' . esc_html__( 'Displays the AuthorWings pricing calculator. No settings needed.', 'authorwings-calculator' ) . '</p>';
	}
}
