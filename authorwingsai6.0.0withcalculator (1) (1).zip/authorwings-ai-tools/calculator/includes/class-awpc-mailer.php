<?php
/**
 * Built-in SMTP sender.
 *
 * Lets the site send mail through an authenticated SMTP server configured on
 * the plugin's own settings page — so estimate emails actually get delivered
 * without needing a separate SMTP plugin. When SMTP is disabled the plugin
 * falls back to WordPress' default mailer (PHP mail()).
 *
 * @package AuthorWings_Pricing_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AWPC_Mailer
 */
class AWPC_Mailer {

	/**
	 * Option key holding the SMTP settings array.
	 */
	const OPTION_KEY = 'awpc_smtp';

	/**
	 * Constructor — wire up the mail hooks (front-end AJAX included).
	 */
	public function __construct() {
		$s = $this->settings();

		// Let the calculator's own emails inherit the configured sender.
		add_filter( 'awpc_from_email', array( $this, 'filter_from_email' ), 5 );
		add_filter( 'awpc_from_name', array( $this, 'filter_from_name' ), 5 );

		// Optionally force a consistent From on ALL site mail (e.g. the test email).
		if ( 'yes' === $s['force_from'] ) {
			if ( '' !== $s['from_email'] ) {
				add_filter( 'wp_mail_from', array( $this, 'filter_from_email' ), 5 );
			}
			if ( '' !== $s['from_name'] ) {
				add_filter( 'wp_mail_from_name', array( $this, 'filter_from_name' ), 5 );
			}
		}

		// Route mail through SMTP when enabled and a host is set.
		if ( 'yes' === $s['enabled'] && '' !== $s['host'] ) {
			add_action( 'phpmailer_init', array( $this, 'configure' ) );
		}
	}

	/**
	 * Default SMTP settings.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'enabled'    => 'no',
			'host'       => '',
			'port'       => 587,
			'encryption' => 'tls', // none | ssl | tls.
			'auth'       => 'yes',
			'username'   => '',
			'password'   => '',
			'from_email' => '',
			'from_name'  => '',
			'force_from' => 'yes',
		);
	}

	/**
	 * Current settings merged over defaults.
	 *
	 * @return array
	 */
	public function settings() {
		$saved = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return wp_parse_args( $saved, self::defaults() );
	}

	/**
	 * From-address filter — use the configured address when set.
	 *
	 * @param string $value Incoming address.
	 * @return string
	 */
	public function filter_from_email( $value ) {
		$s = $this->settings();
		return ( '' !== $s['from_email'] ) ? $s['from_email'] : $value;
	}

	/**
	 * From-name filter — use the configured name when set.
	 *
	 * @param string $value Incoming name.
	 * @return string
	 */
	public function filter_from_name( $value ) {
		$s = $this->settings();
		return ( '' !== $s['from_name'] ) ? $s['from_name'] : $value;
	}

	/**
	 * Apply the SMTP configuration to PHPMailer.
	 *
	 * @param PHPMailer\PHPMailer\PHPMailer|object $phpmailer PHPMailer instance.
	 */
	public function configure( $phpmailer ) {
		$s = $this->settings();
		if ( '' === $s['host'] ) {
			return;
		}

		$phpmailer->isSMTP();
		$phpmailer->Host = $s['host'];
		$phpmailer->Port = (int) $s['port'];

		if ( 'none' === $s['encryption'] ) {
			$phpmailer->SMTPSecure  = '';
			$phpmailer->SMTPAutoTLS = false;
		} else {
			$phpmailer->SMTPSecure = $s['encryption']; // 'ssl' or 'tls'.
		}

		if ( 'yes' === $s['auth'] ) {
			$phpmailer->SMTPAuth = true;
			$phpmailer->Username = $s['username'];
			$phpmailer->Password = $s['password'];
		} else {
			$phpmailer->SMTPAuth = false;
		}
	}
}
