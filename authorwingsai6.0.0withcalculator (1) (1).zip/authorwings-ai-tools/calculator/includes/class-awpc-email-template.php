<?php
/**
 * Professional HTML email templates for the estimate emails.
 *
 * Renders two branded, responsive (table-based, inline-styled) messages that
 * render reliably across Gmail, Outlook and Apple Mail:
 *
 *   1. The site-owner notification  ("New estimate request").
 *   2. The lead's own confirmation  ("Your book estimate").
 *
 * Every send is multipart: the HTML built here is paired with the plain-text
 * fallback the plugin already produced, so text-only clients keep working.
 *
 * All of the copy and the branding (logo, header/footer text, accent colour,
 * subject lines, headings, intro paragraphs, button labels and the closing
 * note) are editable under Settings → AuthorWings Calculator → "Estimate
 * emails". Blank fields fall back to the defaults below. Editable text may use
 * the {name}, {site} and {total} placeholders.
 *
 * Palette and type mirror authorwings.com and the front-end calculator
 * (cream / navy / sage; Fraunces headings, Inter body).
 *
 * @package AuthorWings_Pricing_Calculator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class AWPC_Email_Template
 */
class AWPC_Email_Template {

	/**
	 * Option key holding the editable email-content array.
	 */
	const OPTION_KEY = 'awpc_email';

	/* -----------------------------------------------------------------
	 * Fixed brand palette (kept in sync with the calculator CSS).
	 * The sage accent is overridable per-site; the rest are structural.
	 * --------------------------------------------------------------- */

	const ACCENT = '#5c7a6b'; // Default sage accent.
	const TEXT   = '#1c2439'; // Deep navy.
	const MUTED  = '#5d6675'; // Muted navy-grey.
	const CREAM  = '#f6f1e8'; // Warm page background.
	const CARD   = '#ffffff'; // Card surface.
	const BORDER = '#e7ddc9'; // Warm border.
	const MINT   = '#eef5f0'; // Very light sage tint for zebra rows.
	const TINT   = '#eaf3ec'; // Light sage tint for the estimate-total row.
	const TINT_BORDER = '#c3d8c9'; // Soft sage rule above the total row.

	const FONT_BODY = "'Inter',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif";
	const FONT_HEAD = "'Fraunces',Georgia,'Times New Roman',serif";

	/**
	 * Resolved settings (saved values merged over defaults()).
	 *
	 * @var array
	 */
	private $s;

	/**
	 * Resolved accent colour.
	 *
	 * @var string
	 */
	private $accent;

	/**
	 * Resolved darker accent (for gradients / hovers).
	 *
	 * @var string
	 */
	private $accent_dark;

	/**
	 * Constructor — load the editable settings once.
	 */
	public function __construct() {
		$saved   = get_option( self::OPTION_KEY, array() );
		$this->s = is_array( $saved ) ? $saved : array();

		$this->accent      = $this->opt( 'accent' );
		$this->accent_dark = $this->darken( $this->accent, 18 );
	}

	/**
	 * Default (blank-fallback) values for every editable field.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			// Branding (shared).
			'logo'          => '',                                   // Optional logo URL; blank = wordmark.
			'brand'         => '',                                   // Header name; blank = site name.
			'tagline'       => __( 'Book Cost Estimate', 'authorwings-calculator' ),
			'accent'        => self::ACCENT,
			'footer'        => __( 'crafting and publishing books authors are proud of.', 'authorwings-calculator' ),

			// Lead confirmation.
			'lead_subject'  => __( 'Your consultation request & book estimate — {site}', 'authorwings-calculator' ),
			'lead_intro'    => __( 'Thank you for requesting a consultation with {site}. We have your preferred call time as {preferred}, and a publishing advisor will call you then to talk through your book, your goals and timeline, and refine the quote together. If that time turns out not to work, we will be in touch to find the nearest slot. The estimate you built is below — keep it handy for our conversation.', 'authorwings-calculator' ),
			'lead_button'   => __( 'Reopen or edit your estimate', 'authorwings-calculator' ),
			'lead_note'     => __( 'This is a guide estimate, typically within ~10–15% of your final quote. We will confirm exact pricing on your consultation call — no obligation. Reply to this email any time if you have questions before then.', 'authorwings-calculator' ),

			// Owner notification.
			'owner_subject' => __( '[{site}] Book estimate — {total}', 'authorwings-calculator' ),
			'owner_heading' => __( 'New estimate request', 'authorwings-calculator' ),
			'owner_intro'   => __( 'A visitor just built an estimate worth {total} and asked to be contacted. Their details and the full breakdown are below.', 'authorwings-calculator' ),
			'owner_button'  => __( 'Open this estimate', 'authorwings-calculator' ),
		);
	}

	/**
	 * A single editable value, falling back to its default when blank.
	 *
	 * @param string $key Field key.
	 * @return string
	 */
	private function opt( $key ) {
		$val = isset( $this->s[ $key ] ) ? trim( (string) $this->s[ $key ] ) : '';
		if ( '' !== $val ) {
			return $val;
		}
		$defaults = self::defaults();
		return isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	}

	/* =================================================================
	 * Subjects (used by the AJAX sender).
	 * =============================================================== */

	/**
	 * Lead-email subject with placeholders resolved.
	 *
	 * @param array $vars Placeholder map (site/name/total).
	 * @return string
	 */
	public function subject_lead( $vars ) {
		return $this->fill_raw( $this->opt( 'lead_subject' ), $vars );
	}

	/**
	 * Owner-email subject with placeholders resolved.
	 *
	 * @param array $vars Placeholder map (site/name/total).
	 * @return string
	 */
	public function subject_owner( $vars ) {
		return $this->fill_raw( $this->opt( 'owner_subject' ), $vars );
	}

	/* =================================================================
	 * Full emails.
	 * =============================================================== */

	/**
	 * Render the lead-facing confirmation email.
	 *
	 * @param array $args {
	 *     @type string $site      Site / brand name.
	 *     @type string $name      Lead's name.
	 *     @type string $summary   Plain-text estimate summary (line items).
	 *     @type string $total     Formatted grand total (e.g. "$600").
	 *     @type string $est_url   Deep link that reopens the estimate.
	 * }
	 * @return string Full HTML document.
	 */
	public function render_lead( $args ) {
		$a      = $this->normalize( $args );
		$first  = $this->first_name( $a['name'] );
		$parsed = $this->parse_summary( $a['summary'] );
		$vars   = $this->vars( $a, $first );

		$body  = $this->h1( sprintf( esc_html__( 'Hi %s,', 'authorwings-calculator' ), esc_html( $first ) ) );
		$body .= $this->paragraph( $this->fill_html( $this->opt( 'lead_intro' ), $vars ) );
		$body .= $this->estimate_card( $parsed, $a['total'] );

		if ( '' !== $a['est_url'] ) {
			$body .= $this->button( $a['est_url'], esc_html( $this->fill_raw( $this->opt( 'lead_button' ), $vars ) ) );
		}

		$note = trim( $this->opt( 'lead_note' ) );
		if ( '' !== $note ) {
			$body .= $this->note( $this->fill_html( $note, $vars ) );
		}

		$preheader = sprintf(
			/* translators: %s: formatted total. */
			esc_html__( 'Your consultation request is in — here is the estimate you built (%s).', 'authorwings-calculator' ),
			esc_html( $a['total'] )
		);

		return $this->document( $a['site'], $preheader, $body );
	}

	/**
	 * Render the site-owner notification email (a new lead + their estimate).
	 *
	 * @param array $args {
	 *     @type string $site       Site / brand name.
	 *     @type string $name       Lead's name.
	 *     @type string $email      Lead's email.
	 *     @type string $phone      Lead's phone.
	 *     @type string $ptype      Project type.
	 *     @type string $preferred  Preferred consultation date/time line.
	 *     @type string $message    Free-text notes.
	 *     @type string $summary    Plain-text estimate summary (line items).
	 *     @type string $total      Formatted grand total.
	 *     @type string $est_url    Deep link that reopens the estimate.
	 * }
	 * @return string Full HTML document.
	 */
	public function render_notification( $args ) {
		$a      = $this->normalize( $args );
		$parsed = $this->parse_summary( $a['summary'] );
		$vars   = $this->vars( $a, $a['name'] );

		$body  = $this->h1( esc_html( $this->fill_raw( $this->opt( 'owner_heading' ), $vars ) ) );
		$body .= $this->paragraph( $this->fill_html( $this->opt( 'owner_intro' ), $vars, true ) );
		$body .= $this->contact_card( $a );
		$body .= $this->estimate_card( $parsed, $a['total'] );

		if ( '' !== $a['est_url'] ) {
			$body .= $this->button( $a['est_url'], esc_html( $this->fill_raw( $this->opt( 'owner_button' ), $vars ) ) );
		}

		if ( '' !== $a['email'] ) {
			$body .= $this->note(
				sprintf(
					/* translators: %s: lead's email address (linked). */
					esc_html__( 'Reply straight to this email to reach %s — the reply-to is already set to their address.', 'authorwings-calculator' ),
					'<a href="mailto:' . esc_attr( $a['email'] ) . '" style="color:' . $this->accent_dark . ';">' . esc_html( $a['email'] ) . '</a>'
				)
			);
		}

		$preheader = sprintf(
			/* translators: 1: lead name, 2: total. */
			esc_html__( 'New lead: %1$s — estimate %2$s', 'authorwings-calculator' ),
			esc_html( $a['name'] ? $a['name'] : $a['email'] ),
			esc_html( $a['total'] )
		);

		return $this->document( $a['site'], $preheader, $body );
	}

	/* =================================================================
	 * Building blocks.
	 * =============================================================== */

	/**
	 * Outer document: cream page, centred white card, header + footer.
	 *
	 * @param string $site      Brand name.
	 * @param string $preheader Hidden inbox-preview text.
	 * @param string $inner     Inner body HTML (already escaped).
	 * @return string
	 */
	private function document( $site, $preheader, $inner ) {
		$year        = gmdate( 'Y' );
		$brand       = $this->opt( 'brand' );
		$brand       = ( '' !== $brand ) ? $brand : $site;
		$logo        = $this->opt( 'logo' );
		$tagline     = $this->opt( 'tagline' );
		$footer_line = $this->opt( 'footer' );

		$brand_mark = ( '' !== $logo )
			? '<img src="' . esc_url( $logo ) . '" alt="' . esc_attr( $brand ) . '" height="36" style="display:block; height:36px; max-height:36px; width:auto; border:0;" />'
			: esc_html( $brand );

		ob_start();
		?>
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="color-scheme" content="light only" />
	<meta name="supported-color-schemes" content="light only" />
	<title><?php echo esc_html( $brand ); ?></title>
	<!--[if mso]><style>* { font-family: Georgia, 'Times New Roman', serif !important; }</style><![endif]-->
	<style>
		@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Inter:wght@400;500;600&display=swap');
		body { margin: 0; padding: 0; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
		img { border: 0; line-height: 100%; outline: none; text-decoration: none; -ms-interpolation-mode: bicubic; }
		table { border-collapse: collapse !important; }
		a { text-decoration: none; }
		@media only screen and (max-width: 620px) {
			.awpc-card { width: 100% !important; border-radius: 0 !important; }
			.awpc-pad { padding-left: 22px !important; padding-right: 22px !important; }
			.awpc-btn a { display: block !important; }
		}
	</style>
</head>
<body style="margin:0; padding:0; background-color:<?php echo esc_attr( self::CREAM ); ?>; font-family:<?php echo self::FONT_BODY; // phpcs:ignore ?>;">
	<div style="display:none; max-height:0; overflow:hidden; opacity:0; mso-hide:all; font-size:1px; line-height:1px; color:<?php echo esc_attr( self::CREAM ); ?>;"><?php echo esc_html( $preheader ); ?></div>
	<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:<?php echo esc_attr( self::CREAM ); ?>;">
		<tr>
			<td align="center" style="padding:32px 12px;">
				<table role="presentation" class="awpc-card" width="600" cellpadding="0" cellspacing="0" style="width:600px; max-width:600px; background-color:<?php echo esc_attr( self::CARD ); ?>; border:1px solid <?php echo esc_attr( self::BORDER ); ?>; border-radius:14px; overflow:hidden;">
					<!-- Header -->
					<tr>
						<td style="background-color:<?php echo esc_attr( $this->accent ); ?>; background-image:linear-gradient(135deg, <?php echo esc_attr( $this->accent ); ?> 0%, <?php echo esc_attr( $this->accent_dark ); ?> 100%); padding:30px 40px;">
							<table role="presentation" width="100%" cellpadding="0" cellspacing="0">
								<tr>
									<td style="font-family:<?php echo self::FONT_HEAD; // phpcs:ignore ?>; font-size:26px; font-weight:600; letter-spacing:0.2px; color:#ffffff;">
										<?php echo $brand_mark; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</td>
									<?php if ( '' !== $tagline ) : ?>
									<td align="right" style="font-family:<?php echo self::FONT_BODY; // phpcs:ignore ?>; font-size:12px; font-weight:500; letter-spacing:1.5px; text-transform:uppercase; color:#e6efe8;">
										<?php echo esc_html( $tagline ); ?>
									</td>
									<?php endif; ?>
								</tr>
							</table>
						</td>
					</tr>
					<!-- Body -->
					<tr>
						<td class="awpc-pad" style="padding:34px 40px 12px 40px;">
							<?php echo $inner; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</td>
					</tr>
					<!-- Footer -->
					<tr>
						<td class="awpc-pad" style="padding:24px 40px 30px 40px; border-top:1px solid <?php echo esc_attr( self::BORDER ); ?>;">
							<?php if ( '' !== $footer_line ) : ?>
							<p style="margin:0 0 4px 0; font-family:<?php echo self::FONT_BODY; // phpcs:ignore ?>; font-size:13px; line-height:20px; color:<?php echo esc_attr( self::MUTED ); ?>;">
								<strong style="color:<?php echo esc_attr( self::TEXT ); ?>;"><?php echo esc_html( $brand ); ?></strong> — <?php echo esc_html( $footer_line ); ?>
							</p>
							<?php endif; ?>
							<p style="margin:0; font-family:<?php echo self::FONT_BODY; // phpcs:ignore ?>; font-size:12px; line-height:18px; color:<?php echo esc_attr( self::MUTED ); ?>;">
								&copy; <?php echo esc_html( $year ); ?> <?php echo esc_html( $brand ); ?>. <?php echo esc_html__( 'This estimate was generated from the choices made in the online calculator and is not a binding quote.', 'authorwings-calculator' ); ?>
							</p>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>
		<?php
		return trim( ob_get_clean() );
	}

	/**
	 * Section heading.
	 *
	 * @param string $text Pre-escaped text.
	 * @return string
	 */
	private function h1( $text ) {
		return '<h1 style="margin:0 0 14px 0; font-family:' . self::FONT_HEAD . '; font-size:23px; line-height:30px; font-weight:600; color:' . self::TEXT . ';">' . $text . '</h1>';
	}

	/**
	 * Body paragraph.
	 *
	 * @param string $html Pre-escaped/allowed HTML.
	 * @return string
	 */
	private function paragraph( $html ) {
		return '<p style="margin:0 0 20px 0; font-family:' . self::FONT_BODY . '; font-size:15px; line-height:24px; color:' . self::MUTED . ';">' . $html . '</p>';
	}

	/**
	 * The itemised estimate card: line items + highlighted total.
	 *
	 * @param array  $parsed Result of parse_summary().
	 * @param string $total  Formatted grand total.
	 * @return string
	 */
	private function estimate_card( $parsed, $total ) {
		$rows = '';
		$i    = 0;

		if ( ! empty( $parsed['items'] ) ) {
			foreach ( $parsed['items'] as $item ) {
				$bg    = ( 0 === $i % 2 ) ? self::CARD : self::MINT;
				$rows .= '<tr>'
					. '<td style="padding:11px 18px; font-family:' . self::FONT_BODY . '; font-size:14px; line-height:20px; color:' . self::TEXT . '; background-color:' . $bg . '; border-bottom:1px solid ' . self::BORDER . ';">' . esc_html( $item['label'] ) . '</td>'
					. '<td align="right" style="padding:11px 18px; font-family:' . self::FONT_BODY . '; font-size:14px; line-height:20px; font-weight:600; color:' . self::TEXT . '; white-space:nowrap; background-color:' . $bg . '; border-bottom:1px solid ' . self::BORDER . ';">' . esc_html( $item['amount'] ) . '</td>'
					. '</tr>';
				$i++;
			}
		} else {
			// Fallback: no parseable items — show the raw summary so nothing is lost.
			$raw   = nl2br( esc_html( trim( $parsed['raw'] ) ) );
			$rows .= '<tr><td colspan="2" style="padding:14px 18px; font-family:' . self::FONT_BODY . '; font-size:14px; line-height:22px; color:' . self::TEXT . ';">' . $raw . '</td></tr>';
		}

		// Savings row (optional), shown just under the items.
		$saves_row = '';
		if ( '' !== $parsed['saves'] ) {
			$saves_row = '<tr><td colspan="2" style="padding:10px 18px; font-family:' . self::FONT_BODY . '; font-size:13px; line-height:18px; font-weight:600; color:' . $this->accent_dark . '; background-color:' . self::MINT . '; border-bottom:1px solid ' . self::BORDER . ';">&#10003; ' . esc_html( $parsed['saves'] ) . '</td></tr>';
		}

		// Grand-total row — light sage tint with a sage top rule (not a heavy
		// solid-green bar): navy label, sage figure.
		$total_row = '<tr>'
			. '<td style="padding:16px 18px; font-family:' . self::FONT_HEAD . '; font-size:16px; font-weight:600; color:' . self::TEXT . '; background-color:' . self::TINT . '; border-top:2px solid ' . self::TINT_BORDER . ';">' . esc_html__( 'Estimated total', 'authorwings-calculator' ) . '</td>'
			. '<td align="right" style="padding:16px 18px; font-family:' . self::FONT_HEAD . '; font-size:22px; font-weight:600; color:' . $this->accent_dark . '; white-space:nowrap; background-color:' . self::TINT . '; border-top:2px solid ' . self::TINT_BORDER . ';">' . esc_html( $total ) . '</td>'
			. '</tr>';

		// Payment-plan line (optional), below the card.
		$plan = '';
		if ( '' !== $parsed['plan'] ) {
			$plan = '<p style="margin:10px 2px 22px 2px; font-family:' . self::FONT_BODY . '; font-size:13px; line-height:20px; color:' . self::MUTED . ';">'
				. '<strong style="color:' . self::TEXT . ';">' . esc_html__( 'Payment options:', 'authorwings-calculator' ) . '</strong> '
				. esc_html( $parsed['plan'] ) . '</p>';
		}

		// Rush-delivery note (optional), shown whenever the lead chose rush.
		$rush = '';
		if ( '' !== $parsed['rush'] ) {
			$rush = '<p style="margin:10px 2px 22px 2px; font-family:' . self::FONT_BODY . '; font-size:12px; line-height:19px; color:' . self::MUTED . ';">'
				. esc_html( $parsed['rush'] ) . '</p>';
		}

		return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:4px 0 6px 0; border:1px solid ' . self::BORDER . '; border-radius:12px; overflow:hidden;">'
			. '<tr><td colspan="2" style="padding:12px 18px; font-family:' . self::FONT_BODY . '; font-size:11px; font-weight:600; letter-spacing:1.2px; text-transform:uppercase; color:' . self::MUTED . '; background-color:' . self::CREAM . '; border-bottom:1px solid ' . self::BORDER . ';">' . esc_html__( 'Your estimate', 'authorwings-calculator' ) . '</td></tr>'
			. $rows
			. $saves_row
			. $total_row
			. '</table>'
			. $plan
			. $rush;
	}

	/**
	 * Contact / lead details card (owner email only).
	 *
	 * @param array $a Normalised args.
	 * @return string
	 */
	private function contact_card( $a ) {
		$rows = array();

		$email_val = ( '' !== $a['email'] )
			? '<a href="mailto:' . esc_attr( $a['email'] ) . '" style="color:' . $this->accent_dark . '; font-weight:600;">' . esc_html( $a['email'] ) . '</a>'
			: '';
		$phone_val = ( '' !== $a['phone'] )
			? '<a href="tel:' . esc_attr( preg_replace( '/[^\d+]/', '', $a['phone'] ) ) . '" style="color:' . self::TEXT . '; font-weight:600;">' . esc_html( $a['phone'] ) . '</a>'
			: '';

		$rows[ esc_html__( 'Name', 'authorwings-calculator' ) ]                    = esc_html( $a['name'] );
		$rows[ esc_html__( 'Email', 'authorwings-calculator' ) ]                   = $email_val;
		$rows[ esc_html__( 'Phone', 'authorwings-calculator' ) ]                   = $phone_val;
		$rows[ esc_html__( 'Project type', 'authorwings-calculator' ) ]           = esc_html( $a['ptype'] );
		$rows[ esc_html__( 'Preferred consultation', 'authorwings-calculator' ) ] = esc_html( $a['preferred'] );
		if ( '' !== $a['message'] ) {
			$rows[ esc_html__( 'Notes', 'authorwings-calculator' ) ] = nl2br( esc_html( $a['message'] ) );
		}

		$body = '';
		$n    = 0;
		foreach ( $rows as $label => $value ) {
			if ( '' === $value ) {
				continue;
			}
			$border = ( $n > 0 ) ? 'border-top:1px solid ' . self::BORDER . ';' : '';
			$body  .= '<tr>'
				. '<td valign="top" style="' . $border . ' padding:10px 18px; width:38%; font-family:' . self::FONT_BODY . '; font-size:12px; font-weight:600; letter-spacing:0.4px; text-transform:uppercase; color:' . self::MUTED . ';">' . $label . '</td>'
				. '<td valign="top" style="' . $border . ' padding:10px 18px; font-family:' . self::FONT_BODY . '; font-size:14px; line-height:20px; color:' . self::TEXT . ';">' . $value . '</td>'
				. '</tr>';
			$n++;
		}

		return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:4px 0 24px 0; border:1px solid ' . self::BORDER . '; border-radius:12px; overflow:hidden;">'
			. '<tr><td colspan="2" style="padding:12px 18px; font-family:' . self::FONT_BODY . '; font-size:11px; font-weight:600; letter-spacing:1.2px; text-transform:uppercase; color:' . self::MUTED . '; background-color:' . self::CREAM . '; border-bottom:1px solid ' . self::BORDER . ';">' . esc_html__( 'Lead details', 'authorwings-calculator' ) . '</td></tr>'
			. $body
			. '</table>';
	}

	/**
	 * A bullet-proof (Outlook-safe) call-to-action button.
	 *
	 * @param string $url  Destination URL.
	 * @param string $text Pre-escaped label.
	 * @return string
	 */
	private function button( $url, $text ) {
		$url = esc_url( $url );

		// Light "outline" button: white fill, sage border, sage label — keeps the
		// call-to-action from being another heavy block of green.
		return '<table role="presentation" class="awpc-btn" cellpadding="0" cellspacing="0" style="margin:6px 0 26px 0;"><tr><td align="center" bgcolor="#ffffff" style="border-radius:10px; border:2px solid ' . $this->accent . ';">'
			. '<a href="' . $url . '" target="_blank" rel="noopener" style="display:inline-block; padding:13px 28px; font-family:' . self::FONT_BODY . '; font-size:15px; font-weight:700; line-height:20px; color:' . $this->accent_dark . '; background-color:#ffffff; border-radius:10px;">' . $text . ' &rarr;</a>'
			. '</td></tr></table>';
	}

	/**
	 * A soft, quote-style note block.
	 *
	 * @param string $html Pre-escaped/allowed HTML.
	 * @return string
	 */
	private function note( $html ) {
		return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:2px 0 18px 0;"><tr>'
			. '<td style="padding:14px 18px; background-color:' . self::CREAM . '; border-left:4px solid ' . $this->accent . '; border-radius:0 8px 8px 0; font-family:' . self::FONT_BODY . '; font-size:13px; line-height:21px; color:' . self::MUTED . ';">' . $html . '</td>'
			. '</tr></table>';
	}

	/* =================================================================
	 * Data helpers.
	 * =============================================================== */

	/**
	 * The placeholder map for a given message.
	 *
	 * @param array  $a    Normalised args.
	 * @param string $name Preferred name token ({name}).
	 * @return array
	 */
	private function vars( $a, $name ) {
		return array(
			'{site}'      => $a['site'],
			'{name}'      => $name,
			'{total}'     => $a['total'],
			'{preferred}' => $a['preferred'],
		);
	}

	/**
	 * Replace placeholders in a raw (unescaped) string — for subjects/labels.
	 *
	 * @param string $text Template text.
	 * @param array  $vars Placeholder map.
	 * @return string
	 */
	private function fill_raw( $text, $vars ) {
		return strtr( (string) $text, $vars );
	}

	/**
	 * Escape a template string, then swap placeholders for safe HTML.
	 *
	 * Newlines become <br>. When $bold_total is true the {total} placeholder is
	 * rendered bold in the body-text colour (used in the owner intro).
	 *
	 * @param string $text       Template text.
	 * @param array  $vars       Placeholder map (raw values).
	 * @param bool   $bold_total Emphasise the total.
	 * @return string
	 */
	private function fill_html( $text, $vars, $bold_total = false ) {
		$out = nl2br( esc_html( (string) $text ) );
		$map = array();
		foreach ( $vars as $token => $value ) {
			if ( '{total}' === $token && $bold_total ) {
				$map[ $token ] = '<strong style="color:' . self::TEXT . ';">' . esc_html( $value ) . '</strong>';
			} else {
				$map[ $token ] = esc_html( $value );
			}
		}
		return strtr( $out, $map );
	}

	/**
	 * Fill missing keys and trim everything to strings.
	 *
	 * @param array $args Raw args.
	 * @return array
	 */
	private function normalize( $args ) {
		$defaults = array(
			'site'      => '',
			'name'      => '',
			'email'     => '',
			'phone'     => '',
			'ptype'     => '',
			'preferred' => '',
			'message'   => '',
			'summary'   => '',
			'total'     => '',
			'est_url'   => '',
		);
		$a = wp_parse_args( $args, $defaults );
		foreach ( $a as $k => $v ) {
			$a[ $k ] = is_string( $v ) ? trim( $v ) : $v;
		}
		if ( '' === $a['site'] ) {
			$a['site'] = get_bloginfo( 'name' );
		}
		if ( '' === $a['name'] ) {
			$a['name'] = __( 'there', 'authorwings-calculator' );
		}
		return $a;
	}

	/**
	 * Turn the plain-text estimate summary into structured rows.
	 *
	 * Handles the bullet formats the plugin emits ("• Label: $X", "- Label: $X")
	 * as well as the special "You save…", "Estimated total…" and
	 * "Payment options…" lines, and ignores decorative headings / rules.
	 *
	 * @param string $summary Raw summary text.
	 * @return array { items:[[label,amount]...], saves:string, plan:string, raw:string }
	 */
	private function parse_summary( $summary ) {
		$out = array(
			'items' => array(),
			'saves' => '',
			'plan'  => '',
			'rush'  => '',
			'raw'   => (string) $summary,
		);

		$lines = preg_split( '/\r\n|\r|\n/', (string) $summary );
		foreach ( $lines as $line ) {
			// Strip leading bullet glyphs / dashes and surrounding whitespace.
			$clean = trim( preg_replace( '/^[\s]*[•\-\*\x{2013}\x{2014}\x{00B7}\x{25AA}]+\s*/u', '', $line ) );

			if ( '' === $clean ) {
				continue;
			}
			// Skip pure rules (----) and the decorative title line.
			if ( preg_match( '/^[-=_]{3,}$/', $clean ) ) {
				continue;
			}
			if ( preg_match( '/^my book cost estimate$/i', $clean ) ) {
				continue;
			}

			// Special lines.
			if ( preg_match( '/^you save\s+(.+?)\s*$/i', $clean, $m ) ) {
				$out['saves'] = trim( $m[1] );
				continue;
			}
			if ( preg_match( '/^payment options?\s*:\s*(.+)$/i', $clean, $m ) ) {
				$out['plan'] = trim( $m[1] );
				continue;
			}
			if ( preg_match( '/^rush delivery adds\b/i', $clean ) ) {
				$out['rush'] = trim( $clean );
				continue;
			}
			if ( preg_match( '/^estimated total\s*:/i', $clean ) ) {
				// Grand total is supplied separately; drop it here.
				continue;
			}

			// A line item: "Label: amount" (split on the LAST colon so labels
			// containing colons still work).
			$pos = strrpos( $clean, ':' );
			if ( false !== $pos ) {
				$label  = trim( substr( $clean, 0, $pos ) );
				$amount = trim( substr( $clean, $pos + 1 ) );
				if ( '' !== $label && '' !== $amount ) {
					$out['items'][] = array(
						'label'  => $label,
						'amount' => $amount,
					);
					continue;
				}
			}

			// Anything else that survives: keep it as a label-only row.
			$out['items'][] = array(
				'label'  => $clean,
				'amount' => '',
			);
		}

		return $out;
	}

	/**
	 * First word of a name, for a warmer greeting.
	 *
	 * @param string $name Full name.
	 * @return string
	 */
	private function first_name( $name ) {
		$name = trim( (string) $name );
		if ( '' === $name ) {
			return __( 'there', 'authorwings-calculator' );
		}
		$parts = preg_split( '/\s+/', $name );
		return $parts[0];
	}

	/**
	 * Darken a #rrggbb colour by a percentage (0–100). Returns the input on
	 * anything it cannot parse, so a bad value never breaks rendering.
	 *
	 * @param string $hex     Colour like "#5c7a6b".
	 * @param int    $percent How much darker.
	 * @return string
	 */
	private function darken( $hex, $percent ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( ! preg_match( '/^[0-9a-fA-F]{6}$/', $hex ) ) {
			return '#' . ( '' !== $hex ? $hex : ltrim( self::ACCENT, '#' ) );
		}
		$factor = max( 0, min( 100, (int) $percent ) ) / 100;
		$out    = '#';
		for ( $i = 0; $i < 3; $i++ ) {
			$c    = hexdec( substr( $hex, $i * 2, 2 ) );
			$c    = (int) round( $c * ( 1 - $factor ) );
			$out .= str_pad( dechex( max( 0, min( 255, $c ) ) ), 2, '0', STR_PAD_LEFT );
		}
		return $out;
	}
}
