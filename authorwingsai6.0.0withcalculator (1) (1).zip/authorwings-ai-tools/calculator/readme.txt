=== AuthorWings Pricing Calculator ===
Contributors: authorwings
Tags: calculator, pricing, book publishing, quote, estimate
Requires at least: 5.6
Tested up to: 6.5
Requires PHP: 7.2
Stable tag: 1.9.9
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

An interactive book-cost calculator built from AuthorWings' published services, plans and packages.

== Description ==

AuthorWings Pricing Calculator lets visitors estimate the cost of their book
project in real time, then email themselves (and you) the breakdown as a lead.

It mirrors the AuthorWings service catalogue:

* **Ghostwriting** — Starter, Growth, Authority, plus a **Standard / Children's & illustrated** toggle that swaps in three children's tiers (Starter / Growth / Authority) so the two sets never crowd the same grid.
* **Editing** — a toggle between **Editing package** (Polish / Standard / Comprehensive tiers, priced per word) and **Individual services** (developmental, line, copy, proofreading — base price plus a per-word rate beyond the included allowance). The toggle prevents the two from double-counting.
* **Design** — Cover (Starter / Growth / Authority), Interior formatting (ebook / print / premium) and Illustration. Spot and full-page illustration are priced **per piece**, with a quantity input that multiplies the total.
* **Publishing & Distribution** — Starter, Growth, Authority.
* **Marketing** — Foundation, Growth, Authority.
* **Coaching** — Starter, Growth, Authority.
* **Add-ons** grouped by area:
  * *Publishing & rights* — copyright, ISBN, series setup, additional format (per format), audiobook, translation (per word × languages), book-to-screen pitch, foreign rights pitch (per region).
  * *Marketing* — paid review, PR wire, standard/premium trailer, NetGalley, BookFunnel.
  * *Premium / authority* — TV/podcast booking, national PR, speaking, awards, book fair (per fair), Kindle promotion, billboard (per market).

Per-unit add-ons (per region / market / fair / format / language) and per-piece
illustration show a quantity field that multiplies the price; per-word services
(editing tiers, translation) multiply by the manuscript word count.
* **Ready-made bundles** — Launch-Ready, Editing and Publish-Ready bundles with advertised savings.
* **Rush surcharge** and **payment-plan guidance** based on the running total.

Two modes:

1. **Build Your Own** — choose a stage (idea / draft / finished), set the word
   count, and pick services individually. The total and suggested payment plan
   update live.
2. **Ready-Made Bundles** — one-click bundle pricing with savings shown.

== Installation ==

1. Upload the `authorwings-pricing-calculator` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** screen in WordPress.
3. Add the calculator to any page or post with the shortcode:

   `[authorwings_calculator]`

   You can also use the **AuthorWings Calculator** block or widget.

== Open the calculator from a link (popup) ==

If you would rather show a link/button on your site and have the calculator
open in a popup *on the same page* (instead of embedding it inline), use one of
these:

1. **Ready-made button** — drop this where you want the link to appear:

   `[authorwings_calculator_button label="Open the Cost Calculator"]`

   It prints a styled link; clicking it opens the calculator in a popup overlay.

2. **Your own link / menu item** — place this shortcode once on the page
   (it shows nothing on its own):

   `[authorwings_calculator_modal]`

   Then point ANY link at `#awpc-calculator` and it will open the popup. For a
   navigation-menu link, add a **Custom Link** in *Appearance → Menus* with the
   URL set to `#awpc-calculator`. A plain HTML link works too:

   `<a href="#awpc-calculator">Pricing calculator</a>`

The popup closes on the × button, a click outside it, or the Esc key. Loading a
page with `#awpc-calculator` already in the URL opens it automatically.

== Shortcode attributes ==

* `title` — heading text. Default: "Book Cost Calculator".
* `subtitle` — sub-heading text.
* `show_quote` — `yes` (default) or `no` to hide the "Email me this estimate" form.

Example: `[authorwings_calculator title="What will your book cost?" show_quote="no"]`

The popup shortcodes accept the same `title`, `subtitle` and `show_quote`
attributes; `[authorwings_calculator_button]` also accepts `label` (link text)
and `class` (extra CSS classes to match your theme's buttons).

The **AuthorWings Calculator** block exposes the same three options (title,
subtitle and the "Email me this estimate" toggle) in the editor sidebar, with a
live preview — no need to remember the shortcode attributes.

== Saving & sharing an estimate ==

* The current build is saved to the page URL and to the browser session, so a
  refresh (or returning later) restores the visitor's selections.
* **Copy estimate link** copies a shareable URL that reopens the exact build.
* **Download / Print** opens the browser print dialog with a clean,
  estimate-only layout — handy for "Save as PDF".
* On phones a sticky bar keeps the running total and call-to-action in view
  while scrolling through the options.
* The shareable link is also included in the "Email me this estimate" emails,
  so you (and the lead) can reopen the estimate in one click.

== Viewing submissions (Leads dashboard) ==

Every time a visitor submits the built-in estimate form, the request is saved to
your site and listed under the **AuthorWings Leads** menu in wp-admin. The menu
shows a count bubble for leads you haven't opened yet.

Each lead keeps the visitor's name, email, phone, project type, preferred
consultation date/time and time zone, their notes, the estimated total and the
full itemised breakdown, plus a link to reopen the exact estimate they built.
You can:

* Filter by **New / Read**, or search by name, email, phone or project type.
* Open a lead for the full detail (opening it marks it read).
* Mark leads read/new or delete them, individually or in bulk.
* **Export to Excel** — download the current view as a ready-formatted `.xlsx` workbook for your CRM or a spreadsheet.

Submissions are stored *before* the notification emails are sent, so a lead is
never lost even if email delivery fails.

== Settings ==

Go to **Settings → AuthorWings Calculator** to:

* Set the notification email that receives lead submissions.
* Toggle whether a copy of the estimate is emailed to the lead.
* Edit **everything the calculator shows** — each tier’s name, price, word allowance and feature bullets (one per line), plus add-ons and bundles (price + saving) and the rush surcharge. Fields are generated automatically from the pricing data, so new items appear here too. Leaving a value at its default keeps the published content.
* Configure **built-in SMTP** — send the calculator's emails through your own
  mail server (host, port, encryption, username/password, From address) so they
  reach the inbox without a separate SMTP plugin.
* **Send a test email** to confirm your site can deliver the "Email me this estimate" form.

Email delivery uses WordPress' `wp_mail()`. If the test email never arrives,
turn on **Send via SMTP** in the settings and enter your mail server details
(e.g. Gmail/Workspace, Brevo, or your host's mailbox). No separate plugin needed.

Developers can also filter the entire pricing array via the `awpc_pricing`
filter, and the outgoing sender via the `awpc_from_email` / `awpc_from_name` filters.

== Changelog ==

= 1.9.9 =
* Improved: **Copy now says a publishing advisor will *call* the visitor at their chosen time** (rather than confirm by email). The visitor confirmation email, the on-screen confirmation message and the date/time field hint all read consistently: "a publishing advisor will call you then… if that time isn't available, we'll be in touch to find the nearest slot."

= 1.9.8 =
* Improved: **The visitor confirmation email now names the exact call slot the visitor chose.** The default intro reads "We have your preferred call time as [their date, time & zone], and a publishing advisor will confirm it by email within one business day." A new `{preferred}` placeholder is available in the email wording fields (Settings → AuthorWings Calculator → Emails) for anyone customising the copy.

= 1.9.7 =
* Improved: **Clearer wording on the consultation date/time fields.** The two fields are now labelled "Preferred call date" and "Preferred call time", with a short line above them explaining that the visitor is choosing their preferred slot and that you'll confirm by email within one business day (or suggest the nearest time).

= 1.9.6 =
* Improved: **Lightened the estimate email and downloadable PDF so the sage green no longer feels heavy.** The deep-green header stays, but the "Estimated total" row is now a soft sage tint with a sage figure and a thin sage rule (instead of a solid dark-green bar), and the email's action button is a white "outline" chip with a sage border and sage label (instead of a solid green fill). Applies to both the visitor and owner emails and the PDF download.

= 1.9.5 =
* Improved: **The "None" option cards now show a "Not included" state.** Rather than rendering an empty body, each "None" card displays a muted circle-slash icon with a centered "None" title and "Not included" label, so skipping a service reads as a deliberate choice. No prices or behaviour changed.
* Fixed: **The "Number of illustrations" quantity label is now readable on the navy "Most Popular" card.** It was dark navy text on the navy card, so it disappeared when the popular illustration tier was selected; it now renders in white with a lighter divider.
* Improved: **The quote / consultation form no longer opens on an empty ($0) estimate.** The main quote button now stays disabled until at least one service is selected, so the consultation form only appears once there is something to quote. If every service is deselected, an open form collapses again.
* Improved: **Rewrote the built-in form's default copy to be more professional and consultation-led.** The button labels, intro heading/text, "Good to know" notes and the post-submit confirmation message now guide the visitor toward booking a consultation call to discuss their book, with clear next steps (advisor reply within one business day, a confirmed call time with a join link, then a written proposal within 48 hours). These are defaults only — any wording you have saved in Settings → AuthorWings Calculator is left untouched.
* Improved: **The visitor confirmation email now matches the consultation flow.** Its default subject, intro, button and note frame the submission as a booked consultation request (advisor will confirm the call time within one business day) while still including the estimate for reference. Defaults only — saved custom email wording is untouched.

= 1.9.4 =
* Improved: **The Leads Excel export now auto-fits its columns and evens out the rows.** Column widths are measured from the actual content, so short columns (Total, Status, Phone) tighten up, an empty **Notes** column collapses to its header instead of leaving a wide blank gap, and the **Estimate breakdown** caps at a comfortable reading width and wraps. Every data row now uses one uniform height, so the sheet reads as a clean, even grid. Full values are preserved — a long breakdown previews within the row (expand the row, or open the lead, to read it in full).

= 1.9.3 =
* **The Leads export is now a genuine Excel `.xlsx` file.** "Export to Excel" writes a native OpenXML workbook, so Excel opens it directly with no "the file format and extension don't match" warning, and every field keeps its value exactly — long phone numbers stay text (no more `1.12E+12` scientific notation) rather than being re-parsed as numbers. The sheet keeps the arranged, styled layout: fixed column widths, a frozen branded header, wrapped **Notes** and **Estimate breakdown** columns, an itemised breakdown (one "Label: amount" line per service, plus savings and payment options), zebra striping and coloured New/Read status labels. Hosts without the PHP Zip extension fall back to the styled HTML workbook.

= 1.9.2 =
* **The Leads export now opens neatly arranged and styled.** The "Export to Excel" button produces a formatted Excel workbook instead of a raw CSV, so the data no longer arrives mangled — phone numbers keep their digits, dates stay readable, and the long **Notes** and **Estimate breakdown** fields wrap inside their own fixed-width columns instead of spilling across the sheet. Each row carries a branded header, an itemised breakdown, zebra striping and coloured New/Read status labels.

= 1.9.1 =
* The **rush surcharge is now itemised** in the quote instead of being baked into each service price. Ticking "Rush my project" adds a separate "Rush delivery (+25% on production services)" line and a one-line explanation of what it covers, across the on-screen estimate, the printed/downloaded quote and the estimate emails. The total is unchanged.

= 1.9.0 =
* **Plans & prices is now a full add / edit / delete manager.** Add new tiers, add-ons and bundles, delete ones you don't offer, and drag to reorder — all from *Settings → Plans & prices*, with changes going live on the calculator immediately. Each service shows only the fields its pricing model needs (flat price; flat + word allowance; per-word + minimum; base + allowance + per-word; per-unit), so the differently-shaped services are arranged consistently. Add-on group & per-unit noun, the "Most popular" badge, bundle groups/tiers and payment-plan thresholds are all editable too, and a **Reset to defaults** button restores the built-in catalogue. The full catalogue is stored as one snapshot so additions/deletions persist; earlier price-only tweaks migrate automatically on first save.

= 1.8.0 =
* Every estimate/consultation request submitted through the built-in form is now saved to the site and listed on a new **AuthorWings Leads** dashboard. The admin is consolidated under one top-level **AuthorWings Calculator** menu with **Settings** and **Leads** submenus (the Leads submenu shows a count bubble for unread leads). Each entry keeps the contact details, project type, preferred consultation slot, notes, estimated total and the full itemised breakdown, plus a link to reopen the estimate. Submissions are stored **before** the emails are sent, so a lead is never lost even if mail delivery fails.
* The lead detail view is organised into branded "Lead details" and itemised "Estimate" cards. Leads can be filtered by New/Read, searched by name/email/phone/project, opened for full detail, marked read/new, deleted (individually or in bulk) and exported to CSV.
* **Download / Print** now produces a professional, branded quote (header band with your logo/name and tagline, an itemised estimate table, savings and a highlighted total, payment options and a footer) that matches the estimate emails, instead of a plain receipt. It uses the same logo, brand name, tagline, accent colour and footer set under the "Estimate emails" settings.
* **Copy estimate link** now returns a short, tidy link (e.g. `?awpc=ab12cd9`) instead of a long encoded URL. Shared builds are stored on the site and reopened from the short code; the same short link is used for the "reopen" link in the estimate emails. Short links hold no personal data (only calculator selections) and are pruned automatically after 90 days by a daily task.

= 1.7.10 =
* The "Plans & prices" sections now all start collapsed (including the first, Ghostwriting) for a tidier overview — expand just the one you want to edit, or use "Expand all".

= 1.7.9 =
* Reorganised the settings screen into tabs — "Leads & form", "Emails" and "Plans & prices" — so the growing page is no longer one long scroll. All tabs still save together with one "Save Changes" button, and the tab you were on is remembered. The "How to use" shortcode guide is now a collapsible panel at the top.

= 1.7.8 =
* The estimate emails are now editable from the dashboard under Settings → AuthorWings Calculator → "Estimate emails (design & wording)". You can set a header logo, brand name, tagline, accent colour (with a colour picker; a darker shade is derived automatically) and footer line, plus the subject, heading/greeting intro, button label and closing note for both the visitor confirmation and your notification email. Leave any field blank to use its default; text fields support {name}, {site} and {total} placeholders.
* Added a "Send sample estimate emails" button that emails a live preview of both designs to your notification address.

= 1.7.7 =
* Redesigned both estimate emails as professional, responsive, branded HTML templates (cream / navy / sage to match authorwings.com). The site-owner notification now leads with the lead's contact details and an itemised estimate table with a highlighted total; the visitor's confirmation opens with a personal greeting, the same itemised breakdown, a clear "reopen & edit" button and a friendly next-steps note.
* Every email is now sent as multipart (HTML + plain text), so it renders beautifully in Gmail, Outlook and Apple Mail while text-only clients still receive the full breakdown.

= 1.7.6 =
* The three call-to-action button labels are now editable under Settings → AuthorWings Calculator → Button labels: the main button (defaults to "Get your free quote & consultation"), the built-in form's submit button ("Book my free consultation") and the mobile sticky-bar button ("Get a free quote"). Leave any blank to use its default.

= 1.7.5 =
* Removed the "What happens when you submit" block from the built-in form.
* Restyled "Important notes" as a small, quote-style note.
* Reworded the calls to action to reflect the consultation flow: the main button now reads "See your quote & schedule a free consultation" and the submit button "Schedule my free consultation".

= 1.7.4 =
* Built-in form: added an editable intro heading ("Talk to Us Before You Commit") and sub-text above the fields, plus editable "Important notes" and "What happens when you submit" blocks below the fields. All four are editable under Settings → AuthorWings Calculator → Built-in estimate form (blank uses the defaults).
* The success confirmation panel now has a × close button and auto-dismisses after 10 seconds.
* Sized the phone field's country-flag / dial-code selector to match the other form fields.

= 1.7.3 =
* After a successful built-in-form submission, the form is now replaced by a styled green confirmation panel (heading + "what happens next" details) instead of a one-line "Sent!" message. The wording is editable under Settings → AuthorWings Calculator → Built-in estimate form → Confirmation message (first line = bold heading, rest = body); leave blank for the default.

= 1.7.2 =
* The built-in form's phone field now shows a country-code flag + dial-code selector (intl-tel-input), defaulting to the US, so visitors can pick their country. The submitted number is stored in full international format. Uses real flag images so flags display on every OS, including Windows; if the widget can't load, the field falls back to a normal phone input.

= 1.7.1 =
* Built-in estimate form: all fields except the notes are now required (First name, Last name, Email, Phone, Project type, preferred date, preferred time and time zone), matching the Forminator layout. Enforced both in the browser and on the server.

= 1.7.0 =
* The built-in "Email me this estimate" form (used when no Forminator form is set) is now a full consultation-request form matching the Forminator layout: First name, Last name, Email, Phone, Project type, preferred consultation date & time, time zone, and Additional project notes. The full estimate is still emailed to you (and, optionally, the lead) automatically.
* Added a "Project type options" box under Settings → AuthorWings Calculator → Built-in estimate form. Enter one option per line for the dropdown; leave blank to use sensible defaults (Ghostwriting, Editing, Cover design, Publishing, Marketing, Coaching, Full package, Not sure yet).
* The estimate summary pre-filled into the Forminator project-notes field no longer includes the shareable estimate link.

= 1.6.9 =
* Forminator estimate popup now opens full-screen, matching the calculator's own popup (instead of a small centered card).
* The visitor's full estimate — every line item, total, savings and suggested payment plan — is now pre-filled into the Forminator form's project-notes field, so each lead arrives with complete context. The notes field is detected by its label/placeholder/name (anything mentioning "note"), falling back to the last textarea in the form.

= 1.6.8 =
* Added an optional "Estimate request form (Forminator)" setting. Paste a Forminator form shortcode (e.g. [forminator_form id="53788"]) — or just the form ID — under Settings → AuthorWings Calculator, and the "Email me this estimate" button will open that Forminator form in a popup instead of the built-in email form. Leave it blank to keep the built-in form.

= 1.6.7 =
* Bumped the action tiles' label font size to 0.7rem for slightly better readability.

= 1.6.6 =
* Moved the icon in each action tile (Copy link / Print / PDF / Reset) to the left of its label instead of above it, so each tile is a single compact row.

= 1.6.5 =
* Fixed the action tiles (Copy link / Print / PDF / Reset) picking up the host theme's button hover/focus/active styling — which was fading or "sticking" a tile after it was clicked. All four states (hover, focus, focus-visible, active) are now defined explicitly on the tiles so the theme can't bleed in: hover shows a soft fill, clicking shows a brief pressed tint, keyboard focus shows a ring, and a mouse click never leaves a tile stuck-highlighted. Also made the tiles smaller again — lighter font weight, smaller font, padding and icons.

= 1.6.4 =
* Fixed the estimate action tiles staying visually "highlighted" after a click — the shaded background is now applied only on genuine mouse hover, with a keyboard focus ring (focus-visible) for accessibility, so a click no longer leaves a tile looking stuck-on. Also shrank the tiles a little further (smaller icons, font and padding).

= 1.6.3 =
* Made the estimate action tiles (Copy link / Print / PDF / Reset) more compact — smaller icons, font size, padding and gaps — so they take up less space in the estimate panel.

= 1.6.2 =
* Changed the estimate panel's secondary actions from the segmented bar to a row of three icon tiles — "Copy link", "Print / PDF" and "Reset" — each showing an icon above its label. Reset now lives in the row as a quieter (muted) tile rather than a separate underlined link. Same actions as before, just a different layout.

= 1.6.1 =
* Redesigned the estimate panel's secondary actions. "Copy estimate link" and "Download / Print" are now a single divided "segmented" bar with icons (a bordered control split down the middle) instead of two plain underlined text links, and "Reset" sits centred beneath it. The copied-link confirmation ("Link copied!") now swaps only the label text so the button keeps its icon. Purely a visual/layout change — the buttons do exactly what they did before.

= 1.6.0 =
* Added built-in SMTP sending so estimate emails actually get delivered without needing a separate SMTP plugin. A new "Email sending (SMTP)" section under Settings → AuthorWings Calculator lets you enter your mail server host, port, encryption (None/SSL/TLS), username, password and From name/email; when enabled, every email the site sends (the estimate, the lead copy and the test email) is routed through that authenticated server. Leave it off to keep using WordPress' default PHP mail(). The "Send test email" tool and its notices now point at these settings instead of recommending a third-party plugin. Note: you still need valid SMTP credentials from a mail provider (Gmail/Workspace app password, Brevo, your host's mailbox, etc.) — that is what makes mail deliverable.

= 1.5.11 =
* Estimate emails now go out with an explicit, branded sender on the site's own domain (e.g. "AuthorWings <noreply@yourdomain.com>") instead of WordPress' default "wordpress@" address, and are sent as plain text with a UTF-8 charset. The lead's copy now sets its Reply-To to your notification inbox so their replies reach you. New `awpc_from_name` and `awpc_from_email` filters let you point the sender at a real mailbox. NOTE: this is a deliverability/branding improvement — actually receiving mail still requires your site to be able to send it (configure an SMTP plugin such as WP Mail SMTP if the Test Email does not arrive).

= 1.5.10 =
* Completed the 1.5.9 fix for the duplicated call-to-action button. The JavaScript already set the "Email me this estimate" button's `hidden` attribute when the quote form opened, but the base `.awpc-cta { display: block }` rule outranked the browser's default `[hidden]` styling, so the button stayed visible and two buttons still appeared. Added an `.awpc-cta[hidden] { display: none; }` rule so the button now actually disappears once the form opens, leaving only "Send my estimate".

= 1.5.9 =
* Fixed two "call to action" buttons showing at once after opening the quote form. Clicking "Email me this estimate" revealed the form (with its own "Send my estimate" button) but left the original "Email me this estimate" button in place, so two buttons appeared stacked. The "Email me this estimate" button now hides as soon as the form opens, leaving only "Send my estimate". Applies to both the desktop panel and the mobile "Email me this estimate" bar.

= 1.5.8 =
* Fixed the "Email me this estimate" quote form showing on page load. The form is meant to stay collapsed until "Email me this estimate" is clicked, but a CSS `display: flex` rule was overriding its `hidden` attribute, so the name/email fields and the "Send my estimate" button were always visible alongside the "Email me this estimate" button — making the two buttons look redundant. Added an `.awpc-quote-form[hidden] { display: none; }` rule so the form now stays hidden until requested.

= 1.5.7 =
* Fixed the segmented choice controls overflowing the card's right edge on very small phones (≤330px). At those widths the long labels now shorten automatically — "Standard book / Children's & illustrated" → "Standard / Children's", "I have an idea / I have a draft / It is finished" → "An idea / A draft / Finished", and "Editing package / Individual services" → "Package / Individual service" — so each pill stays on a single row. Screens above 330px are unchanged, and the full label is kept as each button's accessible name for screen readers.

= 1.5.6 =
* Removed the arrow glyphs from the step navigation buttons — they now read plain "Back" and "Next" instead of "← Back" and "Next →".

= 1.5.5 =
* Fixed: the segmented choice controls (e.g. "Where are you in the process?" and the editing package/individual toggle) wrapped into a broken pill shape on small/mobile screens. Below 640px the pill now stretches full width and the segments share that width equally on a single row. Desktop layout is unchanged.

= 1.5.4 =
* Small screens now show two bundle cards per row again (1.5.3 had dropped to one
  per row). Only the bundle price is reduced a little on small screens so two
  cards fit without the price being clipped — the bundle name and feature text
  stay full size. The grid uses an auto-fit floor, so it shows two per row down
  to ~360px and collapses to a single full-width card on very small screens,
  with no horizontal scrollbar at any width.

= 1.5.3 =
* Follow-up to 1.5.2: on small screens the cards now show one per row instead of
  two. With the font sizes restored to full size, two narrow columns could no
  longer fit the price, so it was clipped (e.g. "$12,495" showing as "$12,49")
  and a horizontal scrollbar appeared. One card per row gives the full-size name
  and price room to display completely at every small width.

= 1.5.2 =
* Restored the Ready-Made Bundle and Build-Your-Own card font sizes on small
  screens. Version 1.5.0 had shrunk the card name, price, Save badge, feature
  list and "Most Popular" eyebrow to an "extra compact" size below 640px, which
  made the text noticeably smaller as the viewport narrowed. The cards now keep
  their normal (desktop) font sizes at every width; only the column layout and
  spacing still adjust on small screens.

= 1.5.1 =
* Fixed the **Download / Print** button. It previously called the browser's
  print on the whole page, which a plugin stylesheet can't fully clean up, so it
  printed the entire site (theme header, menus and footer) across many sheets
  with the estimate buried in the middle. It now renders just the estimate
  (business name, date, line items, savings and total) into an off-screen iframe
  and prints that, producing a single clean page / PDF on any theme. The button
  is also disabled until at least one service is selected.

= 1.5.0 =
* Unified the Ready-Made Bundle cards with the Build-Your-Own option cards: the
  bundle name and price now share one line, then the Save badge and feature list
  each take their own row. On small screens both card types show two per row with
  a tighter, "extra compact" size, dropping to one per row on very small phones
  (under ~360px).

= 1.4.6 =
* Follow-up to 1.4.5: the bundle name also disappeared on hover and when a
  bundle was selected, because a hovered/focused <button> picked up the theme's
  button:hover / button:focus colour. The card now re-asserts its text colour in
  the hover, focus and selected states too.

= 1.4.5 =
* Fixed bundle names not showing on some themes. The bundle cards are <button>
  elements, which (unlike the <label> option cards) don't inherit text colour,
  so on themes that set their own button colour the name disappeared while the
  price/features stayed visible. The cards now set an explicit text colour.

= 1.4.4 =
* Ready-Made Bundles now lay out like the Build-Your-Own cards on narrow
  screens — two per row on small devices, dropping to one per row only on very
  small (phone) screens — instead of always stacking one per row.

= 1.4.3 =
* The popup now fills the whole screen (edge-to-edge) instead of a centered
  box, on desktop as well as mobile. The calculator itself stays centered at its
  normal max width; the close (×) stays at the top-right.

= 1.4.2 =
* Settings screen now documents the popup: the help panel on
  *Settings → AuthorWings Calculator* explains the inline shortcode, the
  ready-made button (`[authorwings_calculator_button]`) and the menu-link popup
  (`[authorwings_calculator_modal]` + a link to `#awpc-calculator`).

= 1.4.1 =
* Fixed the popup not opening: when closed, the modal's base `display:flex`
  overrode the browser's `hidden` handling and left an invisible full-screen
  layer over the page that swallowed the click on the trigger button. It now
  collapses to `display:none` while hidden. Also hardened the popup script so a
  click always opens it regardless of init order, and so a calculator-init error
  can never stop the button from working.

= 1.4.0 =
* Added a popup/modal mode: open the calculator over the current page from a
  button (`[authorwings_calculator_button]`), a menu item, or any link pointing
  at `#awpc-calculator` (`[authorwings_calculator_modal]`). Closes on the ×
  button, an outside click or the Esc key; opens automatically when the page URL
  ends in `#awpc-calculator`.

= 1.3.2 =
* Unified the recommended/selected styling across Build-Your-Own cards and bundles. The MOST POPULAR and SELECTED markers are now small eyebrow pills centered on the top edge of the card (matching the site's plan badges). Hover (sage border + subtle lift) and selected (sage ring + small SELECTED eyebrow) are identical in both places; only one eyebrow shows at a time, and the plain "None" choice shows no eyebrow.

= 1.3.1 =
* "Most Popular" now uses the dark navy fill + white text (matching authorwings.com) on both Build-Your-Own cards and Ready-Made bundles. To keep states distinct, "selected" moved to a strong sage ring + "✓ Selected" badge (works on white or navy), and hover is a subtle lift. A popular bundle that's also selected shows navy + ring + Selected badge (the redundant MOST POPULAR badge is hidden to avoid overlap).

= 1.3.0 =
* Added a "Most Popular" recommended-tier highlight (sage badge + sage border + subtle lift), applied consistently to both the Build-Your-Own option cards and the Ready-Made bundles. Navy stays reserved for the selected/active state, so a recommended card and a selected card never look the same. Which tier/bundle is flagged is set by an editable `popular` / `popular_bundles` map in the pricing data (defaults to the Growth tiers, plus Standard editing).

= 1.2.3 =
* Ready-Made bundle cards now have distinct states: a soft sage tint on hover/focus, and a navy (#1C2439) fill with white text, a mint "Save" badge and a "✓ Selected" badge when chosen — so the selected bundle is unmistakable and the host theme's button hover can't bleed in.

= 1.2.2 =
* Fixed the dark box that appeared behind a step on hover/focus on desktop: the new step nodes/checks/dots/arrows now define their own hover & focus styles (transparent for nodes, state-preserving for dots, white for arrows) so the host theme's button:hover/:focus can't bleed in. Added a sage keyboard-focus ring.

= 1.2.1 =
* Fixed garbled "âœ" characters before feature bullets: the checkmark added via CSS is now written as an ASCII escape (\2713) so it renders correctly even when the server delivers the stylesheet without a UTF-8 charset header. The step checkmarks are likewise emitted as a numeric HTML entity.

= 1.2.0 =
* Redesigned the step progress indicator to be fully device-adaptive, in brand colours (done = navy ✓, current = sage, upcoming = light cream): connected numbered nodes with labels on desktop, a collapsed "done ✓ · current · N steps to go" breadcrumb on tablets, and a compact dots + ‹ current › carousel (with prev/next arrows) on phones. The current step name is always visible, and steps remain clickable to jump.

= 1.1.10 =
* Per-unit add-on quantity boxes now show a visible unit label next to the stepper (e.g. "languages", "regions", "markets", "fairs", "formats") so it's clear what the number means, instead of a bare input with only an aria-label.

= 1.1.9 =
* Manuscript-length control now appears only where it affects the price. On the Project step it shows just for the "I have a draft" stage (where editing is word-priced). In the idea/finished stages it no longer shows there; instead a compact word-count field appears inline beside the Translation add-on when that add-on is selected. All word inputs share one value.

= 1.1.8 =
* Real fix for the missing illustration quantity input: the rule that hides each card's own radio/checkbox (`.awpc-card input`) was also matching the nested quantity field and setting it to opacity:0 / pointer-events:none. Scoped that rule to the direct-child control only (`.awpc-card > input`) so the quantity stepper is visible and usable.

= 1.1.7 =
* Fixed the inline illustration quantity input being invisible: inside the narrow card the horizontal layout squeezed the number field to zero width. The label and input now stack vertically, with an explicit width and a visible border.

= 1.1.6 =
* Fixed hover/focus styling: tabs, stepper chips, segmented toggles and bundle cards are all <button> elements and were inheriting the host theme's dark button:hover/:focus, which turned bundle cards navy and made their feature text unreadable. Every interactive element now has its own explicit sage-brand hover/focus state so the theme can't bleed through. Option/bundle card hover borders now use the brand sage instead of a cool grey.

= 1.1.5 =
* The "Number of illustrations / pages" stepper now appears inline inside the selected per-piece illustration card (Spot / Full-page) instead of in a separate box below the cards — clearer context, no page scroll. It hides for the flat-price "Complete picture book", and the value stays in sync if you switch between the two per-piece options.

= 1.1.4 =
* Corrected the brand palette to the actual authorwings.com theme colours: warm cream base (#F6F1E8), deep navy text (#1C2439) and sage-green accent (#5C7A6B) — the previous blue came from WordPress block defaults, not the site theme. Sage now drives buttons, selected states, the running total and the savings badge.

= 1.1.3 =
* Restyled to match authorwings.com — brand blue (#1863dc / #0056a7 hover), the site's text/border/background greys, and the site typography (Inter for body, Fraunces for headings). Brand fonts are enqueued by the plugin so the calculator looks consistent on any theme.

= 1.1.2 =
* Design step (Cover / Interior formatting / Illustration) and the three Add-on groups are now collapsible accordions, so the two longest steps are much shorter. Collapsed headers show the current pick (Design) or a "N selected" badge (Add-ons). Cover stays open by default; add-on groups start collapsed.

= 1.1.1 =
* Ghostwriting step now has a "Standard book / Children's & illustrated" toggle so the children's tiers no longer sit alongside (and visually duplicate) the standard Starter/Growth/Authority cards. Switching book type clears the prior pick; the choice is saved with the shareable estimate.

= 1.1.0 =
* Mobile sticky total bar so the running total and CTA stay in view on phones.
* Build is now saved to the URL + browser session (survives refresh) and can be shared with a "Copy estimate link" button.
* "Download / Print" button with a clean estimate-only print/PDF layout.
* Gutenberg block now has editor controls (title, subtitle, quote-form toggle) with a live preview.
* Shareable estimate link included in the notification emails.
* Children's ghostwriting split into three real tiers (Starter / Growth / Authority) matching the published pricing.

= 1.0.0 =
* Initial release.
