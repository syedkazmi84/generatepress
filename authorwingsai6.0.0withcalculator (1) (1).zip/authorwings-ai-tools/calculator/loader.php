<?php
/**
 * AuthorWings AI — embedded Pricing Calculator module.
 *
 * This folder bundles the standalone "AuthorWings Pricing Calculator" plugin so
 * the AI-tools plugin can ship the interactive book-cost calculator with no
 * second plugin required. The calculator's classes are used verbatim (the
 * AWPC_* namespace-free classes, its shortcodes, block, widget, submissions and
 * share endpoints); only the plugin bootstrap is re-implemented here so the
 * module can load itself, coexist with the standalone plugin, and be toggled
 * from AuthorWings AI → Settings.
 *
 * What it boots: the [authorwings_calculator], [authorwings_calculator_button]
 * and [authorwings_calculator_modal] shortcodes, the "AuthorWings Calculator"
 * block/widget, the estimate-submission + e-mail + share-link engine, and the
 * Calculator / Submissions admin screens.
 *
 * Coexistence: if the original standalone calculator plugin is still active it
 * declares the AWPC_* classes first, so this module stays completely dormant and
 * lets that plugin own everything — no "class already declared" crash. You can
 * install this build first and deactivate the old plugin afterwards. Once the
 * standalone plugin is gone this module takes over using the SAME database
 * tables (awpc_submissions / awpc_shares) and the SAME options, so existing
 * estimate submissions, share links and settings keep working untouched.
 *
 * Master switch: stored in its own option (awg_aig_calc_enabled) so it can be
 * read cheaply at boot. Defaults to ON when never saved. When OFF the module
 * stays fully dormant: no shortcodes, block, widget, admin screens or cron —
 * exactly as if this folder were absent.
 *
 * @package AuthorWings AI
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether the bundled calculator should load at all.
 *
 * The standalone plugin requires its classes at include time (before
 * plugins_loaded fires), so if AWPC_Calculator already exists the standalone
 * plugin is active and owns everything — we must stay dormant.
 */
if ( ! function_exists( 'awg_aig_calc_should_load' ) ) {
	function awg_aig_calc_should_load(): bool {
		return ! class_exists( 'AWPC_Calculator', false );
	}
}

/**
 * Master on/off switch for the whole calculator module. Only an explicit "0"
 * disables it; unset / "1" mean enabled, so existing installs keep the
 * calculator until an admin turns it off from AuthorWings AI → Settings.
 */
if ( ! function_exists( 'awg_aig_calc_is_enabled' ) ) {
	function awg_aig_calc_is_enabled(): bool {
		return '0' !== (string) get_option( 'awg_aig_calc_enabled', '1' );
	}
}

/**
 * Idempotently define the AWPC_* constants and require the calculator classes.
 * Safe to call more than once. Only ever runs when the standalone plugin is
 * absent, so it can never clash with that plugin's own constants / classes.
 */
if ( ! function_exists( 'awg_aig_calc_load_engine' ) ) {
	function awg_aig_calc_load_engine(): void {
		if ( ! awg_aig_calc_should_load() ) {
			return;
		}

		if ( ! defined( 'AWPC_VERSION' ) ) {
			define( 'AWPC_VERSION', '1.9.17-bundled' );
			define( 'AWPC_PLUGIN_FILE', __FILE__ );
			define( 'AWPC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
			define( 'AWPC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
		}

		$dir     = AWPC_PLUGIN_DIR . 'includes/';
		$classes = [
			'AWPC_Pricing_Data'      => 'class-awpc-pricing-data.php',
			'AWPC_Calculator'        => 'class-awpc-calculator.php',
			'AWPC_Mailer'            => 'class-awpc-mailer.php',
			'AWPC_Email_Template'    => 'class-awpc-email-template.php',
			'AWPC_Submissions'       => 'class-awpc-submissions.php',
			'AWPC_Share'             => 'class-awpc-share.php',
			'AWPC_Admin'             => 'class-awpc-admin.php',
			'AWPC_Submissions_Admin' => 'class-awpc-submissions-admin.php',
			'AWPC_Ajax'              => 'class-awpc-ajax.php',
		];
		foreach ( $classes as $class => $file ) {
			if ( ! class_exists( $class, false ) ) {
				require_once $dir . $file;
			}
		}
	}
}

/**
 * Boot the calculator module on plugins_loaded (priority 20, i.e. after the
 * standalone plugin's own boot at the default priority 10, so the dormancy
 * check above sees its classes if it is active).
 */
if ( ! function_exists( 'awg_aig_calc_boot' ) ) {
	function awg_aig_calc_boot(): void {
		if ( ! awg_aig_calc_should_load() ) {
			return; // Standalone calculator plugin owns everything.
		}

		// Register the master switch option even when the module is OFF, so an
		// admin can always re-enable it from AuthorWings AI → Settings.
		add_action( 'admin_init', 'awg_aig_calc_register_master_setting' );

		if ( ! awg_aig_calc_is_enabled() ) {
			return; // Kept fully dormant by the admin's master switch.
		}

		awg_aig_calc_load_engine();

		// Nest the calculator's admin screens (Pricing Calculator + Leads) under
		// the AuthorWings AI top-level menu instead of adding a separate
		// top-level "AuthorWings Calculator" menu. The calculator's admin
		// classes read this filter (default '' = its own top-level menu, which
		// the standalone plugin keeps).
		add_filter( 'awpc_admin_parent_slug', static function () {
			return 'edit.php?post_type=awg_ai_template';
		} );

		// Self-heal the tables after a plugin update (the activation hook only
		// fires on a fresh activate/reactivate). Cheap autoloaded-option reads,
		// so this is safe on the front end too, where estimates submit via AJAX.
		AWPC_Submissions::maybe_install();
		AWPC_Share::maybe_install();
		AWPC_Share::ensure_schedule(); // Idempotent — covers pre-existing installs.

		new AWPC_Calculator();
		new AWPC_Mailer(); // Runs on the front end too — estimate emails send via AJAX.
		new AWPC_Ajax();
		new AWPC_Share();  // Short shareable-link endpoints (front end too).

		if ( is_admin() ) {
			new AWPC_Admin();
			new AWPC_Submissions_Admin();
		}
	}
}
add_action( 'plugins_loaded', 'awg_aig_calc_boot', 20 );

/**
 * Load the calculator's translations from the bundled module folder. Keeps the
 * original 'authorwings-calculator' text domain so existing .mo files drop in.
 */
if ( ! function_exists( 'awg_aig_calc_load_textdomain' ) ) {
	function awg_aig_calc_load_textdomain(): void {
		if ( ! awg_aig_calc_should_load() || ! awg_aig_calc_is_enabled() ) {
			return;
		}
		load_plugin_textdomain(
			'authorwings-calculator',
			false,
			dirname( plugin_basename( AWG_AIG_FILE ) ) . '/calculator/languages'
		);
	}
}
add_action( 'init', 'awg_aig_calc_load_textdomain' );

/**
 * Register the master on/off option (awg_aig_calc_enabled) and its sanitizer in
 * its own settings group, independent of the AI and Membership settings forms.
 */
if ( ! function_exists( 'awg_aig_calc_register_master_setting' ) ) {
	function awg_aig_calc_register_master_setting(): void {
		register_setting( 'awg_aig_calc_master_group', 'awg_aig_calc_enabled', [
			'type'              => 'string',
			'sanitize_callback' => static function ( $v ) {
				return ! empty( $v ) ? '1' : '0';
			},
			'default'           => '1',
		] );
	}
}

/**
 * Render the master Calculator on/off toggle.
 *
 * Called from the AuthorWings AI → Settings "AI Settings" tab (always visible)
 * so it stays reachable whether the calculator is currently on or off. A hidden
 * field guarantees a "0" is submitted when the box is unchecked.
 */
if ( ! function_exists( 'awg_aig_calc_render_master_toggle' ) ) {
	function awg_aig_calc_render_master_toggle(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$enabled = awg_aig_calc_is_enabled();
		?>
		<div class="awg-section" style="border:1px solid #dcdcde;border-radius:6px;padding:12px 16px;margin:0 0 16px;background:#fff;">
			<form method="post" action="options.php" style="margin:0;">
				<?php settings_fields( 'awg_aig_calc_master_group' ); ?>
				<h2 style="margin:0 0 6px;font-size:14px;"><?php esc_html_e( 'Pricing Calculator', 'authorwings-ai-tools' ); ?></h2>
				<input type="hidden" name="awg_aig_calc_enabled" value="0" />
				<label style="display:inline-flex;align-items:center;gap:8px;">
					<input type="checkbox" name="awg_aig_calc_enabled" value="1" <?php checked( $enabled ); ?> />
					<strong><?php esc_html_e( 'Enable pricing calculator', 'authorwings-ai-tools' ); ?></strong>
				</label>
				<p class="description" style="margin:8px 0 12px;max-width:760px;">
					<?php esc_html_e( 'When enabled, the book-cost calculator turns on: the [authorwings_calculator], [authorwings_calculator_button] and [authorwings_calculator_modal] shortcodes, the "AuthorWings Calculator" block and widget, the estimate submission / e-mail / share-link engine, and the Calculator and Submissions admin screens. When disabled, every calculator feature is hidden — exactly as if the module were not installed. If the standalone AuthorWings Pricing Calculator plugin is active, this bundled copy stays dormant and that plugin owns everything.', 'authorwings-ai-tools' ); ?>
				</p>
				<?php submit_button( __( 'Save Calculator Status', 'authorwings-ai-tools' ), 'primary', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}
}

/**
 * Activation: create the calculator tables and schedule its maintenance cron.
 * Wired from the main plugin file's register_activation_hook. Stays dormant if
 * the standalone plugin owns the classes.
 */
if ( ! function_exists( 'awg_aig_calc_activate' ) ) {
	function awg_aig_calc_activate(): void {
		if ( ! awg_aig_calc_should_load() ) {
			return;
		}
		awg_aig_calc_load_engine();
		AWPC_Submissions::install();
		AWPC_Share::install();
		AWPC_Share::ensure_schedule();
	}
}

