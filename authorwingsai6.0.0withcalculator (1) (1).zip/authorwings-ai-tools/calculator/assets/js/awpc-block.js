/**
 * AuthorWings Calculator — Gutenberg block.
 *
 * No build step: this uses the wp.* globals already present in the block
 * editor (wp.element.createElement instead of JSX) and ServerSideRender for a
 * live preview of the real front-end markup.
 */
( function ( wp ) {
	'use strict';

	if ( ! wp || ! wp.blocks || ! wp.element ) {
		return;
	}

	var el                = wp.element.createElement;
	var Fragment          = wp.element.Fragment;
	var __                = ( wp.i18n && wp.i18n.__ ) || function ( s ) { return s; };
	var InspectorControls = wp.blockEditor && wp.blockEditor.InspectorControls;
	var PanelBody         = wp.components && wp.components.PanelBody;
	var TextControl       = wp.components && wp.components.TextControl;
	var ToggleControl     = wp.components && wp.components.ToggleControl;
	var ServerSideRender  = wp.serverSideRender;

	// If the server-registered block was already hydrated into the editor, drop
	// it first so our edit() (with the inspector controls) takes effect.
	if ( wp.blocks.getBlockType && wp.blocks.getBlockType( 'authorwings/calculator' ) ) {
		wp.blocks.unregisterBlockType( 'authorwings/calculator' );
	}

	wp.blocks.registerBlockType( 'authorwings/calculator', {
		title:    __( 'AuthorWings Calculator', 'authorwings-calculator' ),
		icon:     'calculator',
		category: 'widgets',
		keywords: [ __( 'calculator', 'authorwings-calculator' ), __( 'pricing', 'authorwings-calculator' ), __( 'quote', 'authorwings-calculator' ) ],
		attributes: {
			title:      { type: 'string', default: '' },
			subtitle:   { type: 'string', default: '' },
			show_quote: { type: 'boolean', default: true }
		},

		edit: function ( props ) {
			var a = props.attributes;

			var inspector = InspectorControls && el(
				InspectorControls,
				{},
				el(
					PanelBody,
					{ title: __( 'Calculator settings', 'authorwings-calculator' ), initialOpen: true },
					el( TextControl, {
						label: __( 'Title', 'authorwings-calculator' ),
						value: a.title,
						placeholder: __( 'Book Cost Calculator', 'authorwings-calculator' ),
						onChange: function ( v ) { props.setAttributes( { title: v } ); }
					} ),
					el( TextControl, {
						label: __( 'Subtitle', 'authorwings-calculator' ),
						value: a.subtitle,
						placeholder: __( 'Estimate your project within ~10–15% of a final quote.', 'authorwings-calculator' ),
						onChange: function ( v ) { props.setAttributes( { subtitle: v } ); }
					} ),
					el( ToggleControl, {
						label: __( 'Show “Email me this estimate” form', 'authorwings-calculator' ),
						checked: !! a.show_quote,
						onChange: function ( v ) { props.setAttributes( { show_quote: v } ); }
					} )
				)
			);

			var preview = ServerSideRender
				? el( ServerSideRender, { block: 'authorwings/calculator', attributes: a } )
				: el( 'p', {}, __( 'AuthorWings Calculator', 'authorwings-calculator' ) );

			return el( Fragment, {}, inspector, preview );
		},

		// Dynamic block: rendered server-side via render_callback.
		save: function () { return null; }
	} );
} )( window.wp );
