/**
 * AuthorWings Pricing Calculator — front-end logic.
 *
 * All pricing comes from AWPC_DATA.pricing (localized from PHP), so there is a
 * single source of truth shared with the server and admin screens.
 */
( function () {
	'use strict';

	if ( typeof AWPC_DATA === 'undefined' ) {
		return;
	}

	var PRICING = AWPC_DATA.pricing;
	var SYMBOL = ( PRICING.currency && PRICING.currency.symbol ) || '$';

	// When a Forminator form is configured in the settings, the "Email me this
	// estimate" button opens that form in a popup instead of the built-in
	// inline email form.
	var FORMINATOR = !! AWPC_DATA.forminatorEstimate;

	// Services that a rush surcharge applies to.
	var RUSH_SERVICES = [ 'ghostwriting', 'editing', 'cover', 'interior', 'publishing' ];

	// Which groups are relevant at each stage.
	var STAGE_GROUPS = {
		idea: [ 'ghostwriting', 'design', 'publishing', 'marketing', 'coaching', 'addons' ],
		draft: [ 'editing', 'design', 'publishing', 'marketing', 'coaching', 'addons' ],
		finished: [ 'design', 'publishing', 'marketing', 'coaching', 'addons' ]
	};

	// Ordered wizard steps shown for each stage.
	var STAGE_STEPS = {
		idea: [ 'basics', 'writing', 'design', 'publishing', 'marketing', 'coaching', 'addons', 'review' ],
		draft: [ 'basics', 'editing', 'design', 'publishing', 'marketing', 'coaching', 'addons', 'review' ],
		finished: [ 'basics', 'design', 'publishing', 'marketing', 'coaching', 'addons', 'review' ]
	};

	var STEP_TITLES = {
		basics: 'Project',
		writing: 'Writing',
		editing: 'Editing',
		design: 'Design',
		publishing: 'Publishing',
		marketing: 'Marketing',
		coaching: 'Coaching',
		addons: 'Add-ons',
		review: 'Review'
	};

	function money( amount ) {
		var n = Math.round( Number( amount ) || 0 );
		return SYMBOL + n.toLocaleString( 'en-US' );
	}

	function escapeHtml( str ) {
		return String( str ).replace( /[&<>"']/g, function ( c ) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ c ];
		} );
	}

	/**
	 * Compute an editing tier price for a given word count.
	 */
	function editingPrice( tierKey, words ) {
		var tier = PRICING.editing[ tierKey ];
		if ( ! tier ) {
			return 0;
		}
		var byRate = ( tier.rate || 0 ) * words;
		return Math.max( tier.min || 0, byRate );
	}

	/**
	 * Compute an individual (à la carte) editing service price:
	 * base price covers the word allowance, then the marginal rate applies beyond it.
	 */
	function indivEditPrice( key, words ) {
		var s = PRICING.editing_individual && PRICING.editing_individual[ key ];
		if ( ! s ) {
			return 0;
		}
		var allowance = s.words || 0;
		var beyond = Math.max( 0, words - allowance );
		return ( s.base || 0 ) + beyond * ( s.rate || 0 );
	}

	/**
	 * Initialise a single calculator instance.
	 */
	function initCalculator( root ) {
		var showQuote = root.getAttribute( 'data-show-quote' ) === '1';

		// Most recent computed estimate, reused by the PDF / print receipt.
		var lastResult = null;

		// intl-tel-input instance for the built-in form's phone field (if used).
		var itiInstance = null;

		// Timer that auto-dismisses the success confirmation panel.
		var successCloseTimer = null;

		// Hide the confirmation panel and let the visitor reopen the form.
		function hideSuccess( panel ) {
			panel = panel || root.querySelector( '[data-out="form-success"]' );
			if ( panel ) {
				panel.hidden = true;
			}
			if ( successCloseTimer ) {
				window.clearTimeout( successCloseTimer );
				successCloseTimer = null;
			}
			var reopen = root.querySelector( '[data-action="open-quote"]' );
			if ( reopen ) {
				reopen.hidden = false;
			}
		}

		var state = {
			mode: 'build', // 'build' | 'bundles'
			step: 'basics',
			stage: 'idea',
			words: 40000,
			illusQty: 1,
			editMode: 'package', // 'package' | 'individual'
			bookType: 'standard', // 'standard' | 'childrens'
			editServices: {},
			rush: false,
			selections: {
				ghostwriting: 'none',
				editing: 'none',
				cover: 'none',
				interior: 'none',
				illustration: 'none',
				publishing: 'none',
				marketing: 'none',
				coaching: 'none'
			},
			addons: {},
			bundle: null // { key, label, price, saves }
		};

		var els = {
			tabs: root.querySelectorAll( '.awpc-tab' ),
			panels: root.querySelectorAll( '.awpc-panel' ),
			stageBtns: root.querySelectorAll( '[data-control="stage"] .awpc-seg' ),
			editModeBtns: root.querySelectorAll( '[data-control="editmode"] .awpc-seg' ),
			editModePanels: root.querySelectorAll( '[data-editmode-panel]' ),
			bookTypeBtns: root.querySelectorAll( '[data-control="booktype"] .awpc-seg' ),
			bookTypePanels: root.querySelectorAll( '[data-booktype-panel]' ),
			wordsRange: root.querySelector( '[data-input="words"]' ),
			wordsOut: root.querySelector( '[data-out="words"]' ),
			illusQtyInputs: root.querySelectorAll( '.awpc-illus-qty' ),
			rush: root.querySelector( '[data-input="rush"]' ),
			groups: root.querySelectorAll( '.awpc-group[data-group]' ),
			steps: root.querySelectorAll( '.awpc-step' ),
			stepper: root.querySelector( '[data-out="stepper"]' ),
			stepCount: root.querySelector( '[data-out="step-count"]' ),
			navBack: root.querySelector( '[data-nav="back"]' ),
			navNext: root.querySelector( '[data-nav="next"]' ),
			linesReview: root.querySelector( '[data-out="lines-review"]' ),
			lines: root.querySelector( '[data-out="lines"]' ),
			total: root.querySelector( '[data-out="total"]' ),
			savings: root.querySelector( '[data-out="savings"]' ),
			rushNote: root.querySelector( '[data-out="rush-note"]' ),
			plan: root.querySelector( '[data-out="plan"]' ),
			bundleCards: root.querySelectorAll( '[data-bundle]' ),
			reset: root.querySelector( '[data-action="reset"]' ),
			totalMobile: root.querySelector( '[data-out="total-mobile"]' )
		};

		// Persistence guard: stays false until the first paint completes so the
		// initial render never overwrites an incoming shared link.
		var ready = false;

		/* ---------- Shared setters (used by handlers and by state restore) ---------- */
		function setMode( target ) {
			state.mode = target;
			els.tabs.forEach( function ( t ) {
				var active = t.getAttribute( 'data-tab' ) === target;
				t.classList.toggle( 'is-active', active );
				t.setAttribute( 'aria-selected', active ? 'true' : 'false' );
			} );
			els.panels.forEach( function ( p ) {
				p.classList.toggle( 'is-active', p.getAttribute( 'data-panel' ) === target );
			} );
		}

		function setStage( stage ) {
			state.stage = stage;
			els.stageBtns.forEach( function ( b ) {
				b.classList.toggle( 'is-active', b.getAttribute( 'data-stage' ) === stage );
			} );
			applyStageVisibility();
		}

		function setEditMode( mode ) {
			state.editMode = mode;
			els.editModeBtns.forEach( function ( b ) {
				b.classList.toggle( 'is-active', b.getAttribute( 'data-editmode' ) === mode );
			} );
			els.editModePanels.forEach( function ( p ) {
				p.hidden = ( p.getAttribute( 'data-editmode-panel' ) !== mode );
			} );
		}

		// Show the standard or children's ghostwriting cards (UI only — does not
		// touch the current selection, so it is safe to call during state restore).
		function showBookTypePanel( type ) {
			state.bookType = type;
			els.bookTypeBtns.forEach( function ( b ) {
				b.classList.toggle( 'is-active', b.getAttribute( 'data-booktype' ) === type );
			} );
			els.bookTypePanels.forEach( function ( p ) {
				p.hidden = ( p.getAttribute( 'data-booktype-panel' ) !== type );
			} );
		}

		/* ---------- Tabs ---------- */
		els.tabs.forEach( function ( tab ) {
			tab.addEventListener( 'click', function () {
				var target = tab.getAttribute( 'data-tab' );
				setMode( target );
				if ( 'build' === target ) {
					state.bundle = null;
					els.bundleCards.forEach( function ( c ) {
						c.classList.remove( 'is-selected' );
					} );
				}
				render();
			} );
		} );

		/* ---------- Steps (wizard) ---------- */
		function visibleSteps() {
			return STAGE_STEPS[ state.stage ] || STAGE_STEPS.idea;
		}

		function showStep( key ) {
			var steps = visibleSteps();
			if ( steps.indexOf( key ) === -1 ) {
				key = steps[ 0 ];
			}
			state.step = key;
			els.steps.forEach( function ( s ) {
				s.classList.toggle( 'is-active', s.getAttribute( 'data-step' ) === key );
			} );
			renderStepper();
			updateNav();
		}

		function renderStepper() {
			if ( ! els.stepper ) {
				return;
			}
			var steps = visibleSteps();
			var cur = steps.indexOf( state.step );
			var total = steps.length;
			var curTitle = escapeHtml( STEP_TITLES[ state.step ] || state.step );
			var togo = total - 1 - cur;

			function st( i ) {
				return i < cur ? 'is-done' : ( i === cur ? 'is-active' : 'is-future' );
			}
			function title( i ) {
				return escapeHtml( STEP_TITLES[ steps[ i ] ] || steps[ i ] );
			}

			// FULL (desktop): connected numbered nodes + labels.
			var full = '<div class="awpc-sp-full">' + steps.map( function ( key, i ) {
				return '<button type="button" class="awpc-sp-node ' + st( i ) + '" data-goto="' + key + '">' +
					'<span class="awpc-sp-n">' + ( i < cur ? '&#10003;' : ( i + 1 ) ) + '</span>' +
					'<span class="awpc-sp-lab">' + title( i ) + '</span></button>';
			} ).join( '' ) + '</div>';

			// MID (tablet): done checks + current pill + "N to go".
			var mid = '';
			for ( var i = 0; i < cur; i++ ) {
				mid += '<button type="button" class="awpc-sp-check is-done" data-goto="' + steps[ i ] + '" aria-label="' + title( i ) + '"><span class="awpc-sp-n">&#10003;</span></button>';
			}
			mid += '<span class="awpc-sp-active"><span class="awpc-sp-n">' + ( cur + 1 ) + '</span>' + curTitle + '</span>';
			if ( togo > 0 ) {
				mid += '<span class="awpc-sp-ar">›</span><span class="awpc-sp-togo">' + togo + ( 1 === togo ? ' step to go' : ' steps to go' ) + '</span>';
			}
			mid = '<div class="awpc-sp-mid">' + mid + '</div>';

			// MINI (mobile): dots + ‹ current › with prev/next.
			var dots = steps.map( function ( key, i ) {
				return '<button type="button" class="awpc-sp-dot ' + st( i ) + '" data-goto="' + key + '" aria-label="Step ' + ( i + 1 ) + '"></button>';
			} ).join( '' );
			var mini = '<div class="awpc-sp-mini"><div class="awpc-sp-dots">' + dots + '</div>' +
				'<div class="awpc-sp-carrow">' +
					'<button type="button" class="awpc-sp-arrow" data-nav="back" aria-label="Previous step"' + ( cur <= 0 ? ' disabled' : '' ) + '>‹</button>' +
					'<span class="awpc-sp-cur">' + curTitle + '<small>Step ' + ( cur + 1 ) + ' of ' + total + '</small></span>' +
					'<button type="button" class="awpc-sp-arrow" data-nav="next" aria-label="Next step"' + ( cur >= total - 1 ? ' disabled' : '' ) + '>›</button>' +
				'</div></div>';

			els.stepper.innerHTML = full + mid + mini;

			els.stepper.querySelectorAll( '[data-goto]' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					showStep( btn.getAttribute( 'data-goto' ) );
				} );
			} );
			els.stepper.querySelectorAll( '[data-nav]' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					moveStep( 'next' === btn.getAttribute( 'data-nav' ) ? 1 : -1 );
				} );
			} );
		}

		function updateNav() {
			var steps = visibleSteps();
			var idx = steps.indexOf( state.step );
			if ( els.navBack ) {
				els.navBack.disabled = idx <= 0;
			}
			if ( els.navNext ) {
				var last = idx >= steps.length - 1;
				els.navNext.disabled = last;
				els.navNext.style.visibility = last ? 'hidden' : 'visible';
			}
			if ( els.stepCount ) {
				els.stepCount.textContent = 'Step ' + ( idx + 1 ) + ' of ' + steps.length;
			}
		}

		function moveStep( delta ) {
			var steps = visibleSteps();
			var idx = steps.indexOf( state.step ) + delta;
			if ( idx >= 0 && idx < steps.length ) {
				showStep( steps[ idx ] );
				// Scroll the calculator into view on navigation.
				if ( root.scrollIntoView ) {
					root.scrollIntoView( { behavior: 'smooth', block: 'start' } );
				}
			}
		}

		if ( els.navBack ) {
			els.navBack.addEventListener( 'click', function () {
				moveStep( -1 );
			} );
		}
		if ( els.navNext ) {
			els.navNext.addEventListener( 'click', function () {
				moveStep( 1 );
			} );
		}

		/* ---------- Stage ---------- */
		els.stageBtns.forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				setStage( btn.getAttribute( 'data-stage' ) );
				showStep( state.step ); // refresh stepper for the new stage
				render();
			} );
		} );

		function applyStageVisibility() {
			var allowed = STAGE_GROUPS[ state.stage ] || [];
			els.groups.forEach( function ( group ) {
				var name = group.getAttribute( 'data-group' );
				var show = allowed.indexOf( name ) !== -1;
				group.hidden = ! show;
				if ( ! show ) {
					// Reset selections inside hidden groups.
					if ( 'ghostwriting' === name ) {
						setRadio( 'ghostwriting', 'none' );
					}
					if ( 'editing' === name ) {
						setRadio( 'editing', 'none' );
					}
				}
			} );

			// Manuscript length on the basics step is only relevant when editing is
			// in play, i.e. the "draft" stage. Elsewhere it surfaces inline beside
			// the (per-word) Translation add-on instead.
			var wordsField = root.querySelector( '[data-words-field]' );
			if ( wordsField ) {
				wordsField.hidden = ( 'draft' !== state.stage );
			}
		}

		function setRadio( control, value ) {
			state.selections[ control ] = value;
			var inputs = root.querySelectorAll( 'input[name="' + control + '"]' );
			inputs.forEach( function ( input ) {
				var match = input.value === value;
				input.checked = match;
				var card = input.closest( '.awpc-card' );
				if ( card ) {
					card.classList.toggle( 'is-selected', match );
				}
			} );
		}

		/* ---------- Words (slider on basics + inline input beside Translation) ---------- */
		// Single source of truth: every word control updates state.words and syncs
		// the others (skipping whichever the user is actively typing in).
		function setWords( value, sourceEl ) {
			var val = parseInt( value, 10 );
			if ( isNaN( val ) ) {
				val = 0;
			}
			val = Math.max( 2000, Math.min( 120000, val ) );
			state.words = val;
			if ( els.wordsRange && els.wordsRange !== sourceEl ) {
				els.wordsRange.value = val;
			}
			if ( els.wordsOut ) {
				els.wordsOut.textContent = val.toLocaleString( 'en-US' );
			}
			root.querySelectorAll( '.awpc-words-input' ).forEach( function ( wi ) {
				if ( wi !== sourceEl ) {
					wi.value = val;
				}
			} );
			render();
		}

		if ( els.wordsRange ) {
			els.wordsRange.addEventListener( 'input', function () {
				setWords( els.wordsRange.value, els.wordsRange );
			} );
		}

		root.querySelectorAll( '.awpc-words-input' ).forEach( function ( wi ) {
			wi.addEventListener( 'click', function ( e ) {
				e.stopPropagation(); // don't toggle the add-on checkbox
			} );
			wi.addEventListener( 'input', function () {
				setWords( wi.value, wi );
			} );
			wi.addEventListener( 'change', function () {
				wi.value = state.words; // snap to the clamped value on blur
			} );
		} );

		/* ---------- Rush ---------- */
		if ( els.rush ) {
			els.rush.addEventListener( 'change', function () {
				state.rush = els.rush.checked;
				render();
			} );
		}

		/* ---------- Radio cards ---------- */
		// After a package is picked, gently move the visitor forward: to the next
		// collapsible section in the same step (e.g. Cover → Interior Formatting),
		// or to the step's Next button when this was the last / only section.
		function autoAdvance( input ) {
			if ( ! input || ! input.closest ) { return; }
			var acc = input.closest( '.awpc-acc' );
			var nextAcc = null;
			if ( acc ) {
				var sib = acc.nextElementSibling;
				while ( sib ) {
					if ( sib.classList && sib.classList.contains( 'awpc-acc' ) && ! sib.hidden ) {
						nextAcc = sib;
						break;
					}
					sib = sib.nextElementSibling;
				}
			}
			var target = null;
			var block  = 'center';
			if ( nextAcc ) {
				if ( 'open' in nextAcc ) { nextAcc.open = true; } // reveal its options
				target = nextAcc;
				block  = 'start';
			} else if ( els.navNext && ! els.navNext.disabled && 'hidden' !== els.navNext.style.visibility ) {
				target = els.navNext;
			}
			if ( target && target.scrollIntoView ) {
				// Defer a frame so the re-render / accordion open settles first.
				window.requestAnimationFrame( function () {
					target.scrollIntoView( { behavior: 'smooth', block: block } );
				} );
			}
		}

		root.querySelectorAll( '.awpc-options input[type="radio"]' ).forEach( function ( input ) {
			input.addEventListener( 'change', function () {
				setRadio( input.name, input.value );
				render();
				autoAdvance( input );
			} );
		} );

		/* ---------- Editing mode (package vs individual) ---------- */
		els.editModeBtns.forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				setEditMode( btn.getAttribute( 'data-editmode' ) );
				render();
			} );
		} );

		/* ---------- Book type (standard vs children's ghostwriting) ---------- */
		els.bookTypeBtns.forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				showBookTypePanel( btn.getAttribute( 'data-booktype' ) );
				setRadio( 'ghostwriting', 'none' ); // switching book type clears the prior pick
				render();
			} );
		} );

		root.querySelectorAll( '[data-editservice]' ).forEach( function ( cb ) {
			cb.addEventListener( 'change', function () {
				var key = cb.getAttribute( 'data-editservice' );
				if ( cb.checked ) {
					state.editServices[ key ] = true;
				} else {
					delete state.editServices[ key ];
				}
				var card = cb.closest( '.awpc-card' );
				if ( card ) {
					card.classList.toggle( 'is-selected', cb.checked );
				}
				render();
			} );
		} );

		/* ---------- Add-ons ---------- */
		function addonQtyInput( key ) {
			return root.querySelector( '.awpc-addon-qty[data-qty="' + key + '"]' );
		}

		root.querySelectorAll( '[data-addon]' ).forEach( function ( cb ) {
			cb.addEventListener( 'change', function () {
				var key = cb.getAttribute( 'data-addon' );
				if ( cb.checked ) {
					var qi = addonQtyInput( key );
					state.addons[ key ] = qi ? ( Math.max( 1, parseInt( qi.value, 10 ) || 1 ) ) : 1;
				} else {
					delete state.addons[ key ];
				}
				render();
			} );
		} );

		// Per-unit quantity steppers for add-ons (region, market, fair, format, language…).
		root.querySelectorAll( '.awpc-addon-qty' ).forEach( function ( qi ) {
			qi.addEventListener( 'click', function ( e ) {
				e.stopPropagation(); // don't toggle the checkbox
			} );
			qi.addEventListener( 'input', function () {
				var key = qi.getAttribute( 'data-qty' );
				var val = Math.max( 1, parseInt( qi.value, 10 ) || 1 );
				if ( Object.prototype.hasOwnProperty.call( state.addons, key ) ) {
					state.addons[ key ] = val;
				}
				render();
			} );
		} );

		// Illustration quantity (per-piece) — one stepper lives inside each
		// per-unit card; keep them in sync so the value persists if the visitor
		// switches between Spot and Full-page.
		els.illusQtyInputs.forEach( function ( qi ) {
			qi.addEventListener( 'click', function ( e ) {
				e.stopPropagation();
			} );
			qi.addEventListener( 'input', function () {
				var val = Math.max( 1, parseInt( qi.value, 10 ) || 1 );
				state.illusQty = val;
				els.illusQtyInputs.forEach( function ( other ) {
					if ( other !== qi ) {
						other.value = val;
					}
				} );
				render();
			} );
		} );

		/* ---------- Bundles ---------- */
		els.bundleCards.forEach( function ( card ) {
			card.addEventListener( 'click', function () {
				var key = card.getAttribute( 'data-bundle' );
				var already = state.bundle && state.bundle.key === key;
				els.bundleCards.forEach( function ( c ) {
					c.classList.remove( 'is-selected' );
				} );
				if ( already ) {
					state.bundle = null;
				} else {
					card.classList.add( 'is-selected' );
					state.bundle = {
						key: key,
						label: card.getAttribute( 'data-label' ),
						price: parseFloat( card.getAttribute( 'data-price' ) ) || 0,
						saves: parseFloat( card.getAttribute( 'data-saves' ) ) || 0
					};
				}
				render();
			} );
		} );

		/* ---------- Reset ---------- */
		if ( els.reset ) {
			els.reset.addEventListener( 'click', function () {
				state.stage = 'idea';
				state.words = 40000;
				state.illusQty = 1;
				state.editMode = 'package';
				state.bookType = 'standard';
				state.editServices = {};
				state.rush = false;
				state.bundle = null;
				Object.keys( state.selections ).forEach( function ( k ) {
					state.selections[ k ] = 'none';
				} );
				state.addons = {};

				els.stageBtns.forEach( function ( b ) {
					b.classList.toggle( 'is-active', b.getAttribute( 'data-stage' ) === 'idea' );
				} );
				if ( els.wordsRange ) {
					els.wordsRange.value = 40000;
				}
				if ( els.wordsOut ) {
					els.wordsOut.textContent = '40,000';
				}
				root.querySelectorAll( '.awpc-words-input' ).forEach( function ( wi ) {
					wi.value = 40000;
				} );
				if ( els.rush ) {
					els.rush.checked = false;
				}
				Object.keys( state.selections ).forEach( function ( c ) {
					setRadio( c, 'none' );
				} );
				root.querySelectorAll( '[data-addon]' ).forEach( function ( cb ) {
					cb.checked = false;
				} );
				root.querySelectorAll( '[data-editservice]' ).forEach( function ( cb ) {
					cb.checked = false;
					var c = cb.closest( '.awpc-card' );
					if ( c ) {
						c.classList.remove( 'is-selected' );
					}
				} );
				els.editModeBtns.forEach( function ( b ) {
					b.classList.toggle( 'is-active', b.getAttribute( 'data-editmode' ) === 'package' );
				} );
				els.editModePanels.forEach( function ( p ) {
					p.hidden = ( p.getAttribute( 'data-editmode-panel' ) !== 'package' );
				} );
				showBookTypePanel( 'standard' );
				root.querySelectorAll( '.awpc-addon-qty' ).forEach( function ( qi ) {
					qi.value = 1;
				} );
				els.illusQtyInputs.forEach( function ( qi ) {
					qi.value = 1;
				} );
				els.bundleCards.forEach( function ( c ) {
					c.classList.remove( 'is-selected' );
				} );
				state.step = 'basics';
				// Drop any saved/shared state and keep the URL clean after a reset.
				clearPersisted();
				ready = false;
				applyStageVisibility();
				showStep( 'basics' );
				render();
				ready = true;
			} );
		}

		/* ---------- Secondary actions: copy link, print, mobile CTA ---------- */
		var copyBtn = root.querySelector( '[data-action="copy-link"]' );
		if ( copyBtn ) {
			// Swap only the label text so the button's icon is preserved.
			var copyLabel = copyBtn.querySelector( '.awpc-tile-label' ) || copyBtn;
			copyBtn.addEventListener( 'click', function () {
				flushPersist(); // make sure the URL reflects the current build
				var done = function () {
					var orig = copyLabel.getAttribute( 'data-label' ) || copyLabel.textContent;
					copyLabel.setAttribute( 'data-label', orig );
					copyLabel.textContent = 'Link copied!';
					setTimeout( function () { copyLabel.textContent = orig; }, 1800 );
				};
				// Shorten the link first, then copy the tidy URL.
				currentShortUrl( function ( url ) {
					if ( navigator.clipboard && navigator.clipboard.writeText ) {
						navigator.clipboard.writeText( url ).then( done, function () { fallbackCopy( url ); done(); } );
					} else {
						fallbackCopy( url );
						done();
					}
				} );
			} );
		}

		var printBtn = root.querySelector( '[data-action="print"]' );
		if ( printBtn ) {
			printBtn.addEventListener( 'click', function () {
				printEstimate();
			} );
		}

		/**
		 * Render just the estimate into an off-screen iframe and open the
		 * browser's print / "Save as PDF" dialog.
		 *
		 * The old behaviour called window.print() on the live page. A plugin's
		 * print stylesheet can only hide its own markup, not the host theme's
		 * header, menus, hero and footer, so printing produced many sheets with
		 * the estimate buried in the middle. Printing a self-contained iframe
		 * instead guarantees a single, clean page on any theme.
		 */
		function printEstimate() {
			var result = lastResult || computeLineItems();
			if ( ! result.items.length ) {
				return;
			}

			// This is an estimate document, not the calculator UI — use a proper
			// quote title rather than the calculator's on-page heading.
			var title = 'Your Book Cost Estimate';
			var site = ( ( typeof AWPC_DATA !== 'undefined' && AWPC_DATA.siteName ) || '' ).toString();
			var dateStr;
			try {
				dateStr = new Date().toLocaleDateString( undefined, { year: 'numeric', month: 'long', day: 'numeric' } );
			} catch ( e ) {
				dateStr = new Date().toDateString();
			}

			var brand = ( typeof AWPC_DATA !== 'undefined' && AWPC_DATA.brand ) || {};
			var brandName = ( brand.name || site || '' ).toString();
			var accent = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test( brand.accent || '' ) ? brand.accent : '#5c7a6b';
			var accentDark = darkenHex( accent, 18 );
			var year = ( new Date() ).getFullYear();

			var rows = result.items.map( function ( item ) {
				return '<tr><td class="awpc-r-line">' + escapeHtml( item.label ) +
					'</td><td class="awpc-r-amount">' + escapeHtml( money( item.amount ) ) + '</td></tr>';
			} ).join( '' );

			var savingsRow = result.saves ?
				'<tr class="awpc-r-savings"><td colspan="2">✓ ' + escapeHtml( 'You save ' + money( result.saves ) + ' vs. individual pricing' ) + '</td></tr>' : '';
			var planHtml = result.total > 0 ?
				'<p class="awpc-r-plan"><strong>Payment options:</strong> ' + escapeHtml( paymentPlan( result.total ) ) + '</p>' : '';
			var rushNoteHtml = ( result.rushAmount > 0 ) ?
				'<p class="awpc-r-rush">' + escapeHtml( rushExplanation( result.rushPct ) ) + '</p>' : '';

			var brandMark = brand.logo ?
				'<img src="' + escapeHtml( brand.logo ) + '" alt="' + escapeHtml( brandName ) + '" class="awpc-r-logo">' :
				'<span class="awpc-r-brand">' + escapeHtml( brandName ) + '</span>';
			var tagline = brand.tagline ?
				'<span class="awpc-r-tag">' + escapeHtml( brand.tagline ) + '</span>' : '';

			var footerLine = brand.footer ?
				'<p class="awpc-r-foot-line"><strong>' + escapeHtml( brandName ) + '</strong> — ' + escapeHtml( brand.footer ) + '</p>' : '';

			var doc = '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">' +
				'<meta name="viewport" content="width=device-width, initial-scale=1">' +
				'<title>' + escapeHtml( ( brandName ? brandName + ' — ' : '' ) + title ) + '</title>' +
				'<style>' + printStyles( accent, accentDark ) + '</style></head><body>' +
				'<div class="awpc-receipt">' +
				'<header class="awpc-r-head">' + brandMark + tagline + '</header>' +
				'<div class="awpc-r-body">' +
				'<h1 class="awpc-r-title">' + escapeHtml( title ) + '</h1>' +
				'<p class="awpc-r-meta">' + escapeHtml( 'Prepared ' + dateStr ) + '</p>' +
				'<table class="awpc-r-lines"><tbody>' +
				'<tr class="awpc-r-caption"><td colspan="2">Itemised breakdown</td></tr>' +
				rows +
				savingsRow +
				'<tr class="awpc-r-total"><td>Estimated total</td>' +
				'<td class="awpc-r-amount">' + escapeHtml( money( result.total ) ) + '</td></tr>' +
				'</tbody></table>' +
				planHtml +
				rushNoteHtml +
				'<p class="awpc-r-disclaimer">This is a guide estimate generated from the choices in the online calculator — flat, one-time fees, typically within ~10–15% of a final quote. It is not a binding contract.</p>' +
				'</div>' +
				'<footer class="awpc-r-footer">' + footerLine +
				'<p class="awpc-r-copy">© ' + escapeHtml( String( year ) ) + ' ' + escapeHtml( brandName ) + '. All rights reserved.</p>' +
				'</footer>' +
				'</div></body></html>';

			renderAndPrint( doc );
		}

		// Darken a #rrggbb / #rgb colour by a percentage (for the header gradient).
		function darkenHex( hex, pct ) {
			hex = String( hex || '' ).replace( '#', '' );
			if ( hex.length === 3 ) {
				hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
			}
			if ( ! /^[0-9a-fA-F]{6}$/.test( hex ) ) {
				return '#4a6459';
			}
			var f = Math.max( 0, Math.min( 100, pct ) ) / 100;
			var out = '#';
			for ( var i = 0; i < 3; i++ ) {
				var c = parseInt( hex.substr( i * 2, 2 ), 16 );
				c = Math.round( c * ( 1 - f ) );
				out += ( '0' + Math.max( 0, Math.min( 255, c ) ).toString( 16 ) ).slice( -2 );
			}
			return out;
		}

		function printStyles( accent, accentDark ) {
			return "@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Inter:wght@400;500;600&display=swap');" +
				'@page { size: A4 portrait; margin: 12mm; }' +
				'* { box-sizing: border-box; }' +
				'html, body { margin: 0; padding: 0; }' +
				'body { background: #f6f1e8; font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; color: #1c2439; -webkit-print-color-adjust: exact; print-color-adjust: exact; }' +
				'.awpc-receipt { max-width: 680px; margin: 0 auto; background: #fff; border: 1px solid #e7ddc9; border-radius: 14px; overflow: hidden; }' +
				'.awpc-r-head { padding: 26px 34px; color: #fff; background: ' + accent + '; background-image: linear-gradient(135deg, ' + accent + ' 0%, ' + accentDark + ' 100%); display: flex; align-items: center; justify-content: space-between; gap: 16px; }' +
				'.awpc-r-brand { font-family: "Fraunces", Georgia, "Times New Roman", serif; font-size: 24px; font-weight: 600; letter-spacing: .2px; }' +
				'.awpc-r-logo { height: 38px; max-height: 38px; width: auto; display: block; }' +
				'.awpc-r-tag { font-size: 11px; font-weight: 500; letter-spacing: 1.5px; text-transform: uppercase; color: #e6efe8; text-align: right; }' +
				'.awpc-r-body { padding: 30px 34px 6px; }' +
				'.awpc-r-title { font-family: "Fraunces", Georgia, serif; font-size: 23px; font-weight: 600; margin: 0 0 4px; color: #1c2439; }' +
				'.awpc-r-meta { color: #5d6675; font-size: 12px; margin: 0 0 22px; }' +
				'.awpc-r-lines { width: 100%; border-collapse: collapse; border: 1px solid #e7ddc9; border-radius: 12px; overflow: hidden; }' +
				'.awpc-r-lines td { padding: 11px 16px; border-bottom: 1px solid #f0ece2; font-size: 13px; line-height: 19px; vertical-align: top; color: #1c2439; }' +
				'.awpc-r-caption td { background: #f6f1e8; color: #5d6675; font-size: 11px; font-weight: 600; letter-spacing: 1.2px; text-transform: uppercase; }' +
				'.awpc-r-line { color: #1c2439; }' +
				'.awpc-r-amount { text-align: right; font-weight: 600; white-space: nowrap; }' +
				'.awpc-r-savings td { background: #eef5f0; color: #4a6459; font-weight: 600; font-size: 12px; }' +
				'.awpc-r-total td { background: #eaf3ec; color: #1c2439; font-family: "Fraunces", Georgia, serif; font-weight: 600; font-size: 15px; border-top: 2px solid #c3d8c9; border-bottom: none; }' +
				'.awpc-r-total .awpc-r-amount { font-size: 20px; color: ' + accentDark + '; }' +
				'.awpc-r-plan { color: #5d6675; font-size: 12px; margin: 14px 2px 0; }' +
				'.awpc-r-rush { color: #8a5a12; background: #fbf3e2; border-radius: 6px; font-size: 11px; line-height: 17px; margin: 12px 2px 0; padding: 8px 10px; }' +
				'.awpc-r-disclaimer { color: #7a8290; font-size: 11px; line-height: 17px; margin: 12px 2px 24px; }' +
				'.awpc-r-footer { border-top: 1px solid #e7ddc9; padding: 18px 34px 24px; }' +
				'.awpc-r-foot-line { margin: 0 0 4px; font-size: 13px; line-height: 20px; color: #5d6675; }' +
				'.awpc-r-foot-line strong { color: #1c2439; }' +
				'.awpc-r-copy { margin: 0; font-size: 11px; line-height: 17px; color: #7a8290; }';
		}

		/**
		 * Write the document into a throwaway iframe and print it. Falls back to
		 * a new window if the iframe document can't be accessed.
		 */
		function renderAndPrint( html ) {
			var prev = document.getElementById( 'awpc-print-frame' );
			if ( prev && prev.parentNode ) {
				prev.parentNode.removeChild( prev );
			}

			var frame = document.createElement( 'iframe' );
			frame.id = 'awpc-print-frame';
			frame.setAttribute( 'aria-hidden', 'true' );
			frame.style.position = 'fixed';
			frame.style.right = '0';
			frame.style.bottom = '0';
			frame.style.width = '0';
			frame.style.height = '0';
			frame.style.border = '0';
			frame.style.visibility = 'hidden';
			document.body.appendChild( frame );

			var frameDoc;
			try {
				frameDoc = frame.contentWindow.document;
			} catch ( e ) {
				frameDoc = null;
			}

			if ( ! frameDoc ) {
				if ( frame.parentNode ) {
					frame.parentNode.removeChild( frame );
				}
				var w = window.open( '', '_blank' );
				if ( w ) {
					w.document.write( html );
					w.document.close();
					w.focus();
					w.print();
				}
				return;
			}

			var printed = false;
			var triggerPrint = function () {
				if ( printed ) {
					return;
				}
				printed = true;
				var win = frame.contentWindow;
				try {
					win.focus();
					win.print();
				} catch ( e ) {}
				var cleanup = function () {
					if ( frame.parentNode ) {
						frame.parentNode.removeChild( frame );
					}
				};
				if ( 'onafterprint' in win ) {
					win.onafterprint = cleanup;
				}
				setTimeout( cleanup, 2000 );
			};

			frame.onload = triggerPrint;
			frameDoc.open();
			frameDoc.write( html );
			frameDoc.close();
			// Fallback in case the load event already fired before onload was set.
			setTimeout( triggerPrint, 600 );
		}

		var mobileQuote = root.querySelector( '[data-action="mobile-quote"]' );
		if ( mobileQuote ) {
			mobileQuote.addEventListener( 'click', function () {
				if ( ( root._awpcTotalNum || 0 ) <= 0 ) { return; }
				// With a Forminator form configured, open it in a popup instead
				// of revealing the built-in inline email form.
				if ( showQuote && FORMINATOR ) {
					estimateModal.open( mobileQuote, buildEstimateSummary() );
					return;
				}
				var summary = root.querySelector( '.awpc-summary' );
				if ( summary && summary.scrollIntoView ) {
					summary.scrollIntoView( { behavior: 'smooth', block: 'start' } );
				}
				if ( showQuote ) {
					var form = root.querySelector( '[data-form="quote"]' );
					if ( form ) {
						form.hidden = false;
						// Match the desktop flow: hide the standalone
						// "Email me this estimate" button so only the form's
						// "Send my estimate" button shows.
						var openQuoteBtn = root.querySelector( '[data-action="open-quote"]' );
						if ( openQuoteBtn ) {
							openQuoteBtn.hidden = true;
						}
						var emailInput = form.querySelector( '[data-field="email"]' );
						if ( emailInput ) {
							emailInput.focus();
						}
					}
				}
			} );
		}

		/* ---------- Quote form ---------- */
		if ( showQuote && FORMINATOR ) {
			// Forminator mode: the button just opens the configured form popup.
			var fOpenBtn = root.querySelector( '[data-action="open-quote"]' );
			if ( fOpenBtn ) {
				fOpenBtn.addEventListener( 'click', function () {
					if ( ( root._awpcTotalNum || 0 ) <= 0 ) { return; }
					estimateModal.open( fOpenBtn, buildEstimateSummary() );
				} );
			}
		} else if ( showQuote ) {
			var openBtn = root.querySelector( '[data-action="open-quote"]' );
			var form = root.querySelector( '[data-form="quote"]' );

			// Disable past dates on the "Preferred call date" picker — the
			// earliest selectable day is today. Set here (as well as in the
			// server-rendered markup) so a cached page still gets today's date.
			var dateField = form ? form.querySelector( '[data-field="date"]' ) : null;
			if ( dateField ) {
				var _now = new Date();
				var _pad = function ( n ) { return ( n < 10 ? '0' : '' ) + n; };
				dateField.min = _now.getFullYear() + '-' + _pad( _now.getMonth() + 1 ) + '-' + _pad( _now.getDate() );
			}

			// Upgrade the phone field to an international input with a country
			// flag + dial code (intl-tel-input), when the library is present.
			var phoneField = form ? form.querySelector( '[data-field="phone"]' ) : null;
			if ( phoneField && AWPC_DATA.phoneIntl && typeof window.intlTelInput === 'function' ) {
				try {
					itiInstance = window.intlTelInput( phoneField, {
						initialCountry: 'us',
						separateDialCode: true,
						preferredCountries: [ 'us', 'gb', 'ca', 'au' ],
						utilsScript: AWPC_DATA.itiUtils || undefined
					} );
				} catch ( e ) {
					itiInstance = null;
				}
			}

			if ( openBtn && form ) {
				openBtn.addEventListener( 'click', function () {
					if ( ( root._awpcTotalNum || 0 ) <= 0 ) { return; }
					form.hidden = false;
					// Hide the "Email me this estimate" button once the form is
					// revealed so only the form's own "Send my estimate" button
					// remains — one call to action instead of two.
					openBtn.hidden = true;
					var firstInput = form.querySelector( '[data-field="first_name"]' ) || form.querySelector( '[data-field="email"]' );
					if ( firstInput ) {
						firstInput.focus();
					}
				} );
				form.addEventListener( 'submit', function ( e ) {
					e.preventDefault();
					submitQuote( form );
				} );
			}

			// Dismiss the confirmation panel via its × button.
			var successPanelEl = root.querySelector( '[data-out="form-success"]' );
			if ( successPanelEl ) {
				successPanelEl.addEventListener( 'click', function ( e ) {
					if ( e.target && e.target.closest && e.target.closest( '[data-action="success-close"]' ) ) {
						hideSuccess( successPanelEl );
					}
				} );
			}
		}

		/* ---------- Compute & render ---------- */
		function computeLineItems() {
			var items = [];

			if ( 'bundles' === state.mode && state.bundle ) {
				items.push( { label: state.bundle.label, amount: state.bundle.price } );
				return { items: items, total: state.bundle.price, saves: state.bundle.saves };
			}

			var allowed = STAGE_GROUPS[ state.stage ] || [];
			var rushPct = Number( PRICING.rush_multiplier ) || 0;
			var rushBase = 0;

			// Line items are listed at their base (non-rush) price; the rush
			// surcharge is tallied separately and shown as its own line below, so
			// the quote spells out exactly what the surcharge costs.
			function track( service, amount ) {
				if ( state.rush && rushPct > 0 && RUSH_SERVICES.indexOf( service ) !== -1 ) {
					rushBase += amount;
				}
				return amount;
			}

			// Ghostwriting.
			if ( allowed.indexOf( 'ghostwriting' ) !== -1 && state.selections.ghostwriting !== 'none' ) {
				var g = PRICING.ghostwriting[ state.selections.ghostwriting ];
				if ( g ) {
					items.push( { label: 'Ghostwriting — ' + g.label, amount: track( 'ghostwriting', g.price ) } );
				}
			}

			// Editing — either a package tier or à la carte individual services.
			if ( allowed.indexOf( 'editing' ) !== -1 ) {
				if ( 'individual' === state.editMode ) {
					Object.keys( state.editServices ).forEach( function ( key ) {
						var svc = PRICING.editing_individual[ key ];
						if ( ! svc ) {
							return;
						}
						var sp = indivEditPrice( key, state.words );
						items.push( { label: 'Editing — ' + svc.label + ' (' + state.words.toLocaleString( 'en-US' ) + ' words)', amount: track( 'editing', sp ) } );
					} );
				} else if ( state.selections.editing !== 'none' ) {
					var et = PRICING.editing[ state.selections.editing ];
					if ( et ) {
						var ep = editingPrice( state.selections.editing, state.words );
						items.push( { label: 'Editing — ' + et.label + ' (' + state.words.toLocaleString( 'en-US' ) + ' words)', amount: track( 'editing', ep ) } );
					}
				}
			}

			// Cover + interior (design group).
			if ( allowed.indexOf( 'design' ) !== -1 ) {
				if ( state.selections.cover !== 'none' ) {
					var cv = PRICING.cover[ state.selections.cover ];
					if ( cv && cv.price ) {
						items.push( { label: 'Cover — ' + cv.label, amount: track( 'cover', cv.price ) } );
					}
				}
				if ( state.selections.interior !== 'none' ) {
					var iv = PRICING.interior[ state.selections.interior ];
					if ( iv && iv.price ) {
						items.push( { label: 'Formatting — ' + iv.label, amount: track( 'interior', iv.price ) } );
					}
				}
				if ( state.selections.illustration && state.selections.illustration !== 'none' ) {
					var il = PRICING.illustration[ state.selections.illustration ];
					if ( il && il.price ) {
						var iqty = il.unit ? ( state.illusQty || 1 ) : 1;
						var ilabel = 'Illustration — ' + il.label + ( il.unit && iqty > 1 ? ' × ' + iqty + ' ' + il.unit + 's' : '' );
						items.push( { label: ilabel, amount: track( 'cover', il.price * iqty ) } );
					}
				}
			}

			// Publishing.
			if ( allowed.indexOf( 'publishing' ) !== -1 && state.selections.publishing !== 'none' ) {
				var pb = PRICING.publishing[ state.selections.publishing ];
				if ( pb && pb.price ) {
					items.push( { label: 'Publishing — ' + pb.label, amount: track( 'publishing', pb.price ) } );
				}
			}

			// Marketing.
			if ( allowed.indexOf( 'marketing' ) !== -1 && state.selections.marketing !== 'none' ) {
				var mk = PRICING.marketing[ state.selections.marketing ];
				if ( mk && mk.price ) {
					items.push( { label: 'Marketing — ' + mk.label, amount: mk.price } );
				}
			}

			// Coaching.
			if ( allowed.indexOf( 'coaching' ) !== -1 && state.selections.coaching !== 'none' ) {
				var co = PRICING.coaching[ state.selections.coaching ];
				if ( co && co.price ) {
					items.push( { label: 'Coaching — ' + co.label, amount: co.price } );
				}
			}

			// Add-ons: flat, per-word (rate), or per-unit (× quantity), or a combination.
			if ( allowed.indexOf( 'addons' ) !== -1 ) {
				Object.keys( state.addons ).forEach( function ( key ) {
					var addon = PRICING.addons[ key ];
					if ( ! addon ) {
						return;
					}
					var qty = state.addons[ key ] || 1;
					var label = addon.label;
					var amount;
					if ( addon.rate ) {
						amount = addon.rate * state.words * qty;
						label += ' (' + state.words.toLocaleString( 'en-US' ) + ' words'
							+ ( addon.unit && qty > 1 ? ' × ' + qty + ' ' + addon.unit + 's' : '' ) + ')';
					} else {
						amount = ( addon.price || 0 ) * qty;
						if ( addon.unit && qty > 1 ) {
							label += ' × ' + qty + ' ' + addon.unit + 's';
						}
					}
					items.push( { label: label, amount: amount } );
				} );
			}

			// Rush surcharge as its own explicit line (production services only).
			var rushAmount = 0;
			if ( state.rush && rushPct > 0 && rushBase > 0 ) {
				rushAmount = rushBase * rushPct;
				items.push( {
					label: 'Rush delivery (+' + Math.round( rushPct * 100 ) + '% on production services)',
					amount: rushAmount,
					rush: true
				} );
			}

			var total = items.reduce( function ( sum, item ) {
				return sum + item.amount;
			}, 0 );

			return { items: items, total: total, saves: 0, rushAmount: rushAmount, rushPct: rushPct };
		}

		// One-line explanation of what the rush surcharge covers, for the quote.
		function rushExplanation( pct ) {
			return 'Rush delivery adds a ' + Math.round( ( pct || 0 ) * 100 ) +
				'% surcharge to production services (writing, editing, cover & interior design, and publishing).';
		}

		function paymentPlan( total ) {
			var plans = PRICING.payment_plans || [];
			for ( var i = 0; i < plans.length; i++ ) {
				if ( plans[ i ].max === 0 || total < plans[ i ].max ) {
					return plans[ i ].label;
				}
			}
			return '';
		}

		// Build a plain-text summary of the current estimate, for pre-filling the
		// Forminator "project notes" field so the lead arrives with full context.
		function buildEstimateSummary() {
			var result = computeLineItems();
			if ( ! result.items.length ) {
				return '';
			}

			var lines = [];
			lines.push( 'My book cost estimate' );
			lines.push( '----------------------' );
			result.items.forEach( function ( item ) {
				lines.push( '• ' + item.label + ': ' + money( item.amount ) );
			} );
			lines.push( '' );
			if ( result.saves ) {
				lines.push( 'You save ' + money( result.saves ) + ' vs. individual pricing' );
			}
			lines.push( 'Estimated total: ' + money( result.total ) );
			var plan = paymentPlan( result.total );
			if ( plan ) {
				lines.push( 'Payment options: ' + plan );
			}

			return lines.join( '\n' );
		}

		function updateIllusQtyVisibility() {
			// Show the inline stepper only inside the currently selected per-unit card.
			var sel = state.selections.illustration;
			root.querySelectorAll( '[data-control="illustration"] .awpc-card' ).forEach( function ( card ) {
				var qty = card.querySelector( '.awpc-card-qty' );
				if ( ! qty ) {
					return;
				}
				qty.hidden = ! ( sel !== 'none' && card.getAttribute( 'data-card' ) === sel );
			} );
		}

		// Reflect the current selection in each collapsible section header so a
		// collapsed accordion still shows what the visitor picked.
		function updateAccordions() {
			// Design sections: show the chosen tier label (hidden when "none").
			root.querySelectorAll( '[data-acc-sel]' ).forEach( function ( badge ) {
				var control = badge.getAttribute( 'data-acc-sel' );
				var sel = state.selections[ control ];
				var label = '';
				if ( sel && sel !== 'none' && PRICING[ control ] && PRICING[ control ][ sel ] ) {
					label = PRICING[ control ][ sel ].label;
				}
				badge.textContent = label;
				badge.hidden = ! label;
			} );

			// Add-on groups: show "N selected".
			var counts = {};
			Object.keys( state.addons ).forEach( function ( key ) {
				var addon = PRICING.addons[ key ];
				if ( ! addon ) {
					return;
				}
				var grp = addon.group || 'Add-ons';
				counts[ grp ] = ( counts[ grp ] || 0 ) + 1;
			} );
			root.querySelectorAll( '[data-acc-count]' ).forEach( function ( badge ) {
				var grp = badge.getAttribute( 'data-acc-count' );
				var n = counts[ grp ] || 0;
				badge.hidden = n === 0;
				badge.textContent = ( 1 === n ) ? '1 selected' : ( n + ' selected' );
			} );
		}

		// Reveal the inline manuscript-length field only when its (per-word)
		// add-on is selected.
		function updateAddonWords() {
			root.querySelectorAll( '[data-addon-words]' ).forEach( function ( w ) {
				var key = w.getAttribute( 'data-addon-words' );
				w.hidden = ! Object.prototype.hasOwnProperty.call( state.addons, key );
			} );
		}

		function render() {
			var result = computeLineItems();
			lastResult = result;
			if ( printBtn ) {
				printBtn.disabled = ! result.items.length;
			}
			updateIllusQtyVisibility();
			updateAccordions();
			updateAddonWords();

			// Line items (shared by the summary panel and the review step).
			var linesHtml;
			if ( ! result.items.length ) {
				linesHtml = '<li class="awpc-empty">' + escapeHtml( 'Select services to build your estimate.' ) + '</li>';
			} else {
				linesHtml = result.items.map( function ( item ) {
					var cls = item.rush ? ' class="awpc-line--rush"' : '';
					return '<li' + cls + '><span class="awpc-line-label">' + escapeHtml( item.label ) + '</span>' +
						'<span class="awpc-line-amount">' + money( item.amount ) + '</span></li>';
				} ).join( '' );
			}
			els.lines.innerHTML = linesHtml;
			if ( els.linesReview ) {
				els.linesReview.innerHTML = linesHtml;
			}

			// Savings.
			if ( result.saves && els.savings ) {
				els.savings.hidden = false;
				els.savings.textContent = 'You save ' + money( result.saves ) + ' vs. individual pricing';
			} else if ( els.savings ) {
				els.savings.hidden = true;
			}

			// Rush explanation note (shown whenever a rush surcharge applies).
			if ( els.rushNote ) {
				if ( result.rushAmount > 0 ) {
					els.rushNote.hidden = false;
					els.rushNote.textContent = rushExplanation( result.rushPct );
				} else {
					els.rushNote.hidden = true;
				}
			}

			els.total.textContent = money( result.total );
			if ( els.totalMobile ) {
				els.totalMobile.textContent = money( result.total );
			}

			// Gate the quote/consultation form: it may only open once the estimate
			// is above zero (i.e. the user has actually selected a service). While
			// the total is $0 the CTA is disabled and any open form is collapsed.
			root._awpcTotalNum = result.total;
			var quoteForm  = root.querySelector( '[data-form="quote"]' );
			var quoteBtns  = root.querySelectorAll( '[data-action="open-quote"], [data-action="mobile-quote"]' );
			var quoteReady = result.total > 0;
			if ( ! quoteReady && quoteForm && ! quoteForm.hidden ) {
				quoteForm.hidden = true;
			}
			for ( var qi = 0; qi < quoteBtns.length; qi++ ) {
				var qBtn = quoteBtns[ qi ];
				if ( quoteReady ) {
					qBtn.disabled = false;
					qBtn.classList.remove( 'awpc-cta--disabled' );
					qBtn.removeAttribute( 'aria-disabled' );
				} else {
					if ( qBtn.getAttribute( 'data-action' ) === 'open-quote' ) {
						qBtn.hidden = false;
					}
					qBtn.disabled = true;
					qBtn.classList.add( 'awpc-cta--disabled' );
					qBtn.setAttribute( 'aria-disabled', 'true' );
				}
			}

			if ( els.plan ) {
				els.plan.textContent = result.total > 0 ? ( 'Payment options: ' + paymentPlan( result.total ) ) : '';
			}

			// Store a plain-text summary for the quote email and lead dashboard.
			var summaryLines = result.items.map( function ( item ) {
				return '- ' + item.label + ': ' + money( item.amount );
			} );
			// Carry the rush explanation through to the email + dashboard so the
			// lead record matches what the calculator and downloadable quote show.
			if ( result.rushAmount > 0 ) {
				summaryLines.push( rushExplanation( result.rushPct ) );
			}
			root._awpcSummary = summaryLines.join( '\n' );
			root._awpcTotal = money( result.total );

			// Save the build to the URL + sessionStorage so it survives a refresh
			// and can be shared (skipped on the very first paint).
			persist();
		}

		/* ---------- State persistence (URL + sessionStorage) ---------- */
		function serializeState() {
			return {
				m:   state.mode,
				s:   state.stage,
				st:  state.step,
				w:   state.words,
				iq:  state.illusQty,
				em:  state.editMode,
				bt:  state.bookType,
				r:   state.rush ? 1 : 0,
				sel: state.selections,
				es:  Object.keys( state.editServices ),
				ad:  state.addons,
				b:   state.bundle ? state.bundle.key : null
			};
		}

		function buildEncoded() {
			// Return raw JSON; URLSearchParams percent-encodes it once when it is
			// written to the URL (encoding here too would double-encode it).
			return JSON.stringify( serializeState() );
		}

		function doPersist() {
			var enc = buildEncoded();
			try {
				if ( window.history && window.history.replaceState && window.URL ) {
					var url = new URL( window.location.href );
					url.searchParams.set( 'awpc', enc );
					window.history.replaceState( null, '', url.toString() );
				}
			} catch ( e ) {}
			try {
				if ( window.sessionStorage ) {
					window.sessionStorage.setItem( 'awpc_state', enc );
				}
			} catch ( e ) {}
		}

		var persistTimer = null;
		function persist() {
			if ( ! ready ) {
				return;
			}
			if ( persistTimer ) {
				clearTimeout( persistTimer );
			}
			persistTimer = setTimeout( doPersist, 300 );
		}

		function flushPersist() {
			if ( persistTimer ) {
				clearTimeout( persistTimer );
				persistTimer = null;
			}
			doPersist();
		}

		function clearPersisted() {
			try {
				if ( window.history && window.history.replaceState && window.URL ) {
					var url = new URL( window.location.href );
					url.searchParams.delete( 'awpc' );
					window.history.replaceState( null, '', url.toString() );
				}
			} catch ( e ) {}
			try {
				if ( window.sessionStorage ) {
					window.sessionStorage.removeItem( 'awpc_state' );
				}
			} catch ( e ) {}
		}

		function readRawParam() {
			var raw = null;
			try {
				raw = new URLSearchParams( window.location.search ).get( 'awpc' );
			} catch ( e ) {}
			if ( ! raw ) {
				try {
					raw = window.sessionStorage ? window.sessionStorage.getItem( 'awpc_state' ) : null;
				} catch ( e ) {}
			}
			return raw;
		}

		function parseStateRaw( raw ) {
			if ( ! raw ) {
				return null;
			}
			// The build is stored as raw JSON (URLSearchParams decodes the URL
			// value for us); short codes fail here and are resolved server-side.
			try {
				return JSON.parse( raw );
			} catch ( e ) {
				return null;
			}
		}

		// A short share code is a bare alphanumeric token, never JSON.
		function isShortCode( raw ) {
			return typeof raw === 'string' && /^[A-Za-z0-9]{4,16}$/.test( raw );
		}

		// Cache of state JSON -> resolved short URL, so repeated copies/sends of
		// the same build reuse one code without another round-trip.
		var shareCache = {};

		function shareFetch( params, cb ) {
			if ( typeof AWPC_DATA === 'undefined' || ! AWPC_DATA.ajaxUrl ) {
				cb( null );
				return;
			}
			var body = new URLSearchParams();
			Object.keys( params ).forEach( function ( k ) {
				body.append( k, params[ k ] );
			} );
			body.append( 'nonce', AWPC_DATA.nonce );
			try {
				fetch( AWPC_DATA.ajaxUrl, {
					method: 'POST',
					credentials: 'same-origin',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
					body: body.toString()
				} )
					.then( function ( r ) { return r.json(); } )
					.then( function ( res ) { cb( res && res.success ? res.data : null ); } )
					.catch( function () { cb( null ); } );
			} catch ( e ) {
				cb( null );
			}
		}

		// Resolve a short code back to a build object (or null).
		function resolveShare( code, cb ) {
			shareFetch( { action: 'awpc_share_resolve', code: code }, function ( data ) {
				cb( data && data.state ? parseStateRaw( data.state ) : null );
			} );
		}

		// Produce a short shareable URL for the current build. Falls back to the
		// long self-contained URL if the endpoint is unavailable.
		function currentShortUrl( cb ) {
			var stateJson = buildEncoded();
			if ( shareCache[ stateJson ] ) {
				cb( shareCache[ stateJson ] );
				return;
			}
			shareFetch( { action: 'awpc_share_create', state: stateJson }, function ( data ) {
				if ( data && data.code ) {
					var full;
					try {
						var u = new URL( window.location.href );
						u.searchParams.set( 'awpc', data.code );
						full = u.toString();
					} catch ( e ) {
						full = window.location.href;
					}
					shareCache[ stateJson ] = full;
					cb( full );
				} else {
					cb( window.location.href );
				}
			} );
		}

		function fallbackCopy( text ) {
			try {
				var ta = document.createElement( 'textarea' );
				ta.value = text;
				ta.setAttribute( 'readonly', '' );
				ta.style.position = 'absolute';
				ta.style.left = '-9999px';
				document.body.appendChild( ta );
				ta.select();
				document.execCommand( 'copy' );
				document.body.removeChild( ta );
			} catch ( e ) {}
		}

		/**
		 * Restore a previously serialised build into both state and the DOM.
		 */
		function applyState( d ) {
			if ( ! d ) {
				return;
			}

			setStage( d.s || 'idea' );
			setMode( d.m || 'build' );

			state.words = parseInt( d.w, 10 ) || 40000;
			if ( els.wordsRange ) {
				els.wordsRange.value = state.words;
			}
			if ( els.wordsOut ) {
				els.wordsOut.textContent = state.words.toLocaleString( 'en-US' );
			}
			root.querySelectorAll( '.awpc-words-input' ).forEach( function ( wi ) {
				wi.value = state.words;
			} );

			state.illusQty = Math.max( 1, parseInt( d.iq, 10 ) || 1 );
			els.illusQtyInputs.forEach( function ( qi ) {
				qi.value = state.illusQty;
			} );

			setEditMode( d.em || 'package' );

			state.rush = !! d.r;
			if ( els.rush ) {
				els.rush.checked = state.rush;
			}

			var sel = d.sel || {};
			Object.keys( state.selections ).forEach( function ( k ) {
				setRadio( k, sel[ k ] || 'none' );
			} );

			state.editServices = {};
			( d.es || [] ).forEach( function ( key ) {
				state.editServices[ key ] = true;
				var cb = root.querySelector( '[data-editservice="' + key + '"]' );
				if ( cb ) {
					cb.checked = true;
					var card = cb.closest( '.awpc-card' );
					if ( card ) {
						card.classList.add( 'is-selected' );
					}
				}
			} );

			state.addons = {};
			var ad = d.ad || {};
			Object.keys( ad ).forEach( function ( key ) {
				var qty = Math.max( 1, parseInt( ad[ key ], 10 ) || 1 );
				state.addons[ key ] = qty;
				var cb = root.querySelector( '[data-addon="' + key + '"]' );
				if ( cb ) {
					cb.checked = true;
				}
				var qi = addonQtyInput( key );
				if ( qi ) {
					qi.value = qty;
				}
			} );

			state.bundle = null;
			els.bundleCards.forEach( function ( c ) {
				c.classList.remove( 'is-selected' );
			} );
			if ( d.b ) {
				var bcard = root.querySelector( '[data-bundle="' + d.b + '"]' );
				if ( bcard ) {
					bcard.classList.add( 'is-selected' );
					state.bundle = {
						key:   d.b,
						label: bcard.getAttribute( 'data-label' ),
						price: parseFloat( bcard.getAttribute( 'data-price' ) ) || 0,
						saves: parseFloat( bcard.getAttribute( 'data-saves' ) ) || 0
					};
				}
			}

			// Show the book-type panel that matches the restored ghostwriting choice.
			var bt = d.bt || ( ( sel.ghostwriting && sel.ghostwriting.indexOf( 'childrens' ) === 0 ) ? 'childrens' : 'standard' );
			showBookTypePanel( bt );

			var steps = visibleSteps();
			showStep( ( d.st && steps.indexOf( d.st ) !== -1 ) ? d.st : 'basics' );
		}

		function submitQuote( form ) {
			var msgEl = form.querySelector( '[data-out="form-msg"]' );
			var get = function ( field ) {
				var el = form.querySelector( '[data-field="' + field + '"]' );
				return el ? el.value : '';
			};
			var email = get( 'email' );
			if ( ! email ) {
				if ( msgEl ) {
					msgEl.textContent = 'Please enter your email.';
					msgEl.className = 'awpc-form-msg is-error';
				}
				return;
			}

			var submitBtn = form.querySelector( 'button[type="submit"]' );
			if ( submitBtn ) {
				submitBtn.disabled = true;
			}
			if ( msgEl ) {
				msgEl.textContent = 'Sending…';
				msgEl.className = 'awpc-form-msg';
			}

			flushPersist(); // ensure the URL captures the exact build being sent

			var firstName = get( 'first_name' );
			var lastName = get( 'last_name' );
			var fullName = ( firstName + ' ' + lastName ).trim() || get( 'name' );

			// Full international phone number (with country dial code) when the
			// flag widget is active; otherwise the raw field value.
			var phoneVal = get( 'phone' );
			if ( itiInstance ) {
				var intlNum = ( typeof itiInstance.getNumber === 'function' ) ? itiInstance.getNumber() : '';
				if ( intlNum ) {
					phoneVal = intlNum;
				} else if ( typeof itiInstance.getSelectedCountryData === 'function' ) {
					// utils.js not loaded — prepend the selected dial code manually.
					var cc = itiInstance.getSelectedCountryData();
					if ( cc && cc.dialCode && phoneVal ) {
						phoneVal = '+' + cc.dialCode + ' ' + phoneVal;
					}
				}
			}

			var body = new URLSearchParams();
			body.append( 'action', 'awpc_send_quote' );
			body.append( 'nonce', AWPC_DATA.nonce );
			body.append( 'name', fullName );
			body.append( 'first_name', firstName );
			body.append( 'last_name', lastName );
			body.append( 'email', email );
			body.append( 'phone', phoneVal );
			body.append( 'project_type', get( 'project_type' ) );
			body.append( 'date', get( 'date' ) );
			body.append( 'time', get( 'time' ) );
			body.append( 'timezone', get( 'timezone' ) );
			body.append( 'message', get( 'message' ) );
			body.append( 'website', get( 'website' ) ); // honeypot
			body.append( 'summary', root._awpcSummary || '' );
			body.append( 'total', root._awpcTotal || money( 0 ) );
			// Store/email a short shareable "reopen" link instead of the long URL.
			currentShortUrl( function ( shortUrl ) {
			body.append( 'estimate_url', shortUrl || window.location.href );

			fetch( AWPC_DATA.ajaxUrl, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString()
			} )
				.then( function ( r ) {
					return r.json();
				} )
				.then( function ( res ) {
					if ( res.success ) {
						form.reset();
						// Swap the form out for the styled confirmation panel.
						var successPanel = root.querySelector( '[data-out="form-success"]' );
						if ( successPanel ) {
							if ( msgEl ) {
								msgEl.textContent = '';
							}
							form.hidden = true;
							successPanel.hidden = false;
							if ( successPanel.scrollIntoView ) {
								successPanel.scrollIntoView( { behavior: 'smooth', block: 'nearest' } );
							}
							// Auto-dismiss after 10 seconds (the × closes it sooner).
							if ( successCloseTimer ) {
								window.clearTimeout( successCloseTimer );
							}
							successCloseTimer = window.setTimeout( function () {
								hideSuccess( successPanel );
							}, 10000 );
						} else if ( msgEl ) {
							msgEl.textContent = res.data && res.data.message ? res.data.message : 'Sent!';
							msgEl.className = 'awpc-form-msg is-success';
						}
					} else if ( msgEl ) {
						msgEl.textContent = res.data && res.data.message ? res.data.message : 'Something went wrong.';
						msgEl.className = 'awpc-form-msg is-error';
					}
				} )
				.catch( function () {
					if ( msgEl ) {
						msgEl.textContent = 'Network error — please try again.';
						msgEl.className = 'awpc-form-msg is-error';
					}
				} )
				.finally( function () {
					if ( submitBtn ) {
						submitBtn.disabled = false;
					}
				} );
			} );
		}

		// First paint — restore a shared/saved build if one is present.
		// Enable persistence only after the first paint so a fresh load keeps a
		// clean URL until the visitor actually changes something.
		var rawParam = readRawParam();
		var savedState = parseStateRaw( rawParam );

		if ( savedState ) {
			applyState( savedState );
			render();
			ready = true;
		} else if ( isShortCode( rawParam ) ) {
			// A short shareable link: paint a default view, then resolve the code
			// server-side and apply the stored build when it arrives.
			applyStageVisibility();
			showStep( 'basics' );
			render();
			resolveShare( rawParam, function ( state ) {
				if ( state ) {
					applyState( state );
					render();
				}
				ready = true;
			} );
		} else {
			applyStageVisibility();
			showStep( 'basics' );
			render();
			ready = true;
		}
	}

	/**
	 * Popup/modal: open the calculator over the current page when a trigger
	 * (a [authorwings_calculator_button], or any link pointing at
	 * "#awpc-calculator") is clicked.
	 */
	function initModal() {
		var lastFocus = null;

		// Look the modal up at use-time, so wiring never depends on whether the
		// footer markup had already been parsed when this ran.
		function getModal() {
			return document.querySelector( '[data-awpc-modal]' );
		}

		function isOpen( modal ) {
			return modal && ! modal.hasAttribute( 'hidden' );
		}

		function open( trigger ) {
			var modal = getModal();
			if ( ! modal || isOpen( modal ) ) {
				return;
			}
			lastFocus = trigger || document.activeElement;
			modal.removeAttribute( 'hidden' );
			// Force reflow so the transition runs, then flip the open state.
			void modal.offsetWidth;
			modal.classList.add( 'is-open' );
			document.documentElement.classList.add( 'awpc-modal-lock' );

			var focusTarget = modal.querySelector( '.awpc-modal__close' ) || modal;
			if ( focusTarget && typeof focusTarget.focus === 'function' ) {
				focusTarget.focus();
			}
		}

		function close() {
			var modal = getModal();
			if ( ! isOpen( modal ) ) {
				return;
			}
			modal.classList.remove( 'is-open' );
			document.documentElement.classList.remove( 'awpc-modal-lock' );

			var hide = function () {
				modal.setAttribute( 'hidden', '' );
				modal.removeEventListener( 'transitionend', hide );
			};
			// Hide after the fade-out, with a fallback if no transition fires.
			modal.addEventListener( 'transitionend', hide );
			window.setTimeout( hide, 300 );

			if ( lastFocus && typeof lastFocus.focus === 'function' ) {
				lastFocus.focus();
			}
		}

		// Any trigger: [data-awpc-open] or a plain link to #awpc-calculator.
		document.addEventListener( 'click', function ( e ) {
			var el = e.target;
			if ( ! el || ! el.closest ) {
				return;
			}
			var trigger = el.closest( '[data-awpc-open], a[href="#awpc-calculator"], a[href$="#awpc-calculator"]' );
			if ( trigger ) {
				e.preventDefault();
				open( trigger );
				return;
			}
			if ( el.closest( '[data-awpc-close]' ) ) {
				e.preventDefault();
				close();
			}
		} );

		// Escape closes the popup.
		document.addEventListener( 'keydown', function ( e ) {
			if ( ( e.key === 'Escape' || e.key === 'Esc' ) && isOpen( getModal() ) ) {
				close();
			}
		} );

		// Open automatically if the page is loaded with #awpc-calculator in the
		// URL, or with a shared estimate (?awpc=…) — so an emailed or "reopen"
		// link shows the estimate straight away instead of needing a click.
		var hasShared = false;
		try {
			hasShared = !! new URLSearchParams( window.location.search ).get( 'awpc' );
		} catch ( e ) {}
		if ( getModal() && ( window.location.hash === '#awpc-calculator' || hasShared ) ) {
			open( null );
		}
	}

	/**
	 * Standalone controller for the Forminator estimate-form popup.
	 *
	 * Reuses the calculator popup's markup/CSS (.awpc-modal…) but is a separate
	 * dialog keyed by [data-awpc-estimate-modal] so the two never collide.
	 */
	var estimateModal = ( function () {
		var lastFocus = null;

		function getModal() {
			return document.querySelector( '[data-awpc-estimate-modal]' );
		}

		function isOpen( modal ) {
			return modal && ! modal.hasAttribute( 'hidden' );
		}

		// Locate the Forminator "project notes" textarea so the estimate summary
		// can be dropped into it. Match on label / placeholder / name / id text
		// mentioning "note", then fall back to the last textarea in the form
		// (the notes field is conventionally last).
		function findNotesField( modal ) {
			var areas = [].slice.call( modal.querySelectorAll( 'textarea' ) );
			if ( ! areas.length ) {
				return null;
			}

			// 1) A textarea tied to a label that mentions "note".
			var labels = [].slice.call( modal.querySelectorAll( 'label' ) );
			for ( var i = 0; i < labels.length; i++ ) {
				if ( ( labels[ i ].textContent || '' ).toLowerCase().indexOf( 'note' ) === -1 ) {
					continue;
				}
				var forId = labels[ i ].getAttribute( 'for' );
				var byId = forId ? modal.querySelector( '[id="' + forId + '"]' ) : null;
				if ( byId && 'TEXTAREA' === byId.tagName ) {
					return byId;
				}
				var wrap = labels[ i ].closest( '.forminator-field, .forminator-row, .forminator-col, div' );
				var inWrap = wrap ? wrap.querySelector( 'textarea' ) : null;
				if ( inWrap ) {
					return inWrap;
				}
			}

			// 2) A textarea whose own attributes mention "note".
			for ( var j = 0; j < areas.length; j++ ) {
				var meta = (
					( areas[ j ].getAttribute( 'placeholder' ) || '' ) + ' ' +
					( areas[ j ].getAttribute( 'name' ) || '' ) + ' ' +
					( areas[ j ].getAttribute( 'id' ) || '' ) + ' ' +
					( areas[ j ].getAttribute( 'aria-label' ) || '' )
				).toLowerCase();
				if ( meta.indexOf( 'note' ) !== -1 ) {
					return areas[ j ];
				}
			}

			// 3) Fallback: the last textarea.
			return areas[ areas.length - 1 ];
		}

		function fillNotes( modal, text ) {
			if ( ! text ) {
				return;
			}
			var field = findNotesField( modal );
			if ( ! field ) {
				return;
			}
			field.value = text;
			// Let Forminator's own scripts pick up the change (validation, etc.).
			try {
				field.dispatchEvent( new Event( 'input', { bubbles: true } ) );
				field.dispatchEvent( new Event( 'change', { bubbles: true } ) );
			} catch ( e ) {}
		}

		function open( trigger, notes ) {
			var modal = getModal();
			if ( ! modal || isOpen( modal ) ) {
				return;
			}
			lastFocus = trigger || document.activeElement;
			// Drop the current estimate into the form's notes field before showing.
			fillNotes( modal, notes );
			modal.removeAttribute( 'hidden' );
			// Force reflow so the transition runs, then flip the open state.
			void modal.offsetWidth;
			modal.classList.add( 'is-open' );
			document.documentElement.classList.add( 'awpc-modal-lock' );

			var focusTarget = modal.querySelector( '.awpc-modal__close' ) || modal;
			if ( focusTarget && typeof focusTarget.focus === 'function' ) {
				focusTarget.focus();
			}
		}

		function close() {
			var modal = getModal();
			if ( ! isOpen( modal ) ) {
				return;
			}
			modal.classList.remove( 'is-open' );
			document.documentElement.classList.remove( 'awpc-modal-lock' );

			var hide = function () {
				modal.setAttribute( 'hidden', '' );
				modal.removeEventListener( 'transitionend', hide );
			};
			modal.addEventListener( 'transitionend', hide );
			window.setTimeout( hide, 300 );

			if ( lastFocus && typeof lastFocus.focus === 'function' ) {
				lastFocus.focus();
			}
		}

		function init() {
			document.addEventListener( 'click', function ( e ) {
				var el = e.target;
				if ( ! el || ! el.closest ) {
					return;
				}
				if ( el.closest( '[data-awpc-estimate-close]' ) ) {
					e.preventDefault();
					close();
				}
			} );

			document.addEventListener( 'keydown', function ( e ) {
				if ( ( e.key === 'Escape' || e.key === 'Esc' ) && isOpen( getModal() ) ) {
					close();
				}
			} );
		}

		return { init: init, open: open, close: close };
	} )();

	function boot() {
		// Wire the popup first so a calculator-init hiccup can never stop the
		// button from opening it.
		initModal();
		estimateModal.init();
		document.querySelectorAll( '.awpc-wrap' ).forEach( function ( root ) {
			try {
				initCalculator( root );
			} catch ( err ) {
				if ( window.console && window.console.error ) {
					window.console.error( 'AWPC: calculator init failed', err );
				}
			}
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
} )();
