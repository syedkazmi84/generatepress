<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

/**
 * Cookie Consent / GDPR notice.
 *
 * A simple, self-contained way to show that the website complies with the EU
 * Cookie Law / GDPR: a dismissible notice bar shown to first-time visitors.
 * Once accepted, the choice is stored (cookie + localStorage) so the bar never
 * reappears.
 *
 * The bar is printed into the footer markup but kept hidden until the enqueued
 * cookie-consent.js confirms consent has NOT yet been given. Revealing it
 * client-side keeps the feature correct behind full-page caches (Varnish, WP
 * cache plugins, CDNs) where the server can't see the visitor's cookie.
 */
final class Cookie_Consent {
    /** localStorage key + cookie name used to remember the visitor's choice. */
    private const STORE_KEY = 'awg_cookie_consent';

    /** @var Settings */
    private $settings;

    public function __construct(Settings $settings) {
        $this->settings = $settings;
    }

    public function register(): void {
        // Enqueue the (static, browser-cached) CSS/JS only when the feature is on,
        // following the same conditional-loading pattern as the plugin's other
        // front assets. Unlike the AI-tool assets, the consent bar is site-wide by
        // design, so the gate is "feature enabled" rather than "page has a tool".
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_footer', [$this, 'render'], 100);
    }

    /** True when the notice should load/show on the current front-end request. */
    private function is_active(): bool {
        if (is_admin() || is_feed() || (defined('REST_REQUEST') && REST_REQUEST)) {
            return false;
        }
        $s = $this->settings->get();
        if (empty($s['cookie_consent_enabled'])) {
            return false;
        }
        return trim((string) $s['cookie_consent_message']) !== '';
    }

    /** Register + enqueue the consent assets when the feature is active. */
    public function enqueue_assets(): void {
        if (!$this->is_active()) {
            return;
        }
        wp_enqueue_style(
            'awg-aig-cookie-consent',
            plugins_url('assets/cookie-consent.css', AWG_AIG_FILE),
            [],
            AWG_AIG_VERSION
        );
        wp_enqueue_script(
            'awg-aig-cookie-consent',
            plugins_url('assets/cookie-consent.js', AWG_AIG_FILE),
            [],
            AWG_AIG_VERSION,
            true
        );
    }

    /** Print the notice bar (hidden by default; JS reveals it when needed). */
    public function render(): void {
        if (!$this->is_active()) {
            return;
        }

        $s = $this->settings->get();
        $message = trim((string) $s['cookie_consent_message']);

        $button_text = (string) $s['cookie_consent_button_text'];
        if (trim($button_text) === '') {
            $button_text = __('Got it!', 'authorwings-ai-tools');
        }

        $show_reject = !empty($s['cookie_consent_show_reject']);
        $reject_text = isset($s['cookie_consent_reject_text']) ? trim((string) $s['cookie_consent_reject_text']) : '';
        if ($reject_text === '') {
            $reject_text = __('Reject', 'authorwings-ai-tools');
        }

        $learn_text = trim((string) $s['cookie_consent_learn_text']);
        $learn_url  = trim((string) $s['cookie_consent_learn_url']);
        $position   = ($s['cookie_consent_position'] === 'top') ? 'top' : 'bottom';

        $bg     = '#' . ltrim($s['cookie_consent_bg_color'], '#');
        $fg     = '#' . ltrim($s['cookie_consent_text_color'], '#');
        $btn_bg = '#' . ltrim($s['cookie_consent_button_bg'], '#');
        $btn_fg = '#' . ltrim($s['cookie_consent_button_text_color'], '#');

        // Message allows the same safe HTML the admin field sanitized to.
        $message_html = wp_kses_post($message);
        ?>
        <div id="awg-cookie-consent" class="awg-cookie-consent awg-cookie-consent--<?php echo esc_attr($position); ?>"
             role="region" aria-label="<?php echo esc_attr__('Cookie consent', 'authorwings-ai-tools'); ?>"
             hidden
             style="display:none;background:<?php echo esc_attr($bg); ?>;color:<?php echo esc_attr($fg); ?>;">
            <div class="awg-cookie-consent__inner">
                <div class="awg-cookie-consent__msg">
                    <?php
                    echo $message_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized with wp_kses_post.
                    if ($learn_url !== '') {
                        if ($learn_text === '') { $learn_text = __('Learn more', 'authorwings-ai-tools'); }
                        ?>
                        <a class="awg-cookie-consent__learn" href="<?php echo esc_url($learn_url); ?>" style="color:<?php echo esc_attr($btn_bg); ?>;"><?php echo esc_html($learn_text); ?></a>
                        <?php
                    }
                    ?>
                </div>
                <div class="awg-cookie-consent__actions">
                    <?php if ($show_reject) : ?>
                    <button type="button" class="awg-cookie-consent__reject"
                            style="color:<?php echo esc_attr($fg); ?>;border-color:<?php echo esc_attr($fg); ?>;">
                        <?php echo esc_html($reject_text); ?>
                    </button>
                    <?php endif; ?>
                    <button type="button" class="awg-cookie-consent__accept"
                            style="background:<?php echo esc_attr($btn_bg); ?>;color:<?php echo esc_attr($btn_fg); ?>;">
                        <?php echo esc_html($button_text); ?>
                    </button>
                </div>
            </div>
        </div>
        <?php
    }
}
