<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class CPT {
    /** @var string */
    private $cpt;

    public function __construct(string $cpt) {
        $this->cpt = $cpt;
    }

    public function register(): void {
        register_post_type($this->cpt, [
            'labels' => [
                'name' => __('AuthorWings AI Templates', 'authorwings-ai-tools'),
                'singular_name' => __('AuthorWings AI Template', 'authorwings-ai-tools'),
                'add_new_item' => __('Add New AuthorWings AI Template', 'authorwings-ai-tools'),
                'edit_item' => __('Edit AuthorWings AI Template', 'authorwings-ai-tools'),
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_rest' => true,
            // We attach this CPT under the top-level "AuthorWings AI" menu via custom submenus.
            'show_in_menu' => false,
            'supports' => ['title', 'thumbnail'],
            // v5.4.15: lock template CRUD to admins. The submenu link was
            // already gated to manage_options, but without these caps an
            // Author could navigate directly to
            // post-new.php?post_type=awg_ai_template and build/publish a
            // template — which would let them pick the model and set
            // max_output_tokens, then burn OpenAI tokens via the public
            // AJAX endpoint. Mirrors the SUB_CPT cap map in
            // class-submissions.php so both AI surfaces have the same gate.
            'capabilities' => [
                'edit_post'              => 'manage_options',
                'read_post'              => 'manage_options',
                'delete_post'            => 'manage_options',
                'edit_posts'             => 'manage_options',
                'edit_others_posts'      => 'manage_options',
                'publish_posts'          => 'manage_options',
                'read_private_posts'     => 'manage_options',
                'delete_posts'           => 'manage_options',
                'delete_private_posts'   => 'manage_options',
                'delete_published_posts' => 'manage_options',
                'delete_others_posts'    => 'manage_options',
                'edit_private_posts'     => 'manage_options',
                'edit_published_posts'   => 'manage_options',
                'create_posts'           => 'manage_options',
            ],
        ]);

        // The native Featured Image box only renders for a CPT when the active
        // theme declares post-thumbnails support *for this post type*. Many
        // themes scope support to an explicit list (e.g. ['post','page']),
        // which would otherwise hide the box on our editor. Extend that support
        // to include this CPT without overwriting the theme's existing list.
        $support = get_theme_support('post-thumbnails');
        if ($support === false) {
            add_theme_support('post-thumbnails', [$this->cpt]);
        } elseif (is_array($support) && isset($support[0]) && is_array($support[0])) {
            add_theme_support('post-thumbnails', array_values(array_unique(array_merge($support[0], [$this->cpt]))));
        }
        // $support === true means the theme already supports all types — nothing to do.
    }

    public function columns(array $columns): array {
        $new = [];
        foreach ($columns as $key => $label) {
            $new[$key] = $label;
            if ($key === 'title') {
                $new['awg_aig_usage'] = __('Usage', 'authorwings-ai-tools');
                $new['awg_aig_last_generated'] = __('Last Generated', 'authorwings-ai-tools');
            }
        }
        return $new;
    }

    public function column_data(string $column, int $post_id): void {
        if ($column === 'awg_aig_usage') {
            $count = (int) get_post_meta($post_id, '_awg_aig_usage_count', true);
            echo esc_html($count);
        }

        if ($column === 'awg_aig_last_generated') {
            $raw = get_post_meta($post_id, '_awg_aig_last_generated', true);
            if (!$raw) {
                echo esc_html__('—', 'authorwings-ai-tools');
                return;
            }
            $time = strtotime($raw);
            if (!$time) {
                echo esc_html__('—', 'authorwings-ai-tools');
                return;
            }
            echo esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), $time));
        }
    }

    public function sortable_columns(array $columns): array {
        $columns['awg_aig_usage'] = 'awg_aig_usage';
        $columns['awg_aig_last_generated'] = 'awg_aig_last_generated';
        return $columns;
    }

    public function sort_columns(\WP_Query $query): void {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->post_type !== $this->cpt) {
            return;
        }
        $orderby = $query->get('orderby');
        if ($orderby === 'awg_aig_usage') {
            $query->set('meta_key', '_awg_aig_usage_count');
            $query->set('orderby', 'meta_value_num');
        }
        if ($orderby === 'awg_aig_last_generated') {
            $query->set('meta_key', '_awg_aig_last_generated');
            $query->set('orderby', 'meta_value');
        }
    }

    /**
     * Add a "Duplicate" row action on the template list.
     */
    public function row_actions(array $actions, $post): array {
        if (!is_object($post) || $post->post_type !== $this->cpt) {
            return $actions;
        }
        if (!current_user_can('edit_post', $post->ID)) {
            return $actions;
        }

        // Preview: open the live front-end form in the admin without needing to
        // place the [awg_generator] shortcode on a page first. The CPT is
        // non-public, so this routes to a dedicated admin screen instead of the
        // (unavailable) public single-post view.
        $preview_url = wp_nonce_url(
            admin_url('admin.php?page=awg_aig_preview&post=' . $post->ID),
            'awg_aig_preview_' . $post->ID
        );
        $actions['awg_aig_preview'] = sprintf(
            '<a href="%s">%s</a>',
            esc_url($preview_url),
            esc_html__('Preview', 'authorwings-ai-tools')
        );

        $url = wp_nonce_url(
            admin_url('admin-post.php?action=awg_aig_duplicate&post=' . $post->ID),
            'awg_aig_duplicate_' . $post->ID
        );
        $actions['awg_aig_duplicate'] = sprintf(
            '<a href="%s">%s</a>',
            esc_url($url),
            esc_html__('Duplicate', 'authorwings-ai-tools')
        );
        return $actions;
    }

    /**
     * Register a hidden admin page that renders a single template's live
     * front-end form. Hidden (no parent menu) so it doesn't clutter the menu,
     * but reachable at admin.php?page=awg_aig_preview&post=ID from the row
     * action and the editor's "Preview" link.
     */
    public function register_preview_page(): void {
        add_submenu_page(
            '',
            __('Preview Template', 'authorwings-ai-tools'),
            __('Preview Template', 'authorwings-ai-tools'),
            'edit_posts',
            'awg_aig_preview',
            [$this, 'render_preview_page']
        );
    }

    /**
     * Add a "Preview" link to the editor's Publish box so a template can be
     * opened in the admin preview while it's being edited.
     */
    public function submitbox_preview_link(\WP_Post $post): void {
        if ($post->post_type !== $this->cpt) {
            return;
        }
        if (!current_user_can('edit_post', $post->ID)) {
            return;
        }
        $url = wp_nonce_url(
            admin_url('admin.php?page=awg_aig_preview&post=' . $post->ID),
            'awg_aig_preview_' . $post->ID
        );
        ?>
        <div class="misc-pub-section awg-aig-preview-link" style="display:flex;align-items:center;gap:6px;">
            <span class="dashicons dashicons-visibility" style="color:#646970;"></span>
            <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener"><?php esc_html_e('Preview tool', 'authorwings-ai-tools'); ?></a>
        </div>
        <?php
    }

    /**
     * Render the preview screen: a small toolbar (back to list, edit, open in a
     * new tab, the tool's shortcode) above an iframe that renders the template
     * through the active theme for a true match with the shortcode output.
     */
    public function render_preview_page(): void {
        $post_id = isset($_GET['post']) ? (int) $_GET['post'] : 0;
        if ($post_id <= 0) {
            wp_die(esc_html__('Invalid template id.', 'authorwings-ai-tools'));
        }
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
        if (!wp_verify_nonce($nonce, 'awg_aig_preview_' . $post_id)) {
            wp_die(esc_html__('Security check failed.', 'authorwings-ai-tools'));
        }
        $post = get_post($post_id);
        if (!$post || $post->post_type !== $this->cpt) {
            wp_die(esc_html__('Template not found.', 'authorwings-ai-tools'));
        }
        if (!current_user_can('edit_post', $post_id)) {
            wp_die(esc_html__('Permission denied.', 'authorwings-ai-tools'));
        }

        $renderer    = Plugin::instance()->renderer;
        $preview_url = $renderer ? $renderer->preview_url($post_id) : '';
        $edit_link   = get_edit_post_link($post_id, 'url');
        $list_link   = admin_url('edit.php?post_type=' . $this->cpt);
        $shortcode   = '[awg_generator id="' . $post_id . '"]';
        ?>
        <div class="wrap awg-aig-preview-wrap">
            <h1 class="wp-heading-inline">
                <?php
                /* translators: %s: template title */
                echo esc_html(sprintf(__('Preview: %s', 'authorwings-ai-tools'), $post->post_title));
                ?>
            </h1>
            <hr class="wp-header-end">

            <p class="awg-aig-preview-toolbar" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:12px 0 4px;">
                <a href="<?php echo esc_url($list_link); ?>" class="button">&larr; <?php esc_html_e('All Templates', 'authorwings-ai-tools'); ?></a>
                <?php if ($edit_link) : ?>
                    <a href="<?php echo esc_url($edit_link); ?>" class="button button-primary"><?php esc_html_e('Edit Template', 'authorwings-ai-tools'); ?></a>
                <?php endif; ?>
                <?php if ($preview_url) : ?>
                    <a href="<?php echo esc_url($preview_url); ?>" class="button" target="_blank" rel="noopener"><?php esc_html_e('Open in new tab', 'authorwings-ai-tools'); ?></a>
                <?php endif; ?>
                <span style="display:inline-flex;align-items:center;gap:6px;color:#646970;">
                    <?php esc_html_e('Shortcode:', 'authorwings-ai-tools'); ?>
                    <code><?php echo esc_html($shortcode); ?></code>
                </span>
            </p>

            <p class="description" style="margin:0 0 12px;max-width:760px;">
                <?php esc_html_e('Rendered through your active theme, so this matches exactly what visitors see from the [awg_generator] shortcode — no need to place it on a page to test. Running a generation here calls the AI provider and counts toward usage and API costs, just like the front end.', 'authorwings-ai-tools'); ?>
            </p>

            <?php if ($preview_url) : ?>
                <div class="awg-aig-preview-devices" style="display:flex;gap:6px;align-items:center;margin:0 0 12px;">
                    <span style="color:#646970;margin-right:4px;"><?php esc_html_e('Preview at:', 'authorwings-ai-tools'); ?></span>
                    <button type="button" class="button button-primary awg-aig-preview-device" data-device="desktop" aria-pressed="true">
                        <span class="dashicons dashicons-desktop" style="margin:3px 4px 0 0;"></span><?php esc_html_e('Desktop', 'authorwings-ai-tools'); ?>
                    </button>
                    <button type="button" class="button awg-aig-preview-device" data-device="tablet" aria-pressed="false">
                        <span class="dashicons dashicons-tablet" style="margin:3px 4px 0 0;"></span><?php esc_html_e('Tablet', 'authorwings-ai-tools'); ?>
                    </button>
                    <button type="button" class="button awg-aig-preview-device" data-device="mobile" aria-pressed="false">
                        <span class="dashicons dashicons-smartphone" style="margin:3px 4px 0 0;"></span><?php esc_html_e('Mobile', 'authorwings-ai-tools'); ?>
                    </button>
                    <span class="awg-aig-preview-device-size" style="color:#646970;margin-left:6px;font-variant-numeric:tabular-nums;"></span>
                </div>

                <div class="awg-aig-preview-stage" style="background:#f0f0f1;border:1px solid #dcdcde;border-radius:6px;padding:16px;overflow:auto;">
                    <iframe
                        id="awg-aig-preview-frame"
                        src="<?php echo esc_url($preview_url); ?>"
                        title="<?php echo esc_attr(sprintf(__('Preview of %s', 'authorwings-ai-tools'), $post->post_title)); ?>"
                        style="display:block;margin:0 auto;width:100%;max-width:1100px;min-height:560px;border:1px solid #c3c4c7;border-radius:6px;background:#fff;transition:max-width .2s ease;"
                    ></iframe>
                </div>

                <script>
                (function(){
                    var expected = <?php echo wp_json_encode(home_url('')); ?>;
                    var origin = '';
                    try { origin = new URL(expected).origin; } catch (e) { origin = ''; }

                    var frame = document.getElementById('awg-aig-preview-frame');

                    /* Grow the iframe to the content height reported by the framed
                     * page so there's a single, natural scroll. */
                    window.addEventListener('message', function(ev){
                        if (origin && ev.origin !== origin) { return; }
                        var data = ev.data;
                        if (!data || typeof data.awgPreviewHeight !== 'number') { return; }
                        if (frame) { frame.style.height = (data.awgPreviewHeight + 4) + 'px'; }
                    });

                    /* Device width toggles — resize the frame to common breakpoints
                     * so the theme's own responsive layout (mobile menu, stacked
                     * fields) can be checked without leaving the dashboard. */
                    var WIDTHS = { desktop: '1100px', tablet: '768px', mobile: '390px' };
                    var sizeEl = document.querySelector('.awg-aig-preview-device-size');
                    var btns = document.querySelectorAll('.awg-aig-preview-device');
                    Array.prototype.forEach.call(btns, function(btn){
                        btn.addEventListener('click', function(){
                            var device = btn.getAttribute('data-device');
                            Array.prototype.forEach.call(btns, function(b){
                                b.classList.remove('button-primary');
                                b.setAttribute('aria-pressed', 'false');
                            });
                            btn.classList.add('button-primary');
                            btn.setAttribute('aria-pressed', 'true');
                            if (frame) { frame.style.maxWidth = WIDTHS[device] || WIDTHS.desktop; }
                            if (sizeEl) {
                                sizeEl.textContent = device === 'desktop' ? '' : (parseInt(WIDTHS[device], 10) + 'px wide');
                            }
                        });
                    });
                })();
                </script>
            <?php else : ?>
                <p><?php esc_html_e('Preview is unavailable for this template.', 'authorwings-ai-tools'); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Handle the duplicate action: clones a template post + its meta.
     */
    public function handle_duplicate(): void {
        $post_id = isset($_GET['post']) ? (int) $_GET['post'] : 0;
        if ($post_id <= 0) {
            wp_die(esc_html__('Invalid template id.', 'authorwings-ai-tools'));
        }
        check_admin_referer('awg_aig_duplicate_' . $post_id);

        $original = get_post($post_id);
        if (!$original || $original->post_type !== $this->cpt) {
            wp_die(esc_html__('Template not found.', 'authorwings-ai-tools'));
        }
        if (!current_user_can('edit_post', $post_id)) {
            wp_die(esc_html__('Permission denied.', 'authorwings-ai-tools'));
        }

        $new_id = wp_insert_post([
            'post_type'    => $this->cpt,
            'post_status'  => 'draft',
            'post_title'   => $original->post_title . ' ' . __('(Copy)', 'authorwings-ai-tools'),
            'post_author'  => get_current_user_id() ?: $original->post_author,
            'post_content' => $original->post_content,
        ], true);

        if (is_wp_error($new_id) || !$new_id) {
            wp_die(esc_html__('Could not duplicate template.', 'authorwings-ai-tools'));
        }

        // Copy template meta (skip usage counters so the clone starts fresh).
        // v5.4.14: also skip seeded rating votes — copying base_count / base_avg
        // would carry the original's "credibility seed" to the clone, which
        // displays as fake social proof on a brand-new tool. Real votes live in
        // the awg_ratings table keyed by post_id, so they're never cloned.
        // Schema identity meta (type, name, description, pricing) IS copied —
        // that's configuration the admin almost certainly wants duplicated.
        $skip = [
            '_awg_aig_usage_count',
            '_awg_aig_last_generated',
            '_awg_rating_base_count',
            '_awg_rating_base_avg',
        ];
        $meta = get_post_meta($post_id);
        foreach ($meta as $key => $values) {
            if (in_array($key, $skip, true)) continue;
            foreach ($values as $value) {
                $unserialized = maybe_unserialize($value);
                add_post_meta($new_id, $key, wp_slash($unserialized));
            }
        }

        wp_safe_redirect(admin_url('post.php?action=edit&post=' . $new_id));
        exit;
    }
}
