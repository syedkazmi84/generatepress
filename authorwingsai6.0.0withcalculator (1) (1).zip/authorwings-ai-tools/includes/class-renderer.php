<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Renderer {
    /** @var string */
    private $cpt;

    /** @var Settings */
    private $settings;

    public function __construct(string $cpt, Settings $settings) {
        $this->cpt = $cpt;
        $this->settings = $settings;
    }

    /* ------------------------------------------------------------------ *
     * Shared formatting instructions (editable site-wide in Settings)
     *
     * These two lines are appended to every generation's system prompt. They
     * were hardcoded in the generate handler; centralising them here lets the
     * Settings page edit them, the generate handler send them, and the template
     * editor's Final Prompt Preview show them — all from one source. Blank
     * override = built-in default.
     * ------------------------------------------------------------------ */

    /** Default formatting-hygiene line (keep block/markup names out of output). */
    public static function default_format_hygiene(): string {
        return 'Output only the content itself. Never mention formatting, block names or markup in your text, and never use one as a heading — do not write words like "fixcards", "compare block", "scorecard", "proscons", "pullquote", "checklist", "```" or "===". Use a block when it fits and silently omit it when it does not; never explain which blocks you used or skipped.';
    }

    /**
     * v5.8.3: per-block formatting fragments — the single source of truth for
     * HOW each tricky block is formatted. Each entry has:
     *   'use'  => tokens that mean "this prompt uses the block" (case-insensitive);
     *   'have' => a signature phrase that means the formatting is ALREADY spelled
     *             out inline in the prompt (so we must NOT inject it again);
     *   'text' => the rule itself.
     * The runtime injects only the fragments for blocks a tool actually uses and
     * whose formatting isn't already inline, so nothing is ever sent twice and a
     * tool never carries rules for blocks it doesn't use.
     */
    public static function format_fragments(): array {
        return [
            'checklist' => [
                'use'  => ['[x]', '[ ]', 'checklist'],
                'have' => 'every line as a task item',
                'text' => 'A checklist must have every line as a task item ("- [x]" for met, "- [ ]" for unmet) with no plain bullets mixed in; judge each item against your corrected/final text and phrase it as a positive outcome — a clean item is "[x]", so avoid negated wording like "No errors found" and instead state the status of the final text.',
            ],
            'compare' => [
                // v5.8.3: match the fenced tag only — the everyday phrases
                // "before/after" can appear in ordinary prose and mis-trigger.
                'use'  => ['```compare'],
                'have' => 'one original and one revision',
                'text' => 'A before/after comparison must contain exactly one original and one revision per fenced block, separated by a single line of ===; use a separate block for each passage rather than several === in one block.',
            ],
            'fixcards' => [
                // v5.8.3: match the fence and the block's own jargon only — the
                // everyday phrase "fix card" can appear in plain prose.
                'use'  => ['```fixcards', 'fixcards'],
                'have' => 'on the same line',
                'text' => 'A suggested-rewrite fix card must be written as ">> " immediately followed by the rewrite on the SAME line — never put ">>" on a line by itself.',
            ],
            'table' => [
                'use'  => ['|---', 'markdown table'],
                'have' => 'start and end every row with a pipe',
                'text' => 'A table must start and end every row with a pipe "|", including the divider row beneath the header.',
            ],
        ];
    }

    /** Default block-formatting rules (how a block is formatted when used). */
    public static function default_format_rules(): string {
        $parts = ['Formatting rules that apply only when you actually use a result block:'];
        foreach (self::format_fragments() as $frag) {
            $parts[] = $frag['text'];
        }
        return implode(' ', $parts);
    }

    /**
     * v5.8.3: build ONLY the block-formatting rules relevant to one tool.
     * Plain-text tools get nothing. For Editorial tools we include a fragment
     * when its block is referenced in $context AND the formatting isn't already
     * written inline there. $context should be the tool's Rules + prompts.
     */
    public static function relevant_format_rules(array $s, string $render_mode, string $context): string {
        if ($render_mode === 'plain') {
            return '';
        }
        // Honour a full site-wide override: if the admin replaced the rules text
        // in Settings, we can't safely slice it per block, so send it whole.
        $override = trim((string) ($s['format_rules'] ?? ''));
        if ($override !== '') {
            return $override;
        }
        $ctx = strtolower($context);
        $out = [];
        foreach (self::format_fragments() as $frag) {
            $used = false;
            foreach ($frag['use'] as $needle) {
                if ($needle !== '' && strpos($ctx, strtolower($needle)) !== false) {
                    $used = true;
                    break;
                }
            }
            if (!$used) {
                continue;
            }
            if ($frag['have'] !== '' && strpos($ctx, strtolower($frag['have'])) !== false) {
                continue; // formatting already spelled out inline — don't repeat it
            }
            $out[] = $frag['text'];
        }
        return implode("\n\n", $out);
    }

    /** Effective hygiene line: the site override if set, else the default. */
    public static function effective_format_hygiene(array $s): string {
        $o = trim((string) ($s['format_hygiene'] ?? ''));
        return $o !== '' ? $o : self::default_format_hygiene();
    }

    /** Effective block-formatting rules: the site override if set, else the default. */
    public static function effective_format_rules(array $s): string {
        $o = trim((string) ($s['format_rules'] ?? ''));
        return $o !== '' ? $o : self::default_format_rules();
    }

    private function allowed_colors(): array {
        // Retained for backward compatibility; no longer used as a whitelist.
        // The values below mirror the AuthorWings.com brand palette.
        return ['10243c', '7e9374', 'ffffff', 'e8decf', 'f2eae0', 'c97a5e'];
    }

    /**
     * Accept any valid hex color (3 or 6 digits, with or without leading #).
     * Returns bare lowercase 6-digit hex, or $default when invalid.
     */
    private function color_or_default($value, string $default): string {
        return Settings::sanitize_hex_bare($value, $default);
    }

    private function sanitize_icon_class($value): string {
        $class = trim((string) $value);
        if ($class === '') {
            return '';
        }
        $parts = preg_split('/\s+/', $class);
        $parts = array_map('sanitize_html_class', array_filter($parts, static function ($part) {
            return is_string($part) && $part !== '';
        }));
        return trim(implode(' ', $parts));
    }

    private function render_icon(string $icon_class, int $size, string $extra_class = ''): string {
        if ($icon_class === '') {
            return '';
        }
        $classes = trim('awg-aig__icon ' . $extra_class . ' ' . $icon_class);
        return sprintf(
            '<span class="%1$s" style="font-size:%2$spx;width:%2$spx;height:%2$spx;" aria-hidden="true"></span>',
            esc_attr($classes),
            esc_attr($size)
        );
    }

    /**
     * v5.4.24: glyph for the branded icon badge. Uses the admin's dashicon if one
     * is set on the template; otherwise a built-in sparkle so the default tool
     * always has a clean badge. Sizing/shape are handled by the .awg-aig__badge CSS.
     */
    private function branded_badge_icon(string $icon_class): string {
        if ($icon_class !== '') {
            return sprintf('<span class="awg-aig__icon %1$s" aria-hidden="true"></span>', esc_attr($icon_class));
        }
        return '<svg class="awg-aig__badge-spark" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">'
             . '<path d="M12 2.2C12.5 7.5 12.7 9.3 13.6 10.4 14.5 11.3 16.5 11.5 21.8 12 16.5 12.5 14.5 12.7 13.6 13.6 '
             . '12.7 14.5 12.5 16.5 12 21.8 11.5 16.5 11.3 14.5 10.4 13.6 9.5 12.7 7.5 12.5 2.2 12 '
             . '7.5 11.5 9.5 11.3 10.4 10.4 11.3 9.5 11.5 7.5 12 2.2Z"/></svg>';
    }

    public function template_defaults(): array {
        return [
            'form_title' => 'Generator',
            'form_description' => 'Get tailored ideas for your next publishing project.',
            'button_label' => 'Generate',
            'title_icon_class' => '',
            'title_icon_size' => 20,
            'title_icon_position' => 'before',
            // v5.4.24: header design overrides ('global' = use Settings default).
            'form_design' => 'global',
            'header_icon_position' => 'global',
            'title_font' => 'global',
            // v5.4.26: per-template branded header overrides. 'global' / '' = inherit.
            'brand_eyebrow_mode' => 'global',     // global | custom
            'brand_eyebrow' => '',                // used only when mode = custom
            'header_show_rule' => 'global',       // global | yes | no
            'header_subtitle_italic' => 'global', // global | yes | no
            'brand_title_color' => '',            // blank = inherit global
            'brand_subtitle_color' => '',
            'brand_eyebrow_color' => '',
            'brand_badge_bg_color' => '',
            'brand_badge_icon_color' => '',
            'brand_rule_color' => '',
            'success_title' => 'Result',
            'placeholder_output' => 'Your results will appear here…',
            'disclaimer_text' => 'AI results should be reviewed for accuracy before publishing.',
            'hide_cta' => 0,
            'cta_text_override' => '',

            // Design mode: 'standard' builds the form from the Fields array
            // below. 'custom_html' renders admin-authored markup instead — every
            // named input the admin adds is still collected and sent to the AI
            // as {{fields}}, exactly like the standard form. Falls back to the
            // standard renderer if custom_html is empty.
            'design_mode' => 'standard',
            'custom_html' => '',

            'style_bg_color' => 'f2ead9',
            'style_text_color' => '33291c',
            'style_border_color' => 'e5dac4',
            'style_accent_color' => 'c8794f',
            'style_button_bg_color' => '10243c',
            'style_button_text_color' => 'f7efe2',
            'style_button_border_color' => '10243c',
            'style_button_padding_y' => 10,
            'style_button_padding_x' => 14,
            'style_button_radius' => 12,
            'button_icon_class' => '',
            'button_icon_size' => 18,
            'button_icon_position' => 'before',
            'button_icon_css_class' => '',
            'style_padding' => 16,
            'style_margin' => 12,
            'style_padding_top' => 16,
            'style_padding_right' => 16,
            'style_padding_bottom' => 16,
            'style_padding_left' => 16,
            'style_margin_top' => 12,
            'style_margin_right' => 12,
            'style_margin_bottom' => 12,
            'style_margin_left' => 12,
            'style_radius' => 20,
            'style_input_height' => 44,
            'style_textarea_rows' => 5,
            'use_global_styles' => 1,
            'use_global_field_sizes' => 1,

            // Prompt settings
            // v5.4.49: when 1 (default), the global system prompt from Settings
            // is prepended to this template's system prompt. Set 0 to opt out.
            'apply_global_prompt' => 1,
            // v5.4.98: neutral starter prompt that fits both tool kinds —
            // "generators" (create from short settings) and "processors"
            // (rewrite/critique a pasted text). The {{fields}} block is fenced in
            // <input> tags so the model always sees a clear boundary between the
            // user's data and the instructions; the admin steers the rest via the
            // Task verb and the field labels. Defaults are intentionally generic so
            // a fresh tool never misleads the model (was hard-coded to "Book Title
            // Generator" with a numbered-list rule that fought the document layout).
            'system_prompt' => 'You are an expert writing and publishing assistant. Give clear, accurate, helpful results based only on what the user provides, and never invent facts.',
            'user_prompt'   => "Task: {{task}}\n\nUser input:\n<input>\n{{fields}}\n</input>\n\nRules:\n{{rules}}",
            'task' => 'Describe what this tool should do (e.g. write a short book blurb)',
            'rules' => "Be concise and specific.\nAvoid clichés and filler.\nUse only the information in the inputs — don't assume missing details.",

            // Model + tuning
            'model' => '',
            // v5.6.2: optionally run this tool THROUGH an AI Agent instead of a
            // single model call. 0 = single-shot (classic). A positive id is an
            // awg_ai_agent post: the tool's form inputs + prompts become the
            // agent's request, and the agent's multi-step reasoning, tools and
            // knowledge produce the result shown in this tool's result box.
            'agent_id' => 0,
            // v5.9.0: "Discuss result with agent" — an optional published AI Agent
            // offered as a button in the result actions row. Clicking it opens an
            // in-place chat (seeded with the generated result) so the visitor can
            // refine or ask follow-ups. Independent of the deprecated agent modes.
            'result_agent_id' => 0,
            'discuss_label'   => '',
            // v5.6.4: standalone "Run as Agent" — the template runs as its own
            // self-contained chat agent (no linked Agent). Uses the template's
            // own System Prompt as the agent instructions and its own Model, plus
            // these optional tool/knowledge settings.
            'agent_standalone'           => 0,
            'agent_tool_ids'             => [],
            'agent_knowledge_enabled'    => 0,
            'agent_knowledge_post_types' => ['post', 'page'],
            'agent_knowledge_text'       => '',
            // v5.7.9: editable overrides for the two system lines the agent
            // runtime adds automatically (blank = built-in default), mirroring
            // the real AI Agent editor so a standalone template-agent has the
            // same control.
            'agent_knowledge_prefix'     => '',
            'agent_tools_nudge'          => '',
            // v5.4.7: temperature controls removed entirely. OpenAI applies each
            // model's own default. Reasoning models (gpt-5*, o-series) tune
            // creativity internally; other models use ~1.0 which is fine for
            // creative writing tasks. Power users can override per-request via
            // the `awg_openai_payload` filter in class-ajax.php.
            'max_output_tokens' => 600,

            // Download format for the result's "Download" button
            'output_format' => 'text', // text (.txt) | pdf
            // v5.4.81: only two result styles remain — 'plain' (minimal prose) and
            // 'document' (Editorial, which renders flat option-lists as cards and
            // richer output as a document). Legacy auto/cards values normalise to
            // Editorial at render time.
            'render_mode' => 'document', // plain | document
            'wrap_in_pre' => 1,
            // v5.4.9: show_copy/show_download/show_clear removed — buttons always shown.

            // Protection
            'allow_guests' => -1,
            'rate_per_min' => 0,  // v5.4.6: 0 = inherit global rate limit
            // v5.4.48: per-template gibberish guard. 'global' inherits the
            // Settings toggle; 'on'/'off' force it for this template only.
            'gibberish_check' => 'global',
            'debug_admin' => 0,

            // Fields array
            'fields' => [
                [
                    'key' => 'genre',
                    'label' => 'Genre',
                    'type' => 'text',
                    'required' => 1,
                    'placeholder' => 'e.g., Mystery, Romance, Fantasy',
                    'options' => '',
                    'default' => '',
                    'icon_class' => '',
                    'icon_size' => 16,
                    'icon_position' => 'before_label',
                    'width' => 'full',
                ],
                [
                    'key' => 'keywords',
                    'label' => 'Keywords',
                    'type' => 'textarea',
                    'required' => 0,
                    'placeholder' => 'Comma-separated keywords',
                    'options' => '',
                    'default' => '',
                    'icon_class' => '',
                    'icon_size' => 16,
                    'icon_position' => 'before_label',
                    'width' => 'full',
                ],
            ],

            'count' => 10,
        ];
    }

    /**
     * Sanitise a raw array of field definitions into the stored field schema.
     *
     * This is the single source of truth for field validation: the admin
     * metabox save() and the Build Assistant's create_generator_template tool
     * both call it, so an agent-built template is validated identically to a
     * hand-built one (same type allowlist, same numeric clamps). Returns the
     * default fields when nothing valid is supplied, mirroring the metabox.
     *
     * @param mixed $fields_in Raw fields (array of arrays) from $_POST or a tool.
     * @return array Cleaned field schema.
     */
    public function sanitize_fields_array($fields_in): array {
        $fields_out = [];
        if (is_array($fields_in)) {
            foreach ($fields_in as $f) {
                if (!is_array($f)) continue;
                $key = sanitize_key($f['key'] ?? '');
                if (!$key) continue;

                $fields_out[] = [
                    'key' => $key,
                    'label' => sanitize_text_field($f['label'] ?? $key),
                    'type' => in_array(($f['type'] ?? 'text'), ['text','textarea','select','number','email','checkbox','radio','file'], true) ? ($f['type'] ?? 'text') : 'text',
                    'required' => !empty($f['required']) ? 1 : 0,
                    'placeholder' => sanitize_text_field($f['placeholder'] ?? ''),
                    'options' => isset($f['options']) ? (string) $f['options'] : '',
                    'default' => sanitize_text_field($f['default'] ?? ''),
                    'icon_class' => $this->sanitize_icon_class($f['icon_class'] ?? ''),
                    'icon_size' => max(10, min(30, intval($f['icon_size'] ?? 16))),
                    'icon_position' => in_array(($f['icon_position'] ?? 'before_label'), ['before_label', 'after_label', 'before_input', 'after_input'], true) ? ($f['icon_position'] ?? 'before_label') : 'before_label',
                    'width' => in_array(($f['width'] ?? 'full'), ['full', 'half', 'third'], true) ? ($f['width'] ?? 'full') : 'full',
                    'file_types' => sanitize_text_field($f['file_types'] ?? ''),
                    'file_max_mb' => max(0, min(50, intval($f['file_max_mb'] ?? 0))),
                ];
            }
        }
        if (empty($fields_out)) {
            $fields_out = $this->template_defaults()['fields'];
        }
        return $fields_out;
    }

    /**
     * Build a complete, sanitised template meta blob from a partial config.
     *
     * Starts from template_defaults() (every styling/protection key already at a
     * safe value) and overlays only the handful of keys a programmatic caller —
     * the Build Assistant's create_generator_template tool — is allowed to set:
     * the prompts, model, output tuning and fields. Everything dangerous or
     * presentation-only keeps its default, and prompts are run through the same
     * sanitize_textarea_field path the metabox uses. The result is ready to hand
     * straight to update_post_meta($id, '_awg_aig_template', …).
     *
     * @param array $config Partial config (loose keys, typically model-supplied).
     * @return array Full template meta.
     */
    public function build_template_meta(array $config): array {
        $m = $this->template_defaults();

        if (isset($config['task']))          $m['task']          = sanitize_text_field((string) $config['task']);
        if (isset($config['form_title']))    $m['form_title']    = sanitize_text_field((string) $config['form_title']);
        if (isset($config['form_description'])) $m['form_description'] = sanitize_text_field((string) $config['form_description']);
        if (isset($config['button_label']))  $m['button_label']  = sanitize_text_field((string) $config['button_label']);
        if (isset($config['success_title'])) $m['success_title'] = sanitize_text_field((string) $config['success_title']);
        if (isset($config['placeholder_output'])) $m['placeholder_output'] = sanitize_text_field((string) $config['placeholder_output']);
        if (isset($config['disclaimer_text']))    $m['disclaimer_text']    = sanitize_text_field((string) $config['disclaimer_text']);
        if (isset($config['title_icon_class']))   $m['title_icon_class']   = $this->sanitize_icon_class($config['title_icon_class']);
        if (isset($config['system_prompt'])) $m['system_prompt'] = sanitize_textarea_field((string) $config['system_prompt']);
        if (isset($config['user_prompt']))   $m['user_prompt']   = sanitize_textarea_field((string) $config['user_prompt']);
        if (isset($config['rules']))         $m['rules']         = sanitize_textarea_field((string) $config['rules']);
        if (isset($config['model']))         $m['model']         = sanitize_text_field((string) $config['model']);

        if (isset($config['max_output_tokens'])) {
            $m['max_output_tokens'] = max(1, min(8000, intval($config['max_output_tokens'])));
        }
        if (isset($config['count'])) {
            $m['count'] = max(1, min(50, intval($config['count'])));
        }
        if (isset($config['output_format'])) {
            $m['output_format'] = in_array($config['output_format'], ['text', 'pdf'], true) ? $config['output_format'] : 'text';
        }
        if (isset($config['render_mode'])) {
            $m['render_mode'] = ($config['render_mode'] === 'plain') ? 'plain' : 'document';
        }

        if (array_key_exists('fields', $config)) {
            $m['fields'] = $this->sanitize_fields_array($config['fields']);
        }

        return $m;
    }

    /**
     * Return template meta.
     *
     * @param int  $post_id                  Template post id.
     * @param bool $apply_global_overrides   When true (default), and "Use global
     *                                       styles" / "Use global field sizes"
     *                                       toggles are on, the corresponding
     *                                       style fields are replaced by the
     *                                       global Settings values. This is what
     *                                       the front-end renderer needs.
     *                                       Pass false from the admin metabox
     *                                       so the editor reads and saves the
     *                                       user's stored per-template values,
     *                                       regardless of the toggle — otherwise
     *                                       toggling the box on then off
     *                                       silently overwrites custom colors
     *                                       with the global palette.
     */
    public function get_template_meta(int $post_id, bool $apply_global_overrides = true): array {
        $m = get_post_meta($post_id, '_awg_aig_template', true);
        if (!is_array($m)) { $m = []; }
        $meta = array_merge($this->template_defaults(), $m);
        $settings = $this->settings->get();

        $meta['use_global_styles'] = isset($meta['use_global_styles']) ? (int) $meta['use_global_styles'] : 1;
        $meta['use_global_field_sizes'] = isset($meta['use_global_field_sizes']) ? (int) $meta['use_global_field_sizes'] : 1;

        if ($apply_global_overrides && $meta['use_global_styles'] === 1) {
            $meta['style_bg_color'] = $this->color_or_default($settings['global_style_bg_color'] ?? '', 'f2ead9');
            $meta['style_text_color'] = $this->color_or_default($settings['global_style_text_color'] ?? '', '33291c');
            $meta['style_border_color'] = $this->color_or_default($settings['global_style_border_color'] ?? '', 'e5dac4');
            $meta['style_accent_color'] = $this->color_or_default($settings['global_style_accent_color'] ?? '', 'c8794f');
            $meta['style_button_bg_color'] = $this->color_or_default($settings['global_style_button_bg_color'] ?? '', '10243c');
            $meta['style_button_text_color'] = $this->color_or_default($settings['global_style_button_text_color'] ?? '', 'f7efe2');
            $meta['style_button_border_color'] = $this->color_or_default($settings['global_style_button_border_color'] ?? '', '10243c');
            $meta['style_padding'] = max(0, min(80, intval($settings['global_style_padding'] ?? 16)));
            $meta['style_margin'] = max(0, min(80, intval($settings['global_style_margin'] ?? 12)));
            foreach (['top', 'right', 'bottom', 'left'] as $side) {
                $meta['style_padding_' . $side] = max(0, min(80, intval($settings['global_style_padding_' . $side] ?? $meta['style_padding'])));
                $meta['style_margin_' . $side]  = max(0, min(80, intval($settings['global_style_margin_' . $side] ?? $meta['style_margin'])));
            }
            $meta['style_radius'] = max(0, min(40, intval($settings['global_style_radius'] ?? 20)));
            $meta['style_button_padding_y'] = max(6, min(30, intval($settings['global_style_button_padding_y'] ?? 10)));
            $meta['style_button_padding_x'] = max(8, min(40, intval($settings['global_style_button_padding_x'] ?? 14)));
            $meta['style_button_radius'] = max(0, min(20, intval($settings['global_style_button_radius'] ?? 12)));
        } else {
            $meta['style_bg_color'] = $this->color_or_default($meta['style_bg_color'] ?? '', 'f2ead9');
            $meta['style_text_color'] = $this->color_or_default($meta['style_text_color'] ?? '', '33291c');
            $meta['style_border_color'] = $this->color_or_default($meta['style_border_color'] ?? '', 'e5dac4');
            $meta['style_accent_color'] = $this->color_or_default($meta['style_accent_color'] ?? '', 'c8794f');
            $meta['style_button_bg_color'] = $this->color_or_default($meta['style_button_bg_color'] ?? '', '10243c');
            $meta['style_button_text_color'] = $this->color_or_default($meta['style_button_text_color'] ?? '', 'f7efe2');
            $meta['style_button_border_color'] = $this->color_or_default($meta['style_button_border_color'] ?? '', '10243c');
            // Per-template styles do not (yet) expose per-side spacing, so mirror
            // the template's single padding/margin onto all four sides.
            $tpl_pad = max(0, min(80, intval($meta['style_padding'] ?? 16)));
            $tpl_mar = max(0, min(80, intval($meta['style_margin'] ?? 12)));
            foreach (['top', 'right', 'bottom', 'left'] as $side) {
                $meta['style_padding_' . $side] = $tpl_pad;
                $meta['style_margin_' . $side]  = $tpl_mar;
            }
        }

        if ($apply_global_overrides && $meta['use_global_field_sizes'] === 1) {
            $meta['style_input_height'] = max(32, min(80, intval($settings['global_style_input_height'] ?? 44)));
            $meta['style_textarea_rows'] = max(2, min(20, intval($settings['global_style_textarea_rows'] ?? 5)));
        } else {
            $meta['style_input_height'] = max(32, min(80, intval($meta['style_input_height'] ?? 44)));
            $meta['style_textarea_rows'] = max(2, min(20, intval($meta['style_textarea_rows'] ?? 5)));
        }

        $meta['button_icon_class'] = $this->sanitize_icon_class($meta['button_icon_class'] ?? '');
        $meta['button_icon_css_class'] = $this->sanitize_icon_class($meta['button_icon_css_class'] ?? '');
        $meta['button_icon_size'] = max(10, min(40, intval($meta['button_icon_size'] ?? 18)));
        $meta['button_icon_position'] = in_array(($meta['button_icon_position'] ?? 'before'), ['before', 'after'], true) ? ($meta['button_icon_position'] ?? 'before') : 'before';
        $meta['title_icon_class'] = $this->sanitize_icon_class($meta['title_icon_class'] ?? '');
        $meta['title_icon_size'] = max(10, min(40, intval($meta['title_icon_size'] ?? 20)));
        $meta['title_icon_position'] = in_array(($meta['title_icon_position'] ?? 'before'), ['before', 'after'], true) ? ($meta['title_icon_position'] ?? 'before') : 'before';
        // Download format: only 'text' (plain .txt) or 'pdf' (formatted PDF).
        // Legacy 'html'/'json' tools normalise to 'text' here — the single source
        // of truth both the front-end and the generate endpoint read.
        $meta['output_format'] = in_array(($meta['output_format'] ?? 'text'), ['text', 'pdf'], true) ? $meta['output_format'] : 'text';
        // v5.4.48: per-template gibberish guard — 'global' | 'on' | 'off'.
        $meta['gibberish_check'] = in_array(($meta['gibberish_check'] ?? 'global'), ['global', 'on', 'off'], true) ? ($meta['gibberish_check'] ?? 'global') : 'global';
        // v5.4.49: per-template opt-out from the global system prompt.
        $meta['apply_global_prompt'] = isset($meta['apply_global_prompt']) ? (int) (!empty($meta['apply_global_prompt'])) : 1;
        // v5.6.2: optional "run via Agent" link (0 = single-shot). Validity
        // (published agent post) is re-checked at generate time.
        $meta['agent_id'] = 0;
        // v5.9.0: "Discuss result with agent" link. Stored as a plain id; validity
        // (published agent post) is re-checked at render and re-enforced server-side.
        $meta['result_agent_id'] = max(0, (int) ($meta['result_agent_id'] ?? 0));
        $meta['discuss_label']   = sanitize_text_field((string) ($meta['discuss_label'] ?? ''));
        // v5.7.9: agent modes were removed from templates — a template always
        // runs as a normal one-shot generator now. Both flags are forced off
        // here (the single source of truth every consumer reads), so any agent
        // settings left in the database from older versions are simply ignored.
        $meta['agent_standalone'] = 0;
        $awg_atids = is_array($meta['agent_tool_ids'] ?? null) ? $meta['agent_tool_ids'] : [];
        $meta['agent_tool_ids'] = array_values(array_unique(array_filter(array_map('intval', $awg_atids))));
        $meta['agent_knowledge_enabled'] = !empty($meta['agent_knowledge_enabled']) ? 1 : 0;
        $awg_akpts = is_array($meta['agent_knowledge_post_types'] ?? null) ? $meta['agent_knowledge_post_types'] : [];
        $meta['agent_knowledge_post_types'] = array_values(array_filter(array_map('sanitize_key', $awg_akpts)));
        if (empty($meta['agent_knowledge_post_types'])) {
            $meta['agent_knowledge_post_types'] = ['post', 'page'];
        }
        $meta['agent_knowledge_text'] = (string) ($meta['agent_knowledge_text'] ?? '');
        $meta['agent_knowledge_prefix'] = (string) ($meta['agent_knowledge_prefix'] ?? '');
        $meta['agent_tools_nudge'] = (string) ($meta['agent_tools_nudge'] ?? '');
        $meta['form_design'] = in_array(($meta['form_design'] ?? 'global'), ['global', 'branded', 'plain'], true) ? ($meta['form_design'] ?? 'global') : 'global';
        $meta['header_icon_position'] = in_array(($meta['header_icon_position'] ?? 'global'), ['global', 'top', 'left'], true) ? ($meta['header_icon_position'] ?? 'global') : 'global';
        $meta['title_font'] = in_array(($meta['title_font'] ?? 'global'), ['global', 'serif', 'sans'], true) ? ($meta['title_font'] ?? 'global') : 'global';
        // v5.4.26: branded header overrides.
        $meta['brand_eyebrow_mode'] = in_array(($meta['brand_eyebrow_mode'] ?? 'global'), ['global', 'custom'], true) ? ($meta['brand_eyebrow_mode'] ?? 'global') : 'global';
        $meta['header_show_rule'] = in_array(($meta['header_show_rule'] ?? 'global'), ['global', 'yes', 'no'], true) ? ($meta['header_show_rule'] ?? 'global') : 'global';
        $meta['header_subtitle_italic'] = in_array(($meta['header_subtitle_italic'] ?? 'global'), ['global', 'yes', 'no'], true) ? ($meta['header_subtitle_italic'] ?? 'global') : 'global';
        foreach (['brand_title_color', 'brand_subtitle_color', 'brand_eyebrow_color', 'brand_badge_bg_color', 'brand_badge_icon_color', 'brand_rule_color'] as $bk) {
            $bv = ltrim(strtolower(trim((string) ($meta[$bk] ?? ''))), '#');
            $meta[$bk] = preg_match('/^[0-9a-f]{6}$/', $bv) ? $bv : '';
        }

        if (is_array($meta['fields'])) {
            foreach ($meta['fields'] as $idx => $field) {
                if (!is_array($field)) {
                    continue;
                }
                $meta['fields'][$idx]['icon_class'] = $this->sanitize_icon_class($field['icon_class'] ?? '');
                $meta['fields'][$idx]['icon_size'] = max(10, min(30, intval($field['icon_size'] ?? 16)));
                $meta['fields'][$idx]['icon_position'] = in_array(($field['icon_position'] ?? 'before_label'), ['before_label', 'after_label', 'before_input', 'after_input'], true) ? ($field['icon_position'] ?? 'before_label') : 'before_label';
                // v5.4.21: per-field layout width. full = one per row (legacy
                // behaviour, and the fallback for fields saved before this key
                // existed), half = two per row on wide screens, third = three.
                $field_width_value = $field['width'] ?? 'full';
                $meta['fields'][$idx]['width'] = in_array($field_width_value, ['full', 'half', 'third'], true)
                    ? $field_width_value
                    : 'full';
                // v5.4.69: upload-field config. Stored as a raw comma list of
                // extensions + a max size in MB; normalised lazily at render /
                // upload time via file_accept_list()/file_max_mb().
                $meta['fields'][$idx]['file_types'] = isset($field['file_types']) ? (string) $field['file_types'] : '';
                $meta['fields'][$idx]['file_max_mb'] = max(0, min(50, intval($field['file_max_mb'] ?? 0)));
            }
        }

        return $meta;
    }

    public function shortcode($atts): string {
        $atts = shortcode_atts(['id' => 0], $atts, 'awg_generator');
        $id = intval($atts['id']);
        if ($id <= 0) return '';
        return $this->render_form($id);
    }

    /**
     * Build the admin-only, nonce-protected URL that renders a template through
     * the active theme (used as the preview iframe's src). The CPT is
     * non-public, so this is a query-arg on the site home rather than the post's
     * own (unavailable) permalink.
     */
    public function preview_url(int $template_id): string {
        return add_query_arg(
            [
                'awg_aig_preview' => $template_id,
                '_wpnonce'        => wp_create_nonce('awg_aig_preview_' . $template_id),
            ],
            home_url('/')
        );
    }

    /**
     * Front-end render route for the admin preview iframe. Detects the
     * awg_aig_preview query arg on a normal front-end request and, for an
     * authorised admin, outputs a standalone document via wp_head()/wp_footer()
     * so the tool inherits the active theme exactly as the [awg_generator]
     * shortcode would — fonts, colours, stylesheet and all — then exits.
     *
     * Guests and users without edit access never reach the render: the request
     * falls through untouched and WordPress serves the normal home page.
     */
    public function maybe_render_preview(): void {
        if (empty($_GET['awg_aig_preview'])) {
            return;
        }
        $template_id = (int) $_GET['awg_aig_preview'];
        if ($template_id <= 0) {
            return;
        }

        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
        if (!wp_verify_nonce($nonce, 'awg_aig_preview_' . $template_id)) {
            return;
        }
        if (!current_user_can('edit_post', $template_id)) {
            return;
        }
        $post = get_post($template_id);
        if (!$post || $post->post_type !== $this->cpt) {
            return;
        }

        // This is a private, single-use admin preview — keep it out of caches
        // and search results, and hide the admin bar so the frame matches what
        // a visitor sees.
        nocache_headers();
        add_filter('show_admin_bar', '__return_false');
        if (!headers_sent()) {
            header('X-Robots-Tag: noindex, nofollow', true);
        }

        // Render the form first so its front-end assets are enqueued before
        // wp_head() prints the queue (the theme's own styles enqueue during
        // wp_head as usual, giving a true theme-accurate result).
        $form_html = $this->render_form($template_id);

        ?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php echo esc_attr(get_bloginfo('charset')); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<?php wp_head(); ?>
<style>
    /* Stop the theme from padding this single-tool page out to full viewport
     * height (many themes set min-height:100vh on the body/page wrapper), which
     * would otherwise leave a large blank area under the tool in the preview. */
    html.awg-aig-preview-html, body.awg-aig-preview-frame{min-height:0 !important;height:auto !important;margin:0;padding:0;background:#fff;}
    .awg-aig-preview-frame__shell{max-width:760px;margin:32px auto;padding:0 20px;box-sizing:border-box;}
</style>
</head>
<body <?php body_class('awg-aig-preview-frame'); ?>>
    <div class="awg-aig-preview-frame__shell">
        <?php echo $form_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plugin-rendered, escaped markup ?>
    </div>
<?php wp_footer(); ?>
<script>
/* Report this frame's height to the admin preview page so the iframe can grow
 * with the tool (including after a generation expands the result), giving one
 * natural scroll instead of a nested scrollbar. We measure the tool wrapper
 * itself — not document height — so a theme's min-height:100vh stretching never
 * inflates the frame with empty space below the tool. */
(function(){
    document.documentElement.className += ' awg-aig-preview-html';
    if (window.parent === window) { return; }
    var shell = document.querySelector('.awg-aig-preview-frame__shell');
    var last = 0;
    function report(){
        var h;
        if (shell) {
            var rect = shell.getBoundingClientRect();
            // rect.height excludes the shell's top/bottom margin (32px each).
            h = Math.ceil(rect.height) + 64;
        } else {
            h = document.body ? document.body.scrollHeight : 0;
        }
        if (h && h !== last) {
            last = h;
            window.parent.postMessage({ awgPreviewHeight: h }, '*');
        }
    }
    window.addEventListener('load', report);
    window.addEventListener('resize', report);
    if (window.ResizeObserver && shell) {
        new ResizeObserver(report).observe(shell);
    }
    setInterval(report, 800);
})();
</script>
</body>
</html>
<?php
        exit;
    }

    public function render_form(int $template_id): string {
        $p = get_post($template_id);
        if (!$p || $p->post_type !== $this->cpt) return '';

        // Membership integration: render-time guest gate.
        // Mirrors v5.4.18's AJAX submit-time check (class-ajax.php allow_guests
        // logic) so a guest sees a clear "Please log in" notice up front
        // instead of being allowed to fill a form that will reject on submit.
        // Only runs when the membership plugin is active so sites without it
        // keep v5.4.18's original submit-time-only behaviour unchanged.
        if (defined('AWG_MEM_VERSION') && !is_user_logged_in()) {
            $awg_mem_required_plan = get_post_meta($template_id, '_awg_mem_required_plan', true) ?: 'free';
            if (!in_array($awg_mem_required_plan, ['free', 'basic', 'pro', 'publisher'], true)) {
                $awg_mem_required_plan = 'free';
            }
            $awg_mem_is_paid_tool = ($awg_mem_required_plan !== 'free');

            $awg_mem_raw_meta = get_post_meta($template_id, '_awg_aig_template', true);
            $awg_mem_template_allow = (is_array($awg_mem_raw_meta) && isset($awg_mem_raw_meta['allow_guests']))
                ? (int) $awg_mem_raw_meta['allow_guests']
                : -1;
            $awg_mem_global_settings = $this->settings->get();
            $awg_mem_global_allow = (int) ($awg_mem_global_settings['allow_guests'] ?? 0);
            $awg_mem_allow_resolved = ($awg_mem_template_allow === -1)
                ? $awg_mem_global_allow
                : $awg_mem_template_allow;

            // Paid-plan tools ALWAYS gate guests (a logged-out visitor can never
            // satisfy a paid plan, so don't let them fill a form that will be
            // rejected on submit). Free tools gate guests only when "Allow
            // guests" is off.
            if ($awg_mem_is_paid_tool || !$awg_mem_allow_resolved) {
                // Return the visitor to the page they're actually on (the page
                // embedding this shortcode) after logging in — NOT the tool's
                // own post-type URL, which is non-public and would 404.
                $awg_mem_redirect = '';
                $awg_mem_qid = get_queried_object_id();
                if ($awg_mem_qid) {
                    $awg_mem_redirect = get_permalink($awg_mem_qid);
                }
                if (!$awg_mem_redirect && !empty($_SERVER['REQUEST_URI'])) {
                    $awg_mem_redirect = home_url(esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'])));
                }
                if (!$awg_mem_redirect) {
                    $awg_mem_redirect = home_url('/');
                }
                $awg_mem_login_url = function_exists('awg_mem_get_login_url')
                    ? awg_mem_get_login_url($awg_mem_redirect)
                    : wp_login_url($awg_mem_redirect);

                if (!$awg_mem_is_paid_tool) {
                    return '<div class="awg-aig awg-aig--notice">'
                        . '<div class="awg-aig__title">' . esc_html__('Login required', 'authorwings-ai-tools') . '</div>'
                        . '<div class="awg-aig__desc">'
                        . esc_html__('Please log in to use this generator.', 'authorwings-ai-tools')
                        . ' <a href="' . esc_url($awg_mem_login_url) . '">' . esc_html__('Log in', 'authorwings-ai-tools') . '</a>'
                        . ' <a href="' . esc_url(function_exists('awg_mem_get_pricing_url') ? awg_mem_get_pricing_url() : home_url('/pricing/')) . '">' . esc_html__('Create account', 'authorwings-ai-tools') . '</a>'
                        . '</div></div>';
                }

                $awg_mem_upgrade_url = function_exists('awg_mem_get_upgrade_url')
                    ? awg_mem_get_upgrade_url($awg_mem_required_plan)
                    : (function_exists('awg_mem_get_pricing_url') ? awg_mem_get_pricing_url() : home_url('/pricing/'));
                return '<div class="awg-aig awg-aig--notice">'
                    . '<div class="awg-aig__title">' . esc_html__('Subscribe to use this tool', 'authorwings-ai-tools') . '</div>'
                    . '<div class="awg-aig__desc">'
                    . esc_html(sprintf(
                        /* translators: %s: required plan name */
                        __('This generator is part of the %s plan and higher. Log in or choose a plan to continue.', 'authorwings-ai-tools'),
                        ucfirst($awg_mem_required_plan)
                    ))
                    . ' <a href="' . esc_url($awg_mem_login_url) . '">' . esc_html__('Log in', 'authorwings-ai-tools') . '</a>'
                    . ' <a href="' . esc_url($awg_mem_upgrade_url) . '">' . esc_html__('View plans', 'authorwings-ai-tools') . '</a>'
                    . '</div></div>';
            }
        }

        // Membership integration: gate the entire form render based on the
        // member's plan. Only runs when the membership plugin is active. If
        // the filter returns an empty array, the template is hidden from this
        // user and we render an "upgrade" notice instead of the form.
        // No-op for sites without the membership plugin.
        if (defined('AWG_MEM_VERSION')) {
            $awg_mem_visible = apply_filters('awg_aig_visible_templates', [$p], get_current_user_id());
            if (empty($awg_mem_visible)) {
                $awg_mem_required = get_post_meta($template_id, '_awg_mem_required_plan', true) ?: 'free';
                if (!in_array($awg_mem_required, ['free', 'basic', 'pro', 'publisher'], true)) {
                    $awg_mem_required = 'free';
                }
                $awg_mem_upgrade_url = function_exists('awg_mem_get_upgrade_url')
                    ? awg_mem_get_upgrade_url($awg_mem_required !== 'free' ? $awg_mem_required : '')
                    : (function_exists('awg_mem_get_pricing_url') ? awg_mem_get_pricing_url() : home_url('/pricing/'));
                $awg_mem_label = ucfirst($awg_mem_required);
                return '<div class="awg-aig awg-aig--notice">'
                    . '<div class="awg-aig__title">' . esc_html__('Generator unavailable', 'authorwings-ai-tools') . '</div>'
                    . '<div class="awg-aig__desc">'
                    . esc_html(sprintf(
                        /* translators: %s: required plan name */
                        __('Your current membership does not include this generator. It requires the %s plan or higher.', 'authorwings-ai-tools'),
                        $awg_mem_label
                    ))
                    . ' <a href="' . esc_url($awg_mem_upgrade_url) . '">'
                    . esc_html__('Upgrade your plan', 'authorwings-ai-tools')
                    . '</a></div></div>';
            }
        }

        // Only load assets when generator exists on the page.
        $plugin = Plugin::instance();
        if (!empty($plugin->assets)) {
            $plugin->assets->enqueue_front_assets();
        }

        $m = $this->get_template_meta($template_id);
        $settings = $this->settings->get();
        $file_stub = sanitize_file_name($p->post_title ?: ('generator-' . $template_id));

        // v5.4.19: Custom HTML design mode. When on (and markup is present) the
        // admin's form HTML replaces the auto-generated Fields loop. Everything
        // else around the form (wrapper, styles, result panel, JS pipeline) is
        // shared, and every named input still flows to the AI as {{fields}}.
        // Empty custom_html falls back to the standard renderer so a half-set-up
        // template is never broken.
        $awg_is_custom = (($m['design_mode'] ?? 'standard') === 'custom_html')
            && (trim((string) ($m['custom_html'] ?? '')) !== '');

        // v5.4.24: resolve the effective header design. A per-template value of
        // 'global' defers to the Settings defaults; anything else overrides.
        $awg_design = ($m['form_design'] ?? 'global');
        if ($awg_design === 'global') { $awg_design = ($settings['form_design'] ?? 'branded'); }
        $awg_branded = ($awg_design === 'branded');
        $awg_icon_pos = ($m['header_icon_position'] ?? 'global');
        if ($awg_icon_pos === 'global') { $awg_icon_pos = ($settings['header_icon_position'] ?? 'top'); }
        $awg_icon_pos = in_array($awg_icon_pos, ['top', 'left'], true) ? $awg_icon_pos : 'top';
        $awg_title_font = ($m['title_font'] ?? 'global');
        if ($awg_title_font === 'global') { $awg_title_font = ($settings['title_font'] ?? 'serif'); }
        $awg_title_font = in_array($awg_title_font, ['serif', 'sans'], true) ? $awg_title_font : 'serif';

        // v5.4.26: eyebrow / rule / italic now support per-template overrides.
        // Eyebrow uses a mode select ('global' | 'custom'); custom pulls the
        // template's own text. Rule + italic use 'global' | 'yes' | 'no'.
        $awg_eyebrow_mode = ($m['brand_eyebrow_mode'] ?? 'global');
        $awg_eyebrow = ($awg_eyebrow_mode === 'custom')
            ? trim((string) ($m['brand_eyebrow'] ?? ''))
            : trim((string) ($settings['brand_eyebrow'] ?? ''));
        $awg_rule_sel = ($m['header_show_rule'] ?? 'global');
        $awg_show_rule = ($awg_rule_sel === 'global') ? !empty($settings['header_show_rule']) : ($awg_rule_sel === 'yes');
        $awg_italic_sel = ($m['header_subtitle_italic'] ?? 'global');
        $awg_sub_italic = ($awg_italic_sel === 'global') ? !empty($settings['header_subtitle_italic']) : ($awg_italic_sel === 'yes');

        // v5.4.26: branded-only colours. A per-template value wins when set;
        // otherwise the global Settings value applies. (Both default to the warm
        // palette, and the CSS carries accent/text fallbacks as a last resort.)
        $awg_brand_color = static function (string $key) use ($m, $settings): string {
            $t = trim((string) ($m[$key] ?? ''));
            if ($t !== '') { return ltrim($t, '#'); }
            return ltrim(trim((string) ($settings[$key] ?? '')), '#');
        };

        ob_start();

        // Pull global colors from settings (always - these are the extended
        // slots that templates don't override individually). Fallbacks below
        // mirror the AuthorWings.com brand palette defined in Settings::brand_palette().
        $g_input_bg          = $this->color_or_default($settings['global_style_input_bg_color']           ?? '', 'fbf8f2');
        $g_placeholder       = $this->color_or_default($settings['global_style_placeholder_color']        ?? '', '8b7e6f');
        $g_required          = $this->color_or_default($settings['global_style_required_color']           ?? '', 'c97a5e');
        $g_btn_hover_bg      = $this->color_or_default($settings['global_style_button_hover_bg_color']    ?? '', '7e9374');
        $g_btn_hover_text    = $this->color_or_default($settings['global_style_button_hover_text_color']  ?? '', 'ffffff');
        $g_btn_active_bg     = $this->color_or_default($settings['global_style_button_active_bg_color']   ?? '', '0a1a2d');
        $g_focus_ring        = $this->color_or_default($settings['global_style_focus_ring_color']         ?? '', '7e9374');
        $g_action_bg         = $this->color_or_default($settings['global_style_action_btn_bg_color']      ?? '', '7e9374');
        $g_action_text       = $this->color_or_default($settings['global_style_action_btn_text_color']    ?? '', 'ffffff');
        $g_action_border     = $this->color_or_default($settings['global_style_action_btn_border_color']  ?? '', '7e9374');
        $g_action_hover_bg   = $this->color_or_default($settings['global_style_action_btn_hover_bg_color']   ?? '', '10243c');
        $g_action_hover_text = $this->color_or_default($settings['global_style_action_btn_hover_text_color'] ?? '', 'ffffff');
        $g_output_bg         = $this->color_or_default($settings['global_style_output_bg_color']           ?? '', 'ffffff');
        $g_grad_top          = $this->color_or_default($settings['global_style_output_gradient_top_color'] ?? '', 'ffffff');
        $g_grad_bot          = $this->color_or_default($settings['global_style_output_gradient_bot_color'] ?? '', 'fbf8f2');
        $g_code_bg           = $this->color_or_default($settings['global_style_code_bg_color']             ?? '', 'f2eae0');
        $g_badge_bg          = $this->color_or_default($settings['global_style_badge_bg_color']            ?? '', 'e1e8d8');
        $g_badge_text        = $this->color_or_default($settings['global_style_badge_text_color']          ?? '', '10243c');
        $g_shadow_hex        = $this->color_or_default($settings['global_style_shadow_color']              ?? '', '10243c');

        // Convert a bare hex to an rgba string at a given alpha.
        $hex_to_rgba = static function (string $hex, float $alpha): string {
            $hex = ltrim($hex, '#');
            if (strlen($hex) === 3) {
                $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
            }
            if (!preg_match('/^[0-9a-f]{6}$/i', $hex)) {
                return 'rgba(3,12,23,' . $alpha . ')';
            }
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
            return sprintf('rgba(%d,%d,%d,%.3f)', $r, $g, $b, $alpha);
        };

        $shadow_rgba     = $hex_to_rgba($g_shadow_hex, 0.06);
        $focus_ring_rgba = $hex_to_rgba($g_focus_ring, 0.22);

        // Container spacing is now per-side. Compose CSS shorthand strings
        // (top right bottom left) so existing rules using --awg-pad / --awg-margin
        // keep working unchanged while honouring each side.
        $pad_shorthand = sprintf(
            '%dpx %dpx %dpx %dpx',
            (int) ($m['style_padding_top']    ?? $m['style_padding']),
            (int) ($m['style_padding_right']  ?? $m['style_padding']),
            (int) ($m['style_padding_bottom'] ?? $m['style_padding']),
            (int) ($m['style_padding_left']   ?? $m['style_padding'])
        );
        $margin_shorthand = sprintf(
            '%dpx %dpx %dpx %dpx',
            (int) ($m['style_margin_top']    ?? $m['style_margin']),
            (int) ($m['style_margin_right']  ?? $m['style_margin']),
            (int) ($m['style_margin_bottom'] ?? $m['style_margin']),
            (int) ($m['style_margin_left']   ?? $m['style_margin'])
        );

        $style = sprintf(
            '--awg-bg:#%1$s;--awg-text:#%2$s;--awg-border:#%3$s;--awg-accent:#%4$s;'
            . '--awg-pad:%5$s;--awg-margin:%6$s;--awg-radius:%7$spx;'
            . '--awg-btn-bg:#%8$s;--awg-btn-text:#%9$s;--awg-btn-border:#%10$s;'
            . '--awg-btn-pad-y:%11$spx;--awg-btn-pad-x:%12$spx;--awg-btn-radius:%13$spx;'
            . '--awg-input-height:%14$spx;--awg-textarea-rows:%15$s;'
            . '--awg-input-bg:#%16$s;--awg-placeholder:#%17$s;--awg-required:#%18$s;'
            . '--awg-btn-hover-bg:#%19$s;--awg-btn-hover-text:#%20$s;--awg-btn-active-bg:#%21$s;'
            . '--awg-focus-ring:%22$s;'
            . '--awg-action-btn-bg:#%23$s;--awg-action-btn-text:#%24$s;--awg-action-btn-border:#%25$s;'
            . '--awg-action-btn-hover-bg:#%26$s;--awg-action-btn-hover-text:#%27$s;'
            . '--awg-output-bg:#%28$s;--awg-output-gradient-top:#%29$s;--awg-output-gradient-bot:#%30$s;'
            . '--awg-code-bg:#%31$s;--awg-badge-bg:#%32$s;--awg-badge-text:#%33$s;'
            . '--awg-shadow:%34$s;--awg-btn-icon-size:%35$spx;',
            esc_attr($m['style_bg_color']),
            esc_attr($m['style_text_color']),
            esc_attr($m['style_border_color']),
            esc_attr($m['style_accent_color']),
            esc_attr($pad_shorthand),
            esc_attr($margin_shorthand),
            esc_attr((int) $m['style_radius']),
            esc_attr($m['style_button_bg_color']),
            esc_attr($m['style_button_text_color']),
            esc_attr($m['style_button_border_color']),
            esc_attr((int) $m['style_button_padding_y']),
            esc_attr((int) $m['style_button_padding_x']),
            esc_attr((int) $m['style_button_radius']),
            esc_attr((int) $m['style_input_height']),
            esc_attr((int) $m['style_textarea_rows']),
            esc_attr($g_input_bg),
            esc_attr($g_placeholder),
            esc_attr($g_required),
            esc_attr($g_btn_hover_bg),
            esc_attr($g_btn_hover_text),
            esc_attr($g_btn_active_bg),
            esc_attr($focus_ring_rgba),
            esc_attr($g_action_bg),
            esc_attr($g_action_text),
            esc_attr($g_action_border),
            esc_attr($g_action_hover_bg),
            esc_attr($g_action_hover_text),
            esc_attr($g_output_bg),
            esc_attr($g_grad_top),
            esc_attr($g_grad_bot),
            esc_attr($g_code_bg),
            esc_attr($g_badge_bg),
            esc_attr($g_badge_text),
            esc_attr($shadow_rgba),
            esc_attr((int) $m['button_icon_size'])
        );

        // v5.4.26: branded no longer overrides the per-template/global colour
        // pickers. Those already drive every core variable in $style above, so
        // the branded design is now fully editable from Settings and per
        // template. Here we only append the branded-SPECIFIC variables that have
        // no core equivalent (header title/subtitle/eyebrow, the icon badge, the
        // accent rule, and the derived "thinking" tint).
        if ($awg_branded) {
            $brand_extra_map = [
                'brand_title_color'      => '--awg-title',
                'brand_subtitle_color'   => '--awg-subtitle',
                'brand_eyebrow_color'    => '--awg-eyebrow',
                'brand_badge_bg_color'   => '--awg-badge-icon-bg',
                'brand_badge_icon_color' => '--awg-badge-icon-color',
                'brand_rule_color'       => '--awg-rule-color',
            ];
            foreach ($brand_extra_map as $key => $var) {
                $hex = $awg_brand_color($key);
                if (preg_match('/^[0-9a-f]{3,6}$/i', $hex)) {
                    $style .= $var . ':#' . $hex . ';';
                }
            }
            // Thinking tint is derived from the (now editable) accent colour.
            $style .= '--awg-thinking-bg:' . $hex_to_rgba(ltrim((string) $m['style_accent_color'], '#'), 0.10) . ';';
        }
        // v5.4.48: resolve the effective gibberish guard for this template and
        // expose it to front.js via data-attributes. The server re-resolves and
        // re-enforces the same thing in class-ajax.php — these attributes only
        // drive the instant client-side check, they are not the authority.
        $awg_gib_mode = ($m['gibberish_check'] ?? 'global');
        if ($awg_gib_mode === 'on') {
            $awg_gib_on = true;
        } elseif ($awg_gib_mode === 'off') {
            $awg_gib_on = false;
        } else {
            $awg_gib_on = !empty($settings['gibberish_check']);
        }
        $awg_gib_min = max(0, min(50, (int) ($settings['gibberish_min_length'] ?? 4)));

        $awg_wrap_classes = 'awg-aig';
        if ($awg_branded) {
            $awg_wrap_classes .= ' awg-aig--branded awg-aig--icon-' . $awg_icon_pos . ' awg-aig--title-' . $awg_title_font;
            if ($awg_sub_italic) { $awg_wrap_classes .= ' awg-aig--sub-italic'; }
        }

        // v5.6.4: "Run via Agent" UX. When this tool is linked to a published
        // agent, submitting opens an in-place chat window (styled like the result
        // area) seeded with the form inputs, instead of returning a single result.
        // front.js reads data-agent-mode to route the submit through the
        // conversational endpoints; the server re-validates the link and gating.
        $awg_agent_mode = 0;
        $awg_engine_ok  = class_exists('\\AWG_AIG\\Agent\\Agent') && class_exists('\\AWG_AIG\\Agent\\Agent_Runtime');
        $awg_agent_link = (int) ($m['agent_id'] ?? 0);
        if ($awg_engine_ok && $awg_agent_link > 0) {
            $awg_agent_post = get_post($awg_agent_link);
            if ($awg_agent_post
                && $awg_agent_post->post_type === \AWG_AIG\Agent\Agent::CPT
                && $awg_agent_post->post_status === 'publish') {
                $awg_agent_mode = 1;
            }
        }
        // v5.6.4: a template with standalone agent mode on is its own agent.
        if (!$awg_agent_mode && $awg_engine_ok && !empty($m['agent_standalone'])) {
            $awg_agent_mode = 1;
        }
        if ($awg_agent_mode) { $awg_wrap_classes .= ' awg-aig--agent'; }

        // v5.9.0: "Discuss result with agent". Resolve the linked agent (must be a
        // published awg_ai_agent) and prepare the data attributes front.js needs to
        // open an in-place chat. Server re-validates the agent + gating on each turn.
        $awg_discuss_id    = 0;
        $awg_discuss_attrs = '';
        $awg_discuss_label = '';
        $awg_rid = (int) ($m['result_agent_id'] ?? 0);
        if ($awg_engine_ok && $awg_rid > 0) {
            $awg_rpost = get_post($awg_rid);
            if ($awg_rpost
                && $awg_rpost->post_type === \AWG_AIG\Agent\Agent::CPT
                && $awg_rpost->post_status === 'publish') {
                $awg_discuss_id = $awg_rid;
                $awg_ameta = \AWG_AIG\Agent\Agent::get_meta($awg_discuss_id);
                $awg_discuss_label = trim((string) ($m['discuss_label'] ?? '')) !== ''
                    ? (string) $m['discuss_label']
                    : __('Discuss with assistant', 'authorwings-ai-tools');
                $awg_discuss_attrs = ' data-discuss-agent-id="' . esc_attr((string) $awg_discuss_id) . '"'
                    . ' data-discuss-nonce="' . esc_attr(wp_create_nonce('awg_agent_front')) . '"'
                    . ' data-discuss-greeting="' . esc_attr((string) $awg_ameta['greeting']) . '"'
                    . ' data-discuss-placeholder="' . esc_attr((string) $awg_ameta['placeholder']) . '"';
                // v5.9.5: carry the agent's "Suggested prompts" into the Discuss
                // flow too, so they render as clickable chips like they do on the
                // standalone agent page (front.js reads data-discuss-starters).
                $awg_discuss_starters = \AWG_AIG\Agent\Agent::starters((string) ($awg_ameta['starters'] ?? ''));
                if (!empty($awg_discuss_starters)) {
                    $awg_discuss_attrs .= ' data-discuss-starters="' . esc_attr((string) wp_json_encode(array_values($awg_discuss_starters))) . '"';
                }
            }
        }
        ?>
        <div class="<?php echo esc_attr($awg_wrap_classes); ?>" data-template-id="<?php echo esc_attr($template_id); ?>" data-design-mode="<?php echo esc_attr($awg_is_custom ? 'custom' : 'standard'); ?>" data-agent-mode="<?php echo esc_attr($awg_agent_mode); ?>" data-gibberish="<?php echo esc_attr($awg_gib_on ? '1' : '0'); ?>" data-gibberish-min="<?php echo esc_attr($awg_gib_min); ?>"<?php echo $awg_discuss_attrs; ?> style="<?php echo esc_attr($style); ?>">
            <?php if ($awg_branded): ?>
                <?php $awg_badge = $this->branded_badge_icon($this->sanitize_icon_class($m['title_icon_class'] ?? '')); ?>
                <div class="awg-aig__header">
                    <span class="awg-aig__badge"><?php echo $awg_badge; ?></span>
                    <div class="awg-aig__heading">
                        <?php if ($awg_eyebrow !== ''): ?><div class="awg-aig__eyebrow"><?php echo esc_html($awg_eyebrow); ?></div><?php endif; ?>
                        <div class="awg-aig__title"><span><?php echo esc_html($m['form_title']); ?></span></div>
                        <?php if ($awg_show_rule): ?><div class="awg-aig__rule"></div><?php endif; ?>
                        <?php if (!empty($m['form_description'])): ?><div class="awg-aig__subtitle"><?php echo esc_html($m['form_description']); ?></div><?php endif; ?>
                    </div>
                </div>
                <div class="awg-aig__head-divider"></div>
            <?php else: ?>
                <?php $title_icon = $this->render_icon($this->sanitize_icon_class($m['title_icon_class'] ?? ''), max(10, min(40, intval($m['title_icon_size'] ?? 20))), 'awg-aig__title-icon'); ?>
                <div class="awg-aig__title">
                    <?php if ($title_icon && ($m['title_icon_position'] ?? 'before') === 'before') { echo $title_icon; } ?>
                    <span><?php echo esc_html($m['form_title']); ?></span>
                    <?php if ($title_icon && ($m['title_icon_position'] ?? 'before') === 'after') { echo $title_icon; } ?>
                </div>
                <?php if (!empty($m['form_description'])): ?>
                    <div class="awg-aig__desc"><?php echo esc_html($m['form_description']); ?></div>
                <?php endif; ?>
            <?php endif; ?>

            <form class="awg-aig__form">
                <?php if (!empty($settings['enable_gclid'])): ?>
                    <input type="hidden" name="gclid" class="awg-aig__input awg-aig__gclid" value="">
                <?php endif; ?>
                <?php if (!empty($settings['enable_utm'])):
                    foreach (['utm_source','utm_medium','utm_campaign','utm_term','utm_content'] as $utm_key): ?>
                    <input type="hidden" name="<?php echo esc_attr($utm_key); ?>" class="awg-aig__input awg-aig__utm" data-utm-key="<?php echo esc_attr($utm_key); ?>" value="">
                <?php endforeach; endif; ?>
                <?php if ($awg_is_custom): ?>
                    <?php // v5.9.6: output admin-authored markup AS STORED, exactly
                    // like the WordPress core "Custom HTML" block in posts/pages.
                    // Sanitisation happens at SAVE/IMPORT time based on the author's
                    // capability (unfiltered_html), so we must NOT re-kses here or a
                    // legitimately-saved <script>/<style> would be stripped on the
                    // front-end. Inputs need a name attribute to be collected; an
                    // optional data-awg-label controls how each shows in the AI prompt.
                    echo (string) $m['custom_html']; ?>
                    <?php // Always provide a status node so errors/notices surface
                    // even if the admin's markup omits one. ?>
                    <span class="awg-aig__status" aria-live="polite"></span>
                <?php else: ?>
                <?php foreach ($m['fields'] as $f):
                    $key = sanitize_key($f['key']);
                    if ($key === '') {
                        continue;
                    }
                    $label = esc_html($f['label']);
                    $allowed_types = ['text', 'textarea', 'select', 'number', 'email', 'checkbox', 'radio', 'file'];
                    $type = in_array(($f['type'] ?? 'text'), $allowed_types, true) ? ($f['type'] ?? 'text') : 'text';
                    $req = !empty($f['required']);
                    $ph = esc_attr($f['placeholder'] ?? '');
                    $def_raw = (string)($f['default'] ?? '');
                    $name = esc_attr($key);
                    $field_icon = $this->sanitize_icon_class($f['icon_class'] ?? '');
                    $field_icon_size = max(10, min(30, intval($f['icon_size'] ?? 16)));
                    $field_icon_position = in_array(($f['icon_position'] ?? 'before_label'), ['before_label', 'after_label', 'before_input', 'after_input'], true) ? ($f['icon_position'] ?? 'before_label') : 'before_label';
                    $field_icon_markup = $this->render_icon($field_icon, $field_icon_size, 'awg-aig__field-icon');
                    // v5.4.21: per-field width -> layout modifier class. Unknown /
                    // missing values fall back to full so legacy fields render
                    // exactly as before (one field per row).
                    $field_width_raw = $f['width'] ?? 'full';
                    $field_width = in_array($field_width_raw, ['full', 'half', 'third'], true) ? $field_width_raw : 'full';
                    $field_width_class = ' awg-aig__field--' . $field_width;
                ?>
                    <div class="awg-aig__field<?php echo esc_attr($field_width_class); ?>">
                        <label class="awg-aig__label">
                            <?php if ($field_icon_markup && $field_icon_position === 'before_label') { echo $field_icon_markup; } ?>
                            <span><?php echo $label; ?><?php echo $req ? ' <span class="awg-aig__req">*</span>' : ''; ?></span>
                            <?php if ($field_icon_markup && $field_icon_position === 'after_label') { echo $field_icon_markup; } ?>
                        </label>

                        <?php if ($field_icon_markup && $field_icon_position === 'before_input') { echo $field_icon_markup; } ?>
                        <?php if ($type === 'textarea'): ?>
                            <textarea class="awg-aig__input awg-aig__textarea" rows="<?php echo esc_attr((int) $m['style_textarea_rows']); ?>" name="<?php echo $name; ?>" placeholder="<?php echo $ph; ?>" <?php echo $req ? 'required' : ''; ?>><?php echo esc_textarea($def_raw); ?></textarea>

                        <?php elseif ($type === 'select'): ?>
                            <?php
                                $raw_opts = (string)($f['options'] ?? '');
                                $opts = preg_split('/[\r\n,]+/', $raw_opts);
                                $opts = array_values(array_filter(array_map('trim', $opts), static function ($opt) {
                                    return $opt !== '';
                                }));
                                $default_val = trim($def_raw);
                            ?>
                            <select class="awg-aig__input" name="<?php echo $name; ?>" <?php echo $req ? 'required' : ''; ?>>
                                <option value=""><?php echo $ph ? esc_html($ph) : esc_html__('Select…', 'authorwings-ai-tools'); ?></option>
                                <?php foreach ($opts as $opt): ?>
                                    <option value="<?php echo esc_attr($opt); ?>" <?php selected($default_val, $opt); ?>>
                                        <?php echo esc_html($opt); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                        <?php elseif ($type === 'checkbox'): ?>
                            <?php
                                $raw_opts = (string)($f['options'] ?? '');
                                $opts = preg_split('/[\r\n,]+/', $raw_opts);
                                $opts = array_values(array_filter(array_map('trim', $opts), static function ($opt) {
                                    return $opt !== '';
                                }));
                                $default_vals = preg_split('/[\r\n,]+/', $def_raw);
                                $default_vals = array_values(array_filter(array_map('trim', $default_vals), static function ($opt) {
                                    return $opt !== '';
                                }));
                                $single_checked = in_array(strtolower(trim($def_raw)), ['1', 'true', 'yes', 'on'], true);
                            ?>
                            <?php if (!empty($opts)): ?>
                                <div class="awg-aig__choices" role="group" aria-label="<?php echo esc_attr($label); ?>">
                                    <?php foreach ($opts as $opt): ?>
                                        <label class="awg-aig__choice-row">
                                            <input class="awg-aig__choice" type="checkbox" name="<?php echo $name; ?>[]" value="<?php echo esc_attr($opt); ?>" <?php checked(in_array($opt, $default_vals, true)); ?> />
                                            <span><?php echo esc_html($opt); ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <label class="awg-aig__choice-row">
                                    <input class="awg-aig__choice" type="checkbox" name="<?php echo $name; ?>" value="1" <?php checked($single_checked); ?> />
                                    <span><?php echo $ph ? esc_html($ph) : esc_html__('Yes', 'authorwings-ai-tools'); ?></span>
                                </label>
                            <?php endif; ?>

                        <?php elseif ($type === 'radio'): ?>
                            <?php
                                $raw_opts = (string)($f['options'] ?? '');
                                $opts = preg_split('/[\r\n,]+/', $raw_opts);
                                $opts = array_values(array_filter(array_map('trim', $opts), static function ($opt) {
                                    return $opt !== '';
                                }));
                                $default_val = trim($def_raw);
                            ?>
                            <div class="awg-aig__choices" role="radiogroup" aria-label="<?php echo esc_attr($label); ?>">
                                <?php foreach ($opts as $index => $opt): ?>
                                    <label class="awg-aig__choice-row">
                                        <input class="awg-aig__choice" type="radio" name="<?php echo $name; ?>" value="<?php echo esc_attr($opt); ?>" <?php checked($default_val, $opt); ?> <?php echo ($req && $index === 0) ? 'required' : ''; ?> />
                                        <span><?php echo esc_html($opt); ?></span>
                                    </label>
                                <?php endforeach; ?>
                            </div>

                        <?php elseif ($type === 'file'): ?>
                            <?php
                                // v5.4.69: upload field. The admin lists the allowed
                                // extensions and a max size; both are echoed into the
                                // markup so the browser pre-filters with `accept` and
                                // front.js can show a friendly error before uploading.
                                // The server re-validates every upload regardless.
                                $accept_exts   = $this->file_accept_list($f['file_types'] ?? '');
                                $accept_attr   = $accept_exts ? '.' . implode(',.', $accept_exts) : '';
                                $max_mb        = $this->file_max_mb($f['file_max_mb'] ?? 0);
                                $accept_human  = $accept_exts ? strtoupper(implode(', ', $accept_exts)) : __('Any allowed type', 'authorwings-ai-tools');
                            ?>
                            <div class="awg-aig__file-wrap" data-max-mb="<?php echo esc_attr($max_mb); ?>">
                                <input class="awg-aig__input awg-aig__file" type="file" name="<?php echo $name; ?>"
                                       <?php echo $accept_attr ? 'accept="' . esc_attr($accept_attr) . '"' : ''; ?>
                                       <?php echo $req ? 'required' : ''; ?> />
                                <span class="awg-aig__file-hint">
                                    <?php
                                    /* translators: 1: allowed file types, 2: max size in MB */
                                    echo esc_html(sprintf(__('Allowed: %1$s · Max %2$d MB', 'authorwings-ai-tools'), $accept_human, $max_mb));
                                    ?>
                                </span>
                                <span class="awg-aig__file-status" aria-live="polite"></span>
                            </div>

                        <?php else: ?>
                            <input class="awg-aig__input" type="<?php echo esc_attr($type); ?>" name="<?php echo $name; ?>"
                                   value="<?php echo esc_attr($def_raw); ?>" placeholder="<?php echo $ph; ?>" <?php echo $req ? 'required' : ''; ?> />
                        <?php endif; ?>
                        <?php if ($field_icon_markup && $field_icon_position === 'after_input') { echo $field_icon_markup; } ?>
                    </div>
                <?php endforeach; ?>

                <div class="awg-aig__actions">
                    <?php
                    $button_icon = $this->render_icon(
                        $this->sanitize_icon_class($m['button_icon_class'] ?? ''),
                        max(10, min(40, intval($m['button_icon_size'] ?? 18))),
                        trim('awg-aig__button-icon ' . $this->sanitize_icon_class($m['button_icon_css_class'] ?? ''))
                    );
                    ?>
                    <button class="awg-aig__btn" type="submit">
                        <?php if ($button_icon && $m['button_icon_position'] === 'before') { echo $button_icon; } ?>
                        <span><?php echo esc_html($m['button_label']); ?></span>
                        <?php if ($button_icon && $m['button_icon_position'] === 'after') { echo $button_icon; } ?>
                    </button>
                    <?php if ($awg_discuss_id): ?>
                        <button type="button" class="awg-aig__discuss awg-aig__discuss--inline"><span class="dashicons dashicons-format-chat"></span><span><?php echo esc_html($awg_discuss_label); ?></span></button>
                    <?php endif; ?>
                    <span class="awg-aig__status" aria-live="polite"></span>
                </div>
                <?php endif; ?>
            </form>

            <?php if (!empty($m['disclaimer_text'])): ?>
                <div class="awg-aig__note"><?php echo esc_html($m['disclaimer_text']); ?></div>
            <?php endif; ?>

            <div class="awg-aig__result" data-filename="<?php echo esc_attr($file_stub); ?>" hidden>
                <div class="awg-aig__result-head">
                    <strong><span class="awg-aig__result-head-icon dashicons dashicons-saved" aria-hidden="true"></span><span><?php echo esc_html($m['success_title']); ?></span></strong>
                </div>
                <div class="awg-aig__output" data-format="<?php echo esc_attr($m['output_format']); ?>" data-render-mode="<?php echo esc_attr((($m['render_mode'] ?? 'document') === 'plain') ? 'plain' : 'document'); ?>" data-placeholder="<?php echo esc_attr($m['placeholder_output'] ?? ''); ?>"></div>
                <div class="awg-aig__result-actions awg-aig__result-actions--bottom">
                    <?php // v5.4.9: result actions are always rendered (admin toggles removed). ?>
                    <button type="button" class="awg-aig__copy"><span class="dashicons dashicons-clipboard"></span><span><?php echo esc_html__('Copy', 'authorwings-ai-tools'); ?></span></button>
                    <?php // Label reflects the download format: PDF vs a plain .txt file. ?>
                    <?php $awg_dl_label = ( ( $m['output_format'] ?? 'text' ) === 'pdf' ) ? __( 'Download PDF', 'authorwings-ai-tools' ) : __( 'Download', 'authorwings-ai-tools' ); ?>
                    <button type="button" class="awg-aig__download"><span class="dashicons dashicons-download"></span><span><?php echo esc_html( $awg_dl_label ); ?></span></button>
                    <button type="button" class="awg-aig__clear"><span class="dashicons dashicons-trash"></span><span><?php echo esc_html__('Clear', 'authorwings-ai-tools'); ?></span></button>
                    <button type="button" class="awg-aig__regenerate"><span class="dashicons dashicons-update"></span><span><?php echo esc_html__('Regenerate', 'authorwings-ai-tools'); ?></span></button>
                    <?php if ($awg_discuss_id): ?>
                        <button type="button" class="awg-aig__discuss"><span class="dashicons dashicons-format-chat"></span><span><?php echo esc_html($awg_discuss_label); ?></span></button>
                    <?php endif; ?>
                </div>
                <?php
                // Post-result CTA: per-template override wins, otherwise the global one.
                // A template can hide it entirely with the "hide_cta" toggle.
                $cta_html = '';
                if (empty($m['hide_cta'])) {
                    $override = trim((string) ($m['cta_text_override'] ?? ''));
                    if ($override !== '') {
                        $cta_html = $override;
                    } elseif (!empty($settings['cta_enabled']) && !empty($settings['cta_text'])) {
                        $cta_html = (string) $settings['cta_text'];
                    }
                }
                if ($cta_html !== ''):
                ?>
                    <div class="awg-aig__cta" role="complementary"><?php echo wp_kses_post($cta_html); ?></div>
                <?php endif; ?>
            </div>

            <?php
            // Auto-render the per-template rating widget at the BOTTOM of the
            // tool, after the result area. This is the conventional placement
            // for tool pages (CloudConvert, recipe sites, calculators): the
            // user has just finished using the tool, so a "Rate this" prompt
            // sits naturally at the end of their interaction. The widget is
            // always in the DOM (good for credibility on initial pageview)
            // and the result panel appears above it after generation, so the
            // visual flow stays: form → disclaimer → result → rating.
            //
            // The widget reads its data from the template post itself, so
            // multiple host pages embedding the same template share the same
            // rating — which is correct (same tool, same rating).
            if (isset(Plugin::instance()->ratings)) {
                $rating_html = Plugin::instance()->ratings->render_widget($template_id);
                if ($rating_html !== '') {
                    echo '<div class="awg-aig__rating-wrap">' . $rating_html . '</div>';
                }
            }
            ?>
        </div>
        <?php
        return (string)ob_get_clean();
    }

    /**
     * v5.4.19: sanitize admin-authored Custom HTML form markup.
     *
     * The template CPT is already locked to manage_options, so only trusted
     * admins can author this. Even so we run it through wp_kses with a form-aware
     * allowlist: this strips <script>, inline event handlers (onclick=…) and
     * anything not on the list, while keeping the tags, attributes and inline
     * styles needed to lay out and style a real form. Run on save AND on render.
     *
     * Extend the allowlist with the `awg_aig_custom_form_allowed_html` filter if
     * you need extra tags/attributes.
     *
     * @param string $html Raw markup (already wp_unslash'd by the caller on save).
     */
    public static function sanitize_custom_form_html(string $html): string {
        $common = [
            'class'          => true,
            'id'             => true,
            'style'          => true,
            'title'          => true,
            'data-awg-label' => true,
            'aria-label'     => true,
            'aria-hidden'    => true,
            'aria-describedby' => true,
            'role'           => true,
        ];

        $allowed = [
            // Layout / text
            'div' => $common, 'span' => $common, 'p' => $common,
            'section' => $common, 'header' => $common, 'footer' => $common,
            'h1' => $common, 'h2' => $common, 'h3' => $common,
            'h4' => $common, 'h5' => $common, 'h6' => $common,
            'ul' => $common, 'ol' => $common, 'li' => $common,
            'strong' => $common, 'em' => $common, 'b' => $common,
            'i' => $common, 'u' => $common, 'small' => $common,
            'br' => [], 'hr' => $common,
            'img' => array_merge($common, [
                'src' => true, 'alt' => true, 'width' => true,
                'height' => true, 'loading' => true,
            ]),
            'a' => array_merge($common, [
                'href' => true, 'target' => true, 'rel' => true,
            ]),

            // Form structure
            'fieldset' => $common,
            'legend'   => $common,
            'label'    => array_merge($common, ['for' => true]),

            // Controls
            'input' => array_merge($common, [
                'type' => true, 'name' => true, 'value' => true,
                'placeholder' => true, 'required' => true, 'checked' => true,
                'min' => true, 'max' => true, 'step' => true, 'pattern' => true,
                'maxlength' => true, 'minlength' => true, 'readonly' => true,
                'disabled' => true, 'autocomplete' => true, 'list' => true,
                'multiple' => true, 'size' => true, 'inputmode' => true,
            ]),
            'textarea' => array_merge($common, [
                'name' => true, 'placeholder' => true, 'required' => true,
                'rows' => true, 'cols' => true, 'maxlength' => true,
                'minlength' => true, 'readonly' => true, 'disabled' => true,
                'autocomplete' => true,
            ]),
            'select' => array_merge($common, [
                'name' => true, 'required' => true, 'multiple' => true,
                'size' => true, 'disabled' => true,
            ]),
            'option' => array_merge($common, [
                'value' => true, 'selected' => true, 'disabled' => true,
            ]),
            'optgroup' => array_merge($common, ['label' => true, 'disabled' => true]),
            'datalist' => $common,
            'button' => array_merge($common, [
                'type' => true, 'name' => true, 'value' => true, 'disabled' => true,
            ]),
        ];

        $allowed = apply_filters('awg_aig_custom_form_allowed_html', $allowed);

        return wp_kses($html, $allowed);
    }

    /**
     * v5.4.69: hard server-side whitelist of file extensions an upload field may
     * ever accept. The per-field "Allowed File Types" box can only narrow this
     * set, never widen it — so an admin typo (or a tampered request) can never
     * permit php/exe/sh and friends. Extend via the filter if you genuinely need
     * another safe type.
     *
     * @return string[] lowercase extensions, no dots.
     */
    public function file_global_allowed_exts(): array {
        $exts = [
            // Documents
            'txt', 'text', 'md', 'markdown', 'rtf', 'pdf',
            'doc', 'docx', 'odt', 'pages',
            // Spreadsheets
            'csv', 'tsv', 'xls', 'xlsx', 'ods',
            // Slides
            'ppt', 'pptx', 'odp',
            // Data / markup. html/htm are deliberately excluded: an uploaded
            // .html file is served same-origin and renders as a page (the
            // uploads .htaccess blocks php/js execution but not HTML, and is
            // ignored on nginx), a stored-XSS vector — the same reason svg is
            // excluded below. Allow via the filter only if you sanitise them.
            'json', 'xml', 'log',
            // Archives
            'zip',
            // Images — svg is deliberately excluded (unsanitised SVG is an XSS
            // vector, exactly as WordPress core blocks it by default). Allow it
            // via the awg_aig_upload_global_allowed_exts filter only if you
            // sanitise SVGs elsewhere.
            'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'tiff', 'heic',
        ];
        $exts = apply_filters('awg_aig_upload_global_allowed_exts', $exts);
        return array_values(array_unique(array_filter(array_map(static function ($e) {
            return preg_replace('/[^a-z0-9]/', '', strtolower((string) $e));
        }, (array) $exts))));
    }

    /**
     * Resolve a field's "Allowed File Types" string into a clean extension list,
     * always intersected with the global whitelist. Accepts commas / newlines /
     * spaces and tolerates leading dots ("pdf, .docx"). An empty/garbage value
     * falls back to a sensible author-friendly default set.
     *
     * @return string[] lowercase extensions, no dots.
     */
    public function file_accept_list($raw): array {
        $global = $this->file_global_allowed_exts();

        $parts = preg_split('/[\s,]+/', (string) $raw);
        $parts = array_filter(array_map(static function ($p) {
            return preg_replace('/[^a-z0-9]/', '', strtolower((string) $p));
        }, (array) $parts), static function ($p) {
            return $p !== '';
        });

        if (empty($parts)) {
            // Author-friendly default: the formats a manuscript / brief usually
            // arrives in, minus the heavier archive/image types.
            $parts = ['txt', 'pdf', 'doc', 'docx', 'rtf', 'odt', 'md', 'csv'];
        }

        $list = array_values(array_intersect(array_unique($parts), $global));
        return $list;
    }

    /**
     * Clamp a per-field max upload size (MB) into a safe range. 0/blank -> default.
     */
    public function file_max_mb($raw): int {
        $mb = (int) $raw;
        if ($mb <= 0) {
            $mb = (int) apply_filters('awg_aig_upload_default_max_mb', 10);
        }
        return max(1, min(50, $mb));
    }

    public function fields_to_text(array $fields_schema, array $submitted): string {
        $lines = [];
        foreach ($fields_schema as $f) {
            $key = sanitize_key($f['key'] ?? '');
            if (!$key) continue;

            $label = $f['label'] ?? $key;
            $type = $f['type'] ?? 'text';
            $val = $submitted[$key] ?? '';

            if (is_array($val)) {
                $val = implode(', ', array_map('sanitize_text_field', $val));
            }

            // Textareas — and the extracted text of an uploaded file — need
            // newlines preserved so the AI sees multi-paragraph input.
            if ($type === 'textarea' || $type === 'file') {
                $val = is_string($val) ? sanitize_textarea_field($val) : '';
            } else {
                $val = is_string($val) ? sanitize_text_field($val) : '';
            }

            if ($val === '') continue;

            // If the content has newlines, render it on its own block so the AI sees structure.
            if (($type === 'textarea' || $type === 'file') && strpos($val, "\n") !== false) {
                $lines[] = "- {$label}:\n{$val}";
            } else {
                $lines[] = "- {$label}: {$val}";
            }
        }
        return implode("\n", $lines);
    }
}
