<?php
/**
 * Export / Import for AuthorWings AI Tools (v5.4.16+).
 *
 * Purpose
 * -------
 * Move a site's tool definitions — templates (with their per-template
 * configuration) and Tool Categories — between WordPress installations as a
 * single portable JSON file.
 *
 * v5.8.0: the export/import scope was narrowed to templates and categories
 * only. Star ratings (votes + seed), external rating widgets, AI Submissions,
 * and global settings are NO LONGER exported or imported. Rating/schema/pricing
 * meta is also no longer carried on templates.
 *
 * Format
 * ------
 * The export is JSON with two top-level keys:
 *
 *   _meta : plugin name, plugin version, schema version, export timestamp,
 *           source site URL.
 *   data  : categories array, templates array.
 *
 * Each template entry carries its title, post status, dates, menu order, the
 * core template meta keys (whitelist below), and its Tool Category slugs. The
 * category definitions themselves travel in the top-level "categories" block
 * and are recreated (matched by slug) on the target.
 *
 * Modes
 * -----
 * MERGE   : keep everything currently on the target; add imported templates
 *           as new posts and create any missing categories (matched by slug).
 *
 * REPLACE : delete every existing template, wipe the ratings table, strip
 *           every plugin rating-meta key from any post, delete every existing
 *           submission, and reset the plugin settings — then import the
 *           templates and categories fresh. This stays destructive so a
 *           clone-over-empty-target workflow leaves no stale local data.
 *
 * Security
 * --------
 * All endpoints are admin_post (not AJAX) — capability check + nonce check.
 * No API keys, settings, submissions, or visitor PII ever leave the site in
 * an export, so a forgotten export file in Git or email can't leak them.
 *
 * Concurrency
 * -----------
 * The staged-import payload is held in a per-user transient keyed by user
 * ID, so two admins importing simultaneously never see each other's data.
 *
 * @package AWG_AIG
 */

namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Port {

    /** Per-user transient key prefix. Holds parsed JSON between upload and apply. */
    const TRANSIENT_PREFIX = 'awg_aig_port_';

    /** Bump if the JSON format changes incompatibly. Import validates this. */
    const SCHEMA_VERSION = 2;

    /** Hour to keep a staged import alive — admin has time to review and apply. */
    const STAGE_TTL = HOUR_IN_SECONDS;

    public function register(): void {
        // Priority 30 so the parent menu (Settings, priority 10) and the
        // Ratings submenu (priority 20) are already in place when this
        // submenu is registered.
        add_action('admin_menu', [$this, 'menu'], 30);

        add_action('admin_post_awg_aig_export',        [$this, 'handle_export']);
        add_action('admin_post_awg_aig_import_stage',  [$this, 'handle_import_stage']);
        add_action('admin_post_awg_aig_import_apply',  [$this, 'handle_import_apply']);
        add_action('admin_post_awg_aig_import_cancel', [$this, 'handle_import_cancel']);
    }

    public function menu(): void {
        add_submenu_page(
            'edit.php?post_type=' . Plugin::CPT,
            __('Export / Import', 'authorwings-ai-tools'),
            __('Export / Import', 'authorwings-ai-tools'),
            'manage_options',
            'awg-aig-port',
            [$this, 'render_page'],
            100 // v5.4.28: maintenance group, last in the menu.
        );
    }

    // -----------------------------------------------------------------
    // Whitelist: every meta key the plugin owns on a template post.
    //
    // Why a whitelist and not "everything on the post": template posts can
    // accumulate third-party meta over time (SEO plugins, builder caches,
    // featured-image overrides). Carrying those across sites is rarely what
    // an admin wants and can cause bizarre cross-environment behavior. The
    // whitelist is the SOURCE OF TRUTH — adding a new plugin meta key means
    // adding it here too, otherwise it won't survive a round-trip.
    // -----------------------------------------------------------------
    private function template_meta_keys(): array {
        // v5.8.0: rating/schema/pricing meta no longer travels with templates.
        // Only the core template definition (config blob + usage bookkeeping)
        // is carried across sites.
        return [
            '_awg_aig_template',
            '_awg_aig_usage_count',
            '_awg_aig_last_generated',
        ];
    }

    /**
     * Rating-meta keys. v5.8.0: rating data is no longer exported or imported,
     * but this list is still used by Replace mode to strip rating meta from the
     * target site when wiping it clean.
     */
    private function rating_meta_keys(): array {
        return [
            Ratings::META_ENABLED,
            Ratings::META_BASE_COUNT,
            Ratings::META_BASE_AVG,
            Ratings::META_SCHEMA_TYPE,
            Ratings::META_SCHEMA_NAME,
            Ratings::META_HEADING,
            Ratings::META_THANKS,
            Ratings::META_APP_CATEGORY,
            Ratings::META_DESCRIPTION,
            Ratings::META_PRICING_MODEL,
            Ratings::META_PRICE,
            Ratings::META_PRICE_CURRENCY,
        ];
    }

    /**
     * Re-sanitize a meta value coming from an import file. The rating/schema
     * "text" keys surface in JSON-LD and the widget UI, so any markup smuggled
     * into an imported file is stripped here (defense-in-depth alongside the
     * slash-escaped JSON-LD output). The template config blob, custom HTML, and
     * every other key are passed through untouched so they round-trip intact.
     *
     * @param mixed $value
     * @return mixed
     */
    private function sanitize_imported_meta_value(string $key, $value) {
        // v5.9.6: the template config blob carries the Custom Form HTML. Mirror
        // the WordPress core "Custom HTML" block: keep it raw only when the
        // importing user can post unfiltered_html, otherwise run it through the
        // form-aware kses allowlist so an imported file can't smuggle scripts in.
        if ($key === '_awg_aig_template' && is_array($value)
            && isset($value['custom_html']) && is_string($value['custom_html'])
            && !current_user_can('unfiltered_html')) {
            $value['custom_html'] = Renderer::sanitize_custom_form_html($value['custom_html']);
            return $value;
        }
        if (!is_string($value)) {
            return $value;
        }
        $text_keys = [
            Ratings::META_SCHEMA_NAME,
            Ratings::META_SCHEMA_TYPE,
            Ratings::META_HEADING,
            Ratings::META_APP_CATEGORY,
            Ratings::META_PRICING_MODEL,
            Ratings::META_PRICE_CURRENCY,
        ];
        $textarea_keys = [
            Ratings::META_DESCRIPTION,
            Ratings::META_THANKS,
        ];
        if (in_array($key, $text_keys, true)) {
            return sanitize_text_field($value);
        }
        if (in_array($key, $textarea_keys, true)) {
            return sanitize_textarea_field($value);
        }
        return $value;
    }

    /**
     * v5.4.70: find-or-create a Tool Category term by slug, applying its name,
     * description, parent and styling meta. Returns the term id and whether it
     * was newly created. Matching is by slug so re-importing is idempotent.
     *
     * @return array{term_id:int,created:bool}
     */
    private function ensure_category(string $slug, string $name = '', string $description = '', string $parent_slug = '', string $icon = '', string $accent = ''): array {
        $slug = sanitize_title($slug !== '' ? $slug : $name);
        if ($slug === '') {
            return ['term_id' => 0, 'created' => false];
        }

        $existing = get_term_by('slug', $slug, Plugin::TAX);
        $created  = false;

        if ($existing && !is_wp_error($existing)) {
            $term_id = (int) $existing->term_id;
        } else {
            $parent_id = 0;
            if ($parent_slug !== '') {
                $pt = get_term_by('slug', sanitize_title($parent_slug), Plugin::TAX);
                if ($pt && !is_wp_error($pt)) { $parent_id = (int) $pt->term_id; }
            }
            $res = wp_insert_term(
                $name !== '' ? $name : $slug,
                Plugin::TAX,
                ['slug' => $slug, 'description' => wp_strip_all_tags($description), 'parent' => $parent_id]
            );
            if (is_wp_error($res)) {
                // A race or a name collision under a different slug — fall back to
                // whatever term now matches the slug, else give up gracefully.
                $fallback = get_term_by('slug', $slug, Plugin::TAX);
                if ($fallback && !is_wp_error($fallback)) {
                    $term_id = (int) $fallback->term_id;
                } else {
                    return ['term_id' => 0, 'created' => false];
                }
            } else {
                $term_id = (int) $res['term_id'];
                $created = true;
            }
        }

        // Styling meta — only write when provided so we never blank an existing
        // term's icon/accent on a re-import that omitted them.
        $icon = trim($icon);
        if ($icon !== '') {
            update_term_meta($term_id, Taxonomy::ICON_META, sanitize_text_field($icon));
        }
        $accent = trim($accent);
        if ($accent !== '') {
            $hex = sanitize_hex_color($accent);
            if (!$hex && preg_match('/^#?[0-9a-fA-F]{6}$/', $accent)) {
                $hex = '#' . ltrim($accent, '#');
            }
            if ($hex) {
                update_term_meta($term_id, Taxonomy::ACCENT_META, $hex);
            }
        }

        return ['term_id' => $term_id, 'created' => $created];
    }

    // =================================================================
    // UI
    // =================================================================

    public function render_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'authorwings-ai-tools'));
        }

        // If the admin already uploaded a file, jump straight to the preview
        // confirmation screen until they apply or cancel.
        $staged_key = self::TRANSIENT_PREFIX . get_current_user_id();
        $staged = get_transient($staged_key);
        if (is_array($staged) && !empty($staged['_meta'])) {
            $this->render_preview($staged);
            return;
        }

        $this->render_main();
    }

    private function render_main(): void {
        // Notices passed back from the admin-post handlers.
        $msg = isset($_GET['awg_msg']) ? sanitize_text_field(wp_unslash((string) $_GET['awg_msg'])) : '';
        $err = isset($_GET['awg_err']) ? sanitize_text_field(wp_unslash((string) $_GET['awg_err'])) : '';

        // Live counts so the admin sees what they're about to export.
        $counts = wp_count_posts(Plugin::CPT);
        $tpl_count = (int) ($counts->publish ?? 0)
                   + (int) ($counts->draft ?? 0)
                   + (int) ($counts->private ?? 0)
                   + (int) ($counts->pending ?? 0);

        $cat_terms = get_terms(['taxonomy' => Plugin::TAX, 'hide_empty' => false, 'fields' => 'ids']);
        $cat_count = is_array($cat_terms) ? count($cat_terms) : 0;
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('AuthorWings AI — Export / Import', 'authorwings-ai-tools'); ?></h1>

            <?php if ($msg !== ''): ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html($msg); ?></p></div>
            <?php endif; ?>
            <?php if ($err !== ''): ?>
                <div class="notice notice-error is-dismissible"><p><?php echo esc_html($err); ?></p></div>
            <?php endif; ?>

            <h2 style="margin-top:18px;"><?php esc_html_e('Export', 'authorwings-ai-tools'); ?></h2>
            <p class="description" style="max-width:780px;">
                <?php
                printf(
                    /* translators: 1: template count, 2: category count */
                    esc_html__('Download a single JSON file containing every template (%1$d) and every Tool Category (%2$d). Re-import on any other site to clone this setup. Ratings, submissions, global settings, and API keys are NOT included.', 'authorwings-ai-tools'),
                    $tpl_count,
                    $cat_count
                );
                ?></p>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:8px;">
                <input type="hidden" name="action" value="awg_aig_export">
                <?php wp_nonce_field('awg_aig_export'); ?>
                <p>
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-download" style="vertical-align:-4px;"></span>
                        <?php esc_html_e('Download Export File', 'authorwings-ai-tools'); ?>
                    </button>
                </p>
            </form>

            <hr style="margin:30px 0;">

            <h2><?php esc_html_e('Import', 'authorwings-ai-tools'); ?></h2>
            <p class="description" style="max-width:780px;">
                <?php esc_html_e('Upload a JSON export from this or another site. You\'ll see a preview and choose how to handle existing data before anything is changed.', 'authorwings-ai-tools'); ?>
            </p>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
                <input type="hidden" name="action" value="awg_aig_import_stage">
                <?php wp_nonce_field('awg_aig_import_stage'); ?>
                <p>
                    <input type="file" name="awg_import_file" accept=".json,application/json" required>
                </p>
                <p>
                    <button type="submit" class="button button-secondary">
                        <span class="dashicons dashicons-upload" style="vertical-align:-4px;"></span>
                        <?php esc_html_e('Upload and Preview', 'authorwings-ai-tools'); ?>
                    </button>
                </p>
            </form>
        </div>
        <?php
    }

    private function render_preview(array $staged): void {
        $meta = isset($staged['_meta']) && is_array($staged['_meta']) ? $staged['_meta'] : [];
        $data = isset($staged['data']) && is_array($staged['data']) ? $staged['data'] : [];

        $templates = isset($data['templates']) && is_array($data['templates']) ? $data['templates'] : [];
        $tpl_count = count($templates);

        // v5.4.70: categories carried in the export (created on import if missing).
        $categories = isset($data['categories']) && is_array($data['categories']) ? $data['categories'] : [];
        $cat_count  = count($categories);

        $source_url    = (string) ($meta['source_site_url'] ?? '');
        $exported_at   = (string) ($meta['exported_at'] ?? '');
        $source_ver    = (string) ($meta['plugin_version'] ?? '');
        $schema_ver    = (int)    ($meta['schema_version'] ?? 0);
        $cancel_url = wp_nonce_url(
            admin_url('admin-post.php?action=awg_aig_import_cancel'),
            'awg_aig_import_cancel'
        );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Confirm Import', 'authorwings-ai-tools'); ?></h1>

            <div class="notice notice-info" style="padding:12px 14px;">
                <p style="margin:0;">
                    <strong><?php esc_html_e('Source:', 'authorwings-ai-tools'); ?></strong>
                    <?php echo esc_html($source_url !== '' ? $source_url : __('(unknown)', 'authorwings-ai-tools')); ?>
                    &nbsp;·&nbsp;
                    <strong><?php esc_html_e('Exported:', 'authorwings-ai-tools'); ?></strong>
                    <?php echo esc_html($exported_at !== '' ? $exported_at : __('(unknown)', 'authorwings-ai-tools')); ?>
                    <?php if ($source_ver !== ''): ?>
                        &nbsp;·&nbsp;
                        <strong><?php esc_html_e('Plugin version:', 'authorwings-ai-tools'); ?></strong>
                        <?php echo esc_html($source_ver); ?>
                    <?php endif; ?>
                </p>
                <?php if ($schema_ver !== self::SCHEMA_VERSION): ?>
                    <p style="margin:8px 0 0;color:#b32d2e;">
                        <?php
                        printf(
                            /* translators: 1: file schema, 2: current plugin schema */
                            esc_html__('Warning: file schema version is %1$d but this plugin expects %2$d. Import may fail or behave unexpectedly.', 'authorwings-ai-tools'),
                            (int) $schema_ver,
                            (int) self::SCHEMA_VERSION
                        );
                        ?>
                    </p>
                <?php endif; ?>
            </div>

            <table class="widefat striped" style="max-width:720px;margin-top:14px;">
                <tbody>
                    <tr>
                        <td style="width:240px;"><strong><?php esc_html_e('Templates', 'authorwings-ai-tools'); ?></strong></td>
                        <td><?php echo (int) $tpl_count; ?></td>
                    </tr>
                    <tr>
                        <td><strong><?php esc_html_e('Tool Categories', 'authorwings-ai-tools'); ?></strong></td>
                        <td>
                            <?php echo (int) $cat_count; ?>
                            <?php if ($cat_count > 0): ?>
                                <span class="description">— <?php esc_html_e('created on this site if they don\'t already exist (matched by slug)', 'authorwings-ai-tools'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>

            <h2 style="margin-top:30px;"><?php esc_html_e('How should existing data on this site be handled?', 'authorwings-ai-tools'); ?></h2>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="awg_aig_import_apply">
                <?php wp_nonce_field('awg_aig_import_apply'); ?>

                <label style="display:block;padding:14px 16px;border:1px solid #c3c4c7;border-radius:6px;margin-bottom:10px;cursor:pointer;max-width:720px;">
                    <input type="radio" name="mode" value="merge" checked style="margin-right:8px;">
                    <strong><?php esc_html_e('Merge (recommended)', 'authorwings-ai-tools'); ?></strong>
                    <div style="margin:6px 0 0 22px;font-size:13px;color:#50575e;">
                        <?php esc_html_e('Keeps everything currently on this site. Imported templates are added as new entries — original IDs change but their configuration is preserved. Missing Tool Categories are created (matched by slug). This site\'s ratings, submissions, and global settings (including your API keys) are NOT touched.', 'authorwings-ai-tools'); ?>
                    </div>
                </label>

                <label style="display:block;padding:14px 16px;border:1px solid #c3c4c7;border-radius:6px;margin-bottom:10px;cursor:pointer;max-width:720px;">
                    <input type="radio" name="mode" value="replace" style="margin-right:8px;">
                    <strong style="color:#b32d2e;"><?php esc_html_e('Replace', 'authorwings-ai-tools'); ?></strong>
                    <div style="margin:6px 0 0 22px;font-size:13px;color:#50575e;">
                        <?php esc_html_e('Deletes EVERY existing template, EVERY rating vote, EVERY submission, and resets this site\'s global plugin settings (including your API keys) — then loads the imported templates and categories fresh. Use this when cloning a site over an empty target, or when the local data is known-bad. This is destructive and cannot be undone — back up first.', 'authorwings-ai-tools'); ?>
                    </div>
                </label>

                <p style="margin-top:16px;">
                    <button type="submit" class="button button-primary" onclick="return confirm('<?php echo esc_js(__('Apply the import now? Replace mode is irreversible. Continue?', 'authorwings-ai-tools')); ?>');">
                        <?php esc_html_e('Apply Import', 'authorwings-ai-tools'); ?>
                    </button>
                    <a href="<?php echo esc_url($cancel_url); ?>" class="button button-secondary" style="margin-left:8px;">
                        <?php esc_html_e('Cancel and Discard', 'authorwings-ai-tools'); ?>
                    </a>
                </p>
            </form>
        </div>
        <?php
    }

    // =================================================================
    // EXPORT
    // =================================================================

    public function handle_export(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'authorwings-ai-tools'));
        }
        check_admin_referer('awg_aig_export');

        $payload = $this->build_export();

        $json = wp_json_encode(
            $payload,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        );
        if ($json === false) {
            wp_die(esc_html__('Export failed: could not encode JSON.', 'authorwings-ai-tools'));
        }

        $host = wp_parse_url(home_url(), PHP_URL_HOST);
        if (!$host) $host = 'site';
        $filename = sanitize_file_name('authorwings-ai-export-' . $host . '-' . wp_date('Y-m-d-Hi') . '.json');

        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($json));
        echo $json;
        exit;
    }

    /**
     * Assemble the export payload as a PHP array.
     *
     * v5.8.0: scope is templates + categories only. No settings, ratings,
     * external rating widgets, or submissions are included.
     */
    private function build_export(): array {
        global $wpdb;

        // ----- templates -----
        $template_posts = get_posts([
            'post_type'        => Plugin::CPT,
            'post_status'      => ['publish', 'draft', 'private', 'pending'],
            'posts_per_page'   => -1,
            'orderby'          => 'ID',
            'order'            => 'ASC',
            'suppress_filters' => true,
            'no_found_rows'    => true,
        ]);

        $templates = [];
        $template_keys = $this->template_meta_keys();

        foreach ($template_posts as $p) {
            $meta_clean = [];
            foreach ($template_keys as $key) {
                // Use single-value read; the plugin doesn't store multi-value
                // meta on its keys. get_post_meta with $single=true returns
                // '' for missing — preserve "missing" by skipping empties so
                // round-trip doesn't promote unset to set.
                $val = get_post_meta($p->ID, $key, true);
                if ($val === '' || $val === null || $val === false) continue;
                $meta_clean[$key] = $val;
            }

            // v5.4.70: carry the tool's Tool Category assignments (by slug) so
            // categorisation survives an export/import round-trip. The category
            // definitions themselves travel in the top-level "categories" block.
            $term_slugs = wp_get_object_terms($p->ID, Plugin::TAX, ['fields' => 'slugs']);
            if (is_wp_error($term_slugs) || !is_array($term_slugs)) { $term_slugs = []; }

            $templates[] = [
                'title'      => (string) $p->post_title,
                'status'     => (string) $p->post_status,
                'date_gmt'   => (string) $p->post_date_gmt,
                'menu_order' => (int) $p->menu_order,
                'meta'       => $meta_clean,
                'categories' => array_values($term_slugs),
            ];
        }

        // v5.4.70: export every Tool Category (even empty ones) with its slug,
        // name, description, parent and styling meta so the target site can
        // recreate the full category structure on import.
        $categories_out = [];
        $all_terms = get_terms(['taxonomy' => Plugin::TAX, 'hide_empty' => false]);
        if (is_array($all_terms)) {
            foreach ($all_terms as $term) {
                if (!is_object($term) || is_wp_error($term)) { continue; }
                $parent_slug = '';
                if (!empty($term->parent)) {
                    $pt = get_term($term->parent, Plugin::TAX);
                    if ($pt && !is_wp_error($pt)) { $parent_slug = (string) $pt->slug; }
                }
                $categories_out[] = [
                    'name'        => (string) $term->name,
                    'slug'        => (string) $term->slug,
                    'description' => (string) $term->description,
                    'parent'      => $parent_slug,
                    'icon'        => (string) get_term_meta($term->term_id, Taxonomy::ICON_META, true),
                    'accent'      => (string) get_term_meta($term->term_id, Taxonomy::ACCENT_META, true),
                ];
            }
        }

        return [
            '_meta' => [
                'plugin'          => 'authorwings-ai-tools',
                'plugin_version'  => AWG_AIG_VERSION,
                'schema_version'  => self::SCHEMA_VERSION,
                'exported_at'     => gmdate('c'),
                'source_site_url' => home_url(),
            ],
            'data' => [
                'categories' => $categories_out,
                'templates'  => $templates,
            ],
        ];
    }

    // =================================================================
    // IMPORT: stage / cancel / apply
    // =================================================================

    public function handle_import_stage(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'authorwings-ai-tools'));
        }
        check_admin_referer('awg_aig_import_stage');

        if (empty($_FILES['awg_import_file']) || empty($_FILES['awg_import_file']['tmp_name'])) {
            $this->redirect_back('', __('No file uploaded.', 'authorwings-ai-tools'));
        }
        $file = $_FILES['awg_import_file'];

        if (!empty($file['error']) && (int) $file['error'] !== UPLOAD_ERR_OK) {
            $this->redirect_back('', __('File upload failed.', 'authorwings-ai-tools'));
        }

        // Hard size cap: 100 MB. Anything larger probably isn't this plugin.
        $size = (int) ($file['size'] ?? 0);
        if ($size <= 0 || $size > 100 * 1024 * 1024) {
            $this->redirect_back('', __('File is empty or larger than 100 MB.', 'authorwings-ai-tools'));
        }

        // Belt-and-braces: confirm the uploaded path is actually an uploaded
        // file before reading it. Prevents path-traversal abuse if someone
        // ever forges a $_FILES entry.
        if (!is_uploaded_file((string) $file['tmp_name'])) {
            $this->redirect_back('', __('Upload validation failed.', 'authorwings-ai-tools'));
        }

        $contents = file_get_contents((string) $file['tmp_name']);
        if ($contents === false || $contents === '') {
            $this->redirect_back('', __('Could not read the uploaded file.', 'authorwings-ai-tools'));
        }

        // Strip a UTF-8 BOM if a Windows editor saved one in.
        if (substr($contents, 0, 3) === "\xEF\xBB\xBF") {
            $contents = substr($contents, 3);
        }

        $payload = json_decode($contents, true);
        if (!is_array($payload)) {
            $this->redirect_back('', __('File is not valid JSON.', 'authorwings-ai-tools'));
        }

        if (empty($payload['_meta']['plugin']) || $payload['_meta']['plugin'] !== 'authorwings-ai-tools') {
            $this->redirect_back('', __('File is not an AuthorWings AI export.', 'authorwings-ai-tools'));
        }
        if (empty($payload['data']) || !is_array($payload['data'])) {
            $this->redirect_back('', __('Export file is missing the data block.', 'authorwings-ai-tools'));
        }

        $staged_key = self::TRANSIENT_PREFIX . get_current_user_id();
        set_transient($staged_key, $payload, self::STAGE_TTL);

        // Land on the preview screen (render_page picks up the transient).
        $this->redirect_back('', '');
    }

    public function handle_import_cancel(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'authorwings-ai-tools'));
        }
        check_admin_referer('awg_aig_import_cancel');

        delete_transient(self::TRANSIENT_PREFIX . get_current_user_id());
        $this->redirect_back(__('Import cancelled. Nothing was changed.', 'authorwings-ai-tools'), '');
    }

    public function handle_import_apply(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'authorwings-ai-tools'));
        }
        check_admin_referer('awg_aig_import_apply');

        $staged_key = self::TRANSIENT_PREFIX . get_current_user_id();
        $payload = get_transient($staged_key);
        if (!is_array($payload)) {
            $this->redirect_back('', __('Import session expired. Please upload the file again.', 'authorwings-ai-tools'));
        }

        $mode = isset($_POST['mode']) ? sanitize_text_field(wp_unslash((string) $_POST['mode'])) : 'merge';
        if (!in_array($mode, ['merge', 'replace'], true)) $mode = 'merge';

        $stats = $this->apply_import($payload, $mode);

        // Always clear the staged payload after a run — even partial failure
        // shouldn't leave a stale transient pulling the admin back to the
        // preview screen on every page load.
        delete_transient($staged_key);

        $mode_label = ($mode === 'replace')
            ? __('replace', 'authorwings-ai-tools')
            : __('merge', 'authorwings-ai-tools');

        $msg = sprintf(
            /* translators: 1: mode label (merge/replace), 2: templates imported, 3: categories created */
            __('Import complete (%1$s). Templates: %2$d. Categories created: %3$d.', 'authorwings-ai-tools'),
            $mode_label,
            (int) $stats['templates'],
            (int) $stats['categories']
        );
        $this->redirect_back($msg, '');
    }

    /**
     * Apply a staged payload to the target site.
     *
     * @return array{templates:int,categories:int}
     */
    private function apply_import(array $payload, string $mode): array {
        global $wpdb;

        $data = isset($payload['data']) && is_array($payload['data']) ? $payload['data'] : [];
        $stats = [
            'templates'  => 0,
            'categories' => 0,
        ];

        // -------- REPLACE: wipe target first --------
        if ($mode === 'replace') {
            if (function_exists('wp_suspend_cache_addition')) {
                wp_suspend_cache_addition(true);
            }

            // Delete every template post. before_delete_post (hooked by
            // Ratings::on_post_delete) clears each template's rating rows
            // from awg_ratings as we go. Batch in chunks so a multi-thousand
            // template site doesn't hit max_execution_time.
            $batch_size = 200;
            for ($i = 0; $i < 5000; $i++) {
                $ids = get_posts([
                    'post_type'      => Plugin::CPT,
                    'post_status'    => 'any',
                    'posts_per_page' => $batch_size,
                    'fields'         => 'ids',
                    'no_found_rows'  => true,
                    'cache_results'  => false,
                ]);
                if (empty($ids)) break;
                foreach ($ids as $pid) {
                    wp_delete_post((int) $pid, true);
                }
                if (count($ids) < $batch_size) break;
            }

            // Wipe any remaining rating rows (covers external_ratings posts).
            // DELETE rather than TRUNCATE — TRUNCATE needs DROP privilege on
            // some MySQL configurations; DELETE works for every WP host.
            $table = $wpdb->prefix . Ratings::TABLE;
            $wpdb->query("DELETE FROM {$table}");

            // Strip every plugin rating-meta key from any post that has it,
            // so external rating widgets on this site disappear in replace
            // mode (otherwise the wp_head schema output would still fire
            // against the leftover meta with zero matching votes).
            foreach ($this->rating_meta_keys() as $k) {
                delete_post_meta_by_key($k);
            }

            // v5.4.17: delete existing submissions too. Batched the same way
            // as templates so a site with tens of thousands of submission
            // posts doesn't hit max_execution_time. Submission CPT meta is
            // tied to the post and gets reaped by wp_delete_post — no
            // separate meta cleanup needed.
            for ($i = 0; $i < 5000; $i++) {
                $sub_ids = get_posts([
                    'post_type'      => Plugin::SUB_CPT,
                    'post_status'    => 'any',
                    'posts_per_page' => $batch_size,
                    'fields'         => 'ids',
                    'no_found_rows'  => true,
                    'cache_results'  => false,
                ]);
                if (empty($sub_ids)) break;
                foreach ($sub_ids as $pid) {
                    wp_delete_post((int) $pid, true);
                }
                if (count($sub_ids) < $batch_size) break;
            }

            // v5.8.0: settings are no longer part of the export. Replace mode
            // still resets this site's plugin settings (including API keys) so
            // a clone-over-empty-target leaves no stale local configuration.
            delete_option(Plugin::OPT);

            if (function_exists('wp_suspend_cache_addition')) {
                wp_suspend_cache_addition(false);
            }
        }

        // -------- CATEGORIES --------
        // v5.4.70: recreate Tool Categories before templates so each tool can be
        // assigned to them below. Terms are matched/created by slug, so a second
        // import is idempotent. Parents are created before children.
        $categories = isset($data['categories']) && is_array($data['categories']) ? $data['categories'] : [];
        usort($categories, static function ($a, $b) {
            $ap = !empty($a['parent']) ? 1 : 0;
            $bp = !empty($b['parent']) ? 1 : 0;
            return $ap <=> $bp; // parentless first
        });
        foreach ($categories as $c) {
            if (!is_array($c)) { continue; }
            $created = $this->ensure_category(
                (string) ($c['slug'] ?? ''),
                (string) ($c['name'] ?? ''),
                (string) ($c['description'] ?? ''),
                (string) ($c['parent'] ?? ''),
                (string) ($c['icon'] ?? ''),
                (string) ($c['accent'] ?? '')
            );
            if ($created['created']) { $stats['categories']++; }
        }

        // -------- TEMPLATES --------
        $templates = isset($data['templates']) && is_array($data['templates']) ? $data['templates'] : [];
        $allowed_keys = $this->template_meta_keys();

        foreach ($templates as $t) {
            if (!is_array($t)) continue;

            $status = (string) ($t['status'] ?? 'publish');
            if ($status === 'trash') continue;
            if (!in_array($status, ['publish', 'draft', 'private', 'pending'], true)) {
                $status = 'draft';
            }

            $insert_args = [
                'post_type'   => Plugin::CPT,
                'post_status' => $status,
                'post_title'  => (string) ($t['title'] ?? ''),
                'menu_order'  => (int) ($t['menu_order'] ?? 0),
            ];
            $date_gmt = (string) ($t['date_gmt'] ?? '');
            if ($date_gmt !== '' && $date_gmt !== '0000-00-00 00:00:00') {
                $insert_args['post_date_gmt'] = $date_gmt;
                $insert_args['post_date']     = get_date_from_gmt($date_gmt);
            }

            $new_id = wp_insert_post(wp_slash($insert_args), true);
            if (is_wp_error($new_id) || !$new_id) continue;

            // Restore whitelisted meta. wp_slash protects nested arrays so
            // the big '_awg_aig_template' config blob round-trips intact.
            $meta = isset($t['meta']) && is_array($t['meta']) ? $t['meta'] : [];
            foreach ($meta as $key => $value) {
                if (!in_array($key, $allowed_keys, true)) continue;
                update_post_meta((int) $new_id, $key, wp_slash($this->sanitize_imported_meta_value((string) $key, $value)));
            }

            // v5.4.70: assign Tool Categories. Slugs that weren't in the
            // categories block (e.g. a hand-edited import) are created on the
            // fly so the assignment never silently drops a tool's category.
            $cat_slugs = isset($t['categories']) && is_array($t['categories']) ? $t['categories'] : [];
            $term_ids = [];
            foreach ($cat_slugs as $cslug) {
                $res = $this->ensure_category((string) $cslug);
                if ($res['term_id'] > 0) { $term_ids[] = $res['term_id']; }
            }
            if (!empty($term_ids)) {
                wp_set_object_terms((int) $new_id, $term_ids, Plugin::TAX, false);
            }

            $stats['templates']++;
        }

        return $stats;
    }

    // =================================================================
    // Helpers
    // =================================================================

    /** Send the admin back to the Port admin page with a notice. */
    private function redirect_back(string $msg, string $err): void {
        $args = [
            'post_type' => Plugin::CPT,
            'page'      => 'awg-aig-port',
        ];
        if ($msg !== '') $args['awg_msg'] = $msg;
        if ($err !== '') $args['awg_err'] = $err;
        wp_safe_redirect(add_query_arg($args, admin_url('edit.php')));
        exit;
    }
}
