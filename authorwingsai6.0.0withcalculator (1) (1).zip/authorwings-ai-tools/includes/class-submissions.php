<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

/**
 * Stores generator runs as admin-only records.
 */
final class Submissions {
    /** @var string */
    private $cpt;
    /** @var string */
    private $template_cpt;

    public function __construct(string $cpt, string $template_cpt) {
        $this->cpt = $cpt;
        $this->template_cpt = $template_cpt;
    }

    public function register(): void {
        register_post_type($this->cpt, [
            'labels' => [
                'name' => __('AI Submissions', 'authorwings-ai-tools'),
                'singular_name' => __('AI Submission', 'authorwings-ai-tools'),
                'menu_name' => __('AI Submissions', 'authorwings-ai-tools'),
                'all_items' => __('AI Submissions', 'authorwings-ai-tools'),
                // These records are read-only logs, so the editor screen is a
                // "view", not an "edit" — relabel the heading and search box
                // accordingly instead of inheriting the generic "Edit Post" /
                // "Search Posts" strings.
                'edit_item' => __('View AI Submission', 'authorwings-ai-tools'),
                'view_item' => __('View AI Submission', 'authorwings-ai-tools'),
                'search_items' => __('Search Submissions', 'authorwings-ai-tools'),
                'not_found' => __('No submissions found.', 'authorwings-ai-tools'),
                'not_found_in_trash' => __('No submissions found in Trash.', 'authorwings-ai-tools'),
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_rest' => false,
            // We attach this CPT under the top-level "AuthorWings AI" menu via custom submenus.
            'show_in_menu' => false,
            'supports' => ['title'],
            'capabilities' => [
                'edit_post'          => 'manage_options',
                'read_post'          => 'manage_options',
                'delete_post'        => 'manage_options',
                'edit_posts'         => 'manage_options',
                'edit_others_posts'  => 'manage_options',
                'publish_posts'      => 'manage_options',
                'read_private_posts' => 'manage_options',
                'delete_posts'       => 'manage_options',
                'delete_private_posts' => 'manage_options',
                'delete_published_posts' => 'manage_options',
                'delete_others_posts' => 'manage_options',
                'edit_private_posts' => 'manage_options',
                'edit_published_posts' => 'manage_options',
                // Submissions are captured logs created programmatically via
                // wp_insert_post() when a visitor runs a tool — never hand-authored.
                // 'do_not_allow' hides the "Add New" button (and blocks the
                // post-new.php screen) without affecting the programmatic inserts,
                // which don't check this capability.
                'create_posts'       => 'do_not_allow',
            ],
        ]);
    }

    public function register_metabox(): void {
        add_meta_box(
            'awg_aig_submission_details',
            __('Submission Details', 'authorwings-ai-tools'),
            [$this, 'metabox_html'],
            $this->cpt,
            'normal',
            'high'
        );
    }

    public function metabox_html($post): void {
        $template_id = (int) get_post_meta($post->ID, '_awg_aig_template_id', true);
        $user_id = (int) get_post_meta($post->ID, '_awg_aig_user_id', true);
        $gclid = (string) get_post_meta($post->ID, '_awg_aig_gclid', true);
        $utm = get_post_meta($post->ID, '_awg_aig_utm', true);
        $ip = (string) get_post_meta($post->ID, '_awg_aig_ip', true);
        $ua = (string) get_post_meta($post->ID, '_awg_aig_ua', true);
        $fields = get_post_meta($post->ID, '_awg_aig_fields', true);
        $output = (string) get_post_meta($post->ID, '_awg_aig_output', true);
        $model = (string) get_post_meta($post->ID, '_awg_aig_model', true);
        // v5.4.8: cached meta no longer displayed. Old records keep it in DB.
        $source_url = (string) get_post_meta($post->ID, '_awg_aig_source_url', true);

        if (!is_array($fields)) { $fields = []; }
        if (!is_array($utm)) { $utm = []; }

        // v5.4.8: rewritten template lookup. Previously showed "Unknown" when
        // template existed but had an empty post_title (common for AI tools
        // where admins override the schema name and leave title blank). Now:
        //  - template exists with title  → link + title + ID
        //  - template exists, no title   → link + "Template #N (no title)" + ID
        //  - template was deleted        → "Template #N (deleted)" no link
        //  - no template_id at all       → "Unknown"
        $tpl_post = ($template_id > 0) ? get_post($template_id) : null;
        $tpl_is_correct_type = $tpl_post && $tpl_post->post_type === $this->template_cpt;

        echo '<p><strong>' . esc_html__('Template:', 'authorwings-ai-tools') . '</strong> ';
        if ($tpl_is_correct_type) {
            $title = (string) $tpl_post->post_title;
            $label = $title !== ''
                ? $title
                : sprintf(__('Template #%d (no title)', 'authorwings-ai-tools'), $template_id);
            echo '<a href="' . esc_url(get_edit_post_link($template_id)) . '">' . esc_html($label) . '</a> (ID ' . esc_html((string)$template_id) . ')';
        } elseif ($template_id > 0) {
            printf(
                /* translators: %d: template id */
                esc_html__('Template #%d (deleted)', 'authorwings-ai-tools'),
                $template_id
            );
        } else {
            echo esc_html__('Unknown', 'authorwings-ai-tools');
        }
        echo '</p>';

        $user_label = $user_id ? ('#' . $user_id) : __('Guest', 'authorwings-ai-tools');
        if ($user_id) {
            $u = get_user_by('id', $user_id);
            if ($u) { $user_label = $u->display_name . ' (' . $u->user_email . ')'; }
        }

        echo '<p><strong>' . esc_html__('User:', 'authorwings-ai-tools') . '</strong> ' . esc_html($user_label) . '</p>';
        echo '<p><strong>' . esc_html__('Model:', 'authorwings-ai-tools') . '</strong> ' . esc_html($model ?: '') . '</p>';

        // v5.4.8: source URL display.
        if ($source_url !== '') {
            echo '<p><strong>' . esc_html__('Source page:', 'authorwings-ai-tools') . '</strong> ';
            echo '<a href="' . esc_url($source_url) . '" target="_blank" rel="noopener">' . esc_html($source_url) . '</a>';
            echo '</p>';
        }

        if ($gclid !== '') {
            echo '<p><strong>GCLID:</strong> ' . esc_html($gclid) . '</p>';
        }
        if (!empty($utm)) {
            echo '<p><strong>UTM:</strong> ';
            $parts = [];
            foreach ($utm as $k => $v) {
                $parts[] = esc_html($k) . '=' . esc_html((string) $v);
            }
            echo implode(' &middot; ', $parts);
            echo '</p>';
        }
        if ($ip !== '') {
            echo '<p><strong>' . esc_html__('IP:', 'authorwings-ai-tools') . '</strong> ' . esc_html($ip) . '</p>';
        }
        if ($ua !== '') {
            echo '<p><strong>' . esc_html__('User Agent:', 'authorwings-ai-tools') . '</strong> ' . esc_html($ua) . '</p>';
        }

        echo '<hr>';

        echo '<h4 style="margin:0 0 8px;">' . esc_html__('Submitted Fields', 'authorwings-ai-tools') . '</h4>';
        if (empty($fields)) {
            echo '<p class="description">' . esc_html__('No fields stored.', 'authorwings-ai-tools') . '</p>';
        } else {
            echo '<table class="widefat striped" style="max-width:980px;">';
            echo '<thead><tr><th>' . esc_html__('Field', 'authorwings-ai-tools') . '</th><th>' . esc_html__('Value', 'authorwings-ai-tools') . '</th></tr></thead><tbody>';
            foreach ($fields as $k => $v) {
                if (is_array($v)) { $v = implode(', ', $v); }
                echo '<tr><td><code>' . esc_html((string)$k) . '</code></td><td>' . nl2br(esc_html((string)$v)) . '</td></tr>';
            }
            echo '</tbody></table>';
        }

        // v5.4.8: AI Output with copy button. Vanilla JS, no jQuery dep.
        echo '<h4 style="margin:16px 0 8px;display:flex;align-items:center;gap:10px;">';
        echo esc_html__('AI Output', 'authorwings-ai-tools');
        echo '<button type="button" class="button button-small" id="awg-sub-copy">' . esc_html__('Copy', 'authorwings-ai-tools') . '</button>';
        echo '<span id="awg-sub-copy-status" style="font-size:12px;color:#1a8038;"></span>';
        echo '</h4>';
        echo '<textarea id="awg-sub-output" class="large-text code" rows="12" readonly>' . esc_textarea($output) . '</textarea>';
        ?>
        <script>
        (function(){
            var btn = document.getElementById('awg-sub-copy');
            var ta  = document.getElementById('awg-sub-output');
            var st  = document.getElementById('awg-sub-copy-status');
            if (!btn || !ta) return;
            btn.addEventListener('click', function(){
                ta.select();
                try {
                    document.execCommand('copy');
                    if (st) {
                        st.textContent = <?php echo wp_json_encode(__('Copied!', 'authorwings-ai-tools')); ?>;
                        setTimeout(function(){ st.textContent = ''; }, 1800);
                    }
                } catch(e) {}
            });
        })();
        </script>
        <?php
    }

    /**
     * v5.9.11: present the single submission as a read-only log entry.
     *
     * Submissions are captured automatically, not authored, so the post editor's
     * editable title and the Publish box (status / visibility / schedule / Update)
     * are misleading here. On this CPT's edit screen only, we hide the title input
     * and every publishing control except "Move to Trash", and relabel the box so
     * it reads as a log viewer rather than an editor. The descriptive heading is
     * printed by render_readonly_heading() via the edit_form_top hook.
     */
    public function readonly_edit_screen(): void {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->post_type !== $this->cpt || $screen->base !== 'post') {
            return;
        }
        ?>
        <style>
            /* Hide the editable title and the publishing controls; keep only the
               Move to Trash link (inside #major-publishing-actions). */
            #titlediv,
            #minor-publishing-actions,
            #misc-publishing-actions,
            #major-publishing-actions #publishing-action { display: none !important; }
            #submitdiv #major-publishing-actions { overflow: hidden; }
            .awg-sub-readonly-title { margin: 4px 0 2px; }
            .awg-sub-readonly-note { margin: 0 0 6px; color: #646970; font-style: italic; }
        </style>
        <script>
        jQuery(function ($) {
            // "Publish" no longer fits — this box only offers Move to Trash now.
            $('#submitdiv .hndle, #submitdiv h2.hndle').text(<?php echo wp_json_encode(__('Manage', 'authorwings-ai-tools')); ?>);
        });
        </script>
        <?php
    }

    /**
     * v5.9.11: print a human-readable heading for the read-only submission view.
     *
     * Built from stored meta (template name + capture time) rather than the raw
     * post title, so even older records — whose title was the terse
     * "Submission (Template #N)" — read clearly. Hooked on edit_form_top so it
     * lands just under the screen heading and above the details metabox.
     */
    public function render_readonly_heading($post): void {
        if (!($post instanceof \WP_Post) || $post->post_type !== $this->cpt) {
            return;
        }
        $tid   = (int) get_post_meta($post->ID, '_awg_aig_template_id', true);
        $tname = (string) get_post_meta($post->ID, '_awg_aig_template_title', true);
        if ($tname === '' && $tid > 0) {
            $tp = get_post($tid);
            $tname = $tp ? (string) $tp->post_title : '';
        }
        if ($tname === '') {
            $tname = $tid > 0
                ? sprintf(__('Template #%d', 'authorwings-ai-tools'), $tid)
                : __('Submission', 'authorwings-ai-tools');
        }

        $fields = get_post_meta($post->ID, '_awg_aig_fields', true);
        if (!is_array($fields)) { $fields = []; }
        $output = (string) get_post_meta($post->ID, '_awg_aig_output', true);
        // Headline is the subject line (same scheme as the list Title); the tool
        // name + capture time go on a muted subline beneath it.
        $heading = self::compose_record_title($fields, $output, $tname);

        $when = '';
        if ($post->post_date && $post->post_date !== '0000-00-00 00:00:00') {
            $fmt  = get_option('date_format') . ' ' . get_option('time_format');
            $when = mysql2date($fmt, $post->post_date);
        }
        $subline = $when !== '' ? $tname . ' · ' . $when : $tname;

        echo '<h2 class="awg-sub-readonly-title">' . esc_html($heading) . '</h2>';
        echo '<p class="awg-sub-readonly-note">'
            . esc_html($subline) . ' — '
            . esc_html__('read-only log entry captured automatically when a visitor ran this tool.', 'authorwings-ai-tools')
            . '</p>';
    }

    /**
     * v5.9.11: tidy the row actions for a read-only log. Drop Quick Edit (which
     * would let you change the title/status of a captured record) and relabel
     * "Edit" as "View"; keep Trash.
     */
    public function row_actions(array $actions, $post): array {
        if (!($post instanceof \WP_Post) || $post->post_type !== $this->cpt) {
            return $actions;
        }
        unset($actions['inline hide-if-no-js']); // Quick Edit
        if (isset($actions['edit'])) {
            $actions['edit'] = sprintf(
                '<a href="%s">%s</a>',
                esc_url((string) get_edit_post_link($post->ID)),
                esc_html__('View', 'authorwings-ai-tools')
            );
        }
        return $actions;
    }

    /**
     * v5.9.11: drop the redundant "Published" status link above the list. Every
     * submission is published, so the link duplicates "All"; keep All and Trash.
     */
    public function filter_views(array $views): array {
        unset($views['publish']);
        return $views;
    }

    /** Current submission-title scheme. Bump to re-run the backfill below. */
    private const TITLE_MIGRATION_VERSION = 2;

    /**
     * Compose a record title from the submission's own content, so the Title
     * column identifies what each run was *about* rather than repeating the
     * Template / Date columns.
     *
     * Order of preference:
     *  1. The most "subject-like" non-empty input field (its key looks like a
     *     title / name / subject / topic / etc.).
     *  2. Otherwise the first non-empty input field.
     *  3. Otherwise a snippet of the AI output.
     *  4. Otherwise the supplied fallback (e.g. the tool name).
     * The result is whitespace-normalised and truncated on a word boundary.
     */
    public static function compose_record_title(array $fields, string $output = '', string $fallback = ''): string {
        $preferred = '';
        $first = '';
        foreach ($fields as $k => $v) {
            if (is_array($v)) { $v = implode(', ', $v); }
            $v = trim((string) $v);
            if ($v === '') { continue; }
            if ($first === '') { $first = $v; }
            if ($preferred === '' && preg_match('/title|name|subject|topic|keyword|book|theme|idea|headline|product|brand|company|prompt/i', (string) $k)) {
                $preferred = $v;
            }
        }
        $base = $preferred !== '' ? $preferred : $first;
        if ($base === '') { $base = trim(wp_strip_all_tags($output)); }
        if ($base === '') { return $fallback; }

        $base = trim((string) preg_replace('/\s+/', ' ', $base));
        if ($base === '') { return $fallback; }
        return wp_html_excerpt($base, 70, '…');
    }

    /**
     * v5.9.12+: one-time backfill of submission titles.
     *
     * Rewrites stored titles to the current scheme (see compose_record_title) so
     * the Title column reads as a subject line. Runs only for admins, never during
     * AJAX, and is:
     *  - resumable / idempotent: each record stores the scheme version it was
     *    migrated to; we only fetch records not yet on the current version.
     *  - batched: up to 100 per admin page load, so a large backlog catches up over
     *    a few loads instead of timing out one request.
     * Once every record is current, a site option short-circuits the query.
     */
    public function maybe_migrate_titles(): void {
        if (wp_doing_ajax() || !current_user_can('manage_options')) {
            return;
        }
        $version = self::TITLE_MIGRATION_VERSION;
        if ((int) get_option('awg_aig_sub_titles_migrated') >= $version) {
            return;
        }

        $ids = get_posts([
            'post_type'      => $this->cpt,
            'post_status'    => 'any',
            'posts_per_page' => 100,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'cache_results'  => false,
            'meta_query'     => [
                'relation' => 'OR',
                ['key' => '_awg_aig_title_migrated', 'compare' => 'NOT EXISTS'],
                ['key' => '_awg_aig_title_migrated', 'value' => $version, 'compare' => '!='],
            ],
        ]);

        if (empty($ids)) {
            update_option('awg_aig_sub_titles_migrated', $version, false);
            return;
        }

        foreach ($ids as $pid) {
            $pid    = (int) $pid;
            $fields = get_post_meta($pid, '_awg_aig_fields', true);
            if (!is_array($fields)) { $fields = []; }
            $output = (string) get_post_meta($pid, '_awg_aig_output', true);

            // Fallback when a record has no usable content: the tool name, else id.
            $tid   = (int) get_post_meta($pid, '_awg_aig_template_id', true);
            $tname = (string) get_post_meta($pid, '_awg_aig_template_title', true);
            if ($tname === '' && $tid > 0) {
                $tp = get_post($tid);
                $tname = $tp ? (string) $tp->post_title : '';
            }
            if ($tname === '') {
                $tname = $tid > 0
                    ? sprintf(__('Template #%d', 'authorwings-ai-tools'), $tid)
                    : __('Submission', 'authorwings-ai-tools');
            }

            $title = self::compose_record_title($fields, $output, $tname);

            wp_update_post(['ID' => $pid, 'post_title' => $title]);
            update_post_meta($pid, '_awg_aig_title_migrated', $version);
        }
    }

    /**
     * v5.4.8: At-a-glance columns on the AI Submissions list. Replaces the
     * default Title-only display so you can see Template / User / Model
     * without opening each record.
     */
    public function list_columns(array $columns): array {
        $new = [];
        foreach ($columns as $key => $label) {
            $new[$key] = $label;
            // Insert our columns right after the default title column.
            if ($key === 'title') {
                $new['awg_template'] = __('Template', 'authorwings-ai-tools');
                $new['awg_user']     = __('User', 'authorwings-ai-tools');
                $new['awg_model']    = __('Model', 'authorwings-ai-tools');
            }
        }
        return $new;
    }

    public function list_column_data(string $column, int $post_id): void {
        if ($column === 'awg_template') {
            $tid = (int) get_post_meta($post_id, '_awg_aig_template_id', true);
            if ($tid <= 0) { echo '—'; return; }
            $tp = get_post($tid);
            if ($tp && $tp->post_type === $this->template_cpt) {
                $title = (string) $tp->post_title;
                if ($title === '') $title = sprintf(__('Template #%d (no title)', 'authorwings-ai-tools'), $tid);
                echo '<a href="' . esc_url(get_edit_post_link($tid)) . '">' . esc_html($title) . '</a>';
            } else {
                printf(esc_html__('#%d (deleted)', 'authorwings-ai-tools'), $tid);
            }
            return;
        }
        if ($column === 'awg_user') {
            $uid = (int) get_post_meta($post_id, '_awg_aig_user_id', true);
            if ($uid <= 0) { echo esc_html__('Guest', 'authorwings-ai-tools'); return; }
            $u = get_user_by('id', $uid);
            echo $u ? esc_html($u->display_name) : ('#' . $uid);
            return;
        }
        if ($column === 'awg_model') {
            $model = (string) get_post_meta($post_id, '_awg_aig_model', true);
            echo $model !== '' ? '<code>' . esc_html($model) . '</code>' : '—';
            return;
        }
    }

    /**
     * Add a template dropdown filter above the Submissions list.
     */
    public function restrict_manage_posts(string $post_type): void {
        if ($post_type !== $this->cpt) return;

        $current = isset($_GET['awg_filter_template']) ? (int) $_GET['awg_filter_template'] : 0;
        $templates = get_posts([
            'post_type'      => $this->template_cpt,
            'post_status'    => ['publish', 'draft'],
            'numberposts'    => 200,
            'orderby'        => 'title',
            'order'          => 'ASC',
            'suppress_filters' => true,
        ]);

        echo '<select name="awg_filter_template">';
        echo '<option value="0">' . esc_html__('All Templates', 'authorwings-ai-tools') . '</option>';
        foreach ($templates as $tpl) {
            printf(
                '<option value="%1$d" %2$s>%3$s</option>',
                (int) $tpl->ID,
                selected($current, (int) $tpl->ID, false),
                esc_html($tpl->post_title ?: ('#' . $tpl->ID))
            );
        }
        echo '</select>';

        // v5.9.11: Model filter. The list mixes OpenAI / Claude / DeepSeek models,
        // so filtering by model is a natural companion to the template filter. The
        // option list is the set of distinct models actually present in the meta,
        // capped so the query stays cheap on large sites.
        global $wpdb;
        $models = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value <> '' ORDER BY meta_value ASC LIMIT 100",
            '_awg_aig_model'
        ));
        if (!empty($models)) {
            $current_model = isset($_GET['awg_filter_model']) ? sanitize_text_field(wp_unslash($_GET['awg_filter_model'])) : '';
            echo '<select name="awg_filter_model">';
            echo '<option value="">' . esc_html__('All Models', 'authorwings-ai-tools') . '</option>';
            foreach ($models as $model) {
                printf(
                    '<option value="%1$s" %2$s>%3$s</option>',
                    esc_attr($model),
                    selected($current_model, $model, false),
                    esc_html($model)
                );
            }
            echo '</select>';
        }
    }

    /**
     * Apply the template filter to the Submissions list query.
     */
    public function filter_query(\WP_Query $query): void {
        if (!is_admin() || !$query->is_main_query()) return;
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->post_type !== $this->cpt) return;

        $tpl = isset($_GET['awg_filter_template']) ? (int) $_GET['awg_filter_template'] : 0;
        $model = isset($_GET['awg_filter_model']) ? sanitize_text_field(wp_unslash($_GET['awg_filter_model'])) : '';

        $meta = (array) $query->get('meta_query');
        if ($tpl > 0) {
            $meta[] = [
                'key'   => '_awg_aig_template_id',
                'value' => $tpl,
            ];
        }
        if ($model !== '') {
            $meta[] = [
                'key'   => '_awg_aig_model',
                'value' => $model,
            ];
        }
        if (!empty($meta)) {
            $query->set('meta_query', $meta);
        }
    }

    /**
     * Add an "Export CSV" button next to the page title on the list screen.
     */
    public function list_table_export_button(): void {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->id !== 'edit-' . $this->cpt) return;

        $tpl_filter = isset($_GET['awg_filter_template']) ? (int) $_GET['awg_filter_template'] : 0;
        $model_filter = isset($_GET['awg_filter_model']) ? sanitize_text_field(wp_unslash($_GET['awg_filter_model'])) : '';
        $export_args = ['action' => 'awg_aig_export_submissions', 'template' => $tpl_filter];
        if ($model_filter !== '') {
            $export_args['model'] = $model_filter;
        }
        $url = wp_nonce_url(
            add_query_arg($export_args, admin_url('admin-post.php')),
            'awg_aig_export_submissions'
        );
        ?>
        <style>.awg-aig-export-btn{margin-left:8px;}</style>
        <script>
        jQuery(function($){
            $('.wrap h1.wp-heading-inline').after(
                '<a href="<?php echo esc_url($url); ?>" class="page-title-action awg-aig-export-btn"><?php echo esc_js(__('Export to Excel', 'authorwings-ai-tools')); ?></a>'
            );
        });
        </script>
        <?php
    }

    /**
     * Stream all (or filtered) submissions to the browser.
     *
     * Preferred output is a native .xlsx workbook (arranged columns, a frozen
     * branded header and wrapped Source URL / Fields / Output columns), so the
     * file opens directly in Excel with no "format and extension don't match"
     * warning and no values being re-parsed as numbers. Hosts without the PHP
     * Zip extension fall back to the streaming CSV.
     *
     * Both paths page through results in batches of 500 (v5.4.14) so the export
     * never OOMs once a site has tens of thousands of submissions: the .xlsx
     * worksheet is streamed to a temp file batch-by-batch and the CSV goes
     * straight to php://output, so peak memory stays bounded by the batch size,
     * not the total row count.
     */
    public function handle_export(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'authorwings-ai-tools'));
        }
        check_admin_referer('awg_aig_export_submissions');

        $tpl_filter = isset($_GET['template']) ? (int) $_GET['template'] : 0;
        $model_filter = isset($_GET['model']) ? sanitize_text_field(wp_unslash($_GET['model'])) : '';

        // Preferred path: a genuine .xlsx file (needs the Zip extension).
        if ($this->stream_xlsx_export($tpl_filter, $model_filter)) {
            exit;
        }

        // Fallback: streaming CSV.
        nocache_headers();
        header('Content-Type: text/csv; charset=utf-8');
        $filename = 'awg-aig-submissions-' . wp_date('Y-m-d-Hi') . '.csv';
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $fh = fopen('php://output', 'w');
        // UTF-8 BOM for Excel compatibility.
        fwrite($fh, "\xEF\xBB\xBF");
        fputcsv($fh, $this->export_headers());

        // v5.4.15: CSV cell hardener. fputcsv quotes for the CSV parser
        // but does nothing about cells whose first character is one of
        // = + - @ \t \r — those are interpreted as formulas or commands
        // by Excel and LibreOffice Calc when the export is opened. The
        // data rows below include raw guest-submitted field values and
        // unfiltered AI output, so any anonymous submitter could
        // otherwise inject a HYPERLINK exfiltration formula, or (on
        // legacy Excel) a DDE payload that fires the moment an admin
        // opens the file. Prefixing a literal apostrophe forces the
        // cell to render as text and disarms the formula engine, while
        // still being visually obvious to anyone reviewing the export.
        // (The .xlsx path is immune: every cell is written as an inline
        // string, which Excel never evaluates as a formula.)
        $csv_safe = static function ($v): string {
            $s = (string) $v;
            if ($s !== '' && in_array($s[0], ['=', '+', '-', '@', "\t", "\r"], true)) {
                return "'" . $s;
            }
            return $s;
        };

        // v5.4.14: page through results so memory stays bounded.
        $per_page = 500;
        $paged = 1;
        $safety_max_pages = 2000; // hard cap: 1M rows. Beyond that, something is wrong.

        while ($paged <= $safety_max_pages) {
            $posts = get_posts($this->export_query_args($tpl_filter, $model_filter, $paged, $per_page));
            if (empty($posts)) break;

            foreach ($posts as $p) {
                fputcsv($fh, array_map($csv_safe, $this->build_export_row($p)));
            }

            // Flush each batch to the client so the browser keeps the
            // download alive and PHP releases the SAPI buffer.
            if (function_exists('ob_get_level') && ob_get_level() > 0) {
                @ob_flush();
            }
            @flush();

            $this->drop_meta_cache($posts);

            if (count($posts) < $per_page) break; // last (partial) page
            $paged++;
        }

        fclose($fh);
        exit;
    }

    /**
     * Column headers for the export, in order. "Template" is "Template Title"
     * (v5.4.14) so it's distinguishable from "Template ID" at narrow widths.
     *
     * @return string[]
     */
    private function export_headers(): array {
        return [
            'ID', 'Date', 'Template ID', 'Template Title', 'User ID', 'User', 'Model',
            'Source URL',
            'GCLID', 'UTM Source', 'UTM Medium', 'UTM Campaign', 'UTM Term', 'UTM Content',
            'IP', 'User Agent', 'Fields (JSON)', 'Output',
        ];
    }

    /**
     * Per-column min/max width (in Excel character units) and cell kind for the
     * .xlsx export, aligned by index with export_headers(). Widths are then
     * auto-fitted to the actual content between these bounds, so short columns
     * (IDs) stay tight, unused columns (UTM/GCLID on most sites) collapse to
     * their header width, and huge free-text columns (Source URL, Fields,
     * Output) are capped at a comfortable reading width and wrap.
     *
     * 'text' keeps the value verbatim (IDs, dates, model, IP — never re-parsed
     * as numbers); 'wrap' is a text-wrapping cell.
     *
     * @return array<int,array{min:int,max:int,kind:string}>
     */
    private function export_columns_xlsx(): array {
        return [
            ['min' => 6,  'max' => 8,  'kind' => 'text'], // ID
            ['min' => 20, 'max' => 21, 'kind' => 'text'], // Date
            ['min' => 8,  'max' => 12, 'kind' => 'text'], // Template ID
            ['min' => 16, 'max' => 34, 'kind' => 'wrap'], // Template Title
            ['min' => 8,  'max' => 9,  'kind' => 'text'], // User ID
            ['min' => 16, 'max' => 36, 'kind' => 'wrap'], // User
            ['min' => 10, 'max' => 18, 'kind' => 'text'], // Model
            ['min' => 16, 'max' => 48, 'kind' => 'wrap'], // Source URL
            ['min' => 6,  'max' => 24, 'kind' => 'wrap'], // GCLID
            ['min' => 11, 'max' => 16, 'kind' => 'text'], // UTM Source
            ['min' => 11, 'max' => 16, 'kind' => 'text'], // UTM Medium
            ['min' => 13, 'max' => 18, 'kind' => 'wrap'], // UTM Campaign
            ['min' => 10, 'max' => 16, 'kind' => 'wrap'], // UTM Term
            ['min' => 12, 'max' => 16, 'kind' => 'wrap'], // UTM Content
            ['min' => 12, 'max' => 18, 'kind' => 'text'], // IP
            ['min' => 16, 'max' => 46, 'kind' => 'wrap'], // User Agent
            ['min' => 18, 'max' => 52, 'kind' => 'wrap'], // Fields (JSON)
            ['min' => 20, 'max' => 72, 'kind' => 'wrap'], // Output
        ];
    }

    /**
     * Shared WP_Query args for one page of the export.
     *
     * @param int    $tpl_filter   Template ID filter (0 = all).
     * @param string $model_filter Model filter ('' = all).
     * @param int    $paged        1-based page.
     * @param int    $per_page     Rows per page.
     * @return array
     */
    private function export_query_args(int $tpl_filter, string $model_filter, int $paged, int $per_page): array {
        $args = [
            'post_type'      => $this->cpt,
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $paged,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'no_found_rows'  => true,   // we don't need pagination totals
            'cache_results'  => false,  // huge exports: don't pollute object cache
        ];
        $meta_query = [];
        if ($tpl_filter > 0) {
            $meta_query[] = ['key' => '_awg_aig_template_id', 'value' => $tpl_filter];
        }
        if ($model_filter !== '') {
            $meta_query[] = ['key' => '_awg_aig_model', 'value' => $model_filter];
        }
        if (!empty($meta_query)) {
            $args['meta_query'] = $meta_query;
        }
        return $args;
    }

    /**
     * Build the ordered cell values for one submission (aligned with
     * export_headers()). Shared by the CSV and .xlsx exporters.
     *
     * @param \WP_Post $p Submission post.
     * @return string[]
     */
    private function build_export_row(\WP_Post $p): array {
        $tpl_id    = (int) get_post_meta($p->ID, '_awg_aig_template_id', true);
        $tpl_title = $tpl_id > 0 ? $this->export_template_title($tpl_id) : '';

        $user_id    = (int) get_post_meta($p->ID, '_awg_aig_user_id', true);
        $user_label = '';
        if ($user_id) {
            $u = get_user_by('id', $user_id);
            if ($u) $user_label = $u->display_name . ' <' . $u->user_email . '>';
        }

        $utm = get_post_meta($p->ID, '_awg_aig_utm', true);
        if (!is_array($utm)) $utm = [];
        $fields = get_post_meta($p->ID, '_awg_aig_fields', true);
        if (!is_array($fields)) $fields = [];
        $fields_json = wp_json_encode($fields, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($fields_json)) $fields_json = '';

        return [
            (string) $p->ID,
            (string) $p->post_date,
            $tpl_id ? (string) $tpl_id : '',
            $tpl_title,
            $user_id ? (string) $user_id : '',
            $user_label,
            (string) get_post_meta($p->ID, '_awg_aig_model', true),
            (string) get_post_meta($p->ID, '_awg_aig_source_url', true),
            (string) get_post_meta($p->ID, '_awg_aig_gclid', true),
            (string) ($utm['utm_source']   ?? ''),
            (string) ($utm['utm_medium']   ?? ''),
            (string) ($utm['utm_campaign'] ?? ''),
            (string) ($utm['utm_term']     ?? ''),
            (string) ($utm['utm_content']  ?? ''),
            (string) get_post_meta($p->ID, '_awg_aig_ip', true),
            (string) get_post_meta($p->ID, '_awg_aig_ua', true),
            $fields_json,
            (string) get_post_meta($p->ID, '_awg_aig_output', true),
        ];
    }

    /**
     * Resolve a template ID to a display title, distinguishing the "deleted"
     * and "no title" cases (v5.4.14 — matches the metabox/list-column logic).
     *
     * @param int $tpl_id Template post ID.
     * @return string
     */
    private function export_template_title(int $tpl_id): string {
        if ($tpl_id <= 0) {
            return '';
        }
        $tpl_post = get_post($tpl_id);
        if (!$tpl_post || $tpl_post->post_type !== $this->template_cpt) {
            /* translators: %d: template id */
            return sprintf(__('Template #%d (deleted)', 'authorwings-ai-tools'), $tpl_id);
        }
        if ((string) $tpl_post->post_title === '') {
            /* translators: %d: template id */
            return sprintf(__('Template #%d (no title)', 'authorwings-ai-tools'), $tpl_id);
        }
        return (string) $tpl_post->post_title;
    }

    /**
     * Drop the post-meta cache warmed by a batch; otherwise it grows unbounded
     * across batches even with cache_results=false (meta is cached separately
     * by update_meta_cache).
     *
     * @param \WP_Post[] $posts Posts from the batch.
     */
    private function drop_meta_cache(array $posts): void {
        $ids = wp_list_pluck($posts, 'ID');
        if (function_exists('wp_cache_delete_multiple')) {
            wp_cache_delete_multiple($ids, 'post_meta');
        } else {
            foreach ($ids as $id) wp_cache_delete($id, 'post_meta');
        }
    }

    /**
     * Stream a native .xlsx workbook of the submissions.
     *
     * The worksheet XML is streamed to a temp file batch-by-batch (so memory
     * stays bounded), the package is zipped, then sent with readfile(). Returns
     * true if it handled the response (headers + body sent), or false — before
     * any output — when the Zip extension is unavailable, so handle_export()
     * can fall back to CSV.
     *
     * @param int    $tpl_filter   Template ID filter (0 = all).
     * @param string $model_filter Model filter ('' = all).
     * @return bool
     */
    private function stream_xlsx_export(int $tpl_filter, string $model_filter): bool {
        if (!class_exists('ZipArchive')) {
            return false;
        }

        $sheet_tmp = wp_tempnam('awg-aig-sheet-xlsx');
        if (!$sheet_tmp) {
            return false;
        }
        $sh = fopen($sheet_tmp, 'w');
        if (!$sh) {
            @unlink($sheet_tmp);
            return false;
        }

        $headers = $this->export_headers();
        $columns = $this->export_columns_xlsx();
        $last    = $this->xlsx_col_letter(count($columns) - 1);

        // Uniform data-row height (points): tall enough to preview a few wrapped
        // lines of the big free-text columns, so the grid stays even and
        // scannable instead of some rows one line and others forty.
        $data_row_height = 45;

        // --- Pass 1: stream the data rows to a temp file, measuring the widest
        // line in each column so we can auto-fit the columns afterwards. Keeps
        // memory bounded (only the tiny per-column max array is held). ---
        $data_tmp = wp_tempnam('awg-aig-rows-xlsx');
        if (!$data_tmp) {
            fclose($sh);
            @unlink($sheet_tmp);
            return false;
        }
        $dh = fopen($data_tmp, 'w');
        if (!$dh) {
            fclose($sh);
            @unlink($sheet_tmp);
            @unlink($data_tmp);
            return false;
        }

        $maxlen = array_fill(0, count($columns), 0);
        $r = 5;
        $n = 0;
        $per_page = 500;
        $paged = 1;
        $safety_max_pages = 2000;

        while ($paged <= $safety_max_pages) {
            $posts = get_posts($this->export_query_args($tpl_filter, $model_filter, $paged, $per_page));
            if (empty($posts)) break;

            foreach ($posts as $p) {
                $values = $this->build_export_row($p);
                $zebra  = (1 === $n % 2);

                $row_xml = '<row r="' . $r . '" ht="' . $data_row_height . '" customHeight="1">';
                foreach ($columns as $i => $col) {
                    $len = $this->xlsx_longest_line($values[$i]);
                    if ($len > $maxlen[$i]) {
                        $maxlen[$i] = $len;
                    }
                    $style    = $this->xlsx_style_index($col['kind'], $zebra);
                    $ref      = $this->xlsx_col_letter($i) . $r;
                    $row_xml .= $this->xlsx_cell($ref, $style, $values[$i]);
                }
                $row_xml .= '</row>';
                fwrite($dh, $row_xml);

                $r++;
                $n++;
            }

            $this->drop_meta_cache($posts);

            if (count($posts) < $per_page) break;
            $paged++;
        }
        fclose($dh);

        // Auto-fit each column between its min/max bound from the measured
        // content (and always wide enough for its header label).
        $widths = [];
        foreach ($columns as $i => $col) {
            $w = min($maxlen[$i], $col['max']) + 2;         // content, capped
            $w = max($w, strlen($headers[$i]) + 1);          // header must fit
            $w = max($w, $col['min']);                       // not below min
            $w = min($w, $col['max']);                       // not above max
            $widths[$i] = round($w, 2);
        }

        // --- Pass 2: assemble the worksheet (prolog + fitted columns + banner +
        // header), then stream the buffered data rows in and close. ---
        fwrite($sh, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>');
        fwrite($sh, '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">');
        fwrite($sh, '<sheetViews><sheetView workbookViewId="0"><pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>');
        fwrite($sh, '<sheetFormatPr defaultRowHeight="15"/>');

        $cols_xml = '<cols>';
        foreach ($columns as $i => $col) {
            $n = $i + 1;
            $cols_xml .= '<col min="' . $n . '" max="' . $n . '" width="' . $widths[$i] . '" customWidth="1"/>';
        }
        $cols_xml .= '</cols>';
        fwrite($sh, $cols_xml);

        fwrite($sh, '<sheetData>');

        // Row 1 title, row 2 subtitle (scope, count, timestamp), row 4 header
        // (row 3 left blank for breathing room).
        $total = $this->export_total($tpl_filter, $model_filter);
        fwrite($sh, '<row r="1" ht="24" customHeight="1">' . $this->xlsx_cell('A1', 2, __('AI Submissions', 'authorwings-ai-tools')) . '</row>');
        fwrite($sh, '<row r="2" ht="16" customHeight="1">' . $this->xlsx_cell('A2', 3, $this->export_meta_line($total, $tpl_filter, $model_filter)) . '</row>');

        $header_row = '<row r="4" ht="22" customHeight="1">';
        foreach ($headers as $i => $label) {
            $header_row .= $this->xlsx_cell($this->xlsx_col_letter($i) . '4', 1, $label);
        }
        $header_row .= '</row>';
        fwrite($sh, $header_row);

        // Stream the buffered data rows in (chunked, so memory stays bounded).
        $rows_in = fopen($data_tmp, 'r');
        if ($rows_in) {
            while (!feof($rows_in)) {
                $chunk = fread($rows_in, 65536);
                if ('' !== $chunk && false !== $chunk) {
                    fwrite($sh, $chunk);
                }
            }
            fclose($rows_in);
        }
        @unlink($data_tmp);

        fwrite($sh, '</sheetData>');
        fwrite($sh, '<mergeCells count="2"><mergeCell ref="A1:' . $last . '1"/><mergeCell ref="A2:' . $last . '2"/></mergeCells>');
        fwrite($sh, '</worksheet>');
        fclose($sh);

        // Assemble the package.
        $zip_tmp = wp_tempnam('awg-aig-xlsx');
        if (!$zip_tmp) {
            @unlink($sheet_tmp);
            return false;
        }
        $zip = new \ZipArchive();
        if (true !== $zip->open($zip_tmp, \ZipArchive::OVERWRITE)) {
            @unlink($sheet_tmp);
            @unlink($zip_tmp);
            return false;
        }
        $zip->addFromString('[Content_Types].xml', $this->xlsx_content_types());
        $zip->addFromString('_rels/.rels', $this->xlsx_root_rels());
        $zip->addFromString('xl/workbook.xml', $this->xlsx_workbook_xml());
        $zip->addFromString('xl/_rels/workbook.xml.rels', $this->xlsx_workbook_rels());
        $zip->addFromString('xl/styles.xml', $this->xlsx_styles_xml());
        $zip->addFile($sheet_tmp, 'xl/worksheets/sheet1.xml'); // read lazily on close()
        $zip->close();

        nocache_headers();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="awg-aig-submissions-' . wp_date('Y-m-d-Hi') . '.xlsx"');
        $size = filesize($zip_tmp);
        if (false !== $size) {
            header('Content-Length: ' . $size);
        }
        readfile($zip_tmp);

        @unlink($zip_tmp);
        @unlink($sheet_tmp);
        return true;
    }

    /**
     * Count submissions matching the current filter (for the subtitle line).
     *
     * @param int    $tpl_filter   Template ID filter (0 = all).
     * @param string $model_filter Model filter ('' = all).
     * @return int
     */
    private function export_total(int $tpl_filter, string $model_filter): int {
        $args = $this->export_query_args($tpl_filter, $model_filter, 1, 1);
        $args['fields']        = 'ids';
        $args['no_found_rows'] = false;
        $q = new \WP_Query($args);
        return (int) $q->found_posts;
    }

    /**
     * Subtitle line: scope/filters, record count and export timestamp.
     *
     * @param int    $total        Matching record count.
     * @param int    $tpl_filter   Template ID filter (0 = all).
     * @param string $model_filter Model filter ('' = all).
     * @return string
     */
    private function export_meta_line(int $total, int $tpl_filter, string $model_filter): string {
        $parts = [];
        /* translators: %s: number of records */
        $parts[] = sprintf(_n('%s record', '%s records', $total, 'authorwings-ai-tools'), number_format_i18n($total));
        if ($tpl_filter > 0) {
            /* translators: %s: template title */
            $parts[] = sprintf(__('template: %s', 'authorwings-ai-tools'), $this->export_template_title($tpl_filter));
        }
        if ($model_filter !== '') {
            /* translators: %s: model name */
            $parts[] = sprintf(__('model: %s', 'authorwings-ai-tools'), $model_filter);
        }
        /* translators: %s: export date/time */
        $parts[] = sprintf(__('exported %s', 'authorwings-ai-tools'), wp_date(get_option('date_format') . ' ' . get_option('time_format')));
        return implode(' · ', $parts);
    }

    /**
     * Map a column kind + row parity to a cellXfs style index (see
     * xlsx_styles_xml()).
     *
     * @param string $kind  Column kind (text|wrap).
     * @param bool   $zebra Whether this is a shaded (alternate) row.
     * @return int
     */
    private function xlsx_style_index(string $kind, bool $zebra): int {
        if ('text' === $kind) {
            return $zebra ? 7 : 6;
        }
        return $zebra ? 5 : 4; // wrap
    }

    /**
     * Render one worksheet cell. Empty values still emit a styled (bordered)
     * cell; non-empty values are written as inline strings so Excel never
     * re-parses them as numbers or evaluates them as formulas.
     *
     * @param string $ref   A1-style reference.
     * @param int    $style cellXfs index.
     * @param string $value Display value.
     * @return string
     */
    private function xlsx_cell(string $ref, int $style, string $value): string {
        if ('' === $value) {
            return '<c r="' . $ref . '" s="' . $style . '"/>';
        }
        return '<c r="' . $ref . '" s="' . $style . '" t="inlineStr"><is><t xml:space="preserve">' . $this->xlsx_escape($value) . '</t></is></c>';
    }

    /**
     * XML-escape a value for an inline-string cell. Line breaks are preserved;
     * control characters illegal in XML 1.0 are stripped so the worksheet stays
     * well-formed even with messy pasted input.
     *
     * @param string $value Raw value.
     * @return string
     */
    private function xlsx_escape(string $value): string {
        $value = str_replace(["\r\n", "\r"], "\n", $value);
        // Strip control chars except tab (\x09) and newline (\x0A).
        $value = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $value);
        return str_replace(['&', '<', '>'], ['&amp;', '&lt;', '&gt;'], (string) $value);
    }

    /**
     * Length (in characters) of the longest single line in a value — used to
     * auto-fit column widths. Wrapped cells break on newlines, so the widest
     * line, not the total length, is what a column needs to accommodate.
     *
     * @param string $value Raw value.
     * @return int
     */
    private function xlsx_longest_line(string $value): int {
        if ('' === $value) {
            return 0;
        }
        $best = 0;
        foreach (explode("\n", str_replace(["\r\n", "\r"], "\n", $value)) as $line) {
            $len = function_exists('mb_strlen') ? mb_strlen($line) : strlen($line);
            if ($len > $best) {
                $best = $len;
            }
        }
        return $best;
    }

    /**
     * Convert a 0-based column index to its A1 column letters.
     *
     * @param int $index 0-based column index.
     * @return string
     */
    private function xlsx_col_letter(int $index): string {
        $letters = '';
        $index++;
        while ($index > 0) {
            $mod     = ($index - 1) % 26;
            $letters = chr(65 + $mod) . $letters;
            $index   = intdiv($index - 1, 26);
        }
        return $letters;
    }

    /**
     * OpenXML [Content_Types].xml part.
     *
     * @return string
     */
    private function xlsx_content_types(): string {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '</Types>';
    }

    /**
     * OpenXML package root relationships.
     *
     * @return string
     */
    private function xlsx_root_rels(): string {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>';
    }

    /**
     * OpenXML workbook part (single "Submissions" sheet).
     *
     * @return string
     */
    private function xlsx_workbook_xml(): string {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets><sheet name="Submissions" sheetId="1" r:id="rId1"/></sheets>'
            . '</workbook>';
    }

    /**
     * OpenXML workbook relationships (worksheet + styles).
     *
     * @return string
     */
    private function xlsx_workbook_rels(): string {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            . '</Relationships>';
    }

    /**
     * OpenXML styles part — fonts, fills, borders and the cell format records
     * referenced by the sheet. numFmtId 49 is the built-in text format, so text
     * cells are never reinterpreted as numbers.
     *
     * cellXfs indices used by xlsx_style_index(): 1 header, 2 title, 3 subtitle,
     * 4/5 wrap (white/zebra), 6/7 text (white/zebra).
     *
     * @return string
     */
    private function xlsx_styles_xml(): string {
        $fonts = '<fonts count="4">'
            . '<font><sz val="11"/><color rgb="FF1C2439"/><name val="Calibri"/></font>'
            . '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
            . '<font><b/><sz val="16"/><color rgb="FF4A6459"/><name val="Calibri"/></font>'
            . '<font><sz val="10"/><color rgb="FF5D6675"/><name val="Calibri"/></font>'
            . '</fonts>';

        $fills = '<fills count="4">'
            . '<fill><patternFill patternType="none"/></fill>'
            . '<fill><patternFill patternType="gray125"/></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FF4A6459"/></patternFill></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FFFAF7F0"/></patternFill></fill>'
            . '</fills>';

        $edge    = '<left style="thin"><color rgb="FFD8CFBB"/></left><right style="thin"><color rgb="FFD8CFBB"/></right><top style="thin"><color rgb="FFD8CFBB"/></top><bottom style="thin"><color rgb="FFD8CFBB"/></bottom><diagonal/>';
        $borders = '<borders count="2">'
            . '<border><left/><right/><top/><bottom/><diagonal/></border>'
            . '<border>' . $edge . '</border>'
            . '</borders>';

        $cellxfs = '<cellXfs count="8">'
            . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' // 0 default
            . '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="left" vertical="center" wrapText="1"/></xf>' // 1 header
            . '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>' // 2 title
            . '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="left" vertical="center"/></xf>' // 3 subtitle
            . '<xf numFmtId="49" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>' // 4 wrap white
            . '<xf numFmtId="49" fontId="0" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>' // 5 wrap zebra
            . '<xf numFmtId="49" fontId="0" fillId="0" borderId="1" xfId="0" applyFont="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>' // 6 text white
            . '<xf numFmtId="49" fontId="0" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="top"/></xf>' // 7 text zebra
            . '</cellXfs>';

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<numFmts count="0"/>'
            . $fonts . $fills . $borders
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . $cellxfs
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';
    }

    /**
     * Bulk-delete all submissions (from Settings page).
     *
     * v5.4.14: batched so sites with tens of thousands of records don't
     * hit memory or max_execution_time. Suspends cache_addition for the
     * duration; otherwise wp_delete_post warms object cache for every
     * post we're about to throw away.
     */
    public function handle_delete_all(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Permission denied.', 'authorwings-ai-tools'));
        }
        check_admin_referer('awg_aig_delete_all_submissions');

        $deleted = 0;
        $batch_size = 200;
        $safety_max_batches = 5000; // hard cap: 1M records.

        if (function_exists('wp_suspend_cache_addition')) {
            wp_suspend_cache_addition(true);
        }

        for ($i = 0; $i < $safety_max_batches; $i++) {
            $ids = get_posts([
                'post_type'      => $this->cpt,
                'post_status'    => 'any',
                'posts_per_page' => $batch_size,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'cache_results'  => false,
            ]);
            if (empty($ids)) break;

            foreach ($ids as $pid) {
                wp_delete_post((int) $pid, true);
                $deleted++;
            }
            if (count($ids) < $batch_size) break;
        }

        if (function_exists('wp_suspend_cache_addition')) {
            wp_suspend_cache_addition(false);
        }

        wp_safe_redirect(add_query_arg(
            ['page' => 'awg-aig-settings', 'awg_deleted' => $deleted],
            admin_url('edit.php?post_type=' . $this->template_cpt)
        ));
        exit;
    }

    /**
     * Cron callback: delete submissions older than the retention setting.
     *
     * v5.4.14: loops batches of 500 until the date_query returns nothing
     * (capped at 50 iterations = 25k records per cron tick, so a single
     * run can't run away). Previously the hardcoded 500/day cap meant a
     * site with a real backlog could never catch up.
     */
    public function cron_cleanup(): void {
        $settings = get_option(Plugin::OPT, []);
        $days = isset($settings['submissions_retention_days']) ? (int) $settings['submissions_retention_days'] : 0;
        if ($days <= 0) return;

        $cutoff = gmdate('Y-m-d H:i:s', time() - ($days * DAY_IN_SECONDS));
        $batch_size = 500;
        $max_batches = 50; // 25k records per run — enough to catch up busy sites without monopolizing the cron.

        if (function_exists('wp_suspend_cache_addition')) {
            wp_suspend_cache_addition(true);
        }

        for ($i = 0; $i < $max_batches; $i++) {
            $ids = get_posts([
                'post_type'      => $this->cpt,
                'post_status'    => 'any',
                'posts_per_page' => $batch_size,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'cache_results'  => false,
                'date_query'     => [['column' => 'post_date_gmt', 'before' => $cutoff]],
            ]);
            if (empty($ids)) break;

            foreach ($ids as $pid) {
                wp_delete_post((int) $pid, true);
            }
            if (count($ids) < $batch_size) break;
        }

        if (function_exists('wp_suspend_cache_addition')) {
            wp_suspend_cache_addition(false);
        }
    }
}
