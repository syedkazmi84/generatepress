<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Assets {
    public function register_front_assets(): void {
        wp_register_style('awg-aig-front', plugins_url('assets/front.css', AWG_AIG_FILE), [], AWG_AIG_VERSION);
        wp_register_script('awg-aig-front', plugins_url('assets/front.js', AWG_AIG_FILE), ['jquery'], AWG_AIG_VERSION, true);
    }

    /**
     * Enqueue only when a generator shortcode/block exists on the page.
     * Keeps assets off pages that don't use the plugin.
     */
    public function maybe_enqueue_front_assets(): void {
        $this->register_front_assets();

        $should = false;
        $post = isset($GLOBALS['post']) ? $GLOBALS['post'] : null;
        if ($post && isset($post->post_content)) {
            $content = (string) $post->post_content;
            if (has_shortcode($content, 'awg_generator')) {
                $should = true;
            }
            if (!$should && function_exists('has_block') && has_block('awg/generator', $content)) {
                $should = true;
            }
        }

        /**
         * Filter: allow themes/plugins to force-enable assets.
         */
        $should = (bool) apply_filters('awg_aig_enqueue_assets', $should);

        if ($should) {
            $this->enqueue_front_assets();
        }
    }

    public function enqueue_front_assets(): void {
        if (!wp_style_is('awg-aig-front', 'registered')) {
            $this->register_front_assets();
        }
        wp_enqueue_style('dashicons');
        wp_enqueue_style('awg-aig-front');
        wp_enqueue_script('awg-aig-front');
        // v5.4.61: expose whether live streaming is enabled so front.js can pick
        // the streaming endpoint (with automatic fallback to the classic one).
        $settings = get_option(Plugin::OPT, []);
        $stream_on = !is_array($settings) || !array_key_exists('enable_streaming', $settings)
            ? true
            : !empty($settings['enable_streaming']);

        wp_localize_script('awg-aig-front', 'AWG_AIG', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('awg_aig_nonce_front'),
            'stream' => $stream_on ? 1 : 0,
            // Used as the letterhead name / domain on the generated PDF documents.
            'siteName' => html_entity_decode((string) get_bloginfo('name'), ENT_QUOTES, 'UTF-8'),
            'siteDomain' => preg_replace('#^www\.#i', '', (string) wp_parse_url(home_url(), PHP_URL_HOST)),
        ]);
    }

    public function admin_assets(string $hook): void {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || empty($screen->post_type) || $screen->post_type !== Plugin::CPT) {
            return;
        }
        if (!in_array($screen->base, ['post', 'post-new'], true)) {
            return;
        }

        wp_enqueue_style('awg-aig-admin', plugins_url('assets/admin.css', AWG_AIG_FILE), [], AWG_AIG_VERSION);

        // Native WordPress color picker for per-template color overrides.
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');

        // If admin.js relies on sortable, include as a dependency. We also
        // depend on wp-color-picker so the init below runs after it loads.
        wp_enqueue_script(
            'awg-aig-admin',
            plugins_url('assets/admin.js', AWG_AIG_FILE),
            ['jquery', 'jquery-ui-sortable', 'wp-color-picker'],
            AWG_AIG_VERSION,
            true
        );

        wp_add_inline_script('awg-aig-admin',
            'jQuery(function($){$(".awg-color-picker").wpColorPicker();});'
        );
    }
}
