<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Ajax {
    /** @var string */
    private $cpt;
    /** @var Settings */
    private $settings;
    /** @var Renderer */
    private $renderer;

    public function __construct(string $cpt, Settings $settings, Renderer $renderer) {
        $this->cpt = $cpt;
        $this->settings = $settings;
        $this->renderer = $renderer;
    }

    private function ip(): string {
        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
        // v5.4.31: sites behind a TRUSTED reverse proxy / CDN can supply the
        // real client IP via this filter. The default is REMOTE_ADDR — do NOT
        // trust forwarded headers unless your edge sets them and strips any
        // client-supplied copy, since X-Forwarded-For is otherwise trivially
        // spoofable (and spoofing it would defeat per-IP rate limiting). E.g.:
        //   add_filter('awg_aig_client_ip', function ($ip) {
        //       return isset($_SERVER['HTTP_CF_CONNECTING_IP'])
        //           ? sanitize_text_field(wp_unslash($_SERVER['HTTP_CF_CONNECTING_IP']))
        //           : $ip;
        //   });
        $ip = (string) apply_filters('awg_aig_client_ip', $ip);
        $clean = preg_replace('/[^0-9a-fA-F:\.]/', '', $ip);
        return ($clean === null || $clean === '') ? '0.0.0.0' : $clean;
    }

    /**
     * Rate-limit bucket key for the client. IPv4 is used whole; IPv6 is collapsed
     * to its /64 network prefix so a single allocation (which routinely hands one
     * client trillions of addresses) can't mint unlimited distinct rate-limit
     * buckets and walk straight past the per-IP ceiling.
     */
    private function ip_bucket(): string {
        $ip = $this->ip();
        if (strpos($ip, ':') !== false && function_exists('inet_pton')) {
            $bin = @inet_pton($ip);
            if ($bin !== false && strlen($bin) === 16) {
                $prefix = substr($bin, 0, 8) . str_repeat("\0", 8); // zero the interface id
                $back = @inet_ntop($prefix);
                if ($back !== false) {
                    return $back . '/64';
                }
            }
        }
        return $ip;
    }

    /**
     * v5.4.14: per-IP rate limit now uses TWO buckets — one keyed by
     * (template_id, ip, minute) and one keyed by (ip, minute) globally.
     * A request must pass BOTH ceilings to proceed.
     *
     * Why two buckets: the previous single-bucket implementation conflated
     * activity across every template into one counter, so setting a strict
     * 3/min on Template A would (a) be tripped by activity on permissive
     * Template B in the same minute, and (b) wasn't actually "Template A's
     * per-minute hits by this IP", which is what the UI label promised.
     *
     * Old transient keys (`awg_aig_rl_{ip}_{min}`) naturally expire within
     * 120s of upgrade — no migration needed.
     *
     * template_limit = 0 still means "inherit global" — the per-template
     * bucket is skipped entirely and only the global ceiling applies.
     */
    private function rate_ok(int $template_id, int $template_limit, int $global_limit): bool {
        $ip_hash = md5($this->ip_bucket());
        $min = (int) floor(time() / 60);
        $global_limit = max(1, $global_limit);

        // Global ceiling — always checked.
        $g_key = "awg_aig_rl_g_{$ip_hash}_{$min}";
        $g_count = (int) get_transient($g_key);
        if ($g_count >= $global_limit) return false;

        // Per-template ceiling — only when the template sets its own limit.
        $t_key = '';
        $t_count = 0;
        if ($template_limit > 0 && $template_id > 0) {
            $t_key = "awg_aig_rl_t{$template_id}_{$ip_hash}_{$min}";
            $t_count = (int) get_transient($t_key);
            if ($t_count >= $template_limit) return false;
        }

        // Both buckets passed — increment whichever ones we checked.
        set_transient($g_key, $g_count + 1, 120);
        if ($t_key !== '') {
            set_transient($t_key, $t_count + 1, 120);
        }
        return true;
    }

    /**
     * v5.4.31: read the site-wide daily generation counter (across ALL IPs) and
     * report whether today's ceiling has already been met. Read-only on purpose
     * — the gate check must not consume a slot, because the request can still be
     * rejected after this point and a failed OpenAI call shouldn't count toward
     * a *spend* backstop.
     *
     * The counter lives in a regular option (NOT a transient) so it can't be
     * silently reset by an object-cache flush — a budget guard that resets to
     * zero would be worse than none. The date (site timezone) is part of the
     * stored value, so it auto-rolls at midnight with no cron and stale days
     * never linger.
     *
     * @param int $cap Daily ceiling; <= 0 disables the cap (always returns false).
     */
    private function global_cap_reached(int $cap): bool {
        if ($cap <= 0) {
            return false; // feature disabled — never blocked.
        }
        $state = get_option('awg_aig_global_usage');
        if (!is_array($state) || (($state['date'] ?? '') !== wp_date('Y-m-d'))) {
            return false; // nothing recorded for today yet.
        }
        return (int) ($state['count'] ?? 0) >= $cap;
    }

    /**
     * v5.4.31: record one successful generation against today's site-wide
     * counter. Called only after a generation actually succeeds, so only
     * billable output counts toward the daily cap; rejected or failed requests
     * never do. The read-increment-write is not transactional, so under heavy
     * concurrency the effective ceiling may overshoot by roughly the number of
     * simultaneous in-flight requests — an acceptable margin for a soft cap.
     */
    private function global_cap_bump(): void {
        $today = wp_date('Y-m-d');
        $state = get_option('awg_aig_global_usage');
        if (!is_array($state) || (($state['date'] ?? '') !== $today)) {
            $state = ['date' => $today, 'count' => 0];
        }
        $state['count'] = (int) ($state['count'] ?? 0) + 1;
        // autoload=no: changes on every generation, read only in this hot path.
        update_option('awg_aig_global_usage', $state, false);
    }

    private function sanitize_html_output(string $html): string {
        $allowed = [
            'p' => [],
            'br' => [],
            'strong' => [],
            'em' => [],
            'ul' => [],
            'ol' => [],
            'li' => [],
            'h2' => [],
            'h3' => [],
            'h4' => [],
            'blockquote' => [],
            'code' => [],
            'pre' => [],
            'hr' => [],
            'table' => [],
            'thead' => [],
            'tbody' => [],
            'tr' => [],
            'th' => [],
            'td' => [],
            'a' => [
                'href' => true,
                'target' => true,
                'rel' => true,
            ],
        ];

        return wp_kses($html, $allowed);
    }

    /**
     * v5.4.7: temperature parameter removed from the signature. OpenAI uses
     * each model's own default. Use the `awg_openai_payload` filter to inject
     * temperature or any other parameter per-request — useful for non-reasoning
     * models where you want fine creativity control.
     *
     * @param int $template_id The template post ID, or 0 for the key-test call.
     */
    private function openai_call(string $api_key, string $model, string $system, string $user, int $max_tokens, int $timeout, int $template_id = 0): array {
        $url = 'https://api.openai.com/v1/responses';

        $payload = [
            'model' => $model,
            'input' => [
                [
                    'role' => 'system',
                    'content' => [['type' => 'input_text', 'text' => $system]],
                ],
                [
                    'role' => 'user',
                    'content' => [['type' => 'input_text', 'text' => $user]],
                ],
            ],
            'max_output_tokens' => $max_tokens,
        ];

        // v5.4.7: filter hook lets advanced users add temperature, top_p, etc.
        // per model or per template. Example:
        //   add_filter('awg_openai_payload', function($p, $model, $tid){
        //     if (str_contains($model, 'gpt-4o')) $p['temperature'] = 0.6;
        //     return $p;
        //   }, 10, 3);
        $payload = (array) apply_filters('awg_openai_payload', $payload, $model, $template_id);

        $res = wp_remote_post($url, [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ],
            'body' => wp_json_encode($payload),
            'timeout' => $timeout,
        ]);

        if (is_wp_error($res)) return ['ok' => false, 'error' => $res->get_error_message()];

        $code = (int) wp_remote_retrieve_response_code($res);
        $body = (string) wp_remote_retrieve_body($res);
        $json = json_decode($body, true);

        if ($code < 200 || $code >= 300) {
            $msg = 'OpenAI error';
            if (is_array($json) && isset($json['error']['message'])) $msg = (string) $json['error']['message'];
            return ['ok' => false, 'error' => $msg, 'raw' => $json ?: $body];
        }

        // OpenAI reasoning models (gpt-5 / gpt-5.5 / o-series) emit hidden
        // "reasoning" output items before the visible "message", and report a
        // reasoning_tokens count. Track whether the model reasoned and whether
        // it was cut off so an empty answer can be told apart from a broken one.
        $text = '';
        $had_reasoning = false;
        if (is_array($json) && isset($json['output']) && is_array($json['output'])) {
            foreach ($json['output'] as $out) {
                if (!is_array($out)) continue;
                if (($out['type'] ?? '') === 'reasoning') $had_reasoning = true;
                if (($out['type'] ?? '') === 'message' && isset($out['content']) && is_array($out['content'])) {
                    foreach ($out['content'] as $c) {
                        if (($c['type'] ?? '') === 'output_text') $text .= (string) ($c['text'] ?? '');
                    }
                }
            }
        }
        $reasoning_tokens = 0;
        if (is_array($json) && isset($json['usage']['output_tokens_details']['reasoning_tokens'])) {
            $reasoning_tokens = (int) $json['usage']['output_tokens_details']['reasoning_tokens'];
        }
        $status = is_array($json) ? (string) ($json['status'] ?? '') : '';
        $incomplete_reason = is_array($json) ? (string) ($json['incomplete_details']['reason'] ?? '') : '';

        $text = trim($text);
        if ($text === '') {
            // A reasoning model can burn the whole token budget on hidden
            // reasoning before writing any visible answer. That's not a broken
            // key/model — it just needs more room. Mirror the DeepSeek path:
            // surface an actionable message and flag the case so the
            // connectivity test can still count it as a pass.
            if ($had_reasoning || $reasoning_tokens > 0 || $status === 'incomplete' || $incomplete_reason === 'max_output_tokens') {
                return [
                    'ok'             => false,
                    'error'          => __('The model used its whole token budget on reasoning before writing an answer. Raise Max Output Tokens — reasoning models like gpt-5 / gpt-5.5 / the o-series need more room.', 'authorwings-ai-tools'),
                    'raw'            => $json ?: $body,
                    'reasoning_only' => true,
                ];
            }
            // HTTP 200 but no extractable text. Don't leak the raw response
            // body to end users — surface a clean error and keep the raw
            // payload in 'raw' for admin debug only.
            return [
                'ok' => false,
                'error' => __('The model returned an empty or unexpected response. Please try again.', 'authorwings-ai-tools'),
                'raw' => $json ?: $body,
            ];
        }
        return ['ok' => true, 'text' => $text, 'raw' => $json];
    }

    /**
     * v5.5.0 / v5.6.0: decide which provider a model id belongs to.
     *   - ids starting with "claude" (or containing "anthropic") → Anthropic
     *     Messages API.
     *   - ids starting with "deepseek" → DeepSeek (OpenAI-compatible
     *     Chat Completions API). Covers the V4 ids (deepseek-v4-flash,
     *     deepseek-v4-pro) and the legacy aliases (deepseek-chat,
     *     deepseek-reasoner).
     *   - everything else → OpenAI.
     */
    private function provider_for_model(string $model): string {
        $m = strtolower(trim($model));
        if ($m === '') return 'openai';
        if (strpos($m, 'claude') === 0 || strpos($m, 'anthropic') !== false) {
            return 'anthropic';
        }
        if (strpos($m, 'deepseek') === 0) {
            return 'deepseek';
        }
        return 'openai';
    }

    /**
     * v5.5.0: single dispatch point. Sends the request to whichever provider
     * the model belongs to and returns a normalised result with the same shape
     * for both providers: ['ok'=>bool, 'text'=>string, 'error'=>string, 'raw'=>mixed].
     */
    /**
     * v5.6.2: "Run via Agent" path. Hand the template's assembled request to a
     * linked AI Agent's multi-step engine (its model, tools and knowledge) and
     * return the agent's final text, normalised to ai_call()'s shape so the rest
     * of the generate()/generate_stream() pipeline is unchanged.
     *
     * The template still owns the gating, the form schema and the prompt: its
     * fully-expanded user prompt becomes the agent's single user turn, prefixed
     * with the template's own System Prompt so the author's task framing is
     * preserved. The agent's instructions/knowledge govern behaviour and tool use.
     */
    private function agent_call(array $r): array {
        if (!class_exists('\\AWG_AIG\\Agent\\Agent_Runtime') || !class_exists('\\AWG_AIG\\Agent\\Agent')) {
            return ['ok' => false, 'error' => __('The agent engine is unavailable.', 'authorwings-ai-tools')];
        }

        $agent_id   = (int) ($r['agent_id'] ?? 0);
        $agent_meta = \AWG_AIG\Agent\Agent::get_meta($agent_id);

        $message = (string) $r['user'];
        $tpl_system = trim((string) ($r['meta']['system_prompt'] ?? ''));
        if ($tpl_system !== '') {
            $message = $tpl_system . "\n\n" . $message;
        }

        $history = [['role' => 'user', 'content' => $message]];
        $resp = \AWG_AIG\Agent\Agent_Runtime::chat_for_agent($agent_id, $agent_meta, $history);

        // chat_for_agent already returns ['ok','text','error','raw','steps','tools_used'].
        if (!is_array($resp)) {
            return ['ok' => false, 'error' => __('The agent returned no result.', 'authorwings-ai-tools')];
        }

        // v5.6.3: admin diagnostic. With the tool's Debug toggle on, prepend a
        // one-line marker (text output only) confirming the agent path ran, with
        // its model, step count and any tools it called — so it's obvious the
        // "Run via Agent" setting took effect and what the agent did.
        if (!empty($resp['ok'])
            && current_user_can('manage_options')
            && !empty($r['meta']['debug_admin'])
            && (string) ($r['meta']['output_format'] ?? 'text') === 'text') {
            $a_model = $agent_meta['model'] !== '' ? $agent_meta['model'] : (string) ($this->settings->get()['default_model'] ?? '');
            $a_tools = !empty($resp['tools_used']) ? implode(', ', (array) $resp['tools_used']) : '(none)';
            $a_steps = (int) ($resp['steps'] ?? 0);
            $marker  = sprintf('[debug] via agent #%d · model %s · steps %d · tools: %s', $agent_id, $a_model, $a_steps, $a_tools);
            $resp['text'] = $marker . "\n\n" . (string) ($resp['text'] ?? '');
        }

        return $resp;
    }

    /* ------------------------------------------------------------------ *
     * v5.6.4: "Run via Agent" conversational mode.
     *
     * When a tool is linked to a published agent, front.js opens an in-place
     * chat (styled like the result area) instead of printing a single result.
     * The first user turn is the tool's assembled prompt (form inputs + the
     * template's System Prompt); after that the visitor keeps talking to the
     * agent. Every turn runs the SAME tool gating as generate() (membership,
     * rate limit, daily cap, usage logging) via prepare_request()/record_chat_turn().
     *
     * The seeded first message is rebuilt server-side on every turn from the
     * posted form fields, so the template's System Prompt is never exposed to
     * the browser. The client only sends the follow-up turns (the visible
     * assistant replies and the visitor's later messages).
     * ------------------------------------------------------------------ */

    /**
     * Read and sanitise the client-supplied follow-up turns (everything AFTER
     * the seeded first user message). Returns a list of ['role','content'] with
     * role limited to user|assistant.
     */
    private function parse_chat_turns(): array {
        $raw = isset($_POST['turns_json']) ? wp_unslash((string) $_POST['turns_json']) : '';
        if ($raw === '') return [];
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) return [];

        $out = [];
        $max_turns = 40; // hard cap on conversation length carried per request
        foreach ($decoded as $t) {
            if (!is_array($t)) continue;
            $role = isset($t['role']) ? (string) $t['role'] : '';
            if ($role !== 'user' && $role !== 'assistant') continue;
            $content = isset($t['content']) ? trim((string) $t['content']) : '';
            if ($content === '') continue;
            if (function_exists('mb_strlen') && mb_strlen($content) > 8000) {
                $content = mb_substr($content, 0, 8000);
            }
            $out[] = ['role' => $role, 'content' => $content];
            if (count($out) >= $max_turns) break;
        }
        return $out;
    }

    /**
     * Build the full conversation for the agent: the server-owned seeded first
     * message (template System Prompt + assembled form prompt) followed by the
     * client's follow-up turns.
     */
    private function build_chat_history(array $r): array {
        $message = (string) $r['user'];

        // Linked-agent mode: the agent has its own instructions, so we frame the
        // first turn with the template's System Prompt. Standalone mode: the
        // template's System Prompt IS the agent's instructions (see
        // synth_agent_meta), so we must NOT also prepend it here or it'd double.
        if (empty($r['agent_standalone'])) {
            $tpl_system = trim((string) ($r['meta']['system_prompt'] ?? ''));
            if ($tpl_system !== '') {
                $message = $tpl_system . "\n\n" . $message;
            }
        }

        $history = [['role' => 'user', 'content' => $message]];
        foreach ($this->parse_chat_turns() as $turn) {
            $history[] = $turn;
        }
        return $history;
    }

    /**
     * v5.6.4: build an agent-meta array for a STANDALONE template agent from the
     * template's own settings, shaped like Agent::get_meta() so the agent runtime
     * can consume it unchanged. The template's System Prompt becomes the agent
     * instructions; its Model + Max Output Tokens become the agent's; the optional
     * tool/knowledge fields map straight across.
     */
    private function synth_agent_meta(array $r): array {
        $m = $r['meta'];
        return [
            'instructions'         => (string) ($m['system_prompt'] ?? ''),
            'model'                => trim((string) ($m['model'] ?? '')),
            'max_tokens'           => max(64, min(8000, (int) ($m['max_output_tokens'] ?? 1200))),
            'tool_ids'             => array_values(array_filter(array_map('intval', (array) ($m['agent_tool_ids'] ?? [])))),
            'knowledge_enabled'    => !empty($m['agent_knowledge_enabled']) ? 1 : 0,
            'knowledge_post_types' => !empty($m['agent_knowledge_post_types']) ? (array) $m['agent_knowledge_post_types'] : ['post', 'page'],
            'knowledge_text'       => (string) ($m['agent_knowledge_text'] ?? ''),
            // v5.7.9: pass the editable system-line overrides through so a
            // standalone template-agent honours them (blank = built-in default).
            'knowledge_prefix'     => (string) ($m['agent_knowledge_prefix'] ?? ''),
            'tools_nudge'          => (string) ($m['agent_tools_nudge'] ?? ''),
            'apply_global_prompt'  => !empty($m['apply_global_prompt']) ? 1 : 0,
            'debug_admin'          => !empty($m['debug_admin']) ? 1 : 0,
        ];
    }

    /**
     * Run one chat turn through the linked agent. With $on_delta set and a
     * pure-chat agent (no tools/knowledge) the reply token-streams; otherwise the
     * multi-step loop runs and $on_status surfaces "Using X…" notices. Returns
     * ai_call()'s normalised shape.
     */
    private function agent_chat_run(array $r, array $history, ?callable $on_delta = null, ?callable $on_status = null): array {
        if (!class_exists('\\AWG_AIG\\Agent\\Agent_Runtime') || !class_exists('\\AWG_AIG\\Agent\\Agent')) {
            return ['ok' => false, 'error' => __('The agent engine is unavailable.', 'authorwings-ai-tools')];
        }

        // Standalone template-agent: build the agent meta from the template's own
        // settings and use the template id as the agent id (for prompt filters).
        // Linked mode: read the linked Agent post's saved configuration.
        if (!empty($r['agent_standalone'])) {
            $agent_id = (int) $r['template_id'];
            $meta     = $this->synth_agent_meta($r);
        } else {
            $agent_id = (int) $r['agent_id'];
            $meta     = \AWG_AIG\Agent\Agent::get_meta($agent_id);
        }
        $s         = $r['settings'];
        $has_tools = !empty($meta['tool_ids']) || !empty($meta['knowledge_enabled']);

        if (!$has_tools && $on_delta !== null && class_exists('\\AWG_AIG\\Agent\\Agent_Provider')) {
            // Pure chat → real token streaming, mirroring the standalone agent.
            $model    = $meta['model'] !== '' ? $meta['model'] : (string) ($s['default_model'] ?? 'gpt-5-mini');
            $provider = \AWG_AIG\Agent\Agent_Provider::provider_for_model($model);
            list($key, $missing) = \AWG_AIG\Agent\Agent_Runtime::resolve_key($provider, $s);
            if ($key === '') return ['ok' => false, 'error' => $missing];
            $system  = \AWG_AIG\Agent\Agent_Runtime::build_system_prompt_public($meta, $s, $agent_id);
            $timeout = max(20, (int) ($s['timeout'] ?? 45));
            return \AWG_AIG\Agent\Agent_Provider::stream_complete($provider, $key, $model, $system, $history, (int) $meta['max_tokens'], $timeout, $on_delta);
        }

        // Tool-using turn (or non-streaming JSON path) → run the multi-step loop.
        $on_event = null;
        if ($on_status !== null) {
            $on_event = function ($type, $value) use ($on_status) {
                if ($type === 'tool') {
                    $on_status(\AWG_AIG\Agent\Agent_Runtime::tool_label((string) $value));
                }
            };
        }
        return \AWG_AIG\Agent\Agent_Runtime::chat_for_agent($agent_id, $meta, $history, $on_event);
    }

    /**
     * Log one chat turn against the tool's own limits. Usage counter, daily cap
     * and the awg_aig_generated membership hook fire on EVERY turn so a long
     * conversation can't bypass plan limits. The submission is stored only on the
     * first turn ($store) — the form fields don't change between turns, so we
     * avoid one stored row per reply.
     */
    private function record_chat_turn(string $text, array $r, bool $store): void {
        $this->bump_usage($r['template_id']);

        if ((int) ($r['settings']['global_daily_cap'] ?? 0) > 0) {
            $this->global_cap_bump();
        }

        do_action('awg_aig_generated', get_current_user_id(), $r['template_id'], $text);

        if ($store) {
            $this->store_submission(
                $r['template_id'],
                array_merge($r['submitted'], $r['tracking']),
                $text,
                (string) $r['model'],
                $r['settings']
            );
        }
    }

    /**
     * Classic (non-streaming) chat turn: runs the tool pre-flight, one agent
     * turn, returns JSON. Used when the browser can't stream.
     */
    public function agent_chat(): void {
        $r = $this->prepare_request();
        if (empty($r['ok'])) {
            wp_send_json_error($r['data'], $r['status']);
        }
        if ((int) ($r['agent_id'] ?? 0) <= 0 && empty($r['agent_standalone'])) {
            wp_send_json_error(['message' => __('This tool is not set to run as an Agent.', 'authorwings-ai-tools')], 400);
        }

        $is_first = (count($this->parse_chat_turns()) === 0);
        $history  = $this->build_chat_history($r);
        $resp     = $this->agent_chat_run($r, $history);

        if (empty($resp['ok'])) {
            $debug = (current_user_can('manage_options') && !empty($r['meta']['debug_admin'])) ? ($resp['raw'] ?? null) : null;
            wp_send_json_error(['message' => $resp['error'] ?? __('The agent could not reply.', 'authorwings-ai-tools'), 'debug' => $debug], 500);
        }

        $text = trim((string) ($resp['text'] ?? ''));
        $this->record_chat_turn($text, $r, $is_first);

        wp_send_json_success([
            'text'       => $text,
            'tools_used' => isset($resp['tools_used']) ? array_values((array) $resp['tools_used']) : [],
        ]);
    }

    /**
     * Streaming chat turn (Server-Sent Events). Same pre-flight + gating as
     * agent_chat(); pure-chat agents token-stream, tool-using agents emit a
     * "status" event per tool then a single "done".
     */
    public function agent_chat_stream(): void {
        $r = $this->prepare_request();

        $this->stream_open();

        if (empty($r['ok'])) {
            $this->sse_send('error', $r['data']);
            exit;
        }
        if ((int) ($r['agent_id'] ?? 0) <= 0 && empty($r['agent_standalone'])) {
            $this->sse_send('error', ['message' => __('This tool is not set to run as an Agent.', 'authorwings-ai-tools')]);
            exit;
        }

        $is_first = (count($this->parse_chat_turns()) === 0);
        $history  = $this->build_chat_history($r);

        $self      = $this;
        $on_delta  = function ($delta) use ($self) {
            $self->sse_send('delta', ['text' => (string) $delta]);
        };
        $on_status = function ($label) use ($self) {
            $self->sse_send('status', ['label' => (string) $label]);
        };

        $resp = $this->agent_chat_run($r, $history, $on_delta, $on_status);

        if (empty($resp['ok'])) {
            $payload = ['message' => $resp['error'] ?? __('The agent could not reply.', 'authorwings-ai-tools')];
            if (!empty($resp['fallback'])) {
                $payload['fallback'] = true;
            }
            if (current_user_can('manage_options') && !empty($r['meta']['debug_admin']) && isset($resp['raw'])) {
                $payload['debug'] = $resp['raw'];
            }
            $this->sse_send('error', $payload);
            exit;
        }

        $text = trim((string) ($resp['text'] ?? ''));
        $this->record_chat_turn($text, $r, $is_first);

        $this->sse_send('done', [
            'text'       => $text,
            'tools_used' => isset($resp['tools_used']) ? array_values((array) $resp['tools_used']) : [],
        ]);
        exit;
    }

    private function ai_call(string $provider, string $api_key, string $model, string $system, string $user, int $max_tokens, int $timeout, int $template_id = 0): array {
        if ($provider === 'anthropic') {
            return $this->anthropic_call($api_key, $model, $system, $user, $max_tokens, $timeout, $template_id);
        }
        if ($provider === 'deepseek') {
            return $this->deepseek_call($api_key, $model, $system, $user, $max_tokens, $timeout, $template_id);
        }
        return $this->openai_call($api_key, $model, $system, $user, $max_tokens, $timeout, $template_id);
    }

    /**
     * v5.5.0: Anthropic (Claude) Messages API call. Mirrors openai_call()'s
     * return shape so the rest of the pipeline stays provider-agnostic.
     *
     * The system prompt is sent as the top-level `system` parameter and the
     * user prompt as a single user message — the same two-part structure the
     * OpenAI path uses.
     */
    private function anthropic_call(string $api_key, string $model, string $system, string $user, int $max_tokens, int $timeout, int $template_id = 0): array {
        $url = 'https://api.anthropic.com/v1/messages';

        // Anthropic requires a positive max_tokens; fall back to a sane value.
        if ($max_tokens <= 0) $max_tokens = 1024;

        $payload = [
            'model'      => $model,
            'max_tokens' => $max_tokens,
            'messages'   => [
                ['role' => 'user', 'content' => $user],
            ],
        ];
        if (trim($system) !== '') {
            $payload['system'] = $system;
        }

        // Mirror the OpenAI filter so advanced users can tweak temperature,
        // top_p, thinking, etc. per model/template. Example:
        //   add_filter('awg_anthropic_payload', function($p, $model, $tid){
        //     $p['temperature'] = 0.7; return $p;
        //   }, 10, 3);
        $payload = (array) apply_filters('awg_anthropic_payload', $payload, $model, $template_id);

        $res = wp_remote_post($url, [
            'headers' => [
                'Content-Type'      => 'application/json',
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
            ],
            'body'    => wp_json_encode($payload),
            'timeout' => $timeout,
        ]);

        if (is_wp_error($res)) return ['ok' => false, 'error' => $res->get_error_message()];

        $code = (int) wp_remote_retrieve_response_code($res);
        $body = (string) wp_remote_retrieve_body($res);
        $json = json_decode($body, true);

        if ($code < 200 || $code >= 300) {
            $msg = 'Anthropic error';
            if (is_array($json) && isset($json['error']['message'])) $msg = (string) $json['error']['message'];
            return ['ok' => false, 'error' => $msg, 'raw' => $json ?: $body];
        }

        // Anthropic returns content as an array of blocks; concatenate text blocks.
        $text = '';
        if (is_array($json) && isset($json['content']) && is_array($json['content'])) {
            foreach ($json['content'] as $block) {
                if (is_array($block) && ($block['type'] ?? '') === 'text') {
                    $text .= (string) ($block['text'] ?? '');
                }
            }
        }

        $text = trim($text);
        if ($text === '') {
            return [
                'ok'    => false,
                'error' => __('The model returned an empty or unexpected response. Please try again.', 'authorwings-ai-tools'),
                'raw'   => $json ?: $body,
            ];
        }
        return ['ok' => true, 'text' => $text, 'raw' => $json];
    }

    /**
     * v5.6.0: DeepSeek call. DeepSeek exposes an OpenAI-compatible
     * Chat Completions endpoint, so this uses the classic
     * {role, content} messages array and reads choices[0].message.content —
     * the same shape the OpenAI SDK returns. Mirrors the other providers'
     * return shape so the rest of the pipeline stays provider-agnostic.
     *
     * Model ids: deepseek-v4-flash / deepseek-v4-pro (current), or the legacy
     * deepseek-chat / deepseek-reasoner aliases.
     *
     * Note on reasoning models: deepseek-reasoner (and the V4 Expert/thinking
     * path, e.g. deepseek-v4-pro) also return a separate `reasoning_content`
     * field for the chain-of-thought. We keep only the final `content`, so
     * tools receive a clean answer with no visible reasoning — but a thinking
     * model can spend its whole token budget on reasoning before emitting any
     * `content`, which is why deepseek_call() now distinguishes "ran out of
     * budget while thinking" from a genuinely empty/unexpected response.
     * We deliberately ignore it and keep only the final `content`, so tools
     * receive a clean answer with no visible reasoning.
     */
    private function deepseek_call(string $api_key, string $model, string $system, string $user, int $max_tokens, int $timeout, int $template_id = 0): array {
        $url = 'https://api.deepseek.com/chat/completions';

        // Match Anthropic's guard: never send a non-positive cap.
        if ($max_tokens <= 0) $max_tokens = 1024;

        $messages = [];
        if (trim($system) !== '') {
            $messages[] = ['role' => 'system', 'content' => $system];
        }
        $messages[] = ['role' => 'user', 'content' => $user];

        $payload = [
            'model'      => $model,
            'messages'   => $messages,
            'max_tokens' => $max_tokens,
            'stream'     => false,
        ];

        // Mirror the OpenAI/Anthropic filters so advanced users can tweak
        // temperature, top_p, or toggle thinking per model/template. Example —
        // force the cheaper non-thinking path on a V4 model:
        //   add_filter('awg_deepseek_payload', function($p, $model, $tid){
        //     $p['thinking'] = ['type' => 'disabled'];
        //     return $p;
        //   }, 10, 3);
        $payload = (array) apply_filters('awg_deepseek_payload', $payload, $model, $template_id);

        $res = wp_remote_post($url, [
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ],
            'body'    => wp_json_encode($payload),
            'timeout' => $timeout,
        ]);

        if (is_wp_error($res)) return ['ok' => false, 'error' => $res->get_error_message()];

        $code = (int) wp_remote_retrieve_response_code($res);
        $body = (string) wp_remote_retrieve_body($res);
        $json = json_decode($body, true);

        if ($code < 200 || $code >= 300) {
            $msg = 'DeepSeek error';
            if (is_array($json) && isset($json['error']['message'])) $msg = (string) $json['error']['message'];
            return ['ok' => false, 'error' => $msg, 'raw' => $json ?: $body];
        }

        // OpenAI-compatible shape: choices[0].message.content. Thinking models
        // (deepseek-reasoner, deepseek-v4-pro Expert mode) additionally return
        // choices[0].message.reasoning_content with the hidden chain-of-thought,
        // and set finish_reason to "length" when they hit max_tokens.
        $text = '';
        $reasoning = '';
        $finish = '';
        if (is_array($json) && isset($json['choices'][0])) {
            $choice = $json['choices'][0];
            if (isset($choice['message']['content'])) {
                $text = (string) $choice['message']['content'];
            }
            if (isset($choice['message']['reasoning_content'])) {
                $reasoning = (string) $choice['message']['reasoning_content'];
            }
            if (isset($choice['finish_reason'])) {
                $finish = (string) $choice['finish_reason'];
            }
        }

        $text = trim($text);
        if ($text === '') {
            // A thinking model can burn the entire token budget on reasoning
            // before writing any final answer. That's not a broken key/model —
            // it just needs more room. Surface an actionable message and flag
            // the case so the connectivity test can still count it as a pass.
            if (trim($reasoning) !== '' || $finish === 'length') {
                return [
                    'ok'             => false,
                    'error'          => __('The model used its whole token budget on reasoning before writing an answer. Raise Max Output Tokens — thinking models like deepseek-reasoner / deepseek-v4-pro need more room.', 'authorwings-ai-tools'),
                    'raw'            => $json ?: $body,
                    'reasoning_only' => true,
                ];
            }
            return [
                'ok'    => false,
                'error' => __('The model returned an empty or unexpected response. Please try again.', 'authorwings-ai-tools'),
                'raw'   => $json ?: $body,
            ];
        }
        return ['ok' => true, 'text' => $text, 'raw' => $json];
    }

    private function parse_field_options($raw_options): array {
        $options = preg_split('/[\r\n,]+/', (string) $raw_options);
        $options = array_values(array_filter(array_map('trim', $options), static function ($option) {
            return $option !== '';
        }));

        return array_map('sanitize_text_field', $options);
    }

    private function normalize_checkbox_scalar($value): string {
        $value = is_scalar($value) ? strtolower(trim((string) $value)) : '';
        return in_array($value, ['1', 'true', 'yes', 'on'], true) ? '1' : '';
    }

    /**
     * v5.4.19: sanitize a Custom HTML mode submission (no field schema).
     * Arrays (multi-checkbox / multi-select) are joined to a comma string,
     * multi-line strings keep their newlines (sanitize_textarea_field) so the AI
     * sees paragraph structure, everything else is single-line text. Tracking
     * keys are left in place here — generate() captures and strips gclid/utm_*
     * separately, exactly as in standard mode.
     */
    private function sanitize_freeform_submission(array $submitted): array {
        $clean = [];
        foreach ($submitted as $key => $value) {
            $key = sanitize_key((string) $key);
            if ($key === '') {
                continue;
            }

            if (is_array($value)) {
                $parts = array_values(array_filter(
                    array_map(static function ($v) {
                        return sanitize_text_field((string) $v);
                    }, $value),
                    static function ($v) {
                        return $v !== '';
                    }
                ));
                $clean[$key] = implode(', ', $parts);
                continue;
            }

            $value = (string) $value;
            $clean[$key] = (strpos($value, "\n") !== false)
                ? sanitize_textarea_field($value)
                : sanitize_text_field($value);
        }
        return $clean;
    }

    /**
     * v5.4.19: build the {{fields}} block for Custom HTML mode. Output matches
     * Renderer::fields_to_text() ("- Label: value", multi-line values on their
     * own block). The label comes from the optional client hint, otherwise a
     * prettified version of the input name (book_genre -> "Book Genre").
     * Tracking keys are skipped so they never leak into the prompt.
     */
    private function freeform_to_text(array $submitted, array $labels): string {
        $skip = ['gclid', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'];
        $lines = [];
        foreach ($submitted as $key => $value) {
            if (in_array($key, $skip, true)) {
                continue;
            }
            $value = is_string($value) ? $value : (string) $value;
            if (trim($value) === '') {
                continue;
            }

            $label = (isset($labels[$key]) && $labels[$key] !== '')
                ? $labels[$key]
                : $this->prettify_key($key);

            if (strpos($value, "\n") !== false) {
                $lines[] = "- {$label}:\n{$value}";
            } else {
                $lines[] = "- {$label}: {$value}";
            }
        }
        return implode("\n", $lines);
    }

    /**
     * Turn a field name into a human label: underscores/hyphens become spaces,
     * words get capitalised. Used as the {{fields}} label fallback in custom mode.
     */
    private function prettify_key(string $key): string {
        $key = trim((string) preg_replace('/\s+/', ' ', str_replace(['_', '-'], ' ', $key)));
        return $key === '' ? '' : ucwords($key);
    }

    /**
     * v5.4.48: resolve the effective gibberish guard for a generation request.
     * Mirrors the resolution Renderer does for the client data-attributes so the
     * server is the authority and the two can never disagree.
     *
     * Per-template 'on'/'off' force the behaviour; 'global' (or anything else)
     * inherits the Settings toggle.
     *
     * @return array{on:bool,min:int}
     */
    private function gibberish_config(array $m, array $s): array {
        $mode = (string) ($m['gibberish_check'] ?? 'global');
        if ($mode === 'on') {
            $on = true;
        } elseif ($mode === 'off') {
            $on = false;
        } else {
            $on = !empty($s['gibberish_check']);
        }
        $min = max(0, min(50, (int) ($s['gibberish_min_length'] ?? 4)));
        return ['on' => $on, 'min' => $min];
    }

    /**
     * v5.4.48: heuristic "does this look like keyboard mashing?" check.
     *
     * Deliberately CONSERVATIVE — it only returns true when it is confident, so
     * a false positive (blocking a real answer) stays rare. It judges each
     * whitespace-separated word and reports gibberish only when EVERY judged
     * word looks like nonsense, using three Latin-script signals:
     *
     *   1. A run of 6+ of the same character ("aaaaaa", "!!!!!!").
     *   2. A run of 6+ consonants with no vowel ("asdfgh", "qwrtzx") — real
     *      English words top out around five (e.g. "lengths").
     *   3. A long word (7+ letters) whose vowel ratio is below 20%, counting
     *      'y' as a vowel so "rhythm"/"crypt"-style words are not flagged.
     *
     * Non-Latin scripts (CJK, Arabic, Cyrillic, …) are exempt entirely: if
     * fewer than half a value's letters are A–Z it returns false, because the
     * vowel/consonant model simply does not apply to them.
     *
     * @param string $value   The raw (already sanitized) answer.
     * @param int    $min_len Trimmed values shorter than this are never judged.
     */
    private function looks_like_gibberish(string $value, int $min_len): bool {
        $v = trim($value);
        if ($v === '' || mb_strlen($v) < max(1, $min_len)) {
            return false;
        }

        // Signal 1: an absurd run of one repeated character.
        if (preg_match('/(.)\1{5,}/u', $v)) {
            return true;
        }

        // Bail on non-Latin-dominant input — the heuristics below only model
        // Latin script and would wrongly flag other writing systems.
        $letters = preg_replace('/[^\p{L}]/u', '', $v);
        if ($letters === '' || $letters === null) {
            return false; // numbers / punctuation only — not our concern.
        }
        $latin = preg_replace('/[^A-Za-z]/', '', $letters);
        if (mb_strlen((string) $latin) < (mb_strlen((string) $letters) / 2)) {
            return false;
        }

        // Judge each Latin word; require ALL judged words to look like mashing.
        $words = preg_split('/\s+/', $v) ?: [];
        $eligible = 0;
        $suspect = 0;
        foreach ($words as $word) {
            $alpha = preg_replace('/[^A-Za-z]/', '', $word);
            $len = strlen((string) $alpha);
            if ($len < 4) {
                continue; // too short to judge confidently.
            }
            $eligible++;
            $lower = strtolower((string) $alpha);
            $vowels = preg_match_all('/[aeiouy]/', $lower);
            $vowel_ratio = $vowels / $len;

            $no_vowels = ($vowels === 0);
            $long_consonant_run = (bool) preg_match('/[bcdfghjklmnpqrstvwxz]{6,}/', $lower);
            $low_vowel_long_word = ($len >= 7 && $vowel_ratio < 0.20);

            if ($no_vowels || $long_consonant_run || $low_vowel_long_word) {
                $suspect++;
            }
        }

        return $eligible > 0 && $suspect === $eligible;
    }

    private function validate_submission(array $schema, array $submitted): array {
        $clean = [];
        $errors = [];

        foreach ($schema as $field) {
            $key = sanitize_key($field['key'] ?? '');
            if (!$key) {
                continue;
            }

            $label = sanitize_text_field($field['label'] ?? $key);
            $type = $field['type'] ?? 'text';
            $options = $this->parse_field_options($field['options'] ?? '');
            $raw_value = $submitted[$key] ?? '';

            if ($type === 'checkbox') {
                if (!empty($options)) {
                    $raw_values = is_array($raw_value) ? $raw_value : [$raw_value];
                    $raw_values = array_values(array_filter(array_map('sanitize_text_field', $raw_values), static function ($item) {
                        return $item !== '';
                    }));
                    $valid_values = array_values(array_intersect($raw_values, $options));

                    if (count($valid_values) !== count($raw_values)) {
                        $errors[] = sprintf(
                            /* translators: %s: field label */
                            __('Invalid selection for %s.', 'authorwings-ai-tools'),
                            $label
                        );
                    }

                    $clean[$key] = implode(', ', $valid_values);
                } else {
                    $clean[$key] = $this->normalize_checkbox_scalar($raw_value);
                }
                continue;
            }

            // v5.4.69: upload field. The browser cannot post the file through the
            // JSON generate request, so front.js uploads it first (awg_aig_upload)
            // and submits the returned token here. Resolve it back to the extracted
            // text + filename reference that the AI should see. Unknown / expired
            // tokens resolve to '' so a required upload is reported as missing.
            if ($type === 'file') {
                $token = is_string($raw_value) ? trim($raw_value) : '';
                $clean[$key] = $this->resolve_uploaded_file($token);
                continue;
            }

            if (is_array($raw_value)) {
                $raw_value = implode(', ', array_filter(array_map('sanitize_text_field', $raw_value)));
            }

            // Textareas keep newlines so the AI sees multi-paragraph input.
            if ($type === 'textarea') {
                $value = sanitize_textarea_field((string) $raw_value);
            } else {
                $value = sanitize_text_field((string) $raw_value);
            }

            if ($value === '') {
                $clean[$key] = '';
                continue;
            }

            if ($type === 'email') {
                $value = sanitize_email($value);
                if ($value === '' || !is_email($value)) {
                    $errors[] = sprintf(
                        /* translators: %s: field label */
                        __('Please enter a valid email for %s.', 'authorwings-ai-tools'),
                        $label
                    );
                    $clean[$key] = '';
                    continue;
                }
                $clean[$key] = $value;
                continue;
            }

            if ($type === 'number') {
                $normalized = str_replace(',', '.', $value);
                if (!is_numeric($normalized)) {
                    $errors[] = sprintf(
                        /* translators: %s: field label */
                        __('Please enter a valid number for %s.', 'authorwings-ai-tools'),
                        $label
                    );
                    $clean[$key] = '';
                    continue;
                }
                $clean[$key] = (string) (0 + $normalized);
                continue;
            }

            if ($type === 'select' || $type === 'radio') {
                if (!empty($options) && !in_array($value, $options, true)) {
                    $errors[] = sprintf(
                        /* translators: %s: field label */
                        __('Invalid selection for %s.', 'authorwings-ai-tools'),
                        $label
                    );
                    $clean[$key] = '';
                    continue;
                }
            }

            $clean[$key] = $value;
        }

        return [
            'clean' => $clean,
            'errors' => array_values(array_unique($errors)),
        ];
    }

    private function required_missing(array $schema, array $submitted): array {
        $missing = [];
        foreach ($schema as $field) {
            $key = sanitize_key($field['key'] ?? '');
            if (!$key) {
                continue;
            }
            $required = !empty($field['required']);
            if (!$required) {
                continue;
            }
            $value = $submitted[$key] ?? '';
            $type = $field['type'] ?? 'text';
            if ($type === 'checkbox') {
                if (is_array($value)) {
                    $value = array_values(array_filter(array_map('sanitize_text_field', $value), static function($item){
                        return $item !== '';
                    }));
                    if (empty($value)) {
                        $missing[] = $field['label'] ?? $key;
                    }
                } elseif (empty($value)) {
                    $missing[] = $field['label'] ?? $key;
                }
                continue;
            }
            if (is_array($value)) {
                $value = implode(', ', array_filter($value));
            }
            $value = trim((string) $value);
            if ($value === '') {
                $missing[] = $field['label'] ?? $key;
            }
        }
        return $missing;
    }

    private function bump_usage(int $template_id): void {
        $count = (int) get_post_meta($template_id, '_awg_aig_usage_count', true);
        $count++;
        update_post_meta($template_id, '_awg_aig_usage_count', $count);
        update_post_meta($template_id, '_awg_aig_last_generated', current_time('mysql'));
    }

    // v5.4.8: $cached param removed (caching was dropped in v5.4.6).
    // Source URL now captured from POST'd 'source_url' (front.js) with
    // wp_get_referer() as fallback. Old _awg_aig_cached meta values stay
    // in DB on existing records but no new ones are written.
    private function store_submission(int $template_id, array $fields, string $output, string $model, array $settings): void {
        // Global toggle
        if (empty($settings['store_submissions'])) {
            return;
        }

        // Keep gclid and UTM out of the "fields" bucket and store separately.
        $gclid = '';
        if (isset($fields['gclid'])) {
            $gclid = sanitize_text_field((string) $fields['gclid']);
            unset($fields['gclid']);
        }

        $utm_keys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'];
        $utm = [];
        foreach ($utm_keys as $k) {
            if (isset($fields[$k])) {
                $val = sanitize_text_field((string) $fields[$k]);
                if ($val !== '') {
                    $utm[$k] = $val;
                }
                unset($fields[$k]);
            }
        }

        // v5.9.14: record title is a subject line drawn from the submission's own
        // content (the most meaningful input field, else an output snippet), so the
        // Title column doesn't just repeat the Template / Date columns. Falls back
        // to the tool name when there's no usable content.
        $tpl_name = (string) get_the_title($template_id);
        if ($tpl_name === '') {
            $tpl_name = sprintf(
                /* translators: %d: template id */
                __('Template #%d', 'authorwings-ai-tools'),
                $template_id
            );
        }
        $title = Submissions::compose_record_title($fields, (string) $output, $tpl_name);

        $post_id = wp_insert_post([
            'post_type' => Plugin::SUB_CPT,
            'post_status' => 'publish',
            'post_title' => $title,
        ], true);

        if (is_wp_error($post_id) || !$post_id) {
            return;
        }

        update_post_meta($post_id, '_awg_aig_template_id', $template_id);
        update_post_meta($post_id, '_awg_aig_user_id', get_current_user_id());
        // Membership integration meta (harmless when membership plugin is inactive):
        // - template_title gives the dashboard activity feed a durable name even
        //   if the template post is later deleted.
        // - owner_user_id supports team/workspace dashboards where the team owner
        //   sees generations made by their seats. Falls back to the user themselves.
        update_post_meta($post_id, '_awg_aig_template_title', (string) get_the_title($template_id));
        $owner_user_id = (int) apply_filters('awg_mem_usage_owner_user_id', get_current_user_id(), get_current_user_id());
        update_post_meta($post_id, '_awg_aig_owner_user_id', max(0, $owner_user_id));
        update_post_meta($post_id, '_awg_aig_fields', $fields);
        update_post_meta($post_id, '_awg_aig_output', $output);
        update_post_meta($post_id, '_awg_aig_model', $model);
        if ($gclid !== '') update_post_meta($post_id, '_awg_aig_gclid', $gclid);
        if (!empty($utm)) update_post_meta($post_id, '_awg_aig_utm', $utm);

        // v5.4.8: Source URL. Prefer client-supplied (works for SPA hosts),
        // fall back to HTTP_REFERER. Validated via esc_url_raw so junk goes
        // out as empty string rather than getting stored.
        $source_url = '';
        if (isset($_POST['source_url'])) {
            $candidate = esc_url_raw((string) wp_unslash($_POST['source_url']));
            if ($candidate !== '') $source_url = $candidate;
        }
        if ($source_url === '') {
            $ref = wp_get_referer();
            if ($ref) $source_url = esc_url_raw($ref);
        }
        if ($source_url !== '') {
            update_post_meta($post_id, '_awg_aig_source_url', $source_url);
        }

        // Privacy sensitive: only store if enabled globally
        if (!empty($settings['store_ip'])) {
            update_post_meta($post_id, '_awg_aig_ip', $this->ip());
            $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field((string) $_SERVER['HTTP_USER_AGENT']) : '';
            if ($ua !== '') update_post_meta($post_id, '_awg_aig_ua', $ua);
        }
    }

    /** @var int v5.4.61: HTTP status captured during a streaming provider call. */
    private $stream_http_code = 0;

    /**
     * v5.4.61: build a tiny error envelope for prepare_request(). generate()
     * turns it into a JSON response; generate_stream() emits it as an SSE
     * "error" event. Keeps the pre-flight logic output-agnostic.
     */
    private function err(int $status, array $data): array {
        return ['ok' => false, 'status' => $status, 'data' => $data];
    }

    /**
     * v5.4.61: shared pre-flight for both the classic JSON generate() and the
     * streaming generate_stream(). Runs every gate (nonce, template lookup,
     * guest / rate / membership / daily-cap checks, validation, gibberish guard)
     * and assembles the final prompt + provider / model / key. Returns an
     * ['ok'=>true,…] bag of everything the AI call needs, or an ['ok'=>false,…]
     * error envelope. It performs NO output of its own, so each caller can render
     * the result in its own transport (JSON vs Server-Sent Events).
     */
    private function prepare_request(): array {
        $s = $this->settings->get();

        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash((string) $_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'awg_aig_nonce_front')) {
            return $this->err(403, ['message' => __('Invalid request.', 'authorwings-ai-tools')]);
        }

        $template_id = (int) ($_POST['template_id'] ?? 0);
        if ($template_id <= 0) return $this->err(400, ['message' => __('Invalid template.', 'authorwings-ai-tools')]);

        $p = get_post($template_id);
        if (!$p || $p->post_type !== $this->cpt) {
            return $this->err(404, ['message' => __('Template not found.', 'authorwings-ai-tools')]);
        }

        $can_use_unpublished = is_user_logged_in() && current_user_can('edit_post', $template_id);
        if ($p->post_status !== 'publish' && !$can_use_unpublished) {
            return $this->err(404, ['message' => __('Template not found.', 'authorwings-ai-tools')]);
        }

        $m = $this->renderer->get_template_meta($template_id);

        // Guests?
        $template_allow = (int) $m['allow_guests'];
        $allow = ($template_allow === -1) ? (int) $s['allow_guests'] : $template_allow;
        if (!$allow && !is_user_logged_in()) {
            return $this->err(403, ['message' => __('Login required.', 'authorwings-ai-tools')]);
        }

        // Rate limit
        // v5.4.14: pass template_id so per-template and global buckets are
        // tracked independently (see rate_ok docblock).
        $template_rl = (int) $m['rate_per_min'];
        $global_rl = (int) $s['global_rate_per_min'];
        if (!$this->rate_ok($template_id, $template_rl, $global_rl)) {
            return $this->err(429, ['message' => __('Rate limit exceeded. Try again in a minute.', 'authorwings-ai-tools')]);
        }

        // Membership integration: allow membership plugin (or any other) to
        // block generation here. Filter receives ($can, $user_id, $template_id).
        // Returning false sends a generic block; returning a WP_Error sends a
        // custom message with optional upgrade_url / upgrade_label in error data.
        // No-op when no plugin listens to this filter.
        $can_generate = apply_filters('awg_aig_can_generate', true, get_current_user_id(), $template_id);
        if (is_wp_error($can_generate)) {
            $error_data = $can_generate->get_error_data();
            $payload = ['message' => $can_generate->get_error_message()];
            if (is_array($error_data)) {
                if (!empty($error_data['upgrade_url'])) {
                    $payload['upgrade_url'] = esc_url_raw((string) $error_data['upgrade_url']);
                }
                if (!empty($error_data['upgrade_label'])) {
                    $payload['upgrade_label'] = sanitize_text_field((string) $error_data['upgrade_label']);
                }
            }
            return $this->err(429, $payload);
        }
        if ($can_generate === false) {
            // Prefer the lean account page (which holds the Stripe billing
            // controls); awg_mem_get_account_url() resolves to the pricing grid
            // in the lean build, so fall back to it only when the lean helper is
            // unavailable.
            if (function_exists('awg_aig_mem_account_url') && awg_aig_mem_account_url() !== '') {
                $account_url = awg_aig_mem_account_url();
            } elseif (function_exists('awg_mem_get_account_url')) {
                $account_url = awg_mem_get_account_url();
            } else {
                $account_url = add_query_arg('tab', 'account', home_url('/member-dashboard/'));
            }
            return $this->err(403, [
                'message'       => __('This generator is not available for your current plan.', 'authorwings-ai-tools'),
                'upgrade_url'   => $account_url,
                'upgrade_label' => __('Review my account', 'authorwings-ai-tools'),
            ]);
        }

        // v5.4.6: caching removed — AI tools always return a fresh generation.

        $submitted = $_POST['fields'] ?? [];
        if (!is_array($submitted)) {
            $submitted = [];
        }

        // Two paths arrive here. front.js sends both; fields_json wins when
        // valid because it preserves types (arrays for multi-checkbox) better
        // than form-encoded payloads.
        //
        // IMPORTANT: only wp_unslash the path we actually use. The JSON
        // branch already passes its raw string through wp_unslash() ONCE
        // before json_decode, so values coming out of json_decode are
        // already clean. A second wp_unslash on them would strip legitimate
        // backslashes from user input (paths, regex, escapes).
        $used_json = false;
        if (isset($_POST['fields_json'])) {
            $raw_json = wp_unslash((string) $_POST['fields_json']);
            $decoded = json_decode($raw_json, true);
            if (is_array($decoded)) {
                $submitted = $decoded;
                $used_json = true;
            }
        }
        if (!$used_json) {
            $submitted = wp_unslash($submitted);
        }

        // Capture tracking parameters BEFORE validate_submission filters them
        // out. validate_submission only keeps keys present in $m['fields'],
        // and gclid / utm_* are hidden inputs not in the user-defined schema.
        $tracking = [];
        if (isset($submitted['gclid'])) {
            $tracking['gclid'] = (string) $submitted['gclid'];
        }
        foreach (['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'] as $utm_k) {
            if (isset($submitted[$utm_k])) {
                $tracking[$utm_k] = (string) $submitted[$utm_k];
            }
        }

        // v5.4.19: Custom HTML design mode has no field schema — the admin can
        // add any inputs they like. Sanitize every submitted value generically
        // and build {{fields}} from ALL of them, mirroring the standard form's
        // "- Label: value" output. Required-field enforcement in this mode is
        // client-side (HTML5 `required`); the server has no schema to know which
        // inputs are mandatory. Standard mode is unchanged.
        $is_custom = ((string) ($m['design_mode'] ?? 'standard') === 'custom_html')
            && (trim((string) ($m['custom_html'] ?? '')) !== '');

        // v5.4.48: resolve the gibberish guard once (per-template override on top
        // of the global Settings toggle). Enforced below in BOTH form modes,
        // before any billable AI call, so junk input never costs a generation.
        $gib = $this->gibberish_config($m, $s);

        if ($is_custom) {
            // Optional per-field label hints (data-awg-label) sent by front.js.
            $labels = [];
            if (isset($_POST['fields_labels_json'])) {
                $decoded_labels = json_decode(wp_unslash((string) $_POST['fields_labels_json']), true);
                if (is_array($decoded_labels)) {
                    foreach ($decoded_labels as $lk => $lv) {
                        $lk = sanitize_key((string) $lk);
                        if ($lk === '') {
                            continue;
                        }
                        $labels[$lk] = sanitize_text_field((string) $lv);
                    }
                }
            }

            $submitted = $this->sanitize_freeform_submission($submitted);

            // Gibberish guard (custom mode). No field schema here, so judge every
            // submitted string value except the hidden tracking keys (gclid/utm_*),
            // whose values legitimately look random.
            if ($gib['on']) {
                $skip = ['gclid', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'];
                $bad = [];
                foreach ($submitted as $fkey => $fval) {
                    if (in_array($fkey, $skip, true) || !is_string($fval)) {
                        continue;
                    }
                    if ($this->looks_like_gibberish($fval, $gib['min'])) {
                        $label = (isset($labels[$fkey]) && $labels[$fkey] !== '')
                            ? $labels[$fkey]
                            : $this->prettify_key($fkey);
                        $bad[$label] = true;
                    }
                }
                if (!empty($bad)) {
                    return $this->err(422, [
                        'message' => sprintf(
                            /* translators: %s: list of field labels */
                            __('This looks like random text. Please enter real words for: %s', 'authorwings-ai-tools'),
                            implode(', ', array_map('sanitize_text_field', array_keys($bad)))
                        ),
                    ]);
                }
            }

            $fields_text = $this->freeform_to_text($submitted, $labels);
        } else {
            $validated = $this->validate_submission($m['fields'], $submitted);
            $submitted = $validated['clean'];

            if (!empty($validated['errors'])) {
                return $this->err(422, [
                    'message' => implode(' ', array_map('sanitize_text_field', $validated['errors'])),
                ]);
            }

            $missing = $this->required_missing($m['fields'], $submitted);
            if (!empty($missing)) {
                return $this->err(422, [
                    'message' => sprintf(
                        /* translators: %s: list of missing required fields */
                        __('Please complete required fields: %s', 'authorwings-ai-tools'),
                        implode(', ', array_map('sanitize_text_field', $missing))
                    ),
                ]);
            }

            // Gibberish guard (standard mode). Only free-text inputs are judged;
            // email/number/select/radio/checkbox already have their own
            // validation and are never keyboard-mashing in the same sense.
            if ($gib['on']) {
                $bad = [];
                foreach ($m['fields'] as $field) {
                    $type = $field['type'] ?? 'text';
                    if (!in_array($type, ['text', 'textarea'], true)) {
                        continue;
                    }
                    $key = sanitize_key($field['key'] ?? '');
                    if ($key === '' || !isset($submitted[$key])) {
                        continue;
                    }
                    if ($this->looks_like_gibberish((string) $submitted[$key], $gib['min'])) {
                        $bad[] = sanitize_text_field($field['label'] ?? $key);
                    }
                }
                if (!empty($bad)) {
                    return $this->err(422, [
                        'message' => sprintf(
                            /* translators: %s: list of field labels */
                            __('This looks like random text. Please enter real words for: %s', 'authorwings-ai-tools'),
                            implode(', ', array_values(array_unique($bad)))
                        ),
                    ]);
                }
            }

            $fields_text = $this->renderer->fields_to_text($m['fields'], $submitted);
        }

        if ($fields_text === '') $fields_text = '(No inputs provided)';

        $system = (string) $m['system_prompt'];

        // v5.4.49: prepend the global system prompt (Settings) unless this
        // template opted out. Shared rules (tone, language, formatting) thus
        // apply to every tool from one place, ahead of the tool's own prompt.
        // A `awg_aig_global_prompt` filter allows per-request tweaks (e.g.
        // injecting the member's plan or locale). Blank global prompt = no-op.
        $apply_global = !isset($m['apply_global_prompt']) || !empty($m['apply_global_prompt']);
        $global_prompt = trim((string) apply_filters('awg_aig_global_prompt', (string) ($s['global_prompt'] ?? ''), $template_id));
        if ($apply_global && $global_prompt !== '') {
            $system = ($system === '') ? $global_prompt : ($global_prompt . "\n\n" . $system);
        }

        // v5.8.3: formatting guidance is now scoped to the tool by its Result
        // Style, so there is nothing extra to tick. Plain-text tools get NOTHING
        // (clean prose, no block guidance). Editorial tools get the hygiene line
        // plus ONLY the block-formatting rules for the blocks they actually use
        // (detected from their Rules/prompt) — and only when that formatting
        // isn't already written inline, so the same instruction is never sent
        // twice. This replaces the old always-on "Apply formatting rules" toggle.
        $render_mode = (($m['render_mode'] ?? 'document') === 'plain') ? 'plain' : 'document';
        $fmt_context = trim(
            (string) ($m['rules'] ?? '') . "\n" .
            (string) ($m['user_prompt'] ?? '') . "\n" .
            (string) ($m['system_prompt'] ?? '')
        );

        if ($render_mode !== 'plain') {
            // v5.4.94: formatting hygiene — keep internal block/markup names out of
            // the reader-facing output. The `awg_aig_format_hygiene` filter can
            // change or disable it (return '').
            $hygiene = (string) apply_filters('awg_aig_format_hygiene',
                Renderer::effective_format_hygiene($s),
                $template_id);
            if ($hygiene !== '' && stripos($fmt_context, 'never mention formatting') === false) {
                $system = ($system === '') ? $hygiene : ($system . "\n\n" . $hygiene);
            }

            // v5.4.95 / v5.8.3: block-formatting rules, now scoped to the blocks
            // this tool uses. Every rule is conditional — it only refines HOW a
            // block is formatted, never WHETHER to use one. The `awg_aig_format_rules`
            // filter can change or disable the resulting text (return '').
            $fmt_rules = (string) apply_filters('awg_aig_format_rules',
                Renderer::relevant_format_rules($s, $render_mode, $fmt_context),
                $template_id);
            if ($fmt_rules !== '') {
                $system = ($system === '') ? $fmt_rules : ($system . "\n\n" . $fmt_rules);
            }
        }

        $user_tpl = (string) $m['user_prompt'];

        // v5.4.71: pre-expand the scalar placeholders ({{task}}, {{count}})
        // inside the Rules text BEFORE folding it into the template. PHP's
        // str_replace below runs left-to-right, so {{rules}} is substituted
        // last — meaning a {{count}} or {{task}} an author wrote inside Rules
        // would otherwise survive unresolved and reach the model literally.
        // Authors very commonly put "{{count}}" in Rules (e.g. "Return
        // {{count}} ideas"), so resolve those here. The admin Final Prompt
        // Preview mirrors this same pre-expansion.
        $awg_task   = (string) $m['task'];
        $awg_count  = (string) (int) $m['count'];
        $rules_text = str_replace(['{{task}}', '{{count}}'], [$awg_task, $awg_count], (string) $m['rules']);

        $user_prompt = str_replace(
            ['{{task}}','{{count}}','{{fields}}','{{rules}}'],
            [$awg_task, $awg_count, $fields_text, $rules_text],
            $user_tpl
        );

        // v5.4.6: caching removed — every request hits the API for fresh output.

        $model = trim((string) $m['model']);
        if ($model === '') $model = (string) $s['default_model'];

        // v5.5.0 / v5.6.0: route to the right provider based on the model id.
        // Models beginning with "claude" use the Anthropic API + Anthropic key;
        // models beginning with "deepseek" use the DeepSeek API + DeepSeek key;
        // everything else uses the OpenAI API + OpenAI key.
        $provider = $this->provider_for_model($model);
        if ($provider === 'anthropic') {
            $api_key = trim((string) ($s['anthropic_api_key'] ?? ''));
            $missing_msg = __('Anthropic (Claude) API key missing in settings.', 'authorwings-ai-tools');
        } elseif ($provider === 'deepseek') {
            $api_key = trim((string) ($s['deepseek_api_key'] ?? ''));
            $missing_msg = __('DeepSeek API key missing in settings.', 'authorwings-ai-tools');
        } else {
            $api_key = trim((string) $s['api_key']);
            $missing_msg = __('OpenAI API key missing in settings.', 'authorwings-ai-tools');
        }
        if ($api_key === '') {
            return $this->err(500, ['message' => $missing_msg]);
        }

        $timeout = (int) $s['timeout'];
        $max_tokens = (int) $m['max_output_tokens'];

        // v5.6.2: "Run via Agent" — if this template is linked to a published
        // agent, the request is handled by the agent's multi-step engine instead
        // of a single model call (see agent_call()). Validate the link here.
        // v5.6.3: when the link is set but unusable (agent missing, draft, wrong
        // type, engine absent) tell admins exactly why instead of silently
        // reverting to single-shot — that silent fallback made it look like the
        // setting "did nothing". Visitors still fall back gracefully.
        $agent_id = (int) ($m['agent_id'] ?? 0);
        if ($agent_id > 0) {
            $agent_cpt = class_exists('\\AWG_AIG\\Agent\\Agent') ? \AWG_AIG\Agent\Agent::CPT : 'awg_ai_agent';
            $reason = '';
            if (!class_exists('\\AWG_AIG\\Agent\\Agent_Runtime')) {
                $reason = __('the agent engine is unavailable', 'authorwings-ai-tools');
            } else {
                $ap = get_post($agent_id);
                if (!$ap || $ap->post_type !== $agent_cpt) {
                    $reason = __('the linked agent no longer exists', 'authorwings-ai-tools');
                } elseif ($ap->post_status !== 'publish') {
                    /* translators: %s: post status, e.g. draft */
                    $reason = sprintf(__('the linked agent is not published (status: %s)', 'authorwings-ai-tools'), $ap->post_status);
                }
            }
            if ($reason !== '') {
                // v5.6.4: the "Run via Agent" link picker was retired in favour of
                // the standalone "Run as Agent" toggle, so a stale/broken link must
                // never hard-stop. Fall through gracefully: standalone (if enabled)
                // takes over below, otherwise the classic single-shot runs.
                $agent_id = 0;
            }
        }

        // v5.6.4: standalone "Run as Agent" — the template is its own agent.
        // Only applies when there's no usable linked Agent above; a linked Agent
        // always wins. Requires the agent engine to be present.
        $agent_standalone = 0;
        if ($agent_id <= 0
            && !empty($m['agent_standalone'])
            && class_exists('\\AWG_AIG\\Agent\\Agent_Runtime')) {
            $agent_standalone = 1;
        }

        // v5.4.7: temperature handling fully removed. OpenAI applies each
        // model's own default — fine for both reasoning and non-reasoning
        // models. Use `awg_openai_payload` filter for per-tool overrides.

        // v5.4.31: site-wide daily backstop. Read-only gate here — after
        // validation and immediately before the billable call — so a request
        // that's about to be rejected, or a call that fails, never consumes a
        // slot. The actual count is bumped only on success (below). The per-IP
        // limiter (rate_ok) already ran much earlier; this is the cross-IP
        // defence-in-depth layer.
        if ($this->global_cap_reached((int) ($s['global_daily_cap'] ?? 0))) {
            return $this->err(429, ['message' => __('This tool has reached today’s overall usage limit. Please try again tomorrow.', 'authorwings-ai-tools')]);
        }

        // All gates passed. Hand back everything the AI call needs; the caller
        // decides whether to stream the response (SSE) or return it as JSON.
        return [
            'ok'          => true,
            'provider'    => $provider,
            'api_key'     => $api_key,
            'model'       => $model,
            'system'      => $system,
            'user'        => $user_prompt,
            'max_tokens'  => $max_tokens,
            'timeout'     => $timeout,
            'template_id' => $template_id,
            'agent_id'    => $agent_id,
            'agent_standalone' => $agent_standalone,
            'submitted'   => $submitted,
            'tracking'    => $tracking,
            'meta'        => $m,
            'settings'    => $s,
        ];
    }

    /**
     * Apply the template's output format to the model text.
     *
     * The only formats now are 'text' and 'pdf', and both carry the model's
     * text as-is — the download format (plain .txt vs a formatted PDF) is
     * applied client-side. Legacy 'html'/'json' values are already normalised
     * to 'text' by Renderer::get_template_meta(), so no processing remains.
     *
     * @param string $text   Raw model output.
     * @param string $format Download format ('text' | 'pdf').
     * @return string
     */
    private function finalize_output(string $text, string $format): string {
        unset($format); // reserved for future per-format processing
        return $text;
    }

    /**
     * v5.4.61: record a successful generation — usage counters, daily cap, the
     * awg_aig_generated action, and the stored submission. Shared by the JSON and
     * streaming paths so a streamed result is logged identically.
     */
    private function record_generation(string $text, array $r): void {
        $this->bump_usage($r['template_id']);

        // Count toward the site-wide daily cap only when it's enabled.
        if ((int) ($r['settings']['global_daily_cap'] ?? 0) > 0) {
            $this->global_cap_bump();
        }

        // Membership integration: notify external plugins that a generation
        // succeeded (monthly usage counters, etc.). No-op with no listener.
        do_action('awg_aig_generated', get_current_user_id(), $r['template_id'], $text);

        // Merge tracking back in so store_submission can split it into the
        // dedicated meta fields (it strips them from the "fields" bucket).
        $this->store_submission(
            $r['template_id'],
            array_merge($r['submitted'], $r['tracking']),
            $text,
            (string) $r['model'],
            $r['settings']
        );
    }

    /**
     * Classic non-streaming endpoint. Runs the shared pre-flight, makes one
     * blocking AI call, then returns the whole result as JSON.
     */
    public function generate(): void {
        $r = $this->prepare_request();
        if (empty($r['ok'])) {
            wp_send_json_error($r['data'], $r['status']);
        }

        $resp = ((int) ($r['agent_id'] ?? 0) > 0)
            ? $this->agent_call($r)
            : $this->ai_call($r['provider'], $r['api_key'], $r['model'], $r['system'], $r['user'], $r['max_tokens'], $r['timeout'], $r['template_id']);

        if (empty($resp['ok'])) {
            $debug = (current_user_can('manage_options') && !empty($r['meta']['debug_admin'])) ? ($resp['raw'] ?? null) : null;
            wp_send_json_error(['message' => $resp['error'] ?? __('AI request failed.', 'authorwings-ai-tools'), 'debug' => $debug], 500);
        }

        $text = $this->finalize_output((string) ($resp['text'] ?? ''), (string) $r['meta']['output_format']);
        $this->record_generation($text, $r);

        wp_send_json_success(['text' => $text, 'format' => $r['meta']['output_format']]);
    }

    /**
     * v5.4.61: streaming endpoint (Server-Sent Events). Runs the SAME pre-flight
     * as generate(), then streams the model's tokens to the browser as they
     * arrive, so the result types in live instead of appearing all at once.
     *
     * Wire protocol (each message is one SSE event):
     *   event: delta  data: {"text":"…"}                            — append chunk
     *   event: done   data: {"text":"…","format":"text|html|json"}  — final text
     *   event: error  data: {"message":"…"[, "fallback":true, …]}
     *
     * When streaming infrastructure is unavailable (no cURL, blocked by the
     * host), the error carries "fallback":true and front.js silently retries the
     * classic generate() endpoint, so the tool keeps working everywhere.
     */
    public function generate_stream(): void {
        $r = $this->prepare_request();

        $this->stream_open();

        if (empty($r['ok'])) {
            $this->sse_send('error', $r['data']);
            exit;
        }

        // v5.6.2: agent-linked tools can't token-stream (the agent runs a
        // multi-step tool loop). Run it synchronously and emit the final result
        // as a single SSE "done" event — the client shows its working indicator
        // until then. Everything else streams tokens live as before.
        $resp = ((int) ($r['agent_id'] ?? 0) > 0)
            ? $this->agent_call($r)
            : $this->ai_stream_call($r['provider'], $r['api_key'], $r['model'], $r['system'], $r['user'], $r['max_tokens'], $r['timeout'], $r['template_id']);

        if (empty($resp['ok'])) {
            $payload = ['message' => $resp['error'] ?? __('AI request failed.', 'authorwings-ai-tools')];
            if (!empty($resp['fallback'])) {
                $payload['fallback'] = true;
            }
            if (current_user_can('manage_options') && !empty($r['meta']['debug_admin']) && isset($resp['raw'])) {
                $payload['debug'] = $resp['raw'];
            }
            $this->sse_send('error', $payload);
            exit;
        }

        $text = $this->finalize_output((string) ($resp['text'] ?? ''), (string) $r['meta']['output_format']);
        $this->record_generation($text, $r);

        // The live deltas were the raw model text; send the authoritative,
        // format-processed text so the client can swap to the final version.
        $this->sse_send('done', ['text' => $text, 'format' => $r['meta']['output_format']]);
        exit;
    }

    /**
     * Open a Server-Sent Events stream: disable buffering/compression as far as
     * the environment allows, send the SSE headers, and push an initial padded
     * comment so proxies with a minimum-buffer threshold flush right away.
     */
    private function stream_open(): void {
        if (function_exists('ignore_user_abort')) { @ignore_user_abort(true); }
        @ini_set('zlib.output_compression', '0');
        @ini_set('output_buffering', '0');
        @ini_set('implicit_flush', '1');
        while (ob_get_level() > 0) { @ob_end_flush(); }

        if (!headers_sent()) {
            header('Content-Type: text/event-stream; charset=utf-8');
            header('Cache-Control: no-cache, no-store, must-revalidate');
            header('Pragma: no-cache');
            header('Connection: keep-alive');
            header('X-Accel-Buffering: no'); // tell nginx not to buffer
        }

        // ~2KB SSE comment primes the pipe past common proxy buffer thresholds.
        echo ':' . str_repeat(' ', 2048) . "\n\n";
        @flush();
    }

    /** Emit one SSE event with a JSON data payload and flush it immediately. */
    private function sse_send(string $event, array $data): void {
        echo 'event: ' . $event . "\n";
        echo 'data: ' . wp_json_encode($data) . "\n\n";
        @flush();
    }

    /**
     * Pull the incremental text out of one decoded SSE data object, per provider:
     *   - OpenAI Responses : {"type":"response.output_text.delta","delta":"…"}
     *   - Anthropic        : {"type":"content_block_delta","delta":{"type":"text_delta","text":"…"}}
     *   - DeepSeek/OpenAI  : {"choices":[{"delta":{"content":"…"}}]}
     * Anything else (role headers, usage, pings) yields ''.
     */
    private function extract_stream_delta(string $provider, array $obj): string {
        if ($provider === 'anthropic') {
            if (($obj['type'] ?? '') === 'content_block_delta'
                && is_array($obj['delta'] ?? null)
                && ($obj['delta']['type'] ?? '') === 'text_delta') {
                return (string) ($obj['delta']['text'] ?? '');
            }
            return '';
        }
        if ($provider === 'deepseek') {
            return (string) ($obj['choices'][0]['delta']['content'] ?? '');
        }
        // OpenAI Responses API.
        if (($obj['type'] ?? '') === 'response.output_text.delta') {
            return (string) ($obj['delta'] ?? '');
        }
        return '';
    }

    /**
     * v5.4.61: streaming counterpart to ai_call(). Uses cURL directly (the WP
     * HTTP API buffers the whole body, which defeats streaming) with stream=true
     * on each provider. As tokens arrive they are parsed out of the SSE stream
     * and re-emitted to the browser via sse_send('delta', …); the full text is
     * accumulated and returned so the caller can format + store it.
     *
     * On any non-2xx the body is collected and parsed as a normal JSON error so
     * the user sees the provider's message. If cURL is missing the call returns
     * fallback=true so the front-end can retry the classic endpoint.
     *
     * @return array{ok:bool,text?:string,error?:string,raw?:mixed,fallback?:bool}
     */
    private function ai_stream_call(string $provider, string $api_key, string $model, string $system, string $user, int $max_tokens, int $timeout, int $template_id = 0): array {
        if (!function_exists('curl_init')) {
            return ['ok' => false, 'fallback' => true, 'error' => __('Streaming unavailable on this server.', 'authorwings-ai-tools')];
        }
        if ($max_tokens <= 0) $max_tokens = 1024;

        if ($provider === 'anthropic') {
            $url = 'https://api.anthropic.com/v1/messages';
            $headers = [
                'Content-Type: application/json',
                'x-api-key: ' . $api_key,
                'anthropic-version: 2023-06-01',
            ];
            $payload = [
                'model'      => $model,
                'max_tokens' => $max_tokens,
                'stream'     => true,
                'messages'   => [['role' => 'user', 'content' => $user]],
            ];
            if (trim($system) !== '') $payload['system'] = $system;
            $payload = (array) apply_filters('awg_anthropic_payload', $payload, $model, $template_id);
        } elseif ($provider === 'deepseek') {
            $url = 'https://api.deepseek.com/chat/completions';
            $headers = [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $api_key,
            ];
            $messages = [];
            if (trim($system) !== '') $messages[] = ['role' => 'system', 'content' => $system];
            $messages[] = ['role' => 'user', 'content' => $user];
            $payload = [
                'model'      => $model,
                'messages'   => $messages,
                'max_tokens' => $max_tokens,
                'stream'     => true,
            ];
            $payload = (array) apply_filters('awg_deepseek_payload', $payload, $model, $template_id);
        } else {
            $url = 'https://api.openai.com/v1/responses';
            $headers = [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $api_key,
            ];
            $payload = [
                'model' => $model,
                'input' => [
                    ['role' => 'system', 'content' => [['type' => 'input_text', 'text' => $system]]],
                    ['role' => 'user',   'content' => [['type' => 'input_text', 'text' => $user]]],
                ],
                'max_output_tokens' => $max_tokens,
                'stream'            => true,
            ];
            $payload = (array) apply_filters('awg_openai_payload', $payload, $model, $template_id);
        }

        $full   = '';
        $raw    = '';
        $buffer = '';
        $this->stream_http_code = 0;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, wp_json_encode($payload));
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_TIMEOUT, max(30, $timeout));
        curl_setopt($ch, CURLOPT_HEADERFUNCTION, function ($ch, $header) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $header, $mm)) {
                $this->stream_http_code = (int) $mm[1];
            }
            return strlen($header);
        });
        curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($ch, $chunk) use (&$buffer, &$full, &$raw, $provider) {
            $raw .= $chunk;
            // Non-2xx: keep the body for the error path, emit nothing.
            if ($this->stream_http_code && ($this->stream_http_code < 200 || $this->stream_http_code >= 300)) {
                return strlen($chunk);
            }
            $buffer .= $chunk;
            while (($nl = strpos($buffer, "\n")) !== false) {
                $line   = rtrim(substr($buffer, 0, $nl), "\r");
                $buffer = substr($buffer, $nl + 1);
                if ($line === '' || strncmp($line, 'data:', 5) !== 0) continue;
                $data = trim(substr($line, 5));
                if ($data === '' || $data === '[DONE]') continue;
                $obj = json_decode($data, true);
                if (!is_array($obj)) continue;
                $delta = $this->extract_stream_delta($provider, $obj);
                if ($delta !== '') {
                    $full .= $delta;
                    $this->sse_send('delta', ['text' => $delta]);
                }
            }
            return strlen($chunk);
        });

        $exec = curl_exec($ch);
        $cerr = curl_error($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code) $this->stream_http_code = $code;

        // Transport-level failure with nothing streamed → let the client retry
        // the classic endpoint rather than showing a hard error.
        if ($exec === false && $full === '') {
            return ['ok' => false, 'fallback' => true, 'error' => $cerr ?: __('Streaming request failed.', 'authorwings-ai-tools')];
        }

        if ($this->stream_http_code < 200 || $this->stream_http_code >= 300) {
            $json = json_decode($raw, true);
            $msg  = (is_array($json) && isset($json['error']['message']))
                ? (string) $json['error']['message']
                : __('AI request failed.', 'authorwings-ai-tools');
            return ['ok' => false, 'error' => $msg, 'raw' => $json ?: $raw];
        }

        $full = trim($full);
        if ($full === '') {
            // Same thinking-model case as deepseek_call(): if the stream carried
            // reasoning deltas but never any final content, the budget ran out
            // mid-thought. Point the user at Max Output Tokens instead of the
            // generic "empty response".
            if ($provider === 'deepseek' && strpos($raw, 'reasoning_content') !== false) {
                return [
                    'ok'             => false,
                    'error'          => __('The model used its whole token budget on reasoning before writing an answer. Raise Max Output Tokens — thinking models like deepseek-reasoner / deepseek-v4-pro need more room.', 'authorwings-ai-tools'),
                    'raw'            => $raw,
                    'reasoning_only' => true,
                ];
            }
            // OpenAI reasoning models (gpt-5 / gpt-5.5 / o-series): the SSE stream
            // carries reasoning items and/or an "incomplete" completion capped at
            // max_output_tokens, but no visible output_text. Same root cause —
            // the budget was spent on hidden reasoning.
            if ($provider === 'openai'
                && (strpos($raw, '"type":"reasoning"') !== false
                    || strpos($raw, 'reasoning_tokens') !== false
                    || strpos($raw, 'max_output_tokens') !== false)) {
                return [
                    'ok'             => false,
                    'error'          => __('The model used its whole token budget on reasoning before writing an answer. Raise Max Output Tokens — reasoning models like gpt-5 / gpt-5.5 / the o-series need more room.', 'authorwings-ai-tools'),
                    'raw'            => $raw,
                    'reasoning_only' => true,
                ];
            }
            return [
                'ok'    => false,
                'error' => __('The model returned an empty or unexpected response. Please try again.', 'authorwings-ai-tools'),
                'raw'   => $raw,
            ];
        }
        return ['ok' => true, 'text' => $full];
    }

    /**
     * Admin-only: test the saved OpenAI API key with a minimal request.
     * Allows admins to verify credentials before creating templates.
     */
    public function test_key(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'authorwings-ai-tools')], 403);
        }
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash((string) $_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'awg_aig_test_key')) {
            wp_send_json_error(['message' => __('Invalid request.', 'authorwings-ai-tools')], 403);
        }

        $s = $this->settings->get();

        // v5.5.0 / v5.6.0: the per-key Test buttons post a "provider" hint.
        // Otherwise infer the provider from the model id.
        $model = isset($_POST['model']) ? sanitize_text_field(wp_unslash((string) $_POST['model'])) : '';
        $provider = isset($_POST['provider']) ? sanitize_text_field(wp_unslash((string) $_POST['provider'])) : '';
        if (!in_array($provider, ['anthropic', 'openai', 'deepseek'], true)) {
            $provider = $this->provider_for_model($model);
        }
        // Ensure the test model matches the provider being tested. If the saved
        // default model belongs to another provider (or is blank), fall back to
        // a cheap model for the provider we're testing. The DeepSeek fallback
        // uses the legacy non-thinking "deepseek-chat" alias so the tiny test
        // budget below returns a clean answer with no reasoning tokens.
        if ($model === '' || $this->provider_for_model($model) !== $provider) {
            if ($provider === 'anthropic') {
                $model = 'claude-haiku-4-5-20251001';
            } elseif ($provider === 'deepseek') {
                $model = 'deepseek-chat';
            } else {
                $model = 'gpt-4o-mini';
            }
        }

        // Allow overriding the key from the request so the admin can test BEFORE saving.
        $posted_key = isset($_POST['api_key']) ? trim((string) wp_unslash($_POST['api_key'])) : '';
        if ($provider === 'anthropic') {
            $saved_key = trim((string) ($s['anthropic_api_key'] ?? ''));
        } elseif ($provider === 'deepseek') {
            $saved_key = trim((string) ($s['deepseek_api_key'] ?? ''));
        } else {
            $saved_key = trim((string) $s['api_key']);
        }
        $api_key = $posted_key !== '' ? $posted_key : $saved_key;
        if ($api_key === '') {
            wp_send_json_error(['message' => __('No API key to test. Enter one in the field first.', 'authorwings-ai-tools')], 400);
        }

        $timeout = max(10, min(30, (int) $s['timeout']));
        // Reasoning models spend tokens on hidden reasoning before the final
        // answer, so a 16-token cap often leaves no room for the "OK" and the
        // test would intermittently fail. This bites DeepSeek thinking models
        // (deepseek-reasoner, deepseek-v4-pro Expert mode) and OpenAI reasoning
        // models alike (gpt-5 / gpt-5.5 / the o-series), so give both a roomier
        // budget. A plain non-reasoning OpenAI model still just replies "OK" and
        // stops well under the cap, so the larger budget costs nothing there.
        $test_budget = ($provider === 'deepseek' || $provider === 'openai') ? 512 : 16;
        $resp = $this->ai_call(
            $provider,
            $api_key,
            $model,
            'You are a connectivity test. Reply with the single word: OK',
            'Reply with the single word: OK',
            $test_budget,
            $timeout
        );

        if (empty($resp['ok'])) {
            // A thinking model that only produced reasoning within the small
            // test budget still proves the key + model are valid. Count it as a
            // pass rather than a failure — the budget note only matters for real
            // generations, which use the template's Max Output Tokens.
            if (!empty($resp['reasoning_only'])) {
                wp_send_json_success([
                    'message' => sprintf(
                        /* translators: %s: model name */
                        __('Connection OK. Model %s responded (reasoning model — give it enough Max Output Tokens for real runs).', 'authorwings-ai-tools'),
                        $model
                    ),
                    'reply' => '',
                ]);
            }
            wp_send_json_error([
                'message' => sprintf(
                    /* translators: %s: OpenAI error message */
                    __('Test failed: %s', 'authorwings-ai-tools'),
                    (string) ($resp['error'] ?? 'Unknown error')
                ),
            ], 400);
        }

        wp_send_json_success([
            'message' => sprintf(
                /* translators: %s: model name */
                __('Connection OK. Model %s responded.', 'authorwings-ai-tools'),
                $model
            ),
            'reply' => (string) ($resp['text'] ?? ''),
        ]);
    }

    /**
     * v5.4.69: AJAX endpoint for "file" form fields.
     *
     * The JSON generate request can't carry a binary, so front.js uploads each
     * chosen file here the moment it's selected. We validate it against the
     * field's own allowed-types / max-size config (re-derived server-side, never
     * trusting the client), move it into a protected uploads sub-directory,
     * best-effort extract its text, and stash everything under a short-lived
     * one-time token. The token is returned to the browser and submitted with the
     * form; resolve_uploaded_file() swaps it back for the extracted text so the
     * AI receives the document content as part of {{fields}}.
     *
     * Gating mirrors generate(): nonce + guest policy + the same per-IP rate
     * bucket, so the upload route can't be used to bypass either.
     */
    public function upload(): void {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash((string) $_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'awg_aig_nonce_front')) {
            wp_send_json_error(['message' => __('Invalid request.', 'authorwings-ai-tools')], 403);
        }

        $template_id = (int) ($_POST['template_id'] ?? 0);
        $field_key   = sanitize_key((string) ($_POST['field_key'] ?? ''));
        if ($template_id <= 0 || $field_key === '') {
            wp_send_json_error(['message' => __('Invalid upload request.', 'authorwings-ai-tools')], 400);
        }

        $p = get_post($template_id);
        if (!$p || $p->post_type !== $this->cpt) {
            wp_send_json_error(['message' => __('Template not found.', 'authorwings-ai-tools')], 404);
        }

        $m = $this->renderer->get_template_meta($template_id);
        $s = $this->settings->get();

        // Guest policy — identical to generate().
        $template_allow = (int) $m['allow_guests'];
        $allow = ($template_allow === -1) ? (int) $s['allow_guests'] : $template_allow;
        if (!$allow && !is_user_logged_in()) {
            wp_send_json_error(['message' => __('Login required.', 'authorwings-ai-tools')], 403);
        }

        // Rate limit — shares generate()'s bucket so uploads count toward it.
        if (!$this->rate_ok($template_id, (int) $m['rate_per_min'], (int) $s['global_rate_per_min'])) {
            wp_send_json_error(['message' => __('Too many requests. Try again in a minute.', 'authorwings-ai-tools')], 429);
        }

        // Locate the matching upload field in this template's schema.
        $field = null;
        foreach ((array) ($m['fields'] ?? []) as $f) {
            if (!is_array($f)) { continue; }
            if (sanitize_key($f['key'] ?? '') === $field_key && ($f['type'] ?? '') === 'file') {
                $field = $f;
                break;
            }
        }
        if (!$field) {
            wp_send_json_error(['message' => __('This field does not accept uploads.', 'authorwings-ai-tools')], 400);
        }

        if (empty($_FILES['file']) || !is_array($_FILES['file']) || (int) ($_FILES['file']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            wp_send_json_error(['message' => __('No file received.', 'authorwings-ai-tools')], 400);
        }
        $file = $_FILES['file'];
        if ((int) $file['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(['message' => $this->upload_error_message((int) $file['error'])], 400);
        }

        // Size (authoritative re-check).
        $max_mb    = $this->renderer->file_max_mb($field['file_max_mb'] ?? 0);
        $max_bytes = $max_mb * 1024 * 1024;
        if ((int) $file['size'] <= 0) {
            wp_send_json_error(['message' => __('The file appears to be empty.', 'authorwings-ai-tools')], 400);
        }
        if ((int) $file['size'] > $max_bytes) {
            wp_send_json_error(['message' => sprintf(
                /* translators: %d: max size in MB */
                __('File is too large. Max %d MB.', 'authorwings-ai-tools'),
                $max_mb
            )], 400);
        }

        // Extension allowlist — the field's list, already intersected with the
        // hard global whitelist inside file_accept_list().
        $allowed   = $this->renderer->file_accept_list($field['file_types'] ?? '');
        $orig_name = (string) $file['name'];
        $ext       = strtolower((string) pathinfo($orig_name, PATHINFO_EXTENSION));
        if ($ext === '' || !in_array($ext, $allowed, true)) {
            wp_send_json_error(['message' => sprintf(
                /* translators: %s: list of allowed extensions */
                __('File type not allowed. Accepted: %s', 'authorwings-ai-tools'),
                strtoupper(implode(', ', $allowed))
            )], 400);
        }

        // Move into a dedicated, script-execution-protected uploads sub-dir.
        // We do the move ourselves (rather than wp_handle_upload) so legitimate
        // office docs aren't rejected by WP's media MIME policy — safety comes
        // from the hard extension whitelist + forced extension + the .htaccess
        // guard written below, not from MIME sniffing.
        $up = wp_upload_dir();
        if (!empty($up['error'])) {
            wp_send_json_error(['message' => __('Upload directory is not writable.', 'authorwings-ai-tools')], 500);
        }
        $dir = trailingslashit($up['basedir']) . 'awg-ai-uploads';
        if (!wp_mkdir_p($dir)) {
            wp_send_json_error(['message' => __('Could not create the upload directory.', 'authorwings-ai-tools')], 500);
        }
        $this->protect_upload_dir($dir);

        $base = sanitize_file_name((string) pathinfo($orig_name, PATHINFO_FILENAME));
        if ($base === '') { $base = 'upload'; }
        $base = substr($base, 0, 80);
        $stored_name = wp_generate_password(8, false) . '-' . $base . '.' . $ext;
        $dest = trailingslashit($dir) . $stored_name;

        $moved = false;
        if (is_uploaded_file($file['tmp_name'])) {
            $moved = @move_uploaded_file($file['tmp_name'], $dest);
        }
        if (!$moved) {
            wp_send_json_error(['message' => __('Upload failed. Please try again.', 'authorwings-ai-tools')], 500);
        }
        @chmod($dest, 0644);

        $stored_url = trailingslashit($up['baseurl']) . 'awg-ai-uploads/' . $stored_name;

        // Best-effort text extraction (capped so a huge manuscript can't blow the
        // prompt budget — the model still gets a meaningful, truncated excerpt).
        $extracted = $this->extract_text_from_file($dest, $ext);
        $max_chars = (int) apply_filters('awg_aig_upload_max_chars', 30000);
        $truncated = false;
        if ($extracted !== '' && strlen($extracted) > $max_chars) {
            $extracted = substr($extracted, 0, $max_chars);
            $truncated = true;
        }

        $token   = wp_generate_password(24, false);
        $payload = [
            'name'      => sanitize_file_name($orig_name),
            'ext'       => $ext,
            'url'       => $stored_url,
            'path'      => $dest,
            'text'      => $extracted,
            'truncated' => $truncated,
            'user'      => get_current_user_id(),
            'time'      => time(),
        ];
        set_transient('awg_aig_upload_' . $token, $payload, HOUR_IN_SECONDS);

        wp_send_json_success([
            'token'     => $token,
            'name'      => $payload['name'],
            'ext'       => $ext,
            'size'      => (int) $file['size'],
            'has_text'  => $extracted !== '',
            'truncated' => $truncated,
        ]);
    }

    /**
     * Resolve a submitted upload token back to the {{fields}} value the AI sees:
     * the extracted text (with a filename header + truncation note), or — when no
     * text could be extracted (pdf, image, zip…) — a clear reference line naming
     * the file and its URL. Unknown / expired tokens resolve to '' so a required
     * upload is correctly reported as missing.
     */
    private function resolve_uploaded_file(string $token): string {
        $token = preg_replace('/[^A-Za-z0-9]/', '', $token);
        if ($token === '') {
            return '';
        }
        $payload = get_transient('awg_aig_upload_' . $token);
        if (!is_array($payload)) {
            return '';
        }

        $name = sanitize_text_field((string) ($payload['name'] ?? 'file'));
        $url  = esc_url_raw((string) ($payload['url'] ?? ''));
        $text = (string) ($payload['text'] ?? '');

        if ($text !== '') {
            $text = sanitize_textarea_field($text);
            $out  = sprintf(
                /* translators: %s: uploaded file name */
                __('[Uploaded file "%s" — extracted text follows]', 'authorwings-ai-tools'),
                $name
            ) . "\n" . $text;
            if (!empty($payload['truncated'])) {
                $out .= "\n" . __('[Note: the uploaded file was long and the text above was truncated.]', 'authorwings-ai-tools');
            }
            return $out;
        }

        return sprintf(
            /* translators: 1: uploaded file name, 2: file URL */
            __('[Uploaded file "%1$s" available at %2$s — text could not be extracted automatically.]', 'authorwings-ai-tools'),
            $name,
            $url
        );
    }

    /** Map a PHP UPLOAD_ERR_* code to a friendly, translatable message. */
    private function upload_error_message(int $code): string {
        switch ($code) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return __('The file is larger than the server allows.', 'authorwings-ai-tools');
            case UPLOAD_ERR_PARTIAL:
                return __('The upload was interrupted. Please try again.', 'authorwings-ai-tools');
            case UPLOAD_ERR_NO_TMP_DIR:
            case UPLOAD_ERR_CANT_WRITE:
                return __('The server could not save the file.', 'authorwings-ai-tools');
            default:
                return __('Upload failed. Please try again.', 'authorwings-ai-tools');
        }
    }

    /**
     * Drop an index.html + an .htaccess into the uploads sub-dir so the directory
     * can't be browsed and nothing in it can ever be executed as a script —
     * defence in depth on top of the extension whitelist. Written once.
     */
    private function protect_upload_dir(string $dir): void {
        $ht = trailingslashit($dir) . '.htaccess';
        if (!file_exists($ht)) {
            $rules  = "Options -Indexes\n";
            $rules .= "<FilesMatch \"\\.(php|phtml|phps|php[0-9]+|pl|py|cgi|asp|aspx|sh|exe|js)$\">\n";
            $rules .= "  Require all denied\n";
            $rules .= "</FilesMatch>\n";
            @file_put_contents($ht, $rules);
        }
        $idx = trailingslashit($dir) . 'index.html';
        if (!file_exists($idx)) {
            @file_put_contents($idx, '');
        }
    }

    /**
     * Best-effort plain-text extraction from a stored upload. Pure PHP — no
     * external binaries or Composer libraries — so it works on any host. Formats
     * it can't read reliably without a library (pdf, legacy .doc, images, zip)
     * return '' and are surfaced to the AI as a reference link instead.
     */
    private function extract_text_from_file(string $path, string $ext): string {
        if (!is_readable($path)) {
            return '';
        }
        switch ($ext) {
            case 'txt': case 'text': case 'log':
            case 'md': case 'markdown':
            case 'csv': case 'tsv':
            case 'json': case 'xml':
                return $this->collapse_ws($this->read_text_file($path));
            case 'html': case 'htm':
                return $this->extract_html($path);
            case 'rtf':
                return $this->extract_rtf($path);
            case 'docx':
                return $this->extract_zip_xml($path, ['word/document.xml'], ['w:p', 'w:br', 'w:tab']);
            case 'pptx':
                return $this->extract_pptx($path);
            case 'xlsx':
                return $this->extract_xlsx($path);
            case 'odt': case 'ods': case 'odp':
                return $this->extract_zip_xml($path, ['content.xml'], ['text:p', 'text:line-break', 'text:tab']);
            default:
                return '';
        }
    }

    /** Read a (capped) slice of a text file and normalise it to UTF-8. */
    private function read_text_file(string $path): string {
        $raw = @file_get_contents($path, false, null, 0, 2000000);
        return $this->to_utf8((string) $raw);
    }

    /** Coerce arbitrary bytes to clean UTF-8 and strip control characters. */
    private function to_utf8(string $s): string {
        if ($s === '') { return ''; }
        if (function_exists('mb_detect_encoding')) {
            $enc = mb_detect_encoding($s, ['UTF-8', 'Windows-1252', 'ISO-8859-1'], true);
            if ($enc && $enc !== 'UTF-8' && function_exists('mb_convert_encoding')) {
                $s = mb_convert_encoding($s, 'UTF-8', $enc);
            }
        }
        // Keep tab/newline, drop other control chars and any invalid UTF-8.
        $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $s);
        if ($s === null) {
            // preg failed on invalid UTF-8 — fall back to a byte-safe strip.
            $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', (string) $s);
        }
        return (string) $s;
    }

    /** Collapse runs of whitespace/blank lines so the excerpt reads cleanly. */
    private function collapse_ws(string $s): string {
        $s = str_replace(["\r\n", "\r"], "\n", $s);
        $s = preg_replace('/[ \t]+/', ' ', $s);
        $s = preg_replace('/\n{3,}/', "\n\n", $s);
        $s = preg_replace('/[ \t]+\n/', "\n", $s);
        return trim($this->to_utf8((string) $s));
    }

    /** Strip an HTML document down to readable text. */
    private function extract_html(string $path): string {
        $raw = $this->read_text_file($path);
        if ($raw === '') { return ''; }
        $raw = preg_replace('#<(script|style)\b[^>]*>.*?</\1>#is', ' ', $raw);
        $raw = preg_replace('#<br\s*/?>#i', "\n", $raw);
        $raw = preg_replace('#</(p|div|h[1-6]|li|tr)>#i', "\n", $raw);
        $text = wp_strip_all_tags((string) $raw);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return $this->collapse_ws($text);
    }

    /** Crude but dependency-free RTF text extraction. */
    private function extract_rtf(string $path): string {
        $raw = $this->read_text_file($path);
        if ($raw === '') { return ''; }
        // \'hh hex escapes, then control words, then group braces.
        $raw = preg_replace('/\\\\\x27[0-9a-fA-F]{2}/', '', $raw);
        $raw = preg_replace('/\\\\[a-zA-Z]+-?\d* ?/', ' ', $raw);
        $raw = str_replace(['{', '}'], '', $raw);
        return $this->collapse_ws($raw);
    }

    /**
     * Pull text out of an Office-Open-XML / OpenDocument file by reading the
     * named XML entries and turning the given block/break tags into newlines or
     * tabs before stripping the rest of the markup. Covers docx and odt/ods/odp.
     *
     * @param string   $path        Zip archive path.
     * @param string[] $entries     XML entries to read (in order).
     * @param string[] $break_tags  Tags converted to whitespace (paragraph/break/tab).
     */
    private function extract_zip_xml(string $path, array $entries, array $break_tags): string {
        if (!class_exists('ZipArchive')) { return ''; }
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) { return ''; }

        $out = '';
        foreach ($entries as $entry) {
            $xml = $zip->getFromName($entry);
            if ($xml === false) { continue; }
            $out .= $this->xml_block_to_text($xml, $break_tags) . "\n";
        }
        $zip->close();
        return $this->collapse_ws($out);
    }

    /** Convert known break tags to whitespace, then strip remaining XML markup. */
    private function xml_block_to_text(string $xml, array $break_tags): string {
        foreach ($break_tags as $tag) {
            $q = preg_quote($tag, '#');
            // Opening tag (with/without attributes) and self-closing variants.
            if (substr($tag, -3) === 'tab') {
                $xml = preg_replace('#<' . $q . '\b[^>]*/?>#', "\t", $xml);
            } else {
                $xml = preg_replace('#<' . $q . '\b[^>]*/?>#', "\n", $xml);
            }
        }
        $text = wp_strip_all_tags($xml);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_XML1, 'UTF-8');
        return $text;
    }

    /** Extract slide text from a .pptx by reading every ppt/slides/slideN.xml. */
    private function extract_pptx(string $path): string {
        if (!class_exists('ZipArchive')) { return ''; }
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) { return ''; }

        $slides = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if ($name && preg_match('#^ppt/slides/slide(\d+)\.xml$#', $name, $mm)) {
                $slides[(int) $mm[1]] = $name;
            }
        }
        ksort($slides);

        $out = '';
        foreach ($slides as $name) {
            $xml = $zip->getFromName($name);
            if ($xml === false) { continue; }
            $out .= $this->xml_block_to_text($xml, ['a:p', 'a:br']) . "\n";
        }
        $zip->close();
        return $this->collapse_ws($out);
    }

    /**
     * Extract the textual content of a .xlsx: the shared-strings table plus any
     * inline strings in each worksheet. This captures all human-readable text
     * (headers, labels, notes) without reconstructing the full grid — enough for
     * the AI to understand the sheet.
     */
    private function extract_xlsx(string $path): string {
        if (!class_exists('ZipArchive')) { return ''; }
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) { return ''; }

        $parts = [];
        $shared = $zip->getFromName('xl/sharedStrings.xml');
        if ($shared !== false) {
            $parts[] = $this->xml_t_values($shared);
        }
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if ($name && preg_match('#^xl/worksheets/sheet\d+\.xml$#', $name)) {
                $sx = $zip->getFromName($name);
                if ($sx !== false) {
                    $parts[] = $this->xml_t_values($sx);
                }
            }
        }
        $zip->close();
        return $this->collapse_ws(implode("\n", array_filter($parts)));
    }

    /** Collect the text inside every <t>…</t> node (shared strings / inline). */
    private function xml_t_values(string $xml): string {
        if (!preg_match_all('#<t\b[^>]*>(.*?)</t>#s', $xml, $mm)) {
            return '';
        }
        $vals = array_map(static function ($v) {
            return html_entity_decode($v, ENT_QUOTES | ENT_XML1, 'UTF-8');
        }, $mm[1]);
        return implode(' ', $vals);
    }
}
