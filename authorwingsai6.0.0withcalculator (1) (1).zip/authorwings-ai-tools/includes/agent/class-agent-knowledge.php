<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

/**
 * Knowledge grounding. When enabled on an agent, exposes a built-in `search_site`
 * tool the model can call to look things up in the site's own content (selected
 * post types), so answers are grounded in real pages/posts instead of guessed.
 * An optional pasted knowledge blurb is injected straight into the system prompt.
 */
final class Agent_Knowledge {

    const TOOL_NAME = 'search_site';

    /** The tool definition advertised to the model. */
    public static function tool_def(): array {
        return [
            'name'        => self::TOOL_NAME,
            'description' => 'Search this website\'s content (pages, posts, help articles) for information to answer the user. Returns the most relevant titles, excerpts and links. Use it whenever the user asks about this site, its services, pricing, policies or articles.',
            'parameters'  => [
                'type'       => 'object',
                'properties' => [
                    'query' => [
                        'type'        => 'string',
                        'description' => 'What to look for, in a few keywords.',
                    ],
                ],
                'required'             => ['query'],
                'additionalProperties' => false,
            ],
        ];
    }

    /**
     * Run the search and format the hits for the model.
     *
     * @param array    $args       Tool arguments ({query}).
     * @param string[] $post_types Post types to search.
     */
    public static function search(array $args, array $post_types): string {
        $query = trim((string) ($args['query'] ?? ''));
        if ($query === '') {
            return __('No search query was provided.', 'authorwings-ai-tools');
        }
        if (empty($post_types)) {
            $post_types = ['post', 'page'];
        }

        $q = new \WP_Query([
            'post_type'           => $post_types,
            'post_status'         => 'publish',
            's'                   => $query,
            'posts_per_page'      => (int) apply_filters('awg_agent_knowledge_limit', 5),
            'ignore_sticky_posts' => true,
            'no_found_rows'       => true,
        ]);

        if (!$q->have_posts()) {
            wp_reset_postdata();
            return sprintf(
                /* translators: %s: search query */
                __('No matching content was found on the site for "%s".', 'authorwings-ai-tools'),
                $query
            );
        }

        $max_chars = (int) apply_filters('awg_agent_knowledge_excerpt_chars', 600);
        $blocks = [];
        while ($q->have_posts()) {
            $q->the_post();
            $pid = get_the_ID();
            $title = get_the_title($pid);
            $url = get_permalink($pid);
            $body = wp_strip_all_tags((string) get_post_field('post_content', $pid));
            $body = trim(preg_replace('/\s+/', ' ', $body));
            if (function_exists('mb_substr') && mb_strlen($body) > $max_chars) {
                $body = mb_substr($body, 0, $max_chars) . '…';
            } elseif (strlen($body) > $max_chars) {
                $body = substr($body, 0, $max_chars) . '…';
            }
            $blocks[] = "### {$title}\nURL: {$url}\n{$body}";
        }
        wp_reset_postdata();

        return implode("\n\n", $blocks);
    }
}
