<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

/**
 * Dependency-free plain-text extraction for chat attachments. A self-contained
 * copy of the generator's proven extractor (txt/md/csv/html/json/xml + docx,
 * xlsx, pptx, odt/ods/odp, rtf), kept in the agent module so the chat upload
 * path never reaches into the core Ajax class. Formats that need a binary/library
 * (pdf, legacy .doc, images, zip) return '' and are surfaced as a reference line.
 */
final class Text_Extractor {

    /**
     * Hard whitelist of extensions the chat upload will accept. Documents are read
     * as text (below); images are passed to vision-capable models and video is
     * stored and referenced. Extraction returns '' for image/video formats.
     */
    public static function allowed_exts(): array {
        $exts = [
            'txt', 'text', 'md', 'markdown', 'rtf', 'pdf',
            'doc', 'docx', 'odt',
            'csv', 'tsv', 'xls', 'xlsx', 'ods',
            'ppt', 'pptx', 'odp',
            // html/htm excluded: an uploaded .html renders same-origin (stored
            // XSS). Allow via awg_agent_upload_allowed_exts only if sanitised.
            'json', 'xml', 'log',
            // Images (vision) and video (referenced).
            'png', 'jpg', 'jpeg', 'gif', 'webp',
            'mp4', 'webm', 'mov', 'm4v', 'ogv',
        ];
        return array_values(array_unique(array_map('strtolower',
            (array) apply_filters('awg_agent_upload_allowed_exts', $exts)
        )));
    }

    public static function extract(string $path, string $ext): string {
        if (!is_readable($path)) return '';
        switch ($ext) {
            case 'txt': case 'text': case 'log':
            case 'md': case 'markdown':
            case 'csv': case 'tsv':
            case 'json': case 'xml':
                return self::collapse_ws(self::read_text_file($path));
            case 'html': case 'htm':
                return self::extract_html($path);
            case 'rtf':
                return self::extract_rtf($path);
            case 'docx':
                return self::extract_zip_xml($path, ['word/document.xml'], ['w:p', 'w:br', 'w:tab']);
            case 'pptx':
                return self::extract_pptx($path);
            case 'xlsx':
                return self::extract_xlsx($path);
            case 'odt': case 'ods': case 'odp':
                return self::extract_zip_xml($path, ['content.xml'], ['text:p', 'text:line-break', 'text:tab']);
            default:
                return '';
        }
    }

    private static function read_text_file(string $path): string {
        $raw = @file_get_contents($path, false, null, 0, 2000000);
        return self::to_utf8((string) $raw);
    }

    private static function to_utf8(string $s): string {
        if ($s === '') return '';
        if (function_exists('mb_detect_encoding')) {
            $enc = mb_detect_encoding($s, ['UTF-8', 'Windows-1252', 'ISO-8859-1'], true);
            if ($enc && $enc !== 'UTF-8' && function_exists('mb_convert_encoding')) {
                $s = mb_convert_encoding($s, 'UTF-8', $enc);
            }
        }
        $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $s);
        if ($s === null) {
            $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', (string) $s);
        }
        return (string) $s;
    }

    private static function collapse_ws(string $s): string {
        $s = str_replace(["\r\n", "\r"], "\n", $s);
        $s = preg_replace('/[ \t]+/', ' ', $s);
        $s = preg_replace('/\n{3,}/', "\n\n", $s);
        $s = preg_replace('/[ \t]+\n/', "\n", $s);
        return trim(self::to_utf8((string) $s));
    }

    private static function extract_html(string $path): string {
        $raw = self::read_text_file($path);
        if ($raw === '') return '';
        $raw = preg_replace('#<(script|style)\b[^>]*>.*?</\1>#is', ' ', $raw);
        $raw = preg_replace('#<br\s*/?>#i', "\n", $raw);
        $raw = preg_replace('#</(p|div|h[1-6]|li|tr)>#i', "\n", $raw);
        $text = wp_strip_all_tags((string) $raw);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return self::collapse_ws($text);
    }

    private static function extract_rtf(string $path): string {
        $raw = self::read_text_file($path);
        if ($raw === '') return '';
        $raw = preg_replace('/\\\\\x27[0-9a-fA-F]{2}/', '', $raw);
        $raw = preg_replace('/\\\\[a-zA-Z]+-?\d* ?/', ' ', $raw);
        $raw = str_replace(['{', '}'], '', $raw);
        return self::collapse_ws($raw);
    }

    private static function extract_zip_xml(string $path, array $entries, array $break_tags): string {
        if (!class_exists('ZipArchive')) return '';
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) return '';
        $out = '';
        foreach ($entries as $entry) {
            $xml = $zip->getFromName($entry);
            if ($xml === false) continue;
            $out .= self::xml_block_to_text($xml, $break_tags) . "\n";
        }
        $zip->close();
        return self::collapse_ws($out);
    }

    private static function xml_block_to_text(string $xml, array $break_tags): string {
        foreach ($break_tags as $tag) {
            $q = preg_quote($tag, '#');
            if (substr($tag, -3) === 'tab') {
                $xml = preg_replace('#<' . $q . '\b[^>]*/?>#', "\t", $xml);
            } else {
                $xml = preg_replace('#<' . $q . '\b[^>]*/?>#', "\n", $xml);
            }
        }
        $text = wp_strip_all_tags($xml);
        return html_entity_decode($text, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }

    private static function extract_pptx(string $path): string {
        if (!class_exists('ZipArchive')) return '';
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) return '';
        $slides = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if ($name && preg_match('#^ppt/slides/slide(\d+)\.xml$#', $name, $mm)) {
                $slides[(int) $mm[1]] = $name;
            }
        }
        ksort($slides);
        $out = '';
        foreach ($slides as $name) {
            $xml = $zip->getFromName($name);
            if ($xml === false) continue;
            $out .= self::xml_block_to_text($xml, ['a:p', 'a:br']) . "\n";
        }
        $zip->close();
        return self::collapse_ws($out);
    }

    private static function extract_xlsx(string $path): string {
        if (!class_exists('ZipArchive')) return '';
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) return '';
        $parts = [];
        $shared = $zip->getFromName('xl/sharedStrings.xml');
        if ($shared !== false) $parts[] = self::xml_t_values($shared);
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if ($name && preg_match('#^xl/worksheets/sheet\d+\.xml$#', $name)) {
                $sx = $zip->getFromName($name);
                if ($sx !== false) $parts[] = self::xml_t_values($sx);
            }
        }
        $zip->close();
        return self::collapse_ws(implode("\n", array_filter($parts)));
    }

    private static function xml_t_values(string $xml): string {
        if (!preg_match_all('#<t\b[^>]*>(.*?)</t>#s', $xml, $mm)) return '';
        $vals = array_map(static function ($v) {
            return html_entity_decode($v, ENT_QUOTES | ENT_XML1, 'UTF-8');
        }, $mm[1]);
        return implode(' ', $vals);
    }
}
