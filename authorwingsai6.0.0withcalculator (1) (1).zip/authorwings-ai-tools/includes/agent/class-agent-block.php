<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

/**
 * "AuthorWings AI Agent" Gutenberg block — a thin dynamic block that renders an
 * agent by id. The agent CPT is not exposed to REST, so the editor's agent
 * dropdown is populated from a localised list rather than core entity records.
 */
final class Agent_Block {

    /** @var Agent_Renderer */
    private $renderer;

    public function __construct(Agent_Renderer $renderer) {
        $this->renderer = $renderer;
    }

    public function register(): void {
        wp_register_script(
            'awg-agent-block',
            plugins_url('assets/agent-block.js', AWG_AIG_FILE),
            ['wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n'],
            AWG_AIG_VERSION,
            true
        );

        $agents = get_posts([
            'post_type'      => Agent::CPT,
            'post_status'    => 'publish',
            'posts_per_page' => 200,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ]);
        $list = [];
        foreach ($agents as $a) {
            $list[] = ['id' => (int) $a->ID, 'title' => (string) get_the_title($a->ID)];
        }
        wp_localize_script('awg-agent-block', 'AWG_AGENT_BLOCK', ['agents' => $list]);
        wp_set_script_translations('awg-agent-block', 'authorwings-ai-tools', plugin_dir_path(AWG_AIG_FILE) . 'languages');

        register_block_type('awg/agent', [
            'editor_script'   => 'awg-agent-block',
            'render_callback' => [$this, 'render'],
            'attributes'      => [
                'agentId' => ['type' => 'number', 'default' => 0],
            ],
        ]);
    }

    public function render(array $attrs): string {
        $id = (int) ($attrs['agentId'] ?? 0);
        if ($id <= 0) {
            return '<div class="awg-agent awg-agent--empty">' . esc_html__('Select an agent.', 'authorwings-ai-tools') . '</div>';
        }
        return $this->renderer->render($id);
    }
}
