<?php
namespace AWG_AIG\Agent;

use AWG_AIG\Plugin;

if (!defined('ABSPATH')) { exit; }

/**
 * The Agent editor screen: a configuration metabox + save handler, plus a small
 * sidebar box with the ready-to-paste shortcode and usage stats.
 */
final class Agent_Metabox {

    public function register(): void {
        add_meta_box('awg_agent_config', __('Agent Configuration', 'authorwings-ai-tools'), [$this, 'render'], Agent::CPT, 'normal', 'high');
        add_meta_box('awg_agent_embed', __('Embed', 'authorwings-ai-tools'), [$this, 'render_embed'], Agent::CPT, 'side', 'default');
    }

    public function enqueue(string $hook): void {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || ($screen->post_type ?? '') !== Agent::CPT) return;
        if (!in_array($screen->base, ['post', 'post-new'], true)) return;
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_add_inline_script('wp-color-picker', 'jQuery(function($){$(".awg-agent-color").wpColorPicker();});');
    }

    public function render(\WP_Post $post): void {
        $m = Agent::get_meta($post->ID);
        $required_plan = sanitize_key((string) get_post_meta($post->ID, '_awg_mem_required_plan', true)) ?: 'free';
        wp_nonce_field('awg_agent_save', 'awg_agent_nonce');
        $k = '_awg_aig_agent';
        ?>
        <style>
            .awg-agent-grid{max-width:920px}
            .awg-agent-row{margin:0 0 18px}
            .awg-agent-row label.awg-agent-label{display:block;font-weight:600;margin-bottom:4px}
            .awg-agent-row .description{margin-top:4px}
            .awg-agent-tools{max-height:240px;overflow:auto;border:1px solid #dcdcde;border-radius:6px;padding:10px;background:#fff}
            .awg-agent-tools label{display:block;padding:3px 0}
            .awg-agent-cols{display:flex;gap:24px;flex-wrap:wrap}
            .awg-agent-cols>div{flex:1 1 200px}
        </style>
        <div class="awg-agent-grid">

            <div class="awg-agent-row">
                <label class="awg-agent-label" for="awg_agent_instructions"><?php esc_html_e('Instructions (system prompt)', 'authorwings-ai-tools'); ?></label>
                <textarea id="awg_agent_instructions" name="<?php echo esc_attr($k); ?>[instructions]" rows="6" style="width:100%"><?php echo esc_textarea($m['instructions']); ?></textarea>
                <p class="description"><?php esc_html_e('Defines the agent’s role, tone and rules. Shared Settings → Global Prompt is prepended unless you disable it below.', 'authorwings-ai-tools'); ?></p>
            </div>

            <div class="awg-agent-cols">
                <div class="awg-agent-row">
                    <label class="awg-agent-label" for="awg_agent_greeting"><?php esc_html_e('Greeting', 'authorwings-ai-tools'); ?></label>
                    <input type="text" id="awg_agent_greeting" name="<?php echo esc_attr($k); ?>[greeting]" value="<?php echo esc_attr($m['greeting']); ?>" style="width:100%" />
                    <p class="description"><?php esc_html_e('Shown as the assistant’s first message.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-agent-row">
                    <label class="awg-agent-label" for="awg_agent_placeholder"><?php esc_html_e('Input placeholder', 'authorwings-ai-tools'); ?></label>
                    <input type="text" id="awg_agent_placeholder" name="<?php echo esc_attr($k); ?>[placeholder]" value="<?php echo esc_attr($m['placeholder']); ?>" style="width:100%" />
                </div>
            </div>

            <div class="awg-agent-row">
                <label class="awg-agent-label" for="awg_agent_header_design"><?php esc_html_e('Header design', 'authorwings-ai-tools'); ?></label>
                <select id="awg_agent_header_design" name="<?php echo esc_attr($k); ?>[header_design]">
                    <option value="agent" <?php selected($m['header_design'], 'agent'); ?>><?php esc_html_e('Agent — chat-style avatar + name bar', 'authorwings-ai-tools'); ?></option>
                    <option value="branded" <?php selected($m['header_design'], 'branded'); ?>><?php esc_html_e('Branded — icon badge + centered title', 'authorwings-ai-tools'); ?></option>
                    <option value="plain" <?php selected($m['header_design'], 'plain'); ?>><?php esc_html_e('Plain — simple title', 'authorwings-ai-tools'); ?></option>
                    <option value="none" <?php selected($m['header_design'], 'none'); ?>><?php esc_html_e('None — bare chat (like Build Assistant)', 'authorwings-ai-tools'); ?></option>
                </select>
                <p class="description"><?php esc_html_e('How the header above the conversation looks. The agent’s title is used as the name/heading. Branded uses the global eyebrow label and accent colour.', 'authorwings-ai-tools'); ?></p>
            </div>

            <div class="awg-agent-cols">
                <div class="awg-agent-row">
                    <label class="awg-agent-label" for="awg_agent_header_icon"><?php esc_html_e('Header icon', 'authorwings-ai-tools'); ?></label>
                    <input type="text" id="awg_agent_header_icon" name="<?php echo esc_attr($k); ?>[header_icon]" value="<?php echo esc_attr($m['header_icon']); ?>" style="width:100%" placeholder="dashicons dashicons-format-chat" />
                    <p class="description"><?php printf(
                        /* translators: %s: link to the Dashicons reference */
                        esc_html__('Optional Dashicons class shown in the Agent avatar / Branded badge. Leave blank for the default. Browse classes at %s.', 'authorwings-ai-tools'),
                        '<a href="https://developer.wordpress.org/resource/dashicons/" target="_blank" rel="noopener noreferrer">developer.wordpress.org/resource/dashicons</a>'
                    ); ?></p>
                </div>
                <div class="awg-agent-row">
                    <label class="awg-agent-label" for="awg_agent_header_icon_position"><?php esc_html_e('Icon position', 'authorwings-ai-tools'); ?></label>
                    <select id="awg_agent_header_icon_position" name="<?php echo esc_attr($k); ?>[header_icon_position]">
                        <option value="top" <?php selected($m['header_icon_position'], 'top'); ?>><?php esc_html_e('Top (centered)', 'authorwings-ai-tools'); ?></option>
                        <option value="left" <?php selected($m['header_icon_position'], 'left'); ?>><?php esc_html_e('Left (before title)', 'authorwings-ai-tools'); ?></option>
                    </select>
                    <p class="description"><?php esc_html_e('Applies to the Branded header. The Agent avatar bar is always left-aligned.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>

            <div class="awg-agent-row">
                <label class="awg-agent-label" for="awg_agent_starters"><?php esc_html_e('Suggested prompts', 'authorwings-ai-tools'); ?></label>
                <textarea id="awg_agent_starters" name="<?php echo esc_attr($k); ?>[starters]" rows="3" style="width:100%" placeholder="<?php echo esc_attr__('One per line. Shown as clickable chips before the conversation starts.', 'authorwings-ai-tools'); ?>"><?php echo esc_textarea($m['starters']); ?></textarea>
            </div>

            <div class="awg-agent-cols">
                <div class="awg-agent-row">
                    <label class="awg-agent-label" for="awg_agent_model"><?php esc_html_e('Model', 'authorwings-ai-tools'); ?></label>
                    <input type="text" id="awg_agent_model" name="<?php echo esc_attr($k); ?>[model]" value="<?php echo esc_attr($m['model']); ?>" style="width:100%" placeholder="<?php echo esc_attr__('Leave blank to use the Settings default', 'authorwings-ai-tools'); ?>" />
                    <p class="description"><?php esc_html_e('OpenAI, Claude (claude-…) or DeepSeek (deepseek-…). Routing and API key follow the model id, like the generators.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-agent-row">
                    <label class="awg-agent-label" for="awg_agent_max_tokens"><?php esc_html_e('Max reply tokens', 'authorwings-ai-tools'); ?></label>
                    <input type="number" id="awg_agent_max_tokens" name="<?php echo esc_attr($k); ?>[max_tokens]" value="<?php echo esc_attr($m['max_tokens']); ?>" min="64" max="8000" step="1" style="width:120px" />
                </div>
            </div>

            <div class="awg-agent-row">
                <label class="awg-agent-label"><?php esc_html_e('Tools the agent can use', 'authorwings-ai-tools'); ?></label>
                <p class="description" style="margin-top:0"><?php esc_html_e('Pick existing generator templates. The agent can call them with details gathered from the conversation, then explain the result.', 'authorwings-ai-tools'); ?></p>
                <div class="awg-agent-tools">
                    <?php
                    $templates = get_posts([
                        'post_type'      => Plugin::CPT,
                        'post_status'    => 'publish',
                        'posts_per_page' => 200,
                        'orderby'        => 'title',
                        'order'          => 'ASC',
                    ]);
                    if (empty($templates)) {
                        echo '<em>' . esc_html__('No published templates yet. Create some under AuthorWings AI → Templates.', 'authorwings-ai-tools') . '</em>';
                    } else {
                        foreach ($templates as $t) {
                            $checked = in_array($t->ID, $m['tool_ids'], true);
                            printf(
                                '<label><input type="checkbox" name="%1$s[tool_ids][]" value="%2$d" %3$s /> %4$s <span style="color:#787c82">#%2$d</span></label>',
                                esc_attr($k),
                                (int) $t->ID,
                                checked($checked, true, false),
                                esc_html(get_the_title($t->ID))
                            );
                        }
                    }
                    ?>
                </div>
            </div>

            <div class="awg-agent-cols">
                <div class="awg-agent-row">
                    <label class="awg-agent-label" for="awg_agent_guests"><?php esc_html_e('Who can use it', 'authorwings-ai-tools'); ?></label>
                    <select id="awg_agent_guests" name="<?php echo esc_attr($k); ?>[allow_guests]">
                        <option value="-1" <?php selected($m['allow_guests'], -1); ?>><?php esc_html_e('Inherit global setting', 'authorwings-ai-tools'); ?></option>
                        <option value="1" <?php selected($m['allow_guests'], 1); ?>><?php esc_html_e('Allow guests', 'authorwings-ai-tools'); ?></option>
                        <option value="0" <?php selected($m['allow_guests'], 0); ?>><?php esc_html_e('Login required', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
                <div class="awg-agent-row">
                    <label class="awg-agent-label" for="awg_agent_required_plan"><?php esc_html_e('Required plan', 'authorwings-ai-tools'); ?></label>
                    <select id="awg_agent_required_plan" name="awg_agent_required_plan">
                        <?php foreach (['free' => 'Free', 'basic' => 'Basic', 'pro' => 'Pro', 'publisher' => 'Publisher'] as $slug => $label) : ?>
                            <option value="<?php echo esc_attr($slug); ?>" <?php selected($required_plan, $slug); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php esc_html_e('Minimum membership tier (when the membership engine is active).', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-agent-row">
                    <label class="awg-agent-label" for="awg_agent_rate"><?php esc_html_e('Rate limit (per min/IP)', 'authorwings-ai-tools'); ?></label>
                    <input type="number" id="awg_agent_rate" name="<?php echo esc_attr($k); ?>[rate_per_min]" value="<?php echo esc_attr($m['rate_per_min']); ?>" min="0" step="1" style="width:120px" />
                    <p class="description"><?php esc_html_e('0 = inherit the global limit.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>

            <div class="awg-agent-cols">
                <div class="awg-agent-row">
                    <label class="awg-agent-label" for="awg_agent_accent"><?php esc_html_e('Accent color', 'authorwings-ai-tools'); ?></label>
                    <input type="text" class="awg-agent-color" id="awg_agent_accent" name="<?php echo esc_attr($k); ?>[accent_color]" value="<?php echo esc_attr($m['accent_color'] !== '' ? '#' . $m['accent_color'] : ''); ?>" data-default-color="#c8794f" />
                    <p class="description"><?php esc_html_e('Leave blank to use the brand accent.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-agent-row">
                    <label class="awg-agent-label"><?php esc_html_e('Options', 'authorwings-ai-tools'); ?></label>
                    <label style="display:block"><input type="checkbox" name="<?php echo esc_attr($k); ?>[apply_global_prompt]" value="1" <?php checked($m['apply_global_prompt'], 1); ?> /> <?php esc_html_e('Apply the global system prompt', 'authorwings-ai-tools'); ?></label>
                    <label style="display:block"><input type="checkbox" name="<?php echo esc_attr($k); ?>[debug_admin]" value="1" <?php checked($m['debug_admin'], 1); ?> /> <?php esc_html_e('Show raw API errors to admins', 'authorwings-ai-tools'); ?></label>
                </div>
            </div>

            <hr />

            <div class="awg-agent-cols">
                <div class="awg-agent-row">
                    <label class="awg-agent-label"><?php esc_html_e('File attachments', 'authorwings-ai-tools'); ?></label>
                    <label style="display:block"><input type="checkbox" name="<?php echo esc_attr($k); ?>[allow_uploads]" value="1" <?php checked($m['allow_uploads'], 1); ?> /> <?php esc_html_e('Let users attach a document in the chat', 'authorwings-ai-tools'); ?></label>
                    <p class="description"><?php esc_html_e('Text is extracted (txt, md, csv, html, docx, xlsx, pptx, odt…) and given to the assistant. PDFs/images are passed as a reference link.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-agent-row">
                    <label class="awg-agent-label" for="awg_agent_upload_mb"><?php esc_html_e('Max file size (MB)', 'authorwings-ai-tools'); ?></label>
                    <input type="number" id="awg_agent_upload_mb" name="<?php echo esc_attr($k); ?>[upload_max_mb]" value="<?php echo esc_attr($m['upload_max_mb']); ?>" min="1" max="50" step="1" style="width:120px" />
                </div>
            </div>

            <div class="awg-agent-row">
                <label class="awg-agent-label"><?php esc_html_e('Knowledge grounding', 'authorwings-ai-tools'); ?></label>
                <label style="display:block;margin-bottom:8px"><input type="checkbox" name="<?php echo esc_attr($k); ?>[knowledge_enabled]" value="1" <?php checked($m['knowledge_enabled'], 1); ?> /> <?php esc_html_e('Let the assistant search this site’s content to answer questions', 'authorwings-ai-tools'); ?></label>
                <?php
                $selected_types = (array) $m['knowledge_post_types'];
                $pts = get_post_types(['public' => true], 'objects');
                echo '<div style="display:flex;flex-wrap:wrap;gap:14px;margin-bottom:8px">';
                foreach ($pts as $pt) {
                    if (in_array($pt->name, ['attachment'], true)) continue;
                    printf(
                        '<label><input type="checkbox" name="%1$s[knowledge_post_types][]" value="%2$s" %3$s /> %4$s</label>',
                        esc_attr($k),
                        esc_attr($pt->name),
                        checked(in_array($pt->name, $selected_types, true), true, false),
                        esc_html($pt->labels->name)
                    );
                }
                echo '</div>';
                ?>
                <textarea name="<?php echo esc_attr($k); ?>[knowledge_text]" rows="4" style="width:100%" placeholder="<?php echo esc_attr__('Optional: paste key facts (hours, pricing summary, policies, brand voice). Sent with every conversation.', 'authorwings-ai-tools'); ?>"><?php echo esc_textarea($m['knowledge_text']); ?></textarea>
            </div>

            <?php
            $kn_default  = Agent_Runtime::default_agent_knowledge_prefix();
            $nudge_default = Agent_Runtime::default_agent_tools_nudge();
            $full_preview = Agent_Runtime::build_system_prompt_public($m, Agent_Runtime::settings(), $post->ID);
            ?>
            <div class="awg-agent-row">
                <details>
                    <summary style="cursor:pointer;font-weight:600"><?php esc_html_e('Advanced: system prompt extras', 'authorwings-ai-tools'); ?></summary>
                    <p class="description" style="margin-top:8px"><?php esc_html_e('The runtime adds two short lines to the system prompt automatically. You can override either here — leave blank to use the built-in default.', 'authorwings-ai-tools'); ?></p>

                    <p style="margin-bottom:4px"><strong><?php esc_html_e('Knowledge prefix', 'authorwings-ai-tools'); ?></strong> — <?php esc_html_e('the line shown above your pasted Knowledge facts.', 'authorwings-ai-tools'); ?></p>
                    <textarea name="<?php echo esc_attr($k); ?>[knowledge_prefix]" rows="2" style="width:100%" placeholder="<?php echo esc_attr($kn_default); ?>"><?php echo esc_textarea($m['knowledge_prefix']); ?></textarea>

                    <p style="margin:12px 0 4px"><strong><?php esc_html_e('Tool-use nudge', 'authorwings-ai-tools'); ?></strong> — <?php esc_html_e('added only when the agent has tools or knowledge search enabled.', 'authorwings-ai-tools'); ?></p>
                    <textarea name="<?php echo esc_attr($k); ?>[tools_nudge]" rows="4" style="width:100%" placeholder="<?php echo esc_attr($nudge_default); ?>"><?php echo esc_textarea($m['tools_nudge']); ?></textarea>
                </details>
            </div>

            <div class="awg-agent-row">
                <details>
                    <summary style="cursor:pointer;font-weight:600"><?php esc_html_e('Preview the full system prompt (read-only)', 'authorwings-ai-tools'); ?></summary>
                    <textarea rows="12" class="code" readonly style="width:100%;margin-top:8px;background:#f6f7f7"><?php echo esc_textarea($full_preview); ?></textarea>
                    <p class="description"><?php esc_html_e('The global prompt (if applied), your instructions, the knowledge block and the tool-use nudge — assembled exactly as this agent receives them. Save the agent to refresh.', 'authorwings-ai-tools'); ?></p>
                </details>
            </div>

        </div>
        <?php
    }

    public function render_embed(\WP_Post $post): void {
        $count = (int) get_post_meta($post->ID, '_awg_aig_usage_count', true);
        $last  = (string) get_post_meta($post->ID, '_awg_aig_last_generated', true);
        ?>
        <p><strong><?php esc_html_e('Shortcode', 'authorwings-ai-tools'); ?></strong></p>
        <input type="text" readonly onclick="this.select()" value="<?php echo esc_attr('[awg_agent id="' . (int) $post->ID . '"]'); ?>" style="width:100%" />
        <p class="description"><?php esc_html_e('Paste into any page or post, or use the AuthorWings AI Agent block.', 'authorwings-ai-tools'); ?></p>
        <hr />
        <p><?php printf(
            /* translators: %d: number of conversation turns */
            esc_html__('Turns: %d', 'authorwings-ai-tools'),
            $count
        ); ?></p>
        <?php if ($last !== '') : ?>
            <p><?php printf(
                /* translators: %s: date/time */
                esc_html__('Last used: %s', 'authorwings-ai-tools'),
                esc_html($last)
            ); ?></p>
        <?php endif; ?>
        <?php
    }

    public function save(int $post_id, \WP_Post $post): void {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (($post->post_type ?? '') !== Agent::CPT) return;
        if (!isset($_POST['awg_agent_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['awg_agent_nonce'])), 'awg_agent_save')) return;
        if (!current_user_can('manage_options')) return;

        $in = isset($_POST['_awg_aig_agent']) && is_array($_POST['_awg_aig_agent']) ? wp_unslash($_POST['_awg_aig_agent']) : [];

        $clean = [
            'instructions'        => sanitize_textarea_field((string) ($in['instructions'] ?? '')),
            'greeting'            => sanitize_text_field((string) ($in['greeting'] ?? '')),
            'placeholder'         => sanitize_text_field((string) ($in['placeholder'] ?? '')),
            'header_design'       => in_array(($in['header_design'] ?? 'agent'), ['agent', 'none', 'branded', 'plain'], true) ? (string) $in['header_design'] : 'agent',
            'header_icon'         => Agent::sanitize_icon_class((string) ($in['header_icon'] ?? '')),
            'header_icon_position' => in_array(($in['header_icon_position'] ?? 'top'), ['top', 'left'], true) ? (string) $in['header_icon_position'] : 'top',
            'starters'            => sanitize_textarea_field((string) ($in['starters'] ?? '')),
            'model'               => sanitize_text_field((string) ($in['model'] ?? '')),
            'max_tokens'          => max(64, min(8000, (int) ($in['max_tokens'] ?? 1200))),
            'allow_guests'        => in_array((int) ($in['allow_guests'] ?? -1), [-1, 0, 1], true) ? (int) $in['allow_guests'] : -1,
            'rate_per_min'        => max(0, (int) ($in['rate_per_min'] ?? 0)),
            'apply_global_prompt' => !empty($in['apply_global_prompt']) ? 1 : 0,
            'debug_admin'         => !empty($in['debug_admin']) ? 1 : 0,
            'allow_uploads'       => !empty($in['allow_uploads']) ? 1 : 0,
            'upload_max_mb'       => max(1, min(50, (int) ($in['upload_max_mb'] ?? 10))),
            'knowledge_enabled'   => !empty($in['knowledge_enabled']) ? 1 : 0,
            'knowledge_text'      => sanitize_textarea_field((string) ($in['knowledge_text'] ?? '')),
            'knowledge_prefix'    => trim(sanitize_textarea_field((string) ($in['knowledge_prefix'] ?? ''))),
            'tools_nudge'         => trim(sanitize_textarea_field((string) ($in['tools_nudge'] ?? ''))),
        ];

        $accent = ltrim(strtolower(trim((string) ($in['accent_color'] ?? ''))), '#');
        $clean['accent_color'] = preg_match('/^[0-9a-f]{6}$/', $accent) ? $accent : '';

        $tool_ids = isset($in['tool_ids']) && is_array($in['tool_ids']) ? $in['tool_ids'] : [];
        $clean['tool_ids'] = array_values(array_unique(array_filter(array_map('intval', $tool_ids))));

        $kpts = isset($in['knowledge_post_types']) && is_array($in['knowledge_post_types']) ? $in['knowledge_post_types'] : [];
        $kpts = array_values(array_filter(array_map('sanitize_key', $kpts)));
        $clean['knowledge_post_types'] = !empty($kpts) ? $kpts : ['post', 'page'];

        update_post_meta($post_id, Agent::META_KEY, $clean);

        $plan = sanitize_key((string) ($_POST['awg_agent_required_plan'] ?? 'free'));
        if (!in_array($plan, ['free', 'basic', 'pro', 'publisher'], true)) $plan = 'free';
        update_post_meta($post_id, '_awg_mem_required_plan', $plan);
    }
}
