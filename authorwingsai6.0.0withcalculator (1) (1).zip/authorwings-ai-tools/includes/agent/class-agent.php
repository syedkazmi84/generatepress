<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

/**
 * Agent custom post type + meta accessor.
 *
 * An "Agent" is a conversational, optionally tool-using assistant. It reuses the
 * plugin's existing provider layer (OpenAI / Anthropic / DeepSeek keys in
 * Settings) and the existing membership gate (`awg_aig_can_generate` /
 * `awg_aig_generated`, `_awg_mem_required_plan` meta), so plans, usage limits and
 * Stripe billing apply to agent conversations with zero extra wiring.
 *
 * The agent's "tools" are the site's own generator templates: the model can call
 * a template (a Title Generator, a Blurb Critiquer, …) with structured arguments,
 * the runtime runs it, and the result is fed back so the agent can compose a
 * grounded reply. That single mechanism delivers a chat agent, a multi-step
 * tool-using agent, and a new tool type in one feature.
 */
final class Agent {

    const CPT      = 'awg_ai_agent';
    const META_KEY = '_awg_aig_agent';

    public function register(): void {
        register_post_type(self::CPT, [
            'labels' => [
                'name'          => __('AuthorWings AI Agents', 'authorwings-ai-tools'),
                'singular_name' => __('AuthorWings AI Agent', 'authorwings-ai-tools'),
                'add_new_item'  => __('Add New Agent', 'authorwings-ai-tools'),
                'edit_item'     => __('Edit Agent', 'authorwings-ai-tools'),
                'new_item'      => __('New Agent', 'authorwings-ai-tools'),
                'menu_name'     => __('AI Agents', 'authorwings-ai-tools'),
            ],
            'public'       => false,
            'show_ui'      => true,
            'show_in_rest' => false,
            'show_in_menu' => false,
            'supports'     => ['title'],
            // Mirror the template CPT: agent CRUD is admin-only, because an agent
            // picks the model and can call paid tools.
            'capabilities' => [
                'edit_post'              => 'manage_options',
                'read_post'              => 'manage_options',
                'delete_post'            => 'manage_options',
                'edit_posts'             => 'manage_options',
                'edit_others_posts'      => 'manage_options',
                'publish_posts'          => 'manage_options',
                'read_private_posts'     => 'manage_options',
                'delete_posts'           => 'manage_options',
                'delete_private_posts'   => 'manage_options',
                'delete_published_posts' => 'manage_options',
                'delete_others_posts'    => 'manage_options',
                'edit_private_posts'     => 'manage_options',
                'edit_published_posts'   => 'manage_options',
                'create_posts'           => 'manage_options',
            ],
        ]);
    }

    /** Factory defaults for a brand-new / partially-saved agent. */
    public static function defaults(): array {
        return [
            'instructions' => "You are a friendly, concise assistant for an author-services website. "
                . "Help visitors with their writing and publishing questions. When a request matches one "
                . "of your available tools, gather the details the tool needs from the conversation and "
                . "call it, then explain the result in your own words. Never invent tool output.",
            'greeting'     => __('Hi! How can I help with your writing today?', 'authorwings-ai-tools'),
            'placeholder'  => __('Type your message…', 'authorwings-ai-tools'),
            // Front-end header design: agent (avatar + name bar) | none (bare chat,
            // like the Build Assistant) | branded (icon badge + centered title) |
            // plain (simple title).
            'header_design' => 'agent',
            // Optional Dashicons class for the header icon (e.g. "dashicons
            // dashicons-format-chat"); blank uses the default avatar/spark.
            'header_icon'   => '',
            // Icon placement for the branded header: top (centered) | left.
            'header_icon_position' => 'top',
            'starters'     => '',
            'model'        => '',
            'max_tokens'   => 1200,
            'tool_ids'     => [],
            'allow_guests' => -1,   // -1 inherit global | 0 login required | 1 allow
            'rate_per_min' => 0,    // 0 = inherit global
            'accent_color' => '',   // bare hex, '' = inherit brand accent
            'apply_global_prompt' => 1,
            'debug_admin'  => 0,
            // File attachments in chat.
            'allow_uploads'  => 1,
            'upload_max_mb'  => 10,
            // Knowledge grounding: let the agent answer from the site's content.
            'knowledge_enabled'    => 0,
            'knowledge_post_types' => ['post', 'page'],
            'knowledge_text'       => '',
            // v5.7.9: editable overrides for the two system lines the runtime adds
            // automatically. Blank = built-in default (see Agent_Runtime).
            'knowledge_prefix'     => '',
            'tools_nudge'          => '',
        ];
    }

    /** Read + normalise an agent's saved configuration. */
    public static function get_meta(int $post_id): array {
        $raw = get_post_meta($post_id, self::META_KEY, true);
        if (!is_array($raw)) $raw = [];
        $m = array_merge(self::defaults(), $raw);

        $m['instructions'] = (string) $m['instructions'];
        $m['greeting']     = (string) $m['greeting'];
        $m['placeholder']  = (string) $m['placeholder'];
        $m['header_design'] = in_array(($m['header_design'] ?? 'agent'), ['agent', 'none', 'branded', 'plain'], true) ? $m['header_design'] : 'agent';
        $m['header_icon']   = self::sanitize_icon_class((string) ($m['header_icon'] ?? ''));
        $m['header_icon_position'] = in_array(($m['header_icon_position'] ?? 'top'), ['top', 'left'], true) ? $m['header_icon_position'] : 'top';
        $m['starters']     = (string) $m['starters'];
        $m['model']        = trim((string) $m['model']);
        $m['max_tokens']   = max(64, min(8000, (int) $m['max_tokens']));
        $m['allow_guests'] = in_array((int) $m['allow_guests'], [-1, 0, 1], true) ? (int) $m['allow_guests'] : -1;
        $m['rate_per_min'] = max(0, (int) $m['rate_per_min']);
        $m['apply_global_prompt'] = !empty($m['apply_global_prompt']) ? 1 : 0;
        $m['debug_admin']  = !empty($m['debug_admin']) ? 1 : 0;

        $accent = ltrim(strtolower(trim((string) $m['accent_color'])), '#');
        $m['accent_color'] = preg_match('/^[0-9a-f]{6}$/', $accent) ? $accent : '';

        $ids = is_array($m['tool_ids']) ? $m['tool_ids'] : [];
        $m['tool_ids'] = array_values(array_unique(array_filter(array_map('intval', $ids))));

        $m['allow_uploads'] = !empty($m['allow_uploads']) ? 1 : 0;
        $m['upload_max_mb'] = max(1, min(50, (int) $m['upload_max_mb']));

        $m['knowledge_enabled'] = !empty($m['knowledge_enabled']) ? 1 : 0;
        $pts = is_array($m['knowledge_post_types']) ? $m['knowledge_post_types'] : [];
        $m['knowledge_post_types'] = array_values(array_filter(array_map('sanitize_key', $pts)));
        if (empty($m['knowledge_post_types'])) {
            $m['knowledge_post_types'] = ['post', 'page'];
        }
        $m['knowledge_text'] = (string) $m['knowledge_text'];
        $m['knowledge_prefix'] = (string) ($m['knowledge_prefix'] ?? '');
        $m['tools_nudge']      = (string) ($m['tools_nudge'] ?? '');

        return $m;
    }

    /** Normalise a space-separated icon class string (e.g. a Dashicons class). */
    public static function sanitize_icon_class(string $value): string {
        $value = trim($value);
        if ($value === '') {
            return '';
        }
        $parts = preg_split('/\s+/', $value) ?: [];
        $parts = array_map('sanitize_html_class', array_filter($parts, static function ($p) {
            return is_string($p) && $p !== '';
        }));
        return trim(implode(' ', $parts));
    }

    /** Parse the newline/comma list of suggested starter prompts. */
    public static function starters(string $raw): array {
        $parts = preg_split('/[\r\n]+/', $raw) ?: [];
        $parts = array_map('trim', $parts);
        $parts = array_values(array_filter($parts, static function ($p) { return $p !== ''; }));
        return array_slice($parts, 0, 6);
    }
}
