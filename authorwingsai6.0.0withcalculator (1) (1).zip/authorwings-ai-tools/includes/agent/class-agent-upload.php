<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

/**
 * Chat file uploads. A visitor drops a document into the conversation; it is
 * validated, stored in the same script-protected uploads sub-directory the
 * generators use, its text extracted, and a one-time token returned. The next
 * chat turn submits the token(s); the runtime swaps each back for the extracted
 * text so the agent can read the document.
 */
final class Agent_Upload {

    const TOKEN_PREFIX = 'awg_agent_up_';

    public function register(): void {
        add_action('wp_ajax_awg_agent_upload', [$this, 'upload']);
        add_action('wp_ajax_nopriv_awg_agent_upload', [$this, 'upload']);
        // Admin Build Assistant uploads (agent_id = 0, admin nonce, no per-agent meta).
        add_action('wp_ajax_awg_agent_admin_upload', [$this, 'admin_upload']);
    }

    /** Image formats accepted by the chat and sent to vision-capable models. */
    public static function image_exts(): array {
        return ['png', 'jpg', 'jpeg', 'gif', 'webp'];
    }

    /** Video formats accepted for storage (referenced, not watched by the model). */
    public static function video_exts(): array {
        return ['mp4', 'webm', 'mov', 'm4v', 'ogv'];
    }

    public function upload(): void {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash((string) $_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'awg_agent_front')) {
            wp_send_json_error(['message' => __('Invalid request.', 'authorwings-ai-tools')], 403);
        }

        $agent_id = (int) ($_POST['agent_id'] ?? 0);
        $post = $agent_id > 0 ? get_post($agent_id) : null;
        if (!$post || $post->post_type !== Agent::CPT) {
            wp_send_json_error(['message' => __('Agent not found.', 'authorwings-ai-tools')], 404);
        }

        $m = Agent::get_meta($agent_id);
        $s = Agent_Runtime::settings();

        if (empty($m['allow_uploads'])) {
            wp_send_json_error(['message' => __('This assistant does not accept files.', 'authorwings-ai-tools')], 403);
        }

        // Guest policy + rate limit — same gates as a chat turn.
        $allow = ((int) $m['allow_guests'] === -1) ? (int) ($s['allow_guests'] ?? 1) : (int) $m['allow_guests'];
        if (!$allow && !is_user_logged_in()) {
            wp_send_json_error(['message' => __('Please log in to upload a file.', 'authorwings-ai-tools')], 403);
        }
        if (!Agent_Gate::rate_ok($agent_id, (int) $m['rate_per_min'], (int) ($s['global_rate_per_min'] ?? 10))) {
            wp_send_json_error(['message' => __('Too many requests. Try again in a minute.', 'authorwings-ai-tools')], 429);
        }

        $max_mb = max(1, min(50, (int) $m['upload_max_mb']));
        $this->handle_file($max_mb);
    }

    /**
     * Build Assistant upload endpoint. There is no agent post here, so gating is
     * a straight capability + admin-nonce check; storage and extraction are shared
     * with the public path.
     */
    public function admin_upload(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'authorwings-ai-tools')], 403);
        }
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash((string) $_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'awg_agent_admin')) {
            wp_send_json_error(['message' => __('Invalid request.', 'authorwings-ai-tools')], 403);
        }
        $this->handle_file(20);
    }

    /**
     * Validate the uploaded $_FILES['file'], store it in the protected uploads
     * sub-directory, extract text (documents) or note the kind (image/video),
     * and return a one-time token. Shared by the public and admin endpoints.
     */
    private function handle_file(int $max_mb): void {
        if (empty($_FILES['file']) || !is_array($_FILES['file']) || (int) ($_FILES['file']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            wp_send_json_error(['message' => __('No file received.', 'authorwings-ai-tools')], 400);
        }
        $file = $_FILES['file'];
        if ((int) $file['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(['message' => $this->error_message((int) $file['error'])], 400);
        }

        $max_bytes = $max_mb * 1024 * 1024;
        if ((int) $file['size'] <= 0) {
            wp_send_json_error(['message' => __('The file appears to be empty.', 'authorwings-ai-tools')], 400);
        }
        if ((int) $file['size'] > $max_bytes) {
            wp_send_json_error(['message' => sprintf(
                /* translators: %d: max size in MB */
                __('File is too large. Max %d MB.', 'authorwings-ai-tools'),
                $max_mb
            )], 400);
        }

        $orig_name = (string) $file['name'];
        $ext = strtolower((string) pathinfo($orig_name, PATHINFO_EXTENSION));
        $allowed = Text_Extractor::allowed_exts();
        if ($ext === '' || !in_array($ext, $allowed, true)) {
            wp_send_json_error(['message' => sprintf(
                /* translators: %s: list of allowed extensions */
                __('File type not allowed. Accepted: %s', 'authorwings-ai-tools'),
                strtoupper(implode(', ', $allowed))
            )], 400);
        }

        $up = wp_upload_dir();
        if (!empty($up['error'])) {
            wp_send_json_error(['message' => __('Upload directory is not writable.', 'authorwings-ai-tools')], 500);
        }
        $dir = trailingslashit($up['basedir']) . 'awg-ai-uploads';
        if (!wp_mkdir_p($dir)) {
            wp_send_json_error(['message' => __('Could not create the upload directory.', 'authorwings-ai-tools')], 500);
        }
        $this->protect_dir($dir);

        $base = sanitize_file_name((string) pathinfo($orig_name, PATHINFO_FILENAME));
        if ($base === '') $base = 'upload';
        $base = substr($base, 0, 80);
        $stored_name = wp_generate_password(8, false) . '-' . $base . '.' . $ext;
        $dest = trailingslashit($dir) . $stored_name;

        $moved = false;
        if (is_uploaded_file($file['tmp_name'])) {
            $moved = @move_uploaded_file($file['tmp_name'], $dest);
        }
        if (!$moved) {
            wp_send_json_error(['message' => __('Upload failed. Please try again.', 'authorwings-ai-tools')], 500);
        }
        @chmod($dest, 0644);

        $stored_url = trailingslashit($up['baseurl']) . 'awg-ai-uploads/' . $stored_name;

        $kind = in_array($ext, self::image_exts(), true)
            ? 'image'
            : (in_array($ext, self::video_exts(), true) ? 'video' : 'doc');

        // Documents are read as text; images/video carry no extractable text.
        $extracted = ($kind === 'doc') ? Text_Extractor::extract($dest, $ext) : '';
        $max_chars = (int) apply_filters('awg_agent_upload_max_chars', 30000);
        $truncated = false;
        if ($extracted !== '' && strlen($extracted) > $max_chars) {
            $extracted = substr($extracted, 0, $max_chars);
            $truncated = true;
        }

        // Base64-encode images now, while the file is freshly written and
        // certainly readable, so vision delivery never depends on a later
        // disk re-read (which can fail across hosts/permissions).
        $img_data = '';
        if ($kind === 'image') {
            $max_img = (int) apply_filters('awg_agent_image_max_bytes', 6 * 1024 * 1024);
            if ((int) $file['size'] <= $max_img) {
                $raw = @file_get_contents($dest);
                if ($raw !== false && $raw !== '') {
                    $img_data = base64_encode($raw);
                }
            }
        }

        $token = wp_generate_password(24, false);
        set_transient(self::TOKEN_PREFIX . $token, [
            'name'      => sanitize_file_name($orig_name),
            'ext'       => $ext,
            'kind'      => $kind,
            'mime'      => self::mime_for_ext($ext),
            'url'       => $stored_url,
            'path'      => $dest,
            'text'      => $extracted,
            'data'      => $img_data,
            'truncated' => $truncated,
            'user'      => get_current_user_id(),
            'time'      => time(),
        ], HOUR_IN_SECONDS);

        wp_send_json_success([
            'token'    => $token,
            'name'     => sanitize_file_name($orig_name),
            'ext'      => $ext,
            'kind'     => $kind,
            'has_text' => $extracted !== '',
            'viewable' => ($kind === 'image' && $img_data !== ''),
        ]);
    }

    /**
     * Resolve a submitted token back to the text the agent should read, or a
     * reference line when no text could be extracted. Unknown/expired tokens
     * resolve to ''.
     */
    public static function resolve(string $token): string {
        $token = preg_replace('/[^A-Za-z0-9]/', '', $token);
        if ($token === '') return '';
        $payload = get_transient(self::TOKEN_PREFIX . $token);
        if (!is_array($payload)) return '';

        $name = sanitize_text_field((string) ($payload['name'] ?? 'file'));
        $url  = esc_url_raw((string) ($payload['url'] ?? ''));
        $text = (string) ($payload['text'] ?? '');

        if ($text !== '') {
            $text = sanitize_textarea_field($text);
            $out  = sprintf(
                /* translators: %s: uploaded file name */
                __('[Uploaded file "%s" — extracted text follows]', 'authorwings-ai-tools'),
                $name
            ) . "\n" . $text;
            if (!empty($payload['truncated'])) {
                $out .= "\n" . __('[Note: the file was long and the text above was truncated.]', 'authorwings-ai-tools');
            }
            return $out;
        }

        return sprintf(
            /* translators: 1: file name, 2: URL */
            __('[Uploaded file "%1$s" available at %2$s — text could not be extracted automatically.]', 'authorwings-ai-tools'),
            $name,
            $url
        );
    }

    /**
     * Resolve a list of submitted tokens into the two channels a chat turn needs:
     * a block of reference text (documents + a note for video) folded into the
     * user's message, and base64 image parts handed to vision-capable models.
     *
     * @param array $tokens Up to 5 upload tokens.
     * @return array{text:string,images:array<int,array{mime:string,data:string}>}
     */
    public static function collect(array $tokens): array {
        $text   = [];
        $images = [];
        foreach (array_slice($tokens, 0, 5) as $tok) {
            if (!is_string($tok)) continue;
            $part = self::part($tok);
            if (($part['kind'] ?? '') === 'image' && !empty($part['data'])) {
                $images[] = ['mime' => (string) $part['mime'], 'data' => (string) $part['data']];
            } elseif (!empty($part['text'])) {
                $text[] = (string) $part['text'];
            }
        }
        return ['text' => implode("\n\n", $text), 'images' => $images];
    }

    /**
     * Resolve a single token to a typed part:
     *   image → ['kind'=>'image','mime'=>…,'data'=>base64]
     *   doc   → ['kind'=>'doc','text'=>extracted text or reference line]
     *   video → ['kind'=>'video','text'=>reference note]
     *   none  → ['kind'=>'none','text'=>'']  (unknown/expired)
     */
    public static function part(string $token): array {
        $clean = preg_replace('/[^A-Za-z0-9]/', '', $token);
        if ($clean === '') return ['kind' => 'none', 'text' => ''];
        $payload = get_transient(self::TOKEN_PREFIX . $clean);
        if (!is_array($payload)) return ['kind' => 'none', 'text' => ''];

        $kind = (string) ($payload['kind'] ?? 'doc');
        $name = sanitize_text_field((string) ($payload['name'] ?? 'file'));

        if ($kind === 'image') {
            // Prefer the base64 captured at upload time; re-read from disk only
            // if it's missing (e.g. an attachment uploaded by an older version).
            $data = (string) ($payload['data'] ?? '');
            if ($data === '') {
                $data = self::read_image_b64($payload);
            }
            if ($data !== '') {
                return [
                    'kind' => 'image',
                    'mime' => self::mime_for_ext((string) ($payload['ext'] ?? 'png')),
                    'data' => $data,
                    'name' => $name,
                ];
            }
            // Couldn't read it back — fall back to a reference line.
            return ['kind' => 'doc', 'text' => self::resolve($token)];
        }

        if ($kind === 'video') {
            return ['kind' => 'video', 'text' => sprintf(
                /* translators: %s: uploaded video file name */
                __('[Uploaded video "%s" — the assistant cannot watch video. Describe what you need from it, or attach a transcript.]', 'authorwings-ai-tools'),
                $name
            )];
        }

        return ['kind' => 'doc', 'text' => self::resolve($token)];
    }

    /** Read a stored image back as base64, with path-confinement + size guards. */
    private static function read_image_b64(array $payload): string {
        $path = (string) ($payload['path'] ?? '');
        if ($path === '' || !is_readable($path)) return '';

        // Confine to our own uploads sub-directory — never read an arbitrary path.
        $up = wp_upload_dir();
        if (!empty($up['error'])) return '';
        $base = wp_normalize_path(trailingslashit($up['basedir']) . 'awg-ai-uploads/');
        if (strpos(wp_normalize_path($path), $base) !== 0) return '';

        $max = (int) apply_filters('awg_agent_image_max_bytes', 6 * 1024 * 1024);
        $size = @filesize($path);
        if ($size === false || $size <= 0 || $size > $max) return '';

        $raw = @file_get_contents($path);
        if ($raw === false || $raw === '') return '';
        return base64_encode($raw);
    }

    /** Best-effort MIME type from an extension for the formats we accept. */
    public static function mime_for_ext(string $ext): string {
        switch (strtolower($ext)) {
            case 'png':  return 'image/png';
            case 'jpg':
            case 'jpeg': return 'image/jpeg';
            case 'gif':  return 'image/gif';
            case 'webp': return 'image/webp';
            case 'mp4':  return 'video/mp4';
            case 'webm': return 'video/webm';
            case 'mov':  return 'video/quicktime';
            case 'm4v':  return 'video/x-m4v';
            case 'ogv':  return 'video/ogg';
            default:     return 'application/octet-stream';
        }
    }

    private function error_message(int $code): string {
        switch ($code) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return __('The file is larger than the server allows.', 'authorwings-ai-tools');
            case UPLOAD_ERR_PARTIAL:
                return __('The upload was interrupted. Please try again.', 'authorwings-ai-tools');
            case UPLOAD_ERR_NO_TMP_DIR:
            case UPLOAD_ERR_CANT_WRITE:
                return __('The server could not save the file.', 'authorwings-ai-tools');
            default:
                return __('Upload failed. Please try again.', 'authorwings-ai-tools');
        }
    }

    private function protect_dir(string $dir): void {
        $ht = trailingslashit($dir) . '.htaccess';
        if (!file_exists($ht)) {
            $rules  = "Options -Indexes\n";
            $rules .= "<FilesMatch \"\\.(php|phtml|phps|php[0-9]+|pl|py|cgi|asp|aspx|sh|exe|js)$\">\n";
            $rules .= "  Require all denied\n";
            $rules .= "</FilesMatch>\n";
            @file_put_contents($ht, $rules);
        }
        $idx = trailingslashit($dir) . 'index.html';
        if (!file_exists($idx)) {
            @file_put_contents($idx, '');
        }
    }
}
