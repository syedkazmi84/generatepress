<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

/**
 * Agent provider layer.
 *
 * Multi-turn chat with native function/tool calling for the three providers the
 * plugin already supports (OpenAI, Anthropic, DeepSeek). Each provider keeps its
 * own native conversation array so tool-result threading follows that provider's
 * wire format exactly. The tool-execution loop is bounded by MAX_STEPS so a model
 * that keeps asking for tools can never spin forever.
 *
 * Return shape is normalised across providers:
 *   ['ok' => bool, 'text' => string, 'steps' => int, 'tools_used' => string[],
 *    'error' => string, 'raw' => mixed]
 */
final class Agent_Provider {

    /** Maximum number of model<->tool round-trips inside a single chat turn. */
    const MAX_STEPS = 6;

    /**
     * Decide which provider a model id belongs to. Mirrors the routing the core
     * Ajax class uses so an agent and a tool resolve a model identically.
     */
    public static function provider_for_model(string $model): string {
        $m = strtolower(trim($model));
        if ($m === '') return 'openai';
        if (strpos($m, 'claude') === 0 || strpos($m, 'anthropic') !== false) {
            return 'anthropic';
        }
        if (strpos($m, 'deepseek') === 0) {
            return 'deepseek';
        }
        return 'openai';
    }

    /**
     * One-shot completion with no tools — used to execute a template "tool"
     * (run a generator with the arguments the agent supplied). Mirrors the
     * core single-shot calls, normalised to ['ok','text','error','raw'].
     */
    public static function complete(string $provider, string $api_key, string $model, string $system, string $user, int $max_tokens, int $timeout): array {
        if ($max_tokens <= 0) $max_tokens = 1024;

        if ($provider === 'anthropic') {
            $payload = [
                'model'      => $model,
                'max_tokens' => $max_tokens,
                'messages'   => [['role' => 'user', 'content' => $user]],
            ];
            if (trim($system) !== '') $payload['system'] = $system;
            list($code, $json, $body) = self::post('https://api.anthropic.com/v1/messages', self::anthropic_headers($api_key), $payload, $timeout);
            if ($code === 0) return ['ok' => false, 'error' => $body];
            if ($code < 200 || $code >= 300) return ['ok' => false, 'error' => self::err_msg($json, 'Anthropic'), 'raw' => $json ?: $body];
            $text = '';
            foreach ((array) ($json['content'] ?? []) as $b) {
                if (is_array($b) && ($b['type'] ?? '') === 'text') $text .= (string) ($b['text'] ?? '');
            }
            return self::done(trim($text), $json, $body);
        }

        if ($provider === 'deepseek') {
            $messages = [];
            if (trim($system) !== '') $messages[] = ['role' => 'system', 'content' => $system];
            $messages[] = ['role' => 'user', 'content' => $user];
            $payload = ['model' => $model, 'messages' => $messages, 'max_tokens' => $max_tokens, 'stream' => false];
            list($code, $json, $body) = self::post('https://api.deepseek.com/chat/completions', self::bearer_headers($api_key), $payload, $timeout);
            if ($code === 0) return ['ok' => false, 'error' => $body];
            if ($code < 200 || $code >= 300) return ['ok' => false, 'error' => self::err_msg($json, 'DeepSeek'), 'raw' => $json ?: $body];
            $text = (string) ($json['choices'][0]['message']['content'] ?? '');
            return self::done(trim($text), $json, $body);
        }

        // OpenAI Responses API.
        $payload = [
            'model' => $model,
            'input' => [
                ['role' => 'system', 'content' => [['type' => 'input_text', 'text' => $system]]],
                ['role' => 'user',   'content' => [['type' => 'input_text', 'text' => $user]]],
            ],
            'max_output_tokens' => $max_tokens,
        ];
        list($code, $json, $body) = self::post('https://api.openai.com/v1/responses', self::bearer_headers($api_key), $payload, $timeout);
        if ($code === 0) return ['ok' => false, 'error' => $body];
        if ($code < 200 || $code >= 300) return ['ok' => false, 'error' => self::err_msg($json, 'OpenAI'), 'raw' => $json ?: $body];
        $parsed = self::openai_parse_output(is_array($json) ? $json : []);
        return self::done(trim($parsed['text']), $json, $body);
    }

    /**
     * Multi-turn chat with optional tools.
     *
     * @param string   $provider  openai|anthropic|deepseek
     * @param array    $history   [['role'=>'user'|'assistant','content'=>string], ...] ending with the new user turn.
     * @param array    $tools     Normalised tool defs: [['name'=>,'description'=>,'parameters'=>jsonschema], ...]
     * @param callable $executor  function(string $name, array $args): string — runs a tool and returns its text result.
     */
    public static function chat(string $provider, string $api_key, string $model, string $system, array $history, array $tools, callable $executor, int $max_tokens, int $timeout, ?callable $on_event = null, array $images = []): array {
        if ($max_tokens <= 0) $max_tokens = 1024;
        if ($provider === 'anthropic') {
            return self::chat_anthropic($api_key, $model, $system, $history, $tools, $executor, $max_tokens, $timeout, $on_event, $images);
        }
        if ($provider === 'deepseek') {
            // DeepSeek's chat endpoint has no vision input. Let the model know an
            // image was attached so it can ask for a description rather than ignore it.
            if (!empty($images)) {
                $note = sprintf(
                    /* translators: %d: number of attached images */
                    _n(
                        '[The user attached %d image, which this model cannot view. If it matters, ask them to describe it.]',
                        '[The user attached %d images, which this model cannot view. If it matters, ask them to describe them.]',
                        count($images),
                        'authorwings-ai-tools'
                    ),
                    count($images)
                );
                $system = trim($system . "\n\n" . $note);
            }
            return self::chat_deepseek($api_key, $model, $system, $history, $tools, $executor, $max_tokens, $timeout, $on_event);
        }
        return self::chat_openai($api_key, $model, $system, $history, $tools, $executor, $max_tokens, $timeout, $on_event, $images);
    }

    /**
     * Index of the last user turn in a flat history array, or -1. Image
     * attachments belong to the turn the user just sent, so vision blocks are
     * appended only there.
     */
    private static function last_user_index(array $history): int {
        $idx = -1;
        foreach ($history as $i => $msg) {
            if (($msg['role'] ?? '') !== 'assistant') $idx = (int) $i;
        }
        return $idx;
    }

    private static function emit(?callable $on_event, string $type, string $value): void {
        if ($on_event) {
            call_user_func($on_event, $type, $value);
        }
    }

    /* ------------------------------------------------------------------ *
     * Real token streaming (no tools) — used for the live "typing" effect.
     * ------------------------------------------------------------------ */

    /**
     * Stream a plain completion token-by-token, invoking $on_delta($text) for each
     * chunk. No tools — used when an agent has no tools (or for the final answer).
     * Uses cURL directly because the WP HTTP API buffers the whole body. Returns
     * ['ok'=>bool,'text'=>string] or ['ok'=>false,'fallback'=>true] so the caller
     * can retry the non-streaming path.
     *
     * @return array{ok:bool,text?:string,error?:string,fallback?:bool,raw?:mixed}
     */
    public static function stream_complete(string $provider, string $api_key, string $model, string $system, array $history, int $max_tokens, int $timeout, callable $on_delta): array {
        if (!function_exists('curl_init')) {
            return ['ok' => false, 'fallback' => true, 'error' => __('Streaming unavailable on this server.', 'authorwings-ai-tools')];
        }
        if ($max_tokens <= 0) $max_tokens = 1024;

        if ($provider === 'anthropic') {
            $url = 'https://api.anthropic.com/v1/messages';
            $headers = ['Content-Type: application/json', 'x-api-key: ' . $api_key, 'anthropic-version: 2023-06-01'];
            $messages = [];
            $seen_user = false;
            foreach ($history as $msg) {
                $role = ($msg['role'] === 'assistant') ? 'assistant' : 'user';
                if (!$seen_user && $role === 'assistant') continue;
                $seen_user = true;
                $messages[] = ['role' => $role, 'content' => (string) $msg['content']];
            }
            $payload = ['model' => $model, 'max_tokens' => $max_tokens, 'stream' => true, 'messages' => $messages];
            if (trim($system) !== '') $payload['system'] = $system;
        } elseif ($provider === 'deepseek') {
            $url = 'https://api.deepseek.com/chat/completions';
            $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . $api_key];
            $messages = [];
            if (trim($system) !== '') $messages[] = ['role' => 'system', 'content' => $system];
            foreach ($history as $msg) {
                $messages[] = ['role' => ($msg['role'] === 'assistant') ? 'assistant' : 'user', 'content' => (string) $msg['content']];
            }
            $payload = ['model' => $model, 'messages' => $messages, 'max_tokens' => $max_tokens, 'stream' => true];
        } else {
            $url = 'https://api.openai.com/v1/responses';
            $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . $api_key];
            $input = [];
            if (trim($system) !== '') $input[] = ['role' => 'system', 'content' => [['type' => 'input_text', 'text' => $system]]];
            foreach ($history as $msg) {
                $role = ($msg['role'] === 'assistant') ? 'assistant' : 'user';
                $type = ($role === 'assistant') ? 'output_text' : 'input_text';
                $input[] = ['role' => $role, 'content' => [['type' => $type, 'text' => (string) $msg['content']]]];
            }
            $payload = ['model' => $model, 'input' => $input, 'max_output_tokens' => $max_tokens, 'stream' => true];
        }

        $full = '';
        $raw = '';
        $buffer = '';
        $http = 0;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, wp_json_encode($payload));
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_TIMEOUT, max(30, $timeout));
        curl_setopt($ch, CURLOPT_HEADERFUNCTION, function ($ch, $header) use (&$http) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $header, $mm)) $http = (int) $mm[1];
            return strlen($header);
        });
        curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($ch, $chunk) use (&$buffer, &$full, &$raw, $provider, $on_delta, &$http) {
            $raw .= $chunk;
            if ($http && ($http < 200 || $http >= 300)) {
                return strlen($chunk);
            }
            $buffer .= $chunk;
            while (($nl = strpos($buffer, "\n")) !== false) {
                $line = rtrim(substr($buffer, 0, $nl), "\r");
                $buffer = substr($buffer, $nl + 1);
                if ($line === '' || strncmp($line, 'data:', 5) !== 0) continue;
                $data = trim(substr($line, 5));
                if ($data === '' || $data === '[DONE]') continue;
                $obj = json_decode($data, true);
                if (!is_array($obj)) continue;
                $delta = self::stream_delta($provider, $obj);
                if ($delta !== '') {
                    $full .= $delta;
                    call_user_func($on_delta, $delta);
                }
            }
            return strlen($chunk);
        });

        $exec = curl_exec($ch);
        $cerr = curl_error($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code) $http = $code;

        if ($exec === false && $full === '') {
            return ['ok' => false, 'fallback' => true, 'error' => $cerr ?: __('Streaming request failed.', 'authorwings-ai-tools')];
        }
        if ($http < 200 || $http >= 300) {
            $json = json_decode($raw, true);
            $msg = (is_array($json) && isset($json['error']['message'])) ? (string) $json['error']['message'] : __('AI request failed.', 'authorwings-ai-tools');
            return ['ok' => false, 'error' => $msg, 'raw' => $json ?: $raw];
        }
        $full = trim($full);
        if ($full === '') {
            return ['ok' => false, 'error' => __('The assistant returned an empty reply. Please try again.', 'authorwings-ai-tools'), 'raw' => $raw];
        }
        return ['ok' => true, 'text' => $full];
    }

    /** Pull the incremental text out of one decoded SSE data object, per provider. */
    private static function stream_delta(string $provider, array $obj): string {
        if ($provider === 'anthropic') {
            if (($obj['type'] ?? '') === 'content_block_delta'
                && is_array($obj['delta'] ?? null)
                && ($obj['delta']['type'] ?? '') === 'text_delta') {
                return (string) ($obj['delta']['text'] ?? '');
            }
            return '';
        }
        if ($provider === 'deepseek') {
            return (string) ($obj['choices'][0]['delta']['content'] ?? '');
        }
        if (($obj['type'] ?? '') === 'response.output_text.delta') {
            return (string) ($obj['delta'] ?? '');
        }
        return '';
    }

    /* ------------------------------------------------------------------ *
     * OpenAI Responses API
     * ------------------------------------------------------------------ */

    private static function chat_openai(string $api_key, string $model, string $system, array $history, array $tools, callable $executor, int $max_tokens, int $timeout, ?callable $on_event = null, array $images = []): array {
        $input = [];
        if (trim($system) !== '') {
            $input[] = ['role' => 'system', 'content' => [['type' => 'input_text', 'text' => $system]]];
        }
        $last_user = self::last_user_index($history);
        foreach ($history as $i => $msg) {
            $role = ($msg['role'] === 'assistant') ? 'assistant' : 'user';
            $type = ($role === 'assistant') ? 'output_text' : 'input_text';
            $content = [['type' => $type, 'text' => (string) $msg['content']]];
            if ($role === 'user' && $i === $last_user && !empty($images)) {
                foreach ($images as $img) {
                    $content[] = [
                        'type'      => 'input_image',
                        'image_url' => 'data:' . $img['mime'] . ';base64,' . $img['data'],
                    ];
                }
            }
            $input[] = ['role' => $role, 'content' => $content];
        }

        $tool_defs = [];
        foreach ($tools as $t) {
            $tool_defs[] = [
                'type'        => 'function',
                'name'        => $t['name'],
                'description' => $t['description'],
                'parameters'  => $t['parameters'],
            ];
        }

        $tools_used = [];
        for ($step = 0; $step < self::MAX_STEPS; $step++) {
            $payload = ['model' => $model, 'input' => $input, 'max_output_tokens' => $max_tokens];
            if (!empty($tool_defs)) $payload['tools'] = $tool_defs;

            list($code, $json, $body) = self::post('https://api.openai.com/v1/responses', self::bearer_headers($api_key), $payload, $timeout);
            if ($code === 0) return ['ok' => false, 'error' => $body];
            if ($code < 200 || $code >= 300) return ['ok' => false, 'error' => self::err_msg($json, 'OpenAI'), 'raw' => $json ?: $body];

            $parsed = self::openai_parse_output(is_array($json) ? $json : []);
            if (empty($parsed['calls'])) {
                return self::final_text(trim($parsed['text']), $step, $tools_used, $json, $body);
            }

            // Execute each requested tool and append the call + its output.
            foreach ($parsed['calls'] as $call) {
                $input[] = [
                    'type'      => 'function_call',
                    'call_id'   => $call['call_id'],
                    'name'      => $call['name'],
                    'arguments' => $call['arguments'],
                ];
                $tools_used[] = $call['name'];
                self::emit($on_event, 'tool', $call['name']);
                $result = self::run_tool($executor, $call['name'], $call['arguments']);
                $input[] = [
                    'type'    => 'function_call_output',
                    'call_id' => $call['call_id'],
                    'output'  => $result,
                ];
            }
        }
        return ['ok' => false, 'error' => __('The assistant took too many steps. Please rephrase and try again.', 'authorwings-ai-tools')];
    }

    /** Pull text + function calls out of an OpenAI Responses `output` array. */
    private static function openai_parse_output(array $json): array {
        $text = '';
        $calls = [];
        foreach ((array) ($json['output'] ?? []) as $out) {
            if (!is_array($out)) continue;
            $type = $out['type'] ?? '';
            if ($type === 'message' && is_array($out['content'] ?? null)) {
                foreach ($out['content'] as $c) {
                    if (($c['type'] ?? '') === 'output_text') $text .= (string) ($c['text'] ?? '');
                }
            } elseif ($type === 'function_call') {
                $calls[] = [
                    'call_id'   => (string) ($out['call_id'] ?? ($out['id'] ?? '')),
                    'name'      => (string) ($out['name'] ?? ''),
                    'arguments' => (string) ($out['arguments'] ?? '{}'),
                ];
            }
        }
        return ['text' => $text, 'calls' => $calls];
    }

    /* ------------------------------------------------------------------ *
     * Anthropic Messages API
     * ------------------------------------------------------------------ */

    private static function chat_anthropic(string $api_key, string $model, string $system, array $history, array $tools, callable $executor, int $max_tokens, int $timeout, ?callable $on_event = null, array $images = []): array {
        $messages = [];
        $seen_user = false;
        foreach ($history as $msg) {
            $role = ($msg['role'] === 'assistant') ? 'assistant' : 'user';
            // Anthropic requires the conversation to begin with a user turn, so
            // drop any leading assistant messages (e.g. the agent's greeting).
            if (!$seen_user && $role === 'assistant') {
                continue;
            }
            $seen_user = true;
            $messages[] = ['role' => $role, 'content' => (string) $msg['content']];
        }

        // Attach any image parts to the final user turn as vision content blocks.
        if (!empty($images)) {
            for ($i = count($messages) - 1; $i >= 0; $i--) {
                if ($messages[$i]['role'] !== 'user') continue;
                $blocks = [['type' => 'text', 'text' => (string) $messages[$i]['content']]];
                foreach ($images as $img) {
                    $blocks[] = [
                        'type'   => 'image',
                        'source' => ['type' => 'base64', 'media_type' => $img['mime'], 'data' => $img['data']],
                    ];
                }
                $messages[$i]['content'] = $blocks;
                break;
            }
        }

        $tool_defs = [];
        foreach ($tools as $t) {
            $tool_defs[] = [
                'name'         => $t['name'],
                'description'  => $t['description'],
                'input_schema' => $t['parameters'],
            ];
        }

        $tools_used = [];
        for ($step = 0; $step < self::MAX_STEPS; $step++) {
            $payload = ['model' => $model, 'max_tokens' => $max_tokens, 'messages' => $messages];
            if (trim($system) !== '') $payload['system'] = $system;
            if (!empty($tool_defs)) $payload['tools'] = $tool_defs;

            list($code, $json, $body) = self::post('https://api.anthropic.com/v1/messages', self::anthropic_headers($api_key), $payload, $timeout);
            if ($code === 0) return ['ok' => false, 'error' => $body];
            if ($code < 200 || $code >= 300) return ['ok' => false, 'error' => self::err_msg($json, 'Anthropic'), 'raw' => $json ?: $body];

            $content = is_array($json['content'] ?? null) ? $json['content'] : [];
            $text = '';
            $uses = [];
            foreach ($content as $b) {
                if (!is_array($b)) continue;
                if (($b['type'] ?? '') === 'text') {
                    $text .= (string) ($b['text'] ?? '');
                } elseif (($b['type'] ?? '') === 'tool_use') {
                    $uses[] = $b;
                }
            }

            if (empty($uses)) {
                return self::final_text(trim($text), $step, $tools_used, $json, $body);
            }

            // Echo the assistant's full content back, then answer each tool_use.
            $messages[] = ['role' => 'assistant', 'content' => $content];
            $results = [];
            foreach ($uses as $u) {
                $name = (string) ($u['name'] ?? '');
                $args = is_array($u['input'] ?? null) ? $u['input'] : [];
                $tools_used[] = $name;
                self::emit($on_event, 'tool', $name);
                $results[] = [
                    'type'        => 'tool_result',
                    'tool_use_id' => (string) ($u['id'] ?? ''),
                    'content'     => self::run_tool_args($executor, $name, $args),
                ];
            }
            $messages[] = ['role' => 'user', 'content' => $results];
        }
        return ['ok' => false, 'error' => __('The assistant took too many steps. Please rephrase and try again.', 'authorwings-ai-tools')];
    }

    /* ------------------------------------------------------------------ *
     * DeepSeek (OpenAI-compatible Chat Completions)
     * ------------------------------------------------------------------ */

    private static function chat_deepseek(string $api_key, string $model, string $system, array $history, array $tools, callable $executor, int $max_tokens, int $timeout, ?callable $on_event = null): array {
        $messages = [];
        if (trim($system) !== '') $messages[] = ['role' => 'system', 'content' => $system];
        foreach ($history as $msg) {
            $role = ($msg['role'] === 'assistant') ? 'assistant' : 'user';
            $messages[] = ['role' => $role, 'content' => (string) $msg['content']];
        }

        $tool_defs = [];
        foreach ($tools as $t) {
            $tool_defs[] = [
                'type'     => 'function',
                'function' => [
                    'name'        => $t['name'],
                    'description' => $t['description'],
                    'parameters'  => $t['parameters'],
                ],
            ];
        }

        $tools_used = [];
        for ($step = 0; $step < self::MAX_STEPS; $step++) {
            $payload = ['model' => $model, 'messages' => $messages, 'max_tokens' => $max_tokens, 'stream' => false];
            if (!empty($tool_defs)) {
                $payload['tools'] = $tool_defs;
                $payload['tool_choice'] = 'auto';
            }

            list($code, $json, $body) = self::post('https://api.deepseek.com/chat/completions', self::bearer_headers($api_key), $payload, $timeout);
            if ($code === 0) return ['ok' => false, 'error' => $body];
            if ($code < 200 || $code >= 300) return ['ok' => false, 'error' => self::err_msg($json, 'DeepSeek'), 'raw' => $json ?: $body];

            $message = is_array($json['choices'][0]['message'] ?? null) ? $json['choices'][0]['message'] : [];
            $calls = is_array($message['tool_calls'] ?? null) ? $message['tool_calls'] : [];

            if (empty($calls)) {
                return self::final_text(trim((string) ($message['content'] ?? '')), $step, $tools_used, $json, $body);
            }

            // Append the assistant turn verbatim, then one tool message per call.
            $messages[] = $message;
            foreach ($calls as $call) {
                $name = (string) ($call['function']['name'] ?? '');
                $args = (string) ($call['function']['arguments'] ?? '{}');
                $tools_used[] = $name;
                self::emit($on_event, 'tool', $name);
                $messages[] = [
                    'role'         => 'tool',
                    'tool_call_id' => (string) ($call['id'] ?? ''),
                    'content'      => self::run_tool($executor, $name, $args),
                ];
            }
        }
        return ['ok' => false, 'error' => __('The assistant took too many steps. Please rephrase and try again.', 'authorwings-ai-tools')];
    }

    /* ------------------------------------------------------------------ *
     * Shared helpers
     * ------------------------------------------------------------------ */

    /** Decode a JSON-string argument blob and run the executor. */
    private static function run_tool(callable $executor, string $name, string $arguments): string {
        $args = json_decode($arguments, true);
        if (!is_array($args)) $args = [];
        return self::run_tool_args($executor, $name, $args);
    }

    private static function run_tool_args(callable $executor, string $name, array $args): string {
        try {
            $out = (string) call_user_func($executor, $name, $args);
        } catch (\Throwable $e) {
            $out = '';
        }
        if (trim($out) === '') {
            $out = __('(The tool returned no result.)', 'authorwings-ai-tools');
        }
        // Keep a single tool result from blowing the context budget.
        if (strlen($out) > 16000) {
            $out = substr($out, 0, 16000) . "\n…(truncated)";
        }
        return $out;
    }

    private static function final_text(string $text, int $step, array $tools_used, $json, string $body): array {
        if ($text === '') {
            return [
                'ok'    => false,
                'error' => __('The assistant returned an empty reply. Please try again.', 'authorwings-ai-tools'),
                'raw'   => $json ?: $body,
            ];
        }
        return ['ok' => true, 'text' => $text, 'steps' => $step + 1, 'tools_used' => array_values(array_unique($tools_used)), 'raw' => $json];
    }

    private static function done(string $text, $json, string $body): array {
        if ($text === '') {
            return [
                'ok'    => false,
                'error' => __('The model returned an empty or unexpected response. Please try again.', 'authorwings-ai-tools'),
                'raw'   => $json ?: $body,
            ];
        }
        return ['ok' => true, 'text' => $text, 'raw' => $json];
    }

    private static function err_msg($json, string $label): string {
        if (is_array($json) && isset($json['error']['message'])) {
            return (string) $json['error']['message'];
        }
        return $label . ' error';
    }

    private static function bearer_headers(string $api_key): array {
        return [
            'Content-Type'  => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
        ];
    }

    private static function anthropic_headers(string $api_key): array {
        return [
            'Content-Type'      => 'application/json',
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
        ];
    }

    /**
     * POST JSON via the WP HTTP API.
     *
     * @return array{0:int,1:mixed,2:string} [http_code|0, decoded_json|null, body_or_error]
     */
    private static function post(string $url, array $headers, array $payload, int $timeout): array {
        $res = wp_remote_post($url, [
            'headers' => $headers,
            'body'    => wp_json_encode($payload),
            'timeout' => max(15, $timeout),
        ]);
        if (is_wp_error($res)) {
            return [0, null, $res->get_error_message()];
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        $body = (string) wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        return [$code, $json, $body];
    }
}
