<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

/**
 * Conversation memory for logged-in users. Two custom tables store threads and
 * their messages so a member's chats persist across reloads and devices, with a
 * history list and per-thread delete. Guests are not persisted server-side (the
 * browser keeps their current chat locally).
 */
final class Agent_Threads {

    const DB_VERSION = '1';
    const OPT_DB     = 'awg_agent_db_version';

    public function register(): void {
        add_action('wp_ajax_awg_agent_threads', [$this, 'ajax_list']);
        add_action('wp_ajax_awg_agent_thread', [$this, 'ajax_get']);
        add_action('wp_ajax_awg_agent_thread_delete', [$this, 'ajax_delete']);
    }

    /* ------------------------------------------------------------------ *
     * Schema
     * ------------------------------------------------------------------ */

    public static function threads_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'awg_agent_threads';
    }

    public static function messages_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'awg_agent_messages';
    }

    /** Create/upgrade the tables. Idempotent — safe to call on every load. */
    public static function maybe_install(): void {
        if (get_option(self::OPT_DB) === self::DB_VERSION) return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $threads = self::threads_table();
        $messages = self::messages_table();

        dbDelta("CREATE TABLE {$threads} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            agent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            title VARCHAR(200) NOT NULL DEFAULT '',
            created_at DATETIME NULL DEFAULT NULL,
            updated_at DATETIME NULL DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY user_agent (user_id, agent_id, updated_at)
        ) {$charset};");

        dbDelta("CREATE TABLE {$messages} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            thread_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            role VARCHAR(16) NOT NULL DEFAULT 'user',
            content LONGTEXT NULL,
            created_at DATETIME NULL DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY thread (thread_id, id)
        ) {$charset};");

        update_option(self::OPT_DB, self::DB_VERSION);
    }

    /* ------------------------------------------------------------------ *
     * Persistence used by the chat endpoints
     * ------------------------------------------------------------------ */

    /**
     * Persist one completed turn (the user message + the assistant reply) for a
     * logged-in user, creating the thread on first use. Returns the thread id (0
     * when not persisted, e.g. guests).
     */
    public static function record_turn(int $agent_id, int $thread_id, string $user_msg, string $assistant_msg): int {
        $user_id = get_current_user_id();
        if ($user_id <= 0) return 0;

        global $wpdb;
        $now = current_time('mysql');
        $threads = self::threads_table();

        if ($thread_id > 0 && !self::owns($thread_id, $user_id, $agent_id)) {
            $thread_id = 0; // ownership mismatch — start a fresh thread.
        }

        if ($thread_id <= 0) {
            $title = self::make_title($user_msg);
            $wpdb->insert($threads, [
                'user_id'    => $user_id,
                'agent_id'   => $agent_id,
                'title'      => $title,
                'created_at' => $now,
                'updated_at' => $now,
            ], ['%d', '%d', '%s', '%s', '%s']);
            $thread_id = (int) $wpdb->insert_id;
            if ($thread_id <= 0) return 0;
        } else {
            $wpdb->update($threads, ['updated_at' => $now], ['id' => $thread_id], ['%s'], ['%d']);
        }

        $messages = self::messages_table();
        $wpdb->insert($messages, ['thread_id' => $thread_id, 'role' => 'user', 'content' => $user_msg, 'created_at' => $now], ['%d', '%s', '%s', '%s']);
        $wpdb->insert($messages, ['thread_id' => $thread_id, 'role' => 'assistant', 'content' => $assistant_msg, 'created_at' => $now], ['%d', '%s', '%s', '%s']);

        return $thread_id;
    }

    private static function owns(int $thread_id, int $user_id, int $agent_id): bool {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            'SELECT user_id, agent_id FROM ' . self::threads_table() . ' WHERE id = %d',
            $thread_id
        ));
        return $row && (int) $row->user_id === $user_id && (int) $row->agent_id === $agent_id;
    }

    private static function make_title(string $msg): string {
        $msg = trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($msg)));
        if ($msg === '') return __('New chat', 'authorwings-ai-tools');
        if (function_exists('mb_substr') && mb_strlen($msg) > 60) {
            return mb_substr($msg, 0, 60) . '…';
        }
        return strlen($msg) > 60 ? substr($msg, 0, 60) . '…' : $msg;
    }

    /* ------------------------------------------------------------------ *
     * AJAX: list / get / delete
     * ------------------------------------------------------------------ */

    private function require_user(): int {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash((string) $_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'awg_agent_front')) {
            wp_send_json_error(['message' => __('Invalid request.', 'authorwings-ai-tools')], 403);
        }
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            wp_send_json_error(['message' => __('Please log in.', 'authorwings-ai-tools')], 403);
        }
        return $user_id;
    }

    public function ajax_list(): void {
        $user_id = $this->require_user();
        $agent_id = (int) ($_POST['agent_id'] ?? 0);
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT id, title, updated_at FROM ' . self::threads_table()
            . ' WHERE user_id = %d AND agent_id = %d ORDER BY updated_at DESC LIMIT 50',
            $user_id, $agent_id
        ));
        $out = [];
        foreach ((array) $rows as $r) {
            $out[] = ['id' => (int) $r->id, 'title' => (string) $r->title, 'updated' => (string) $r->updated_at];
        }
        wp_send_json_success(['threads' => $out]);
    }

    public function ajax_get(): void {
        $user_id = $this->require_user();
        $agent_id = (int) ($_POST['agent_id'] ?? 0);
        $thread_id = (int) ($_POST['thread_id'] ?? 0);
        if ($thread_id <= 0 || !self::owns($thread_id, $user_id, $agent_id)) {
            wp_send_json_error(['message' => __('Chat not found.', 'authorwings-ai-tools')], 404);
        }
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT role, content FROM ' . self::messages_table() . ' WHERE thread_id = %d ORDER BY id ASC LIMIT 200',
            $thread_id
        ));
        $msgs = [];
        foreach ((array) $rows as $r) {
            $msgs[] = ['role' => ($r->role === 'assistant' ? 'assistant' : 'user'), 'content' => (string) $r->content];
        }
        wp_send_json_success(['thread_id' => $thread_id, 'messages' => $msgs]);
    }

    public function ajax_delete(): void {
        $user_id = $this->require_user();
        $agent_id = (int) ($_POST['agent_id'] ?? 0);
        $thread_id = (int) ($_POST['thread_id'] ?? 0);
        if ($thread_id <= 0 || !self::owns($thread_id, $user_id, $agent_id)) {
            wp_send_json_error(['message' => __('Chat not found.', 'authorwings-ai-tools')], 404);
        }
        global $wpdb;
        $wpdb->delete(self::messages_table(), ['thread_id' => $thread_id], ['%d']);
        $wpdb->delete(self::threads_table(), ['id' => $thread_id], ['%d']);
        wp_send_json_success(['deleted' => $thread_id]);
    }
}
