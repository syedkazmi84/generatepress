<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

/**
 * Front-end rendering for agents: the [awg_agent] shortcode, the chat markup, and
 * conditional asset loading. Visual language follows the generator (warm brand
 * accent, rounded card) via a small set of CSS variables.
 */
final class Agent_Renderer {

    private $assets_done = false;

    public function register(): void {
        add_shortcode('awg_agent', [$this, 'shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'maybe_enqueue']);
    }

    public function register_assets(): void {
        wp_register_style('awg-agent', plugins_url('assets/agent.css', AWG_AIG_FILE), ['dashicons'], AWG_AIG_VERSION);
        wp_register_script('awg-agent', plugins_url('assets/agent.js', AWG_AIG_FILE), [], AWG_AIG_VERSION, true);
    }

    public function maybe_enqueue(): void {
        $this->register_assets();
        $post = $GLOBALS['post'] ?? null;
        $should = false;
        if ($post && isset($post->post_content)) {
            $content = (string) $post->post_content;
            if (has_shortcode($content, 'awg_agent')) $should = true;
            if (!$should && function_exists('has_block') && has_block('awg/agent', $content)) $should = true;
        }
        $should = (bool) apply_filters('awg_agent_enqueue_assets', $should);
        if ($should) $this->enqueue();
    }

    public function enqueue(): void {
        if ($this->assets_done) return;
        $this->register_assets();
        wp_enqueue_style('awg-agent');
        wp_enqueue_script('awg-agent');

        $settings = get_option('awg_aig_settings', []);
        $stream_on = !is_array($settings) || !array_key_exists('enable_streaming', $settings)
            ? true
            : !empty($settings['enable_streaming']);

        wp_localize_script('awg-agent', 'AWG_AGENT', [
            'ajaxurl'  => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('awg_agent_front'),
            'stream'   => $stream_on ? 1 : 0,
            'loggedIn' => is_user_logged_in() ? 1 : 0,
            'i18n'     => [
                'send'      => __('Send', 'authorwings-ai-tools'),
                'stop'      => __('Stop', 'authorwings-ai-tools'),
                'thinking'  => __('Thinking…', 'authorwings-ai-tools'),
                'error'     => __('Something went wrong. Please try again.', 'authorwings-ai-tools'),
                'newChat'   => __('New chat', 'authorwings-ai-tools'),
                'history'   => __('History', 'authorwings-ai-tools'),
                'deleteQ'   => __('Delete this chat?', 'authorwings-ai-tools'),
                'attach'    => __('Attach a file', 'authorwings-ai-tools'),
                'uploading' => __('Uploading…', 'authorwings-ai-tools'),
                'copy'      => __('Copy', 'authorwings-ai-tools'),
                'download'  => __('Download', 'authorwings-ai-tools'),
                'downloadChat' => __('Download conversation', 'authorwings-ai-tools'),
            ],
        ]);
        $this->assets_done = true;
    }

    public function shortcode($atts): string {
        $atts = shortcode_atts(['id' => 0], $atts, 'awg_agent');
        $id = (int) $atts['id'];
        if ($id <= 0) return '';
        return $this->render($id);
    }

    public function render(int $agent_id): string {
        $post = get_post($agent_id);
        if (!$post || $post->post_type !== Agent::CPT) return '';
        $can_preview = is_user_logged_in() && current_user_can('edit_post', $agent_id);
        if ($post->post_status !== 'publish' && !$can_preview) return '';

        $this->enqueue();

        $m = Agent::get_meta($agent_id);
        $title    = get_the_title($agent_id);
        $greeting = $m['greeting'];
        $starters = Agent::starters($m['starters']);
        $accent   = $m['accent_color'] !== '' ? '#' . $m['accent_color'] : '';

        $style = $accent !== '' ? ' style="--awg-agent-accent:' . esc_attr($accent) . '"' : '';
        $logged_in    = is_user_logged_in();
        $allow_upload = !empty($m['allow_uploads']);

        // Front-end header design (per agent). 'none' renders a bare chat like the
        // Build Assistant; the others place a header above the conversation log.
        $header = in_array(($m['header_design'] ?? 'agent'), ['agent', 'none', 'branded', 'plain'], true) ? $m['header_design'] : 'agent';
        $display_title = $title !== '' ? $title : __('Assistant', 'authorwings-ai-tools');
        // Branded uses the global eyebrow label (same source as the AI tools).
        $awg_settings = get_option('awg_aig_settings', []);
        $eyebrow = is_array($awg_settings) ? trim((string) ($awg_settings['brand_eyebrow'] ?? '')) : '';
        $spark = '<svg class="awg-agent-spark" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.09 5.26L19.5 8.5l-4 3.64L16.5 18 12 15.27 7.5 18l1-5.86-4-3.64 5.41-1.24L12 2z"/></svg>';
        // Optional Dashicons header icon, shown in the avatar / branded badge.
        $icon      = (string) ($m['header_icon'] ?? '');
        $icon_pos  = in_array(($m['header_icon_position'] ?? 'top'), ['top', 'left'], true) ? $m['header_icon_position'] : 'top';
        $icon_html = $icon !== '' ? '<span class="awg-agent-icon ' . esc_attr($icon) . '" aria-hidden="true"></span>' : '';

        ob_start();
        ?>
        <div class="awg-agent awg-agent--head-<?php echo esc_attr($header); ?><?php echo $logged_in ? ' awg-agent--memory' : ''; ?>" data-agent-id="<?php echo esc_attr($agent_id); ?>" data-greeting="<?php echo esc_attr($greeting); ?>" data-placeholder="<?php echo esc_attr($m['placeholder']); ?>" data-allow-uploads="<?php echo $allow_upload ? '1' : '0'; ?>" data-max-mb="<?php echo esc_attr($m['upload_max_mb']); ?>"<?php echo $style; ?>>
            <?php if ($header === 'agent') : ?>
                <div class="awg-agent-head">
                    <span class="awg-agent-avatar<?php echo $icon !== '' ? ' awg-agent-avatar--icon' : ''; ?>" aria-hidden="true"><?php echo $icon_html; ?></span>
                    <span class="awg-agent-name"><?php echo esc_html($display_title); ?></span>
                </div>
            <?php elseif ($header === 'branded') : ?>
                <div class="awg-agent-branded awg-agent-branded--icon-<?php echo esc_attr($icon_pos); ?>">
                    <span class="awg-agent-branded-badge" aria-hidden="true"><?php echo $icon_html !== '' ? $icon_html : $spark; ?></span>
                    <div class="awg-agent-branded-heading">
                        <?php if ($eyebrow !== '') : ?><div class="awg-agent-branded-eyebrow"><?php echo esc_html($eyebrow); ?></div><?php endif; ?>
                        <div class="awg-agent-branded-title"><?php echo esc_html($display_title); ?></div>
                        <div class="awg-agent-branded-rule"></div>
                    </div>
                </div>
            <?php elseif ($header === 'plain') : ?>
                <div class="awg-agent-plain">
                    <div class="awg-agent-plain-title"><?php echo esc_html($display_title); ?></div>
                </div>
            <?php endif; ?>
            <div class="awg-agent-log" role="log" aria-live="polite"></div>
            <?php if (!empty($starters)) : ?>
                <div class="awg-agent-starters">
                    <?php foreach ($starters as $sp) : ?>
                        <button type="button" class="awg-agent-starter"><?php echo esc_html($sp); ?></button>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <div class="awg-agent-attachments"></div>
            <form class="awg-agent-form" autocomplete="off">
                <?php if ($allow_upload) : ?>
                    <label class="awg-agent-attach" title="<?php echo esc_attr__('Attach a file', 'authorwings-ai-tools'); ?>" aria-label="<?php echo esc_attr__('Attach a file', 'authorwings-ai-tools'); ?>">
                        <input type="file" class="awg-agent-file" hidden />
                        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                    </label>
                <?php endif; ?>
                <textarea class="awg-agent-input" rows="1" placeholder="<?php echo esc_attr($m['placeholder']); ?>"></textarea>
                <button type="submit" class="awg-agent-send"><?php esc_html_e('Send', 'authorwings-ai-tools'); ?></button>
                <button type="button" class="awg-agent-stop" hidden><?php esc_html_e('Stop', 'authorwings-ai-tools'); ?></button>
            </form>
        </div>
        <?php
        return (string) ob_get_clean();
    }
}
