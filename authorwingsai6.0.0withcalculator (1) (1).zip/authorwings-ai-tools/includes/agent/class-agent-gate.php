<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

/**
 * Shared request gating for the agent endpoints — the same client-IP handling,
 * per-IP rate buckets, site-wide daily cap and membership filter the core
 * generator uses, so agent turns and uploads are limited and billed identically.
 */
final class Agent_Gate {

    public static function client_ip(): string {
        $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
        $ip = (string) apply_filters('awg_aig_client_ip', $ip);
        $clean = preg_replace('/[^0-9a-fA-F:\.]/', '', $ip);
        return ($clean === null || $clean === '') ? '0.0.0.0' : $clean;
    }

    public static function ip_bucket(): string {
        $ip = self::client_ip();
        if (strpos($ip, ':') !== false && function_exists('inet_pton')) {
            $bin = @inet_pton($ip);
            if ($bin !== false && strlen($bin) === 16) {
                $prefix = substr($bin, 0, 8) . str_repeat("\0", 8);
                $back = @inet_ntop($prefix);
                if ($back !== false) return $back . '/64';
            }
        }
        return $ip;
    }

    /**
     * Two-bucket per-IP rate limit (one global, one per-agent). Mirrors the core.
     * $agent_limit = 0 means inherit the global ceiling only.
     */
    public static function rate_ok(int $agent_id, int $agent_limit, int $global_limit): bool {
        $ip_hash = md5(self::ip_bucket());
        $min = (int) floor(time() / 60);
        $global_limit = max(1, $global_limit);

        $g_key = "awg_aig_rl_g_{$ip_hash}_{$min}";
        $g_count = (int) get_transient($g_key);
        if ($g_count >= $global_limit) return false;

        $t_key = '';
        $t_count = 0;
        if ($agent_limit > 0 && $agent_id > 0) {
            $t_key = "awg_agent_rl_{$agent_id}_{$ip_hash}_{$min}";
            $t_count = (int) get_transient($t_key);
            if ($t_count >= $agent_limit) return false;
        }

        set_transient($g_key, $g_count + 1, 120);
        if ($t_key !== '') set_transient($t_key, $t_count + 1, 120);
        return true;
    }

    public static function global_cap_reached(int $cap): bool {
        if ($cap <= 0) return false;
        $state = get_option('awg_aig_global_usage');
        if (!is_array($state) || (($state['date'] ?? '') !== wp_date('Y-m-d'))) return false;
        return (int) ($state['count'] ?? 0) >= $cap;
    }

    public static function global_cap_bump(): void {
        $today = wp_date('Y-m-d');
        $state = get_option('awg_aig_global_usage');
        if (!is_array($state) || (($state['date'] ?? '') !== $today)) {
            $state = ['date' => $today, 'count' => 0];
        }
        $state['count'] = (int) ($state['count'] ?? 0) + 1;
        update_option('awg_aig_global_usage', $state, false);
    }

    /**
     * Run the membership filter for an agent turn.
     * @return true|array  true to allow, or ['status'=>int,'data'=>array] to block.
     */
    public static function membership(int $agent_id) {
        $can = apply_filters('awg_aig_can_generate', true, get_current_user_id(), $agent_id);

        if (is_wp_error($can)) {
            $error_data = $can->get_error_data();
            $payload = ['message' => $can->get_error_message()];
            if (is_array($error_data)) {
                if (!empty($error_data['upgrade_url'])) {
                    $payload['upgrade_url'] = esc_url_raw((string) $error_data['upgrade_url']);
                }
                if (!empty($error_data['upgrade_label'])) {
                    $payload['upgrade_label'] = sanitize_text_field((string) $error_data['upgrade_label']);
                }
            }
            return ['status' => 429, 'data' => $payload];
        }

        if ($can === false) {
            if (function_exists('awg_aig_mem_account_url') && awg_aig_mem_account_url() !== '') {
                $account_url = awg_aig_mem_account_url();
            } elseif (function_exists('awg_mem_get_account_url')) {
                $account_url = awg_mem_get_account_url();
            } else {
                $account_url = add_query_arg('tab', 'account', home_url('/member-dashboard/'));
            }
            return ['status' => 403, 'data' => [
                'message'       => __('This assistant is not available for your current plan.', 'authorwings-ai-tools'),
                'upgrade_url'   => $account_url,
                'upgrade_label' => __('Review my account', 'authorwings-ai-tools'),
            ]];
        }

        return true;
    }
}
