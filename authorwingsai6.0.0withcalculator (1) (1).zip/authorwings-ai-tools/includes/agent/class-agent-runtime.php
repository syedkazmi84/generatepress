<?php
namespace AWG_AIG\Agent;

use AWG_AIG\Plugin;

if (!defined('ABSPATH')) { exit; }

/**
 * Agent runtime: turns an agent's saved config + a conversation history into a
 * reply. Builds the tool definitions from the site's generator templates, runs a
 * template when the model calls it, and assembles the system prompt. The actual
 * provider/tool-loop lives in Agent_Provider; this class is the glue between an
 * agent post, the plugin's Settings, and that loop.
 */
final class Agent_Runtime {

    /** The plugin's shared Settings array (API keys, default model, timeout…). */
    public static function settings(): array {
        $s = get_option(Plugin::OPT, []);
        return is_array($s) ? $s : [];
    }

    /**
     * Resolve the API key + a human "missing" message for a provider.
     * @return array{0:string,1:string} [api_key, missing_message]
     */
    public static function resolve_key(string $provider, array $s): array {
        if ($provider === 'anthropic') {
            return [trim((string) ($s['anthropic_api_key'] ?? '')), __('Anthropic (Claude) API key missing in settings.', 'authorwings-ai-tools')];
        }
        if ($provider === 'deepseek') {
            return [trim((string) ($s['deepseek_api_key'] ?? '')), __('DeepSeek API key missing in settings.', 'authorwings-ai-tools')];
        }
        return [trim((string) ($s['api_key'] ?? '')), __('OpenAI API key missing in settings.', 'authorwings-ai-tools')];
    }

    /**
     * Run a full conversational turn for a public agent.
     *
     * @param int   $agent_id
     * @param array $meta     Normalised agent meta (Agent::get_meta()).
     * @param array $history  [['role'=>'user'|'assistant','content'=>string], ...]
     * @return array Agent_Provider-shaped result, with 'meta' echoed for the caller.
     */
    public static function chat_for_agent(int $agent_id, array $meta, array $history, ?callable $on_event = null, array $images = []): array {
        $s = self::settings();

        $model = $meta['model'] !== '' ? $meta['model'] : (string) ($s['default_model'] ?? 'gpt-5-mini');
        $provider = Agent_Provider::provider_for_model($model);
        list($key, $missing) = self::resolve_key($provider, $s);
        if ($key === '') {
            return ['ok' => false, 'error' => $missing];
        }

        $system = self::build_system_prompt($meta, $s, $agent_id);

        $built = self::build_template_tools($meta['tool_ids']);
        $tools = $built['defs'];
        $map   = $built['map'];

        // Knowledge grounding: add the built-in site-search tool when enabled.
        $knowledge_on = !empty($meta['knowledge_enabled']);
        $post_types   = (array) ($meta['knowledge_post_types'] ?? ['post', 'page']);
        if ($knowledge_on) {
            $tools[] = Agent_Knowledge::tool_def();
        }

        $executor = static function (string $name, array $args) use ($map, $knowledge_on, $post_types) {
            if ($name === Agent_Knowledge::TOOL_NAME) {
                return $knowledge_on
                    ? Agent_Knowledge::search($args, $post_types)
                    : __('Site search is not available.', 'authorwings-ai-tools');
            }
            if (!isset($map[$name])) {
                return __('Unknown tool.', 'authorwings-ai-tools');
            }
            return self::run_template_tool((int) $map[$name], $args);
        };

        $timeout = max(20, (int) ($s['timeout'] ?? 45));
        return Agent_Provider::chat($provider, $key, $model, $system, $history, $tools, $executor, (int) $meta['max_tokens'], $timeout, $on_event, $images);
    }

    /** Friendly label for a tool name (used in streaming status chips). */
    public static function tool_label(string $name): string {
        if ($name === Agent_Knowledge::TOOL_NAME) {
            return __('Searching the site', 'authorwings-ai-tools');
        }
        if (strpos($name, 'tool_') === 0) {
            $tid = (int) substr($name, 5);
            $title = $tid > 0 ? (string) get_the_title($tid) : '';
            if ($title !== '') {
                /* translators: %s: tool name */
                return sprintf(__('Using %s', 'authorwings-ai-tools'), $title);
            }
        }
        return __('Working…', 'authorwings-ai-tools');
    }

    /**
     * Admin "AI Assistant" — a builder agent that helps authors design tools and
     * write prompts. It gets a single read-only built-in tool so it can ground
     * its advice in the templates that already exist on the site. It never writes
     * to the database; it only suggests ready-to-paste configuration.
     */
    public static function chat_for_builder(array $history, array $images = []): array {
        $s = self::settings();

        // v5.7.0: the Build Assistant runs on its own model when set, otherwise
        // falls back to the site-wide default. Routing/key follow the model id.
        $model = trim((string) ($s['builder_model'] ?? '')) ?: (string) ($s['default_model'] ?? 'gpt-5-mini');
        $provider = Agent_Provider::provider_for_model($model);
        list($key, $missing) = self::resolve_key($provider, $s);
        if ($key === '') {
            return ['ok' => false, 'error' => $missing];
        }

        // v5.7.9: the Build Assistant control panel can switch each write power
        // off independently. Keys absent (installs that predate the panel and
        // haven't re-saved settings) are treated as enabled so behaviour is
        // unchanged until an admin deliberately turns one off.
        $allow_tpl  = !isset($s['builder_allow_template']) || !empty($s['builder_allow_template']);
        $allow_post = !isset($s['builder_allow_post']) || !empty($s['builder_allow_post']);
        $can_create = Agent_Actions::can_create_template() && $allow_tpl;
        $can_post   = Agent_Actions::can_create_post() && $allow_post;

        // v5.7.9: the base instructions are editable in the Build Assistant
        // control panel. A blank override keeps the built-in default. The
        // tool-orchestration sections below are ALWAYS appended by the server
        // (and only when the matching write power is on) so the draft-only rules
        // and the Result-blocks question can't be lost by an edited base prompt.
        $custom = trim((string) ($s['builder_system_prompt'] ?? ''));
        $system = $custom !== '' ? $custom : self::default_builder_system_prompt();

        if ($can_create) {
            $system .= "\n\n" . self::effective_template_instructions($s);
            $blocks_brief = self::result_blocks_brief();
            if ($blocks_brief !== '') {
                $system .= "\n\n" . $blocks_brief;
            }
        }
        if ($can_post) {
            $system .= "\n\n" . self::effective_post_instructions($s);
        }
        if (!$can_create && !$can_post) {
            $system .= "\n\n" . trim(self::builder_advise_only_instructions());
        }

        $tools = [[
            'name'        => 'list_templates',
            'description' => 'List the AI generator templates that already exist on this site, with their id, title and model.',
            'parameters'  => ['type' => 'object', 'properties' => new \stdClass(), 'additionalProperties' => false],
        ]];
        if ($can_create) {
            $tools[] = Agent_Actions::create_template_tool_def();
        }
        if ($can_post) {
            $tools[] = Agent_Actions::create_post_tool_def();
        }
        $executor = static function (string $name, array $args) use ($can_create, $can_post) {
            if ($name === 'list_templates') {
                return self::list_templates_summary();
            }
            if ($name === Agent_Actions::TOOL_CREATE_TEMPLATE) {
                return $can_create
                    ? Agent_Actions::create_template($args)
                    : __('You do not have permission to create templates.', 'authorwings-ai-tools');
            }
            if ($name === Agent_Actions::TOOL_CREATE_POST) {
                return $can_post
                    ? Agent_Actions::create_post($args)
                    : __('You do not have permission to create posts.', 'authorwings-ai-tools');
            }
            return __('Unknown tool.', 'authorwings-ai-tools');
        };

        $timeout = max(20, (int) ($s['timeout'] ?? 45));
        // v5.7.9: response length is admin-configurable (Build Assistant panel).
        // Out-of-range or absent values fall back to the 2000 default.
        $max_tokens = (int) ($s['builder_max_tokens'] ?? 0);
        if ($max_tokens < 256) {
            $max_tokens = 2000;
        }
        $max_tokens = min(8000, $max_tokens);
        return Agent_Provider::chat($provider, $key, $model, $system, $history, $tools, $executor, $max_tokens, $timeout, null, $images);
    }

    /* ------------------------------------------------------------------ *
     * Build Assistant prompt sections (viewable/editable in the admin)
     * ------------------------------------------------------------------ */

    /**
     * The built-in base instructions for the Build Assistant. This is the part an
     * admin may override from Settings → Build Assistant; the tool-orchestration
     * sections below are appended automatically and are not editable.
     */
    public static function default_builder_system_prompt(): string {
        return "You are the AuthorWings AI build assistant, embedded in the WordPress admin. "
            . "You help the site owner design AI generator tools and conversational agents for the "
            . "AuthorWings AI plugin. You know the plugin's building blocks: each tool is a template "
            . "with input fields, a System Prompt, a User Prompt (using {{fields}}, {{task}}, {{count}}, "
            . "{{rules}} placeholders), a model, and a result style. When asked, propose concrete field "
            . "lists, system prompts and user prompts the owner can paste straight into the Template "
            . "editor. Use the list_templates tool when it helps to reference what already exists. "
            . "The owner may attach files to a message: images are shown to you directly (a "
            . "screenshot of a design, a mockup, an example tool), and documents are provided as "
            . "extracted text. Use whatever is attached to inform your suggestions. "
            . "Be practical and concise.";
    }

    /** Auto-appended when the user may create templates. Not editable. */
    public static function builder_template_instructions(): string {
        return " You can also CREATE a generator template directly: once you and the user have "
            . "agreed on the design, call create_generator_template to save it. You set the on-page wording "
            . "and structure: title, form title & description, button label, the input fields (including "
            . "file-upload fields), the {{count}} default, result heading, output placeholder, "
            . "disclaimer/helper text, an optional Dashicons title icon class, and the system prompt, user "
            . "prompt and rules. Do NOT set the model or the output format — leave those at the site "
            . "defaults (the tool does not accept them). "
            . "IMPORTANT: every time, before you create a template, ASK the user ONE simple yes/no question: "
            . "\"Do you want this tool to use Result blocks (Editorial), so its output can include things like "
            . "option cards, checklists, scorecards, before/after and callouts?\" If they say NO, set "
            . "use_result_blocks=false and leave result_blocks empty. If they say YES, set "
            . "use_result_blocks=true and put in result_blocks the keys of ONLY the blocks that genuinely fit "
            . "this tool's purpose — not the whole list. The server expands those keys into the right Rules "
            . "instructions automatically, so keep the rules argument short and never paste block text yourself. "
            . "Confirm the key details (title, what it does, the input fields) too, then create. "
            . "The new template is saved as a DRAFT — never claim it is live or published; after creating, "
            . "give the user the edit link the tool returns so they can review and publish it themselves.";
    }

    /** Auto-appended when the user may create posts. Not editable. */
    public static function builder_post_instructions(): string {
        return " You can also create a WordPress blog post with create_post, built from Gutenberg "
            . "blocks (paragraph, heading, list, quote). It saves a DRAFT by default — only publish when "
            . "the user explicitly asks. Confirm the topic and angle first, then return the edit link.";
    }

    /** Auto-appended when the user has no write powers. Not editable. */
    public static function builder_advise_only_instructions(): string {
        return " You only advise — never claim to have changed any settings or created anything.";
    }

    /**
     * Effective template-creation rules: the admin override if set, otherwise the
     * built-in default. The hard guarantees (draft-only insert, capability check,
     * server-side block expansion) live in Agent_Actions and apply regardless of
     * this text — so editing it can only change how the assistant behaves, never
     * whether the result is safe.
     */
    public static function effective_template_instructions(array $s): string {
        $o = trim((string) ($s['builder_template_prompt'] ?? ''));
        return $o !== '' ? $o : trim(self::builder_template_instructions());
    }

    /** Effective post-creation rules: admin override if set, else the default. */
    public static function effective_post_instructions(array $s): string {
        $o = trim((string) ($s['builder_post_prompt'] ?? ''));
        return $o !== '' ? $o : trim(self::builder_post_instructions());
    }

    /**
     * The full system prompt the Build Assistant would send, for a read-only
     * preview in the admin. Mirrors chat_for_builder()'s assembly: the (custom or
     * default) base, then every auto-appended section that the current user's
     * write powers would include.
     */
    public static function builder_prompt_preview(): string {
        $s = self::settings();
        $custom = trim((string) ($s['builder_system_prompt'] ?? ''));
        $system = $custom !== '' ? $custom : self::default_builder_system_prompt();

        $allow_tpl  = !isset($s['builder_allow_template']) || !empty($s['builder_allow_template']);
        $allow_post = !isset($s['builder_allow_post']) || !empty($s['builder_allow_post']);
        $can_create = Agent_Actions::can_create_template() && $allow_tpl;
        $can_post   = Agent_Actions::can_create_post() && $allow_post;

        if ($can_create) {
            $system .= "\n\n" . self::effective_template_instructions($s);
            $brief = self::result_blocks_brief();
            if ($brief !== '') {
                $system .= "\n\n" . $brief;
            }
        }
        if ($can_post) {
            $system .= "\n\n" . self::effective_post_instructions($s);
        }
        if (!$can_create && !$can_post) {
            $system .= "\n\n" . trim(self::builder_advise_only_instructions());
        }
        return $system;
    }

    /**
     * Compact key reference for the create_generator_template tool's result_blocks
     * argument: one short line per block (key — label: when to use). Just enough
     * for the model to pick the fitting keys; the full instruction text stays
     * server-side in Agent_Actions. Returns '' if the palette is unavailable.
     */
    private static function result_blocks_brief(): string {
        if (!class_exists('\\AWG_AIG\\Metabox') || !method_exists('\\AWG_AIG\\Metabox', 'result_blocks_palette')) {
            return '';
        }
        $palette = \AWG_AIG\Metabox::result_blocks_palette();
        if (!is_array($palette) || empty($palette)) {
            return '';
        }
        $items = [];
        foreach ($palette as $group) {
            if (!is_array($group)) continue;
            foreach ((array) ($group['blocks'] ?? []) as $bkey => $b) {
                if (!is_array($b)) continue;
                $bkey  = trim((string) $bkey);
                $label = trim((string) ($b['label'] ?? ''));
                $desc  = trim((string) ($b['desc'] ?? ''));
                if ($bkey === '') continue;
                $items[] = '- ' . $bkey . ($label !== '' ? ' (' . $label . ')' : '') . ($desc !== '' ? ' — ' . $desc : '');
            }
        }
        if (empty($items)) {
            return '';
        }
        return "RESULT BLOCK KEYS for the result_blocks argument — choose ONLY the keys that fit the tool you are "
            . "creating (omit the rest); the server adds their instructions to the Rules:\n" . implode("\n", $items);
    }

    /* ------------------------------------------------------------------ *
     * System prompt
     * ------------------------------------------------------------------ */

    /** Public accessor used by the streaming endpoint (no-tools fast path). */
    public static function build_system_prompt_public(array $meta, array $s, int $agent_id): string {
        return self::build_system_prompt($meta, $s, $agent_id);
    }

    private static function build_system_prompt(array $meta, array $s, int $agent_id): string {
        $parts = [];

        $apply_global = !empty($meta['apply_global_prompt']);
        $global = trim((string) apply_filters('awg_aig_global_prompt', (string) ($s['global_prompt'] ?? ''), $agent_id));
        if ($apply_global && $global !== '') {
            $parts[] = $global;
        }

        $instructions = trim((string) $meta['instructions']);
        if ($instructions !== '') {
            $parts[] = $instructions;
        }

        // Knowledge blurb: pasted business/site facts injected verbatim (capped).
        $knowledge_text = trim((string) ($meta['knowledge_text'] ?? ''));
        if ($knowledge_text !== '') {
            if (strlen($knowledge_text) > 6000) {
                $knowledge_text = substr($knowledge_text, 0, 6000);
            }
            // v5.7.9: the prefix line is editable per agent (blank = default).
            $prefix = trim((string) ($meta['knowledge_prefix'] ?? '')) ?: self::default_agent_knowledge_prefix();
            $parts[] = $prefix . "\n" . $knowledge_text;
        }

        if (!empty($meta['tool_ids']) || !empty($meta['knowledge_enabled'])) {
            // v5.7.9: the tools nudge is editable per agent (blank = default).
            $parts[] = trim((string) ($meta['tools_nudge'] ?? '')) ?: self::default_agent_tools_nudge();
        }

        $system = implode("\n\n", $parts);
        return (string) apply_filters('awg_agent_system_prompt', $system, $agent_id, $meta);
    }

    /** Default prefix shown above an agent's pasted Knowledge facts. Editable per agent. */
    public static function default_agent_knowledge_prefix(): string {
        return 'Reference knowledge about this site/business (treat as authoritative):';
    }

    /** Default tool-use nudge added when an agent has tools or knowledge. Editable per agent. */
    public static function default_agent_tools_nudge(): string {
        return "You have access to tools. Prefer calling a tool over guessing whenever a request "
            . "matches one. Collect the required inputs from the conversation first; if something is "
            . "missing, ask the user one short question. After a tool runs, summarise or present its "
            . "result clearly — never fabricate or alter what a tool returned.";
    }

    /* ------------------------------------------------------------------ *
     * Template-as-tool plumbing
     * ------------------------------------------------------------------ */

    /**
     * Build provider-agnostic tool definitions from a list of template ids.
     * @return array{defs:array,map:array<string,int>}
     */
    public static function build_template_tools(array $tool_ids): array {
        $defs = [];
        $map  = [];
        $renderer = Plugin::instance()->renderer;

        foreach ($tool_ids as $tid) {
            $tid = (int) $tid;
            $post = get_post($tid);
            if (!$post || $post->post_type !== Plugin::CPT || $post->post_status !== 'publish') {
                continue;
            }
            $m = $renderer->get_template_meta($tid);
            $name = 'tool_' . $tid;

            $title = (string) get_the_title($tid);
            $hint  = trim((string) ($m['task'] ?? ''));
            if ($hint === '') {
                $hint = trim(wp_strip_all_tags((string) ($m['system_prompt'] ?? '')));
            }
            $hint = self::shorten($hint, 240);
            $description = $title !== '' ? $title : 'AI tool';
            if ($hint !== '') {
                $description .= ' — ' . $hint;
            }

            $defs[] = [
                'name'        => $name,
                'description' => self::shorten($description, 360),
                'parameters'  => self::fields_to_schema(is_array($m['fields'] ?? null) ? $m['fields'] : []),
            ];
            $map[$name] = $tid;
        }

        return ['defs' => $defs, 'map' => $map];
    }

    /** Convert a template's field schema into a JSON-Schema object for tool args. */
    public static function fields_to_schema(array $fields): array {
        $properties = [];
        $required   = [];

        foreach ($fields as $f) {
            if (!is_array($f)) continue;
            $key = sanitize_key((string) ($f['key'] ?? ''));
            if ($key === '') continue;
            $type = (string) ($f['type'] ?? 'text');
            if ($type === 'file') continue; // chat can't carry binaries.

            $label = (string) ($f['label'] ?? $key);
            $prop  = ['description' => $label];

            $options = self::parse_options((string) ($f['options'] ?? ''));
            if ($type === 'number') {
                $prop['type'] = 'number';
            } elseif (in_array($type, ['select', 'radio'], true) && !empty($options)) {
                $prop['type'] = 'string';
                $prop['enum'] = $options;
            } else {
                $prop['type'] = 'string';
                if (!empty($options)) {
                    $prop['description'] = $label . ' (options: ' . implode(', ', $options) . ')';
                }
            }

            $properties[$key] = $prop;
            if (!empty($f['required'])) {
                $required[] = $key;
            }
        }

        $schema = [
            'type'                 => 'object',
            'properties'           => empty($properties) ? new \stdClass() : $properties,
            'additionalProperties' => false,
        ];
        if (!empty($required)) {
            $schema['required'] = array_values(array_unique($required));
        }
        return $schema;
    }

    /**
     * Execute a template tool: assemble its prompt with the supplied arguments
     * and make a single-shot provider call. Returns the model's text (or a short
     * error string the agent can relay). Mirrors the core generate() prompt
     * assembly, minus the front-end-only gates (already enforced at agent level).
     */
    public static function run_template_tool(int $tid, array $args): string {
        $renderer = Plugin::instance()->renderer;
        $s = self::settings();

        $post = get_post($tid);
        if (!$post || $post->post_type !== Plugin::CPT || $post->post_status !== 'publish') {
            return __('That tool is unavailable.', 'authorwings-ai-tools');
        }
        $m = $renderer->get_template_meta($tid);

        // Map the model-supplied args onto the template's field keys.
        $submitted = [];
        foreach ((array) ($m['fields'] ?? []) as $f) {
            if (!is_array($f)) continue;
            $key = sanitize_key((string) ($f['key'] ?? ''));
            if ($key === '' || ($f['type'] ?? '') === 'file') continue;
            $val = $args[$key] ?? '';
            if (is_array($val)) {
                $val = implode(', ', array_map('strval', $val));
            }
            $val = (string) $val;
            $submitted[$key] = (strpos($val, "\n") !== false)
                ? sanitize_textarea_field($val)
                : sanitize_text_field($val);
        }

        $fields_text = $renderer->fields_to_text((array) ($m['fields'] ?? []), $submitted);
        if ($fields_text === '') $fields_text = '(No inputs provided)';

        $system = (string) ($m['system_prompt'] ?? '');
        $apply_global = !isset($m['apply_global_prompt']) || !empty($m['apply_global_prompt']);
        $global = trim((string) apply_filters('awg_aig_global_prompt', (string) ($s['global_prompt'] ?? ''), $tid));
        if ($apply_global && $global !== '') {
            $system = ($system === '') ? $global : ($global . "\n\n" . $system);
        }

        $task  = (string) ($m['task'] ?? '');
        $count = (string) (int) ($m['count'] ?? 0);
        $rules = str_replace(['{{task}}', '{{count}}'], [$task, $count], (string) ($m['rules'] ?? ''));
        $user  = str_replace(
            ['{{task}}', '{{count}}', '{{fields}}', '{{rules}}'],
            [$task, $count, $fields_text, $rules],
            (string) ($m['user_prompt'] ?? '')
        );
        if (trim($user) === '') $user = $fields_text;

        $model = trim((string) ($m['model'] ?? ''));
        if ($model === '') $model = (string) ($s['default_model'] ?? 'gpt-5-mini');
        $provider = Agent_Provider::provider_for_model($model);
        list($key, $missing) = self::resolve_key($provider, $s);
        if ($key === '') return $missing;

        $timeout = max(20, (int) ($s['timeout'] ?? 45));
        $max_tokens = (int) ($m['max_output_tokens'] ?? 800);

        $resp = Agent_Provider::complete($provider, $key, $model, $system, $user, $max_tokens, $timeout);
        if (empty($resp['ok'])) {
            return (string) ($resp['error'] ?? __('The tool could not complete.', 'authorwings-ai-tools'));
        }
        return (string) $resp['text'];
    }

    /* ------------------------------------------------------------------ *
     * Helpers
     * ------------------------------------------------------------------ */

    private static function list_templates_summary(): string {
        $renderer = Plugin::instance()->renderer;
        $posts = get_posts([
            'post_type'      => Plugin::CPT,
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ]);
        if (empty($posts)) {
            return __('No generator templates exist yet.', 'authorwings-ai-tools');
        }
        $lines = [];
        foreach ($posts as $p) {
            $m = $renderer->get_template_meta($p->ID);
            $model = trim((string) ($m['model'] ?? '')) ?: '(default model)';
            $lines[] = sprintf('#%d "%s" — model: %s', $p->ID, get_the_title($p->ID), $model);
        }
        return implode("\n", $lines);
    }

    private static function parse_options(string $raw): array {
        $opts = preg_split('/[\r\n,]+/', $raw) ?: [];
        $opts = array_map('trim', $opts);
        $opts = array_values(array_filter($opts, static function ($o) { return $o !== ''; }));
        return array_map('sanitize_text_field', $opts);
    }

    private static function shorten(string $text, int $max): string {
        $text = trim(preg_replace('/\s+/', ' ', $text));
        if (function_exists('mb_strlen') && mb_strlen($text) > $max) {
            return rtrim(mb_substr($text, 0, $max - 1)) . '…';
        }
        if (strlen($text) > $max) {
            return rtrim(substr($text, 0, $max - 1)) . '…';
        }
        return $text;
    }
}
