<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

require_once __DIR__ . '/class-agent.php';
require_once __DIR__ . '/class-agent-gate.php';
require_once __DIR__ . '/class-agent-text-extractor.php';
require_once __DIR__ . '/class-agent-knowledge.php';
require_once __DIR__ . '/class-agent-actions.php';
require_once __DIR__ . '/class-agent-provider.php';
require_once __DIR__ . '/class-agent-runtime.php';
require_once __DIR__ . '/class-agent-threads.php';
require_once __DIR__ . '/class-agent-upload.php';
require_once __DIR__ . '/class-agent-metabox.php';
require_once __DIR__ . '/class-agent-renderer.php';
require_once __DIR__ . '/class-agent-block.php';
require_once __DIR__ . '/class-agent-ajax.php';
require_once __DIR__ . '/class-agent-admin.php';

/**
 * Agent subsystem bootstrap. Instantiates the pieces and registers their hooks.
 * Loaded from the main plugin file on plugins_loaded, after the core Plugin
 * singleton exists (the runtime reads Plugin::instance()->renderer).
 */
final class Bootstrap {

    private static $booted = false;

    public static function init(): void {
        if (self::$booted) return;
        self::$booted = true;

        // Conversation-memory tables (idempotent; self-heals if missing).
        Agent_Threads::maybe_install();

        $cpt      = new Agent();
        $metabox  = new Agent_Metabox();
        $renderer = new Agent_Renderer();
        $block    = new Agent_Block($renderer);
        $ajax     = new Agent_Ajax();
        $upload   = new Agent_Upload();
        $threads  = new Agent_Threads();
        $admin    = new Agent_Admin();

        add_action('init', [$cpt, 'register']);
        add_action('init', [$renderer, 'register']);
        add_action('init', [$block, 'register']);

        add_action('add_meta_boxes', [$metabox, 'register']);
        add_action('save_post', [$metabox, 'save'], 10, 2);
        add_action('admin_enqueue_scripts', [$metabox, 'enqueue']);

        $ajax->register();
        $upload->register();
        $threads->register();
        $admin->register();
    }
}
