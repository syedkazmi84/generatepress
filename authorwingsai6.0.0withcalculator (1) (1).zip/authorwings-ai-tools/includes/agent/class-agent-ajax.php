<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

/**
 * AJAX endpoints for agent conversations.
 *
 *  - awg_agent_chat         public/member chat turn (JSON).
 *  - awg_agent_chat_stream  same, streamed token-by-token over SSE.
 *  - awg_agent_admin_chat   admin-only build assistant.
 *
 * Gating mirrors the core generator (Agent_Gate): guest policy, per-IP rate
 * buckets, membership filter and the site-wide daily cap, so an agent turn is
 * billed and limited exactly like a generation. Attachments (Agent_Upload) and
 * conversation memory (Agent_Threads) are woven into both chat paths.
 */
final class Agent_Ajax {

    const MAX_HISTORY = 20;
    const MAX_CHARS   = 8000;

    public function register(): void {
        add_action('wp_ajax_awg_agent_chat', [$this, 'chat']);
        add_action('wp_ajax_nopriv_awg_agent_chat', [$this, 'chat']);
        add_action('wp_ajax_awg_agent_chat_stream', [$this, 'chat_stream']);
        add_action('wp_ajax_nopriv_awg_agent_chat_stream', [$this, 'chat_stream']);
        add_action('wp_ajax_awg_agent_admin_chat', [$this, 'admin_chat']);
    }

    /* ------------------------------------------------------------------ *
     * Non-streaming chat
     * ------------------------------------------------------------------ */

    public function chat(): void {
        $r = $this->prepare();
        if (empty($r['ok'])) {
            wp_send_json_error($r['data'], $r['status']);
        }

        $resp = Agent_Runtime::chat_for_agent($r['agent_id'], $r['meta'], $r['history'], null, $r['images'] ?? []);
        if (empty($resp['ok'])) {
            $debug = (current_user_can('manage_options') && !empty($r['meta']['debug_admin'])) ? ($resp['raw'] ?? null) : null;
            wp_send_json_error([
                'message' => $resp['error'] ?? __('The assistant could not reply. Please try again.', 'authorwings-ai-tools'),
                'debug'   => $debug,
            ], 500);
        }

        $text = (string) $resp['text'];
        $this->record_usage($r['agent_id'], $text, $r['settings']);
        $thread_id = Agent_Threads::record_turn($r['agent_id'], $r['thread_id'], $r['last_user'], $text);

        wp_send_json_success([
            'text'       => $text,
            'tools_used' => isset($resp['tools_used']) ? array_values((array) $resp['tools_used']) : [],
            'thread_id'  => $thread_id,
        ]);
    }

    /* ------------------------------------------------------------------ *
     * Streaming chat (Server-Sent Events)
     * ------------------------------------------------------------------ */

    public function chat_stream(): void {
        $r = $this->prepare();

        $this->stream_open();

        if (empty($r['ok'])) {
            $this->sse('error', $r['data']);
            exit;
        }

        $meta = $r['meta'];
        $has_tools = !empty($meta['tool_ids']) || !empty($meta['knowledge_enabled']);
        $has_images = !empty($r['images']);

        // Token streaming can't carry image inputs, so any turn with an image is
        // answered through the full (vision-capable) chat path below.
        if (!$has_tools && !$has_images) {
            // Pure chat → real token streaming.
            $s = $r['settings'];
            $model = $meta['model'] !== '' ? $meta['model'] : (string) ($s['default_model'] ?? 'gpt-5-mini');
            $provider = Agent_Provider::provider_for_model($model);
            list($key, $missing) = Agent_Runtime::resolve_key($provider, $s);
            if ($key === '') {
                $this->sse('error', ['message' => $missing]);
                exit;
            }
            $system = Agent_Runtime::build_system_prompt_public($meta, $s, $r['agent_id']);
            $timeout = max(20, (int) ($s['timeout'] ?? 45));

            $self = $this;
            $resp = Agent_Provider::stream_complete($provider, $key, $model, $system, $r['history'], (int) $meta['max_tokens'], $timeout, function ($delta) use ($self) {
                $self->sse('delta', ['text' => $delta]);
            });

            if (empty($resp['ok'])) {
                $payload = ['message' => $resp['error'] ?? __('The assistant could not reply.', 'authorwings-ai-tools')];
                if (!empty($resp['fallback'])) $payload['fallback'] = true;
                $this->sse('error', $payload);
                exit;
            }

            $text = (string) $resp['text'];
            $this->record_usage($r['agent_id'], $text, $s);
            $thread_id = Agent_Threads::record_turn($r['agent_id'], $r['thread_id'], $r['last_user'], $text);
            $this->sse('done', ['text' => $text, 'tools_used' => [], 'thread_id' => $thread_id]);
            exit;
        }

        // Tool-using turn → run the loop, surface "Using X…" status, then deliver.
        $self = $this;
        $on_event = function ($type, $value) use ($self) {
            if ($type === 'tool') {
                $self->sse('status', ['label' => Agent_Runtime::tool_label((string) $value)]);
            }
        };
        $resp = Agent_Runtime::chat_for_agent($r['agent_id'], $meta, $r['history'], $on_event, $r['images'] ?? []);

        if (empty($resp['ok'])) {
            $payload = ['message' => $resp['error'] ?? __('The assistant could not reply.', 'authorwings-ai-tools')];
            if (current_user_can('manage_options') && !empty($meta['debug_admin']) && isset($resp['raw'])) {
                $payload['debug'] = $resp['raw'];
            }
            $this->sse('error', $payload);
            exit;
        }

        $text = (string) $resp['text'];
        $this->record_usage($r['agent_id'], $text, $r['settings']);
        $thread_id = Agent_Threads::record_turn($r['agent_id'], $r['thread_id'], $r['last_user'], $text);
        $this->sse('done', [
            'text'       => $text,
            'tools_used' => isset($resp['tools_used']) ? array_values((array) $resp['tools_used']) : [],
            'thread_id'  => $thread_id,
        ]);
        exit;
    }

    /* ------------------------------------------------------------------ *
     * Admin build assistant
     * ------------------------------------------------------------------ */

    public function admin_chat(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'authorwings-ai-tools')], 403);
        }
        // v5.7.9: respect the Build Assistant master switch.
        if (!Agent_Admin::builder_enabled()) {
            wp_send_json_error(['message' => __('The Build Assistant is disabled.', 'authorwings-ai-tools')], 403);
        }
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash((string) $_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'awg_agent_admin')) {
            wp_send_json_error(['message' => __('Invalid request.', 'authorwings-ai-tools')], 403);
        }

        $history = $this->parse_messages();
        if (empty($history)) {
            wp_send_json_error(['message' => __('Please enter a message.', 'authorwings-ai-tools')], 400);
        }

        // Fold any attached documents into the last user turn; hand images to the
        // vision-capable model alongside the conversation.
        $images = [];
        $attached = $this->collect_attachments();
        if ($attached['text'] !== '') {
            $idx = count($history) - 1;
            $history[$idx]['content'] = $history[$idx]['content'] . "\n\n" . $attached['text'];
        }
        $images = $attached['images'];

        $resp = Agent_Runtime::chat_for_builder($history, $images);
        if (empty($resp['ok'])) {
            wp_send_json_error(['message' => $resp['error'] ?? __('The assistant could not reply.', 'authorwings-ai-tools')], 500);
        }
        wp_send_json_success(['text' => (string) $resp['text']]);
    }

    /* ------------------------------------------------------------------ *
     * Shared pre-flight
     * ------------------------------------------------------------------ */

    /**
     * Validate + gate a chat request and assemble everything a turn needs.
     * Returns ['ok'=>true, agent_id, meta, settings, history, last_user, thread_id]
     * or ['ok'=>false, 'status'=>int, 'data'=>array].
     */
    private function prepare(): array {
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash((string) $_POST['nonce'])) : '';
        if (!wp_verify_nonce($nonce, 'awg_agent_front')) {
            return $this->err(403, ['message' => __('Invalid request.', 'authorwings-ai-tools')]);
        }

        $agent_id = (int) ($_POST['agent_id'] ?? 0);
        if ($agent_id <= 0) {
            return $this->err(400, ['message' => __('Invalid agent.', 'authorwings-ai-tools')]);
        }
        $post = get_post($agent_id);
        if (!$post || $post->post_type !== Agent::CPT) {
            return $this->err(404, ['message' => __('Agent not found.', 'authorwings-ai-tools')]);
        }
        $can_preview = is_user_logged_in() && current_user_can('edit_post', $agent_id);
        if ($post->post_status !== 'publish' && !$can_preview) {
            return $this->err(404, ['message' => __('Agent not found.', 'authorwings-ai-tools')]);
        }

        $meta = Agent::get_meta($agent_id);
        $s = Agent_Runtime::settings();

        $allow = ((int) $meta['allow_guests'] === -1) ? (int) ($s['allow_guests'] ?? 1) : (int) $meta['allow_guests'];
        if (!$allow && !is_user_logged_in()) {
            return $this->err(403, ['message' => __('Please log in to chat with this assistant.', 'authorwings-ai-tools')]);
        }

        if (!Agent_Gate::rate_ok($agent_id, (int) $meta['rate_per_min'], (int) ($s['global_rate_per_min'] ?? 10))) {
            return $this->err(429, ['message' => __('Rate limit exceeded. Try again in a minute.', 'authorwings-ai-tools')]);
        }

        $gate = Agent_Gate::membership($agent_id);
        if ($gate !== true) {
            return $this->err($gate['status'], $gate['data']);
        }

        if (Agent_Gate::global_cap_reached((int) ($s['global_daily_cap'] ?? 0))) {
            return $this->err(429, ['message' => __('This assistant has reached today’s overall usage limit. Please try again tomorrow.', 'authorwings-ai-tools')]);
        }

        $history = $this->parse_messages();
        if (empty($history)) {
            return $this->err(400, ['message' => __('Please enter a message.', 'authorwings-ai-tools')]);
        }

        // The user's typed text (for thread persistence) before any attachment
        // text is folded into the model-facing message.
        $tail = end($history);
        $last_user = is_array($tail) ? (string) $tail['content'] : '';

        $images = [];
        if (!empty($meta['allow_uploads'])) {
            $attached = $this->collect_attachments();
            if ($attached['text'] !== '') {
                $idx = count($history) - 1;
                $history[$idx]['content'] = $history[$idx]['content'] . "\n\n" . $attached['text'];
            }
            $images = $attached['images'];
        }

        $thread_id = (int) ($_POST['thread_id'] ?? 0);

        return [
            'ok'        => true,
            'agent_id'  => $agent_id,
            'meta'      => $meta,
            'settings'  => $s,
            'history'   => $history,
            'images'    => $images,
            'last_user' => $last_user,
            'thread_id' => $thread_id,
        ];
    }

    private function err(int $status, array $data): array {
        return ['ok' => false, 'status' => $status, 'data' => $data];
    }

    /**
     * Read the conversation from POST['messages'] (JSON). Sanitises every turn,
     * caps history length + per-message size, and guarantees the last turn is a
     * user message.
     */
    private function parse_messages(): array {
        $raw = isset($_POST['messages']) ? wp_unslash((string) $_POST['messages']) : '';
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) return [];

        $clean = [];
        foreach ($decoded as $m) {
            if (!is_array($m)) continue;
            $role = ($m['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
            $content = isset($m['content']) ? (string) $m['content'] : '';
            $content = sanitize_textarea_field($content);
            if (trim($content) === '') continue;
            if (strlen($content) > self::MAX_CHARS) {
                $content = substr($content, 0, self::MAX_CHARS);
            }
            $clean[] = ['role' => $role, 'content' => $content];
        }

        if (count($clean) > self::MAX_HISTORY) {
            $clean = array_slice($clean, -self::MAX_HISTORY);
        }
        while (!empty($clean) && end($clean)['role'] === 'assistant') {
            array_pop($clean);
        }
        return array_values($clean);
    }

    /**
     * Resolve POST['attachments'] (JSON array of upload tokens) into a reference
     * text block (documents/video) and base64 image parts (for vision models).
     *
     * @return array{text:string,images:array}
     */
    private function collect_attachments(): array {
        $raw = isset($_POST['attachments']) ? wp_unslash((string) $_POST['attachments']) : '';
        $tokens = json_decode($raw, true);
        if (!is_array($tokens)) return ['text' => '', 'images' => []];
        return Agent_Upload::collect($tokens);
    }

    /* ------------------------------------------------------------------ *
     * Usage metering
     * ------------------------------------------------------------------ */

    private function record_usage(int $agent_id, string $text, array $s): void {
        $count = (int) get_post_meta($agent_id, '_awg_aig_usage_count', true) + 1;
        update_post_meta($agent_id, '_awg_aig_usage_count', $count);
        update_post_meta($agent_id, '_awg_aig_last_generated', current_time('mysql'));

        if ((int) ($s['global_daily_cap'] ?? 0) > 0) {
            Agent_Gate::global_cap_bump();
        }
        do_action('awg_aig_generated', get_current_user_id(), $agent_id, $text);
    }

    /* ------------------------------------------------------------------ *
     * SSE transport
     * ------------------------------------------------------------------ */

    private function stream_open(): void {
        if (function_exists('ignore_user_abort')) { @ignore_user_abort(true); }
        @ini_set('zlib.output_compression', '0');
        @ini_set('output_buffering', '0');
        @ini_set('implicit_flush', '1');
        while (ob_get_level() > 0) { @ob_end_flush(); }

        if (!headers_sent()) {
            header('Content-Type: text/event-stream; charset=utf-8');
            header('Cache-Control: no-cache, no-store, must-revalidate');
            header('Pragma: no-cache');
            header('Connection: keep-alive');
            header('X-Accel-Buffering: no');
        }
        echo ':' . str_repeat(' ', 2048) . "\n\n";
        @flush();
    }

    /** Public so streaming callbacks can reach it; emits one SSE event. */
    public function sse(string $event, array $data): void {
        echo 'event: ' . $event . "\n";
        echo 'data: ' . wp_json_encode($data) . "\n\n";
        @flush();
    }
}
