<?php
namespace AWG_AIG\Agent;

use AWG_AIG\Plugin;

if (!defined('ABSPATH')) { exit; }

/**
 * Write actions an agent may perform on the site.
 *
 * Unlike the read-only template tools and the search_site knowledge tool, these
 * tools change the database, so every one is guarded hard:
 *
 *   - Capability gated. create_generator_template requires the same capability
 *     the template CPT itself requires (manage_options — see CPT::register),
 *     re-checked inside the executor as defence-in-depth even though the only
 *     caller today (the admin Build Assistant) is already manage_options-gated.
 *   - Always creates a DRAFT. The tool never publishes; the owner reviews the
 *     generated template in the editor and publishes it deliberately.
 *   - Bound to the current user as author, and audit-logged.
 *
 * Phase 1 ships create_generator_template only. Other write tools (create_post,
 * media sideload, …) would live here behind the same gate.
 */
final class Agent_Actions {

    const TOOL_CREATE_TEMPLATE = 'create_generator_template';
    const TOOL_CREATE_POST     = 'create_post';

    /** Whether the current user is allowed to create generator templates. */
    public static function can_create_template(): bool {
        // Templates are locked to manage_options in CPT::register(); mirror that.
        return current_user_can('manage_options');
    }

    /** Whether the current user may create blog posts. */
    public static function can_create_post(): bool {
        return current_user_can('edit_posts');
    }

    /** Provider-agnostic tool definition for create_generator_template. */
    public static function create_template_tool_def(): array {
        return [
            'name'        => self::TOOL_CREATE_TEMPLATE,
            'description' => 'Create a new AI generator template (saved as a DRAFT for the owner to review and publish). '
                . 'Use this only after you and the user have agreed on the design AND you have asked the yes/no '
                . 'question about Result blocks (Editorial). Supply the prompts, the on-page wording (form '
                . 'title/description, button label, result heading, etc.), the input fields, and use_result_blocks. '
                . 'Keep the rules field SHORT — never paste block instructions into it; the server adds them when '
                . 'use_result_blocks is true. Do NOT set the model or output format — those are left at the site '
                . 'defaults. Returns the new template id and its edit-screen link.',
            'parameters'  => [
                'type'       => 'object',
                'properties' => [
                    'title' => [
                        'type'        => 'string',
                        'description' => 'Admin title for the template (e.g. "Book Blurb Writer"). Also used as the on-page Form Title when none is given.',
                    ],
                    'form_title' => [
                        'type'        => 'string',
                        'description' => 'On-page heading shown above the form. Defaults to the title.',
                    ],
                    'form_description' => [
                        'type'        => 'string',
                        'description' => 'Short sub-heading under the form title describing what the tool does for the visitor.',
                    ],
                    'button_label' => [
                        'type'        => 'string',
                        'description' => 'Text on the submit button (e.g. "Generate", "Write my blurb"). Defaults to "Generate".',
                    ],
                    'task' => [
                        'type'        => 'string',
                        'description' => 'One-line description of what the tool does, used in the {{task}} placeholder.',
                    ],
                    'system_prompt' => [
                        'type'        => 'string',
                        'description' => 'The System Prompt that sets the model\'s role and constraints.',
                    ],
                    'user_prompt' => [
                        'type'        => 'string',
                        'description' => 'The User Prompt. May use {{task}}, {{fields}}, {{rules}} and {{count}} placeholders. Leave blank to use the default template.',
                    ],
                    'rules' => [
                        'type'        => 'string',
                        'description' => 'Newline-separated rules injected into {{rules}}.',
                    ],
                    'count' => [
                        'type'        => 'number',
                        'description' => 'Default for the {{count}} placeholder — "How many results?" (1–50).',
                    ],
                    'success_title' => [
                        'type'        => 'string',
                        'description' => 'Result Heading shown above the generated output (e.g. "Result", "Your blurb"). Defaults to "Result".',
                    ],
                    'placeholder_output' => [
                        'type'        => 'string',
                        'description' => 'Output Placeholder text shown in the result area before anything is generated.',
                    ],
                    'disclaimer_text' => [
                        'type'        => 'string',
                        'description' => 'Disclaimer / helper text shown near the form (e.g. a review-before-publishing note).',
                    ],
                    'title_icon_class' => [
                        'type'        => 'string',
                        'description' => 'Optional Dashicons class for the title icon, e.g. "dashicons dashicons-book" or "dashicons dashicons-edit". Leave blank for the default spark badge.',
                    ],
                    'use_result_blocks' => [
                        'type'        => 'boolean',
                        'description' => 'Set true if the user wants Result blocks (Editorial). When true the layout is set to Editorial; list the specific blocks to enable in result_blocks. Set false for a plain result.',
                    ],
                    'result_blocks' => [
                        'type'        => 'array',
                        'items'       => self::result_blocks_items_schema(),
                        'description' => 'When use_result_blocks is true, the keys of ONLY the Result blocks that genuinely fit THIS tool\'s purpose (e.g. a line-editing tool might use ["compare","redline","fixcards","checklist"]). The server expands each key into its instruction in the Rules — do NOT write block instructions yourself, and do NOT include blocks that do not fit. Leave empty/omit for a plain result.',
                    ],
                    'max_output_tokens' => [
                        'type'        => 'number',
                        'description' => 'Optional output length cap (1–8000). Defaults to 600.',
                    ],
                    'fields' => [
                        'type'        => 'array',
                        'description' => 'Input fields shown on the tool\'s form.',
                        'items'       => [
                            'type'       => 'object',
                            'properties' => [
                                'key'         => ['type' => 'string', 'description' => 'Machine key (lowercase, a-z 0-9 _).'],
                                'label'       => ['type' => 'string', 'description' => 'Field label shown to the user.'],
                                'type'        => ['type' => 'string', 'enum' => ['text', 'textarea', 'select', 'number', 'email', 'checkbox', 'radio', 'file'], 'description' => 'Input type. Use "file" to let visitors upload a manuscript/brief/spreadsheet/image — its text is extracted and sent to the AI as part of {{fields}}.'],
                                'required'    => ['type' => 'boolean', 'description' => 'Whether the field is required.'],
                                'placeholder' => ['type' => 'string', 'description' => 'Placeholder / hint text.'],
                                'options'     => ['type' => 'string', 'description' => 'Comma- or newline-separated options (for select/radio).'],
                                'default'     => ['type' => 'string', 'description' => 'Optional default value.'],
                                'width'       => ['type' => 'string', 'enum' => ['full', 'half', 'third'], 'description' => 'Field width on wide screens. Defaults to full.'],
                                'file_types'  => ['type' => 'string', 'description' => 'For file fields: comma-separated allowed extensions (e.g. "pdf, docx, txt"). Blank = all allowed types.'],
                                'file_max_mb' => ['type' => 'number', 'description' => 'For file fields: max upload size in MB (0–50). 0 = site default.'],
                            ],
                            'required' => ['key', 'label'],
                        ],
                    ],
                ],
                'required'             => ['title'],
                'additionalProperties' => false,
            ],
        ];
    }

    /**
     * Execute create_generator_template: build a sanitised template blob and
     * insert it as a draft. Returns a short text result for the model to relay.
     */
    public static function create_template(array $args): string {
        if (!self::can_create_template()) {
            return __('You do not have permission to create templates on this site.', 'authorwings-ai-tools');
        }

        $title = sanitize_text_field((string) ($args['title'] ?? ''));
        if (trim($title) === '') {
            return __('A template title is required. Ask the user for one, then try again.', 'authorwings-ai-tools');
        }

        $renderer = Plugin::instance()->renderer;
        $meta = $renderer->build_template_meta(is_array($args) ? $args : []);
        // Keep the form title in step with the post title unless the model set one.
        if (trim((string) ($meta['form_title'] ?? '')) === '') {
            $meta['form_title'] = $title;
        }

        // Result blocks (Editorial): the model only names which blocks fit this
        // tool (small keys) — the server owns the layout choice and expands each
        // key into its instruction in the Rules, so the tool call stays small and
        // only the relevant blocks are added.
        $selected = self::clean_block_keys($args['result_blocks'] ?? null);
        $use_blocks = self::truthy($args['use_result_blocks'] ?? null) || !empty($selected);
        $meta['render_mode'] = $use_blocks ? 'document' : 'plain';
        if ($use_blocks) {
            $block_rules = self::result_blocks_rules($selected);
            if ($block_rules !== '') {
                $existing = trim((string) ($meta['rules'] ?? ''));
                $meta['rules'] = $existing === '' ? $block_rules : ($existing . "\n\n" . $block_rules);
            }
        }

        $post_id = wp_insert_post([
            'post_type'   => Plugin::CPT,
            'post_title'  => $title,
            'post_status' => 'draft',
            'post_author' => get_current_user_id(),
        ], true);

        if (is_wp_error($post_id) || !$post_id) {
            return __('The template could not be created. Please try again.', 'authorwings-ai-tools');
        }

        update_post_meta((int) $post_id, '_awg_aig_template', $meta);

        // Best-effort audit trail (only records when the membership add-on's
        // error logging is enabled; namespaced class may be absent entirely).
        if (class_exists('\\AWG_MEM\\Logger')) {
            \AWG_MEM\Logger::log('agent_create_template', [
                'template_id' => (int) $post_id,
                'title'       => $title,
                'user_id'     => get_current_user_id(),
                'model'       => (string) ($meta['model'] ?? ''),
                'fields'      => count((array) ($meta['fields'] ?? [])),
            ]);
        }

        $edit_url = admin_url('post.php?post=' . (int) $post_id . '&action=edit');
        return sprintf(
            /* translators: 1: template id, 2: template title, 3: edit URL */
            __('Created draft template #%1$d "%2$s". Review and publish it here: %3$s', 'authorwings-ai-tools'),
            (int) $post_id,
            $title,
            $edit_url
        );
    }

    /**
     * Instruction lines from the shared palette for the chosen block keys (or all
     * blocks when $keys is empty), ready to fold into a template's Rules. Kept
     * server-side so the model only sends small keys, never this (large) text.
     *
     * @param array $keys Block keys to include; empty = every block.
     */
    public static function result_blocks_rules(array $keys = []): string {
        $palette = self::block_palette();
        if (empty($palette)) {
            return '';
        }
        $want = [];
        foreach ($keys as $k) {
            $k = sanitize_key((string) $k);
            if ($k !== '') $want[$k] = true;
        }
        $all = empty($want);

        $lines = [];
        foreach ($palette as $group) {
            if (!is_array($group)) continue;
            foreach ((array) ($group['blocks'] ?? []) as $bkey => $b) {
                if (!is_array($b)) continue;
                if (!$all && empty($want[(string) $bkey])) continue;
                $p = trim((string) ($b['prompt'] ?? ''));
                if ($p !== '') $lines[] = $p;
            }
        }
        return implode("\n", $lines);
    }

    /** The shared Result-blocks palette, or [] if the editor class is unavailable. */
    private static function block_palette(): array {
        if (!class_exists('\\AWG_AIG\\Metabox') || !method_exists('\\AWG_AIG\\Metabox', 'result_blocks_palette')) {
            return [];
        }
        $palette = \AWG_AIG\Metabox::result_blocks_palette();
        return is_array($palette) ? $palette : [];
    }

    /** All valid Result-block keys (e.g. compare, redline, checklist…). */
    public static function block_keys(): array {
        $keys = [];
        foreach (self::block_palette() as $group) {
            if (!is_array($group)) continue;
            foreach ((array) ($group['blocks'] ?? []) as $bkey => $b) {
                $bkey = sanitize_key((string) $bkey);
                if ($bkey !== '') $keys[] = $bkey;
            }
        }
        return array_values(array_unique($keys));
    }

    /** JSON-schema for a result_blocks array item: a string, enum-constrained when known. */
    private static function result_blocks_items_schema(): array {
        $keys = self::block_keys();
        $schema = ['type' => 'string'];
        if (!empty($keys)) {
            $schema['enum'] = $keys;
        }
        return $schema;
    }

    /** Sanitise a model-supplied result_blocks value to a clean list of valid keys. */
    private static function clean_block_keys($value): array {
        if (!is_array($value)) return [];
        $valid = array_flip(self::block_keys());
        $out = [];
        foreach ($value as $k) {
            $k = sanitize_key((string) $k);
            if ($k !== '' && isset($valid[$k])) $out[$k] = true;
        }
        return array_keys($out);
    }

    /** Coerce a model-supplied flag (bool, "true"/"yes"/"1", 1) to a boolean. */
    private static function truthy($v): bool {
        if (is_bool($v))   return $v;
        if (is_int($v))    return $v === 1;
        if (is_string($v)) return in_array(strtolower(trim($v)), ['1', 'true', 'yes', 'y', 'on'], true);
        return false;
    }

    /* ------------------------------------------------------------------ *
     * create_post — a Gutenberg blog post
     * ------------------------------------------------------------------ */

    /** Provider-agnostic tool definition for create_post. */
    public static function create_post_tool_def(): array {
        return [
            'name'        => self::TOOL_CREATE_POST,
            'description' => 'Create a WordPress blog post built from Gutenberg blocks. Defaults to a DRAFT for the owner to review. '
                . 'Supply the body as a "blocks" array (preferred) or as plain "content" text. Returns the post id and its edit link.',
            'parameters'  => [
                'type'       => 'object',
                'properties' => [
                    'title'   => ['type' => 'string', 'description' => 'Post title.'],
                    'blocks'  => [
                        'type'        => 'array',
                        'description' => 'Ordered content blocks. Preferred over "content".',
                        'items'       => [
                            'type'       => 'object',
                            'properties' => [
                                'type'    => ['type' => 'string', 'enum' => ['paragraph', 'heading', 'list', 'quote'], 'description' => 'Block type.'],
                                'text'    => ['type' => 'string', 'description' => 'Text for paragraph/heading/quote. Inline HTML (<strong>, <em>, <a>) is allowed.'],
                                'level'   => ['type' => 'number', 'description' => 'Heading level 2–4 (heading blocks only).'],
                                'items'   => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'List items (list blocks only).'],
                                'ordered' => ['type' => 'boolean', 'description' => 'Numbered list (list blocks only).'],
                            ],
                            'required' => ['type'],
                        ],
                    ],
                    'content' => ['type' => 'string', 'description' => 'Fallback plain-text body; blank lines become paragraphs. Ignored when "blocks" is given.'],
                    'excerpt' => ['type' => 'string', 'description' => 'Optional excerpt.'],
                    'status'  => ['type' => 'string', 'enum' => ['draft', 'publish'], 'description' => 'Defaults to draft. "publish" only works if you have publish rights.'],
                    'categories' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Category names (created if missing).'],
                    'tags'       => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Tag names.'],
                ],
                'required'             => ['title'],
                'additionalProperties' => false,
            ],
        ];
    }

    /**
     * Execute create_post: assemble Gutenberg block markup and insert the post.
     * Returns a short text result for the model to relay.
     */
    public static function create_post(array $args): string {
        if (!self::can_create_post()) {
            return __('You do not have permission to create posts on this site.', 'authorwings-ai-tools');
        }

        $title = sanitize_text_field((string) ($args['title'] ?? ''));
        if (trim($title) === '') {
            return __('A post title is required. Ask the user for one, then try again.', 'authorwings-ai-tools');
        }

        $content = '';
        if (!empty($args['blocks']) && is_array($args['blocks'])) {
            $content = self::blocks_to_content($args['blocks']);
        }
        if (trim($content) === '' && isset($args['content'])) {
            $paras  = preg_split('/\n\s*\n/', (string) $args['content']) ?: [];
            $blocks = [];
            foreach ($paras as $p) {
                $p = trim($p);
                if ($p !== '') $blocks[] = ['type' => 'paragraph', 'text' => $p];
            }
            $content = self::blocks_to_content($blocks);
        }
        if (trim($content) === '') {
            return __('Post content is required. Provide the body as blocks or text, then try again.', 'authorwings-ai-tools');
        }

        // Draft unless the user explicitly asked to publish AND can publish.
        $status = (($args['status'] ?? 'draft') === 'publish') ? 'publish' : 'draft';
        if ($status === 'publish' && !current_user_can('publish_posts')) {
            $status = 'draft';
        }

        $postarr = [
            'post_type'    => 'post',
            'post_title'   => $title,
            'post_content' => $content,
            'post_status'  => $status,
            'post_author'  => get_current_user_id(),
        ];
        if (!empty($args['excerpt'])) {
            $postarr['post_excerpt'] = sanitize_textarea_field((string) $args['excerpt']);
        }

        $post_id = wp_insert_post($postarr, true);
        if (is_wp_error($post_id) || !$post_id) {
            return __('The post could not be created. Please try again.', 'authorwings-ai-tools');
        }
        $post_id = (int) $post_id;

        // Categories — resolve/create by name via core term functions (always
        // loaded, unlike wp_create_category which lives in wp-admin/includes).
        if (!empty($args['categories']) && is_array($args['categories']) && current_user_can('manage_categories')) {
            $cat_ids = [];
            foreach ($args['categories'] as $name) {
                $name = sanitize_text_field((string) $name);
                if ($name === '') continue;
                $term = term_exists($name, 'category');
                if (!$term) {
                    $term = wp_insert_term($name, 'category');
                }
                if (!is_wp_error($term) && isset($term['term_id'])) {
                    $cat_ids[] = (int) $term['term_id'];
                }
            }
            if (!empty($cat_ids)) {
                wp_set_post_categories($post_id, $cat_ids);
            }
        }

        // Tags — wp_set_post_tags creates missing tags by name.
        if (!empty($args['tags']) && is_array($args['tags'])) {
            $tags = array_values(array_filter(array_map(static function ($t) {
                return sanitize_text_field((string) $t);
            }, $args['tags'])));
            if (!empty($tags)) {
                wp_set_post_tags($post_id, $tags);
            }
        }

        if (class_exists('\\AWG_MEM\\Logger')) {
            \AWG_MEM\Logger::log('agent_create_post', [
                'post_id' => $post_id,
                'title'   => $title,
                'status'  => $status,
                'user_id' => get_current_user_id(),
            ]);
        }

        $edit_url = admin_url('post.php?post=' . $post_id . '&action=edit');
        $label = ($status === 'publish')
            ? __('Published post', 'authorwings-ai-tools')
            : __('Created draft post', 'authorwings-ai-tools');
        return sprintf(
            /* translators: 1: created/published label, 2: post id, 3: title, 4: edit URL */
            __('%1$s #%2$d "%3$s". Open it here: %4$s', 'authorwings-ai-tools'),
            $label,
            $post_id,
            $title,
            $edit_url
        );
    }

    /**
     * Turn a list of simple block descriptors into Gutenberg block markup.
     *
     * Block delimiters are emitted by serialize_blocks(); only the inner text is
     * passed through wp_kses_post (which would otherwise strip the block-comment
     * delimiters). Unknown types fall back to a paragraph.
     */
    private static function blocks_to_content(array $blocks): string {
        $out = [];
        foreach ($blocks as $b) {
            if (!is_array($b)) continue;
            $type = (string) ($b['type'] ?? 'paragraph');

            if ($type === 'heading') {
                $level = max(2, min(4, (int) ($b['level'] ?? 2)));
                $text  = wp_kses_post((string) ($b['text'] ?? ''));
                if (trim(wp_strip_all_tags($text)) === '') continue;
                $html  = sprintf('<h%1$d>%2$s</h%1$d>', $level, $text);
                $out[] = ['blockName' => 'core/heading', 'attrs' => ['level' => $level], 'innerBlocks' => [], 'innerHTML' => $html, 'innerContent' => [$html]];
                continue;
            }

            if ($type === 'list') {
                $items   = is_array($b['items'] ?? null) ? $b['items'] : [];
                $ordered = !empty($b['ordered']);
                $li = '';
                foreach ($items as $it) {
                    $t = wp_kses_post((string) $it);
                    if (trim(wp_strip_all_tags($t)) === '') continue;
                    $li .= '<li>' . $t . '</li>';
                }
                if ($li === '') continue;
                $tag   = $ordered ? 'ol' : 'ul';
                $html  = '<' . $tag . '>' . $li . '</' . $tag . '>';
                $out[] = ['blockName' => 'core/list', 'attrs' => $ordered ? ['ordered' => true] : [], 'innerBlocks' => [], 'innerHTML' => $html, 'innerContent' => [$html]];
                continue;
            }

            if ($type === 'quote') {
                $text = wp_kses_post((string) ($b['text'] ?? ''));
                if (trim(wp_strip_all_tags($text)) === '') continue;
                $html  = '<blockquote class="wp-block-quote"><p>' . $text . '</p></blockquote>';
                $out[] = ['blockName' => 'core/quote', 'attrs' => [], 'innerBlocks' => [], 'innerHTML' => $html, 'innerContent' => [$html]];
                continue;
            }

            // paragraph (default)
            $text = wp_kses_post((string) ($b['text'] ?? ''));
            if (trim(wp_strip_all_tags($text)) === '') continue;
            $html  = '<p>' . $text . '</p>';
            $out[] = ['blockName' => 'core/paragraph', 'attrs' => [], 'innerBlocks' => [], 'innerHTML' => $html, 'innerContent' => [$html]];
        }

        if (empty($out)) return '';
        if (function_exists('serialize_blocks')) {
            return serialize_blocks($out);
        }
        // Defensive fallback: emit delimiters by hand if serialize_blocks is gone.
        $markup = '';
        foreach ($out as $blk) {
            $name  = substr((string) $blk['blockName'], 5); // strip "core/"
            $attrs = !empty($blk['attrs']) ? ' ' . wp_json_encode($blk['attrs']) : '';
            $markup .= '<!-- wp:' . $name . $attrs . ' -->' . $blk['innerHTML'] . '<!-- /wp:' . $name . " -->\n";
        }
        return $markup;
    }
}
