<?php
namespace AWG_AIG\Agent;

if (!defined('ABSPATH')) { exit; }

/**
 * Admin glue for agents: submenu entries under the AuthorWings AI menu (the
 * Agents list + the Build Assistant), menu-highlight fixes for the hidden CPT
 * screens, an at-a-glance Turns column, and the Build Assistant page itself.
 */
final class Agent_Admin {

    const PARENT = 'edit.php?post_type=awg_ai_template';

    /**
     * Whether the Build Assistant is enabled (master switch in Settings →
     * Build Assistant). Absent key = enabled, so installs that predate the
     * control panel keep working until an admin turns it off.
     */
    public static function builder_enabled(): bool {
        $s = get_option(\AWG_AIG\Plugin::OPT, []);
        if (!is_array($s)) {
            return true;
        }
        return !isset($s['builder_enabled']) || !empty($s['builder_enabled']);
    }

    public function register(): void {
        add_action('admin_menu', [$this, 'menu'], 12);
        add_filter('parent_file', [$this, 'fix_menu_highlight']);

        add_filter('manage_' . Agent::CPT . '_posts_columns', [$this, 'columns']);
        add_action('manage_' . Agent::CPT . '_posts_custom_column', [$this, 'column_data'], 10, 2);

        add_action('admin_enqueue_scripts', [$this, 'assets']);
    }

    public function menu(): void {
        add_submenu_page(
            self::PARENT,
            __('AI Agents', 'authorwings-ai-tools'),
            __('AI Agents', 'authorwings-ai-tools'),
            'manage_options',
            'edit.php?post_type=' . Agent::CPT,
            '',
            20
        );

        if (!self::builder_enabled()) {
            return;
        }

        add_submenu_page(
            self::PARENT,
            __('Build Assistant', 'authorwings-ai-tools'),
            __('Build Assistant', 'authorwings-ai-tools'),
            'manage_options',
            'awg-agent-builder',
            [$this, 'render_builder'],
            25
        );
    }

    /** Keep the AuthorWings AI menu highlighted on the hidden agent CPT screens. */
    public function fix_menu_highlight(string $parent_file): string {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($screen && ($screen->post_type ?? '') === Agent::CPT) {
            return self::PARENT;
        }
        return $parent_file;
    }

    public function columns(array $columns): array {
        $new = [];
        foreach ($columns as $key => $label) {
            $new[$key] = $label;
            if ($key === 'title') {
                $new['awg_agent_turns'] = __('Turns', 'authorwings-ai-tools');
                $new['awg_agent_model'] = __('Model', 'authorwings-ai-tools');
            }
        }
        return $new;
    }

    public function column_data(string $column, int $post_id): void {
        if ($column === 'awg_agent_turns') {
            echo esc_html((string) (int) get_post_meta($post_id, '_awg_aig_usage_count', true));
        } elseif ($column === 'awg_agent_model') {
            $m = Agent::get_meta($post_id);
            echo esc_html($m['model'] !== '' ? $m['model'] : __('(default)', 'authorwings-ai-tools'));
        }
    }

    public function assets(string $hook): void {
        // The builder page hook ends in "_page_awg-agent-builder"; match loosely
        // so we don't depend on the exact parent-slug prefix.
        if (strpos((string) $hook, 'awg-agent-builder') === false) {
            return;
        }
        wp_enqueue_style('awg-agent', plugins_url('assets/agent.css', AWG_AIG_FILE), [], AWG_AIG_VERSION);
        wp_enqueue_script('awg-agent', plugins_url('assets/agent.js', AWG_AIG_FILE), [], AWG_AIG_VERSION, true);
        wp_localize_script('awg-agent', 'AWG_AGENT', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('awg_agent_admin'),
            'i18n'    => [
                'send'      => __('Send', 'authorwings-ai-tools'),
                'thinking'  => __('Thinking…', 'authorwings-ai-tools'),
                'error'     => __('Something went wrong. Please try again.', 'authorwings-ai-tools'),
                'copy'      => __('Copy', 'authorwings-ai-tools'),
                'download'  => __('Download', 'authorwings-ai-tools'),
                'attach'    => __('Attach a file', 'authorwings-ai-tools'),
                'uploading' => __('Uploading…', 'authorwings-ai-tools'),
            ],
        ]);
    }

    public function render_builder(): void {
        $greeting = __('Hi! Tell me what kind of AI tool or agent you want to build, and I’ll draft the fields and prompts for you.', 'authorwings-ai-tools');
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Build Assistant', 'authorwings-ai-tools'); ?></h1>
            <p class="description" style="max-width:760px"><?php esc_html_e('Chat with an assistant that knows the AuthorWings AI plugin. Ask it to design a generator template, write a system/user prompt, or plan a new agent. Once you agree on a design it can create the template — or a Gutenberg blog post — for you as a draft, which you review and publish yourself.', 'authorwings-ai-tools'); ?></p>
            <div class="awg-agent awg-agent--admin" data-agent-id="0" data-action="awg_agent_admin_chat" data-allow-uploads="1" data-max-mb="20" data-greeting="<?php echo esc_attr($greeting); ?>" data-placeholder="<?php echo esc_attr__('Describe the tool you want to build…', 'authorwings-ai-tools'); ?>" style="max-width:820px;margin-top:16px">
                <div class="awg-agent-log" role="log" aria-live="polite"></div>
                <div class="awg-agent-attachments"></div>
                <form class="awg-agent-form" autocomplete="off">
                    <label class="awg-agent-attach" title="<?php echo esc_attr__('Attach a file', 'authorwings-ai-tools'); ?>" aria-label="<?php echo esc_attr__('Attach a file', 'authorwings-ai-tools'); ?>">
                        <input type="file" class="awg-agent-file" accept="image/*,video/*,.txt,.md,.csv,.tsv,.json,.xml,.html,.htm,.log,.rtf,.pdf,.doc,.docx,.odt,.xls,.xlsx,.ods,.ppt,.pptx,.odp" hidden />
                        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                    </label>
                    <textarea class="awg-agent-input" rows="1" placeholder="<?php echo esc_attr__('Describe the tool you want to build…', 'authorwings-ai-tools'); ?>"></textarea>
                    <button type="submit" class="awg-agent-send"><?php esc_html_e('Send', 'authorwings-ai-tools'); ?></button>
                </form>
            </div>
            <p class="description" style="max-width:820px;margin-top:8px"><?php esc_html_e('Attach an image, document or short video with the paperclip button — or paste a screenshot straight into the box with Ctrl/⌘+V. Images are shown to vision-capable models (OpenAI GPT-4o/GPT-5, Claude); documents are read as text. DeepSeek has no vision and cannot read images.', 'authorwings-ai-tools'); ?></p>
        </div>
        <?php
    }
}
