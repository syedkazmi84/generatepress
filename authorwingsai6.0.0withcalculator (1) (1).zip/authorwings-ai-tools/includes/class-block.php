<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Block {
    /** @var Renderer */
    private $renderer;

    public function __construct(Renderer $renderer) {
        $this->renderer = $renderer;
    }

    public function register(): void {
        wp_register_script(
            'awg-aig-block',
            plugins_url('assets/block.js', AWG_AIG_FILE),
            ['wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-data', 'wp-api-fetch', 'wp-i18n'],
            AWG_AIG_VERSION,
            true
        );


        wp_set_script_translations('awg-aig-block', 'authorwings-ai-tools', plugin_dir_path(AWG_AIG_FILE) . 'languages');

        register_block_type('awg/generator', [
            'editor_script'   => 'awg-aig-block',
            'render_callback' => [$this, 'render'],
            'attributes'      => [
                'templateId' => ['type' => 'number', 'default' => 0],
            ],
        ]);
    }

    public function render(array $attrs): string {
        $id = intval($attrs['templateId'] ?? 0);
        if ($id <= 0) {
            return '<div class="awg-aig awg-aig--empty">' . esc_html__('Select a generator template.', 'authorwings-ai-tools') . '</div>';
        }
        return $this->renderer->render_form($id);
    }
}
