<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Metabox {

    /**
     * Result blocks palette — the full toolbox of blocks the Editorial result
     * layout can render. Single source of truth shared by the template editor UI
     * (the "Insert" menu) and the Build Assistant, which uses it to ask which
     * blocks a new template should use and to write the matching instruction
     * lines into the Rules field.
     *
     * Each block: 'label' = name shown, 'desc' = one-line hint, 'prompt' = the
     * instruction appended to Rules when chosen.
     */
    public static function result_blocks_palette(): array {
        return [
                'instruct' => [
                    'title'  => __('Needs a prompt line — these appear only when you ask for them', 'authorwings-ai-tools'),
                    'blocks' => [
                        'checklist' => [
                            'label'  => __('Checklist (pass/fail)', 'authorwings-ai-tools'),
                            'desc'   => __('Use when the piece is judged against concrete pass/fail criteria.', 'authorwings-ai-tools'),
                            'prompt' => 'If the piece can be judged against concrete pass/fail criteria, end with a checklist. Format every line as a task item — "- [x] met" or "- [ ] unmet" — and do not mix in plain bullets (a single non-task line removes the tick/cross styling from the whole list). Evaluate each item against your corrected version: mark "[x]" when it is true of the corrected text. Phrase items as positive outcomes and avoid negated wording like "No errors found" — state the status of the final text instead (e.g. "Spelling correct in the final version"). Mark "[ ]" only for issues that remain unfixed. Only include checks you can verify; do not pad the list.',
                        ],
                        'redline' => [
                            'label'  => __('Redline / tracked changes', 'authorwings-ai-tools'),
                            'desc'   => __('Use for word-level edits on the user\'s own text.', 'authorwings-ai-tools'),
                            'prompt' => 'Mark inline corrections on the user\'s own words using this exact syntax: delete with {--old--} and insert with {++new++} — for example, "a {--very --}{++truly ++}bold claim". Do not substitute ~~strikethrough~~, HTML tags or square brackets. Use this for small word-level edits only; for a full-sentence rewrite use Before/After, and for several separate line fixes use Fix cards. Only mark genuine errors and leave correct text untouched; if nothing needs changing, omit it.',
                        ],
                        'stats' => [
                            'label'  => __('Stat grid', 'authorwings-ai-tools'),
                            'desc'   => __('Use when you have real figures to report — word count, reading level, etc.', 'authorwings-ai-tools'),
                            'prompt' => "If you have real figures to report (word count, reading level, etc.), open with a fenced ```stats block (the opening fence must be exactly ```stats, never a bare ```), one \"Label: Value\" per line (e.g. Words: 1240). Only include metrics you can actually determine — never guess a number.",
                        ],
                        'tags' => [
                            'label'  => __('Tag / keyword chips', 'authorwings-ai-tools'),
                            'desc'   => __('Use when clear keywords, genres or themes apply.', 'authorwings-ai-tools'),
                            'prompt' => "If clear keywords, genres or themes apply, list them in a fenced ```tags block (the opening fence must be exactly ```tags, never a bare ```), comma-separated. Skip it when none genuinely fit.",
                        ],
                        'compare' => [
                            'label'  => __('Before / After', 'authorwings-ai-tools'),
                            'desc'   => __('Use when a full sentence or passage needs rewriting.', 'authorwings-ai-tools'),
                            'prompt' => "Only when a sentence or passage genuinely needs improving, show it in a fenced ```compare block (the opening fence must be exactly ```compare, never a bare ```): the original, then a line of ===, then your revision. Put exactly one original and one revision per block, separated by a single === — to compare several passages, use a separate ```compare block for each rather than stacking multiple === in one block. Use this for a full-sentence rewrite; for inline word-level edits use Redline instead. Do not rewrite text that is already fine or invent changes to fill the block; if nothing needs rewriting, omit it.",
                        ],
                        'scorecard' => [
                            'label'  => __('Scorecard (multi-criteria)', 'authorwings-ai-tools'),
                            'desc'   => __('Use when rating on two or more named criteria.', 'authorwings-ai-tools'),
                            'prompt' => "When rating the piece on two or more named criteria, score it in a fenced ```scorecard block (the opening fence must be exactly ```scorecard, never a bare ```), one \"Criterion: 8/10\" per line (e.g. Clarity: 8/10). For a single overall number use Rating instead. Base every score on the actual text and omit the block when scoring is not meaningful.",
                        ],
                        'callout' => [
                            'label'  => __('Callout (Tip / Note / Warning)', 'authorwings-ai-tools'),
                            'desc'   => __('Use when one point of advice or a warning deserves emphasis.', 'authorwings-ai-tools'),
                            'prompt' => "If one point of advice or a warning genuinely deserves emphasis, put it in a fenced ```tip block (or ```note / ```warning) — the opening fence must be exactly that tag, never a bare ```. Use it sparingly — skip it when nothing stands out.",
                        ],
                        'proscons' => [
                            'label'  => __('Pros & Cons', 'authorwings-ai-tools'),
                            'desc'   => __('Use when there are real strengths and weaknesses to weigh.', 'authorwings-ai-tools'),
                            'prompt' => "If the piece has real strengths and weaknesses worth weighing, set them in a fenced ```proscons block (the opening fence must be exactly ```proscons, never a bare ```): the pros, a line of ===, then the cons. List only genuine points; never invent a con to balance the columns.",
                        ],
                        'steps' => [
                            'label'  => __('Steps / how-to', 'authorwings-ai-tools'),
                            'desc'   => __('Use when the answer is genuinely an ordered sequence of actions.', 'authorwings-ai-tools'),
                            'prompt' => "Only when the answer is genuinely a sequence of actions, give it in a fenced ```steps block (the opening fence must be exactly ```steps, never a bare ```), one step per line. Do not force ordinary prose into steps.",
                        ],
                        'pullquote' => [
                            'label'  => __('Pull-quote', 'authorwings-ai-tools'),
                            'desc'   => __('Use for one short line shown large for emphasis.', 'authorwings-ai-tools'),
                            'prompt' => "For one short, punchy line you want shown large for visual emphasis, pull it into a fenced ```pullquote block (the opening fence must be exactly ```pullquote, never a bare ```); put any attribution on a line starting with \"— \". To quote a passage from the source text, use a normal > blockquote instead. Skip it when nothing stands out — do not invent a quote.",
                        ],
                        'fixcards' => [
                            'label'  => __('Suggestion → fix cards', 'authorwings-ai-tools'),
                            'desc'   => __('Use for several separate line-level problems, each with a rewrite.', 'authorwings-ai-tools'),
                            'prompt' => "Where there are specific line-level problems worth fixing, give them as cards in a fenced ```fixcards block (the opening fence must be exactly ```fixcards, never a bare ```): separate each card with a blank line; put the problem line first, then on the next line write the rewrite as \">> \" immediately followed by the rewrite on the SAME line (e.g. \">> the corrected sentence\") — do not put \">>\" on a line by itself — then a short why-note. Only include genuine issues — if a line is fine, do not make a card for it.",
                        ],
                    ],
                ],
                'auto' => [
                    'title'  => __('Renders automatically — insert an optional nudge to steer the AI toward one', 'authorwings-ai-tools'),
                    'blocks' => [
                        'cards' => [
                            'label'  => __('Option cards', 'authorwings-ai-tools'),
                            'desc'   => __('Use when offering a set of choices.', 'authorwings-ai-tools'),
                            'prompt' => 'When you are offering a set of choices, give them as a flat list with each option on its own line.',
                        ],
                        'rating' => [
                            'label'  => __('Rating / score bar', 'authorwings-ai-tools'),
                            'desc'   => __('Use for one single overall score — use Scorecard for multiple.', 'authorwings-ai-tools'),
                            'prompt' => 'For one single overall score, include a line like "Rating: 8/10". For two or more named criteria, use Scorecard instead.',
                        ],
                        'sections' => [
                            'label'  => __('Sections (strength / limit icons)', 'authorwings-ai-tools'),
                            'desc'   => __('Use when the answer has distinct parts — headings plus bullets.', 'authorwings-ai-tools'),
                            'prompt' => 'When the answer has distinct parts, organise it under ## headings, each followed by bullet points.',
                        ],
                        'verdict' => [
                            'label'  => __('Verdict callout', 'authorwings-ai-tools'),
                            'desc'   => __('Use when a clear conclusion is warranted.', 'authorwings-ai-tools'),
                            'prompt' => 'When a clear conclusion is warranted, finish with a line starting "Verdict:" summarising it.',
                        ],
                        'table' => [
                            'label'  => __('Table', 'authorwings-ai-tools'),
                            'desc'   => __('Use when data is genuinely tabular.', 'authorwings-ai-tools'),
                            'prompt' => 'When data is genuinely tabular, present it as a Markdown table; start and end every row with a pipe |, including the |---|---| divider row beneath the header.',
                        ],
                        'quote' => [
                            'label'  => __('Quote', 'authorwings-ai-tools'),
                            'desc'   => __('Use when quoting a passage from the source text.', 'authorwings-ai-tools'),
                            'prompt' => 'To quote a sentence or passage taken from the source text, set it as a > blockquote. For a single line shown large for visual emphasis, use Pull-quote instead.',
                        ],
                        'code' => [
                            'label'  => __('Code', 'authorwings-ai-tools'),
                            'desc'   => __('Use for any code.', 'authorwings-ai-tools'),
                            'prompt' => 'Wrap any code in a fenced ``` code block.',
                        ],
                    ],
                ],
        ];
    }
    /** @var string */
    private $cpt;

    /** @var Renderer */
    private $renderer;

    public function __construct(string $cpt, Renderer $renderer) {
        $this->cpt = $cpt;
        $this->renderer = $renderer;
    }

    public function register(): void {
        add_meta_box('awg_aig_builder', __('Template Builder', 'authorwings-ai-tools'), [$this, 'html'], $this->cpt, 'normal', 'high');
    }

    public function html($post): void {
        wp_nonce_field('awg_aig_save', 'awg_aig_nonce');
        // v5.4.12: pass false so the editor shows the saved per-template
        // colors and field sizes, not the globally-overridden view. Without
        // this, ticking "Use global styles" then saving silently overwrites
        // the user's custom per-template colors with the global palette.
        $m = $this->renderer->get_template_meta($post->ID, false);

        // Brand palette is the correct "Default" target for each per-template
        // color picker — not the currently saved value.
        $palette = Settings::brand_palette();
        $palette_for = static function(string $tpl_key) use ($palette): string {
            // Map per-template style keys to their global brand equivalents.
            $map = [
                'style_bg_color'            => 'global_style_bg_color',
                'style_text_color'          => 'global_style_text_color',
                'style_border_color'        => 'global_style_border_color',
                'style_accent_color'        => 'global_style_accent_color',
                'style_button_bg_color'     => 'global_style_button_bg_color',
                'style_button_text_color'   => 'global_style_button_text_color',
                'style_button_border_color' => 'global_style_button_border_color',
            ];
            $global_key = $map[$tpl_key] ?? '';
            return '#' . ltrim((string) ($palette[$global_key] ?? ''), '#');
        };
        ?>
        <div class="awg-aig-wrap">

            <?php Settings::section_open('tpl_basics', __('Form Basics', 'authorwings-ai-tools'), false, __('Title, description, button, fields shown to users', 'authorwings-ai-tools')); ?>

            <?php // v5.4.19: choose how the form is built. ?>
            <div class="awg-col" style="margin-bottom:14px;">
                <label class="awg-label"><?php echo esc_html__('Design Mode', 'authorwings-ai-tools'); ?></label>
                <select class="awg-input" id="awg-design-mode" name="awg_aig[design_mode]">
                    <option value="standard" <?php selected(($m['design_mode'] ?? 'standard'), 'standard'); ?>><?php echo esc_html__('Standard — build the form from the Fields below', 'authorwings-ai-tools'); ?></option>
                    <option value="custom_html" <?php selected(($m['design_mode'] ?? 'standard'), 'custom_html'); ?>><?php echo esc_html__('Custom HTML — design your own form markup', 'authorwings-ai-tools'); ?></option>
                </select>
                <p class="description"><?php echo esc_html__('Standard renders the Fields section automatically. Custom HTML lets you write any form you like in the Custom Form HTML box below — every named input you add is still sent to the AI as {{fields}}, exactly like the standard form.', 'authorwings-ai-tools'); ?></p>
                <p class="description"><?php echo current_user_can('unfiltered_html')
                    ? esc_html__('This box behaves like the WordPress core “Custom HTML” block: because you can publish unfiltered HTML, you may include <script> and <style> here (e.g. to embed an interactive tool). Scripts run on the front-end — only paste code you trust.', 'authorwings-ai-tools')
                    : esc_html__('Like the WordPress core “Custom HTML” block, <script>/<style> are only kept for users allowed to publish unfiltered HTML. Your markup is sanitized to safe form tags.', 'authorwings-ai-tools'); ?></p>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Form Title', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[form_title]" value="<?php echo esc_attr($m['form_title']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Form Description', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[form_description]" value="<?php echo esc_attr($m['form_description']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Task (used in prompt)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[task]" value="<?php echo esc_attr($m['task']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Label', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[button_label]" value="<?php echo esc_attr($m['button_label']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('How many results? ({{count}})', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="1" max="50" name="awg_aig[count]" value="<?php echo esc_attr($m['count']); ?>">
                </div>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Result Heading', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[success_title]" value="<?php echo esc_attr($m['success_title'] ?? ''); ?>" placeholder="<?php echo esc_attr__('Result', 'authorwings-ai-tools'); ?>">
                    <p class="description"><?php echo esc_html__('Heading shown above the generated output. Leave blank for the default.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Output Placeholder', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[placeholder_output]" value="<?php echo esc_attr($m['placeholder_output'] ?? ''); ?>" placeholder="<?php echo esc_attr__('Your results will appear here…', 'authorwings-ai-tools'); ?>">
                    <p class="description"><?php echo esc_html__('Shown in the empty result area before the first generation.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Disclaimer / Helper Text', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[disclaimer_text]" value="<?php echo esc_attr($m['disclaimer_text']); ?>">
                    <p class="description"><?php echo esc_html__('Optional text below the generate button. Result actions (Copy, Download, Clear, Regenerate) are always shown on results.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>

            <?php Settings::section_close(); ?>

            <?php Settings::section_open('tpl_header', __('Header & Branding', 'authorwings-ai-tools'), false, __('Header layout, icon badge, title font, eyebrow, and branded colors', 'authorwings-ai-tools')); ?>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Title Icon Class', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[title_icon_class]" value="<?php echo esc_attr($m['title_icon_class'] ?? ''); ?>" placeholder="dashicons dashicons-book">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Title Icon Size (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="10" max="40" name="awg_aig[title_icon_size]" value="<?php echo esc_attr((int) ($m['title_icon_size'] ?? 20)); ?>">
                    <p class="description"><?php echo esc_html__('Used in Plain header mode. In Branded mode the badge size is automatic.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Title Icon Position', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[title_icon_position]">
                        <option value="before" <?php selected(($m['title_icon_position'] ?? 'before'), 'before'); ?>><?php echo esc_html__('Before Title', 'authorwings-ai-tools'); ?></option>
                        <option value="after" <?php selected(($m['title_icon_position'] ?? 'before'), 'after'); ?>><?php echo esc_html__('After Title', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Header design', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[form_design]">
                        <option value="global" <?php selected(($m['form_design'] ?? 'global'), 'global'); ?>><?php echo esc_html__('Use global setting', 'authorwings-ai-tools'); ?></option>
                        <option value="branded" <?php selected(($m['form_design'] ?? 'global'), 'branded'); ?>><?php echo esc_html__('Branded (icon, title, subtitle)', 'authorwings-ai-tools'); ?></option>
                        <option value="plain" <?php selected(($m['form_design'] ?? 'global'), 'plain'); ?>><?php echo esc_html__('Plain (title + description)', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Icon position', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[header_icon_position]">
                        <option value="global" <?php selected(($m['header_icon_position'] ?? 'global'), 'global'); ?>><?php echo esc_html__('Use global setting', 'authorwings-ai-tools'); ?></option>
                        <option value="top" <?php selected(($m['header_icon_position'] ?? 'global'), 'top'); ?>><?php echo esc_html__('Top (centered)', 'authorwings-ai-tools'); ?></option>
                        <option value="left" <?php selected(($m['header_icon_position'] ?? 'global'), 'left'); ?>><?php echo esc_html__('Left (before title)', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Title font', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[title_font]">
                        <option value="global" <?php selected(($m['title_font'] ?? 'global'), 'global'); ?>><?php echo esc_html__('Use global setting', 'authorwings-ai-tools'); ?></option>
                        <option value="serif" <?php selected(($m['title_font'] ?? 'global'), 'serif'); ?>><?php echo esc_html__('Serif', 'authorwings-ai-tools'); ?></option>
                        <option value="sans" <?php selected(($m['title_font'] ?? 'global'), 'sans'); ?>><?php echo esc_html__('Sans', 'authorwings-ai-tools'); ?></option>
                    </select>
                    <p class="description"><?php echo esc_html__('Overrides the global Header & Branding setting for this template only. The icon glyph comes from the Title Icon field; in Branded mode the badge size is set automatically.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Eyebrow label', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[brand_eyebrow_mode]">
                        <option value="global" <?php selected(($m['brand_eyebrow_mode'] ?? 'global'), 'global'); ?>><?php echo esc_html__('Use global setting', 'authorwings-ai-tools'); ?></option>
                        <option value="custom" <?php selected(($m['brand_eyebrow_mode'] ?? 'global'), 'custom'); ?>><?php echo esc_html__('Custom for this template', 'authorwings-ai-tools'); ?></option>
                    </select>
                    <input class="awg-input" type="text" name="awg_aig[brand_eyebrow]" value="<?php echo esc_attr($m['brand_eyebrow'] ?? ''); ?>" placeholder="<?php echo esc_attr__('Leave blank to hide the eyebrow', 'authorwings-ai-tools'); ?>" style="margin-top:6px;">
                    <p class="description"><?php echo esc_html__('Choose "Custom" to override the global eyebrow text for this template.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Accent rule under title', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[header_show_rule]">
                        <option value="global" <?php selected(($m['header_show_rule'] ?? 'global'), 'global'); ?>><?php echo esc_html__('Use global setting', 'authorwings-ai-tools'); ?></option>
                        <option value="yes" <?php selected(($m['header_show_rule'] ?? 'global'), 'yes'); ?>><?php echo esc_html__('Show', 'authorwings-ai-tools'); ?></option>
                        <option value="no" <?php selected(($m['header_show_rule'] ?? 'global'), 'no'); ?>><?php echo esc_html__('Hide', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Italic subtitle', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[header_subtitle_italic]">
                        <option value="global" <?php selected(($m['header_subtitle_italic'] ?? 'global'), 'global'); ?>><?php echo esc_html__('Use global setting', 'authorwings-ai-tools'); ?></option>
                        <option value="yes" <?php selected(($m['header_subtitle_italic'] ?? 'global'), 'yes'); ?>><?php echo esc_html__('Italic', 'authorwings-ai-tools'); ?></option>
                        <option value="no" <?php selected(($m['header_subtitle_italic'] ?? 'global'), 'no'); ?>><?php echo esc_html__('Normal', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
            </div>

            <p class="description" style="margin:4px 0 8px;"><strong><?php echo esc_html__('Branded header colors', 'authorwings-ai-tools'); ?></strong> — <?php echo esc_html__('leave any blank to inherit the global Header & Branding colors.', 'authorwings-ai-tools'); ?></p>
            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Header title', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[brand_title_color]" value="<?php echo ($m['brand_title_color'] ?? '') !== '' ? '#' . esc_attr(ltrim($m['brand_title_color'], '#')) : ''; ?>" data-alpha-enabled="false">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Header subtitle', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[brand_subtitle_color]" value="<?php echo ($m['brand_subtitle_color'] ?? '') !== '' ? '#' . esc_attr(ltrim($m['brand_subtitle_color'], '#')) : ''; ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Eyebrow label', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[brand_eyebrow_color]" value="<?php echo ($m['brand_eyebrow_color'] ?? '') !== '' ? '#' . esc_attr(ltrim($m['brand_eyebrow_color'], '#')) : ''; ?>">
                </div>
            </div>
            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Icon badge background', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[brand_badge_bg_color]" value="<?php echo ($m['brand_badge_bg_color'] ?? '') !== '' ? '#' . esc_attr(ltrim($m['brand_badge_bg_color'], '#')) : ''; ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Icon badge glyph', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[brand_badge_icon_color]" value="<?php echo ($m['brand_badge_icon_color'] ?? '') !== '' ? '#' . esc_attr(ltrim($m['brand_badge_icon_color'], '#')) : ''; ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Accent rule', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[brand_rule_color]" value="<?php echo ($m['brand_rule_color'] ?? '') !== '' ? '#' . esc_attr(ltrim($m['brand_rule_color'], '#')) : ''; ?>">
                </div>
            </div>

            <?php Settings::section_close(); ?>

            <?php Settings::section_open('tpl_cta', __('Post-Result CTA', 'authorwings-ai-tools'), false, __('Hide or override the global CTA for this template', 'authorwings-ai-tools')); ?>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label" style="display:flex;align-items:center;gap:8px;">
                        <input type="checkbox" name="awg_aig[hide_cta]" value="1" <?php checked((int) ($m['hide_cta'] ?? 0), 1); ?>>
                        <?php echo esc_html__('Hide post-result CTA on this template', 'authorwings-ai-tools'); ?>
                    </label>
                    <p class="description"><?php echo esc_html__('Useful on pages the CTA would link back to (e.g. the Book Cost Calculator itself).', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('CTA Override (HTML, optional)', 'authorwings-ai-tools'); ?></label>
                    <textarea class="awg-input" name="awg_aig[cta_text_override]" rows="3" placeholder="<?php echo esc_attr__('Leave empty to use the global CTA from Settings.', 'authorwings-ai-tools'); ?>"><?php echo esc_textarea($m['cta_text_override'] ?? ''); ?></textarea>
                    <p class="description"><?php echo esc_html__('If filled, this replaces the global CTA on this template only. Ignored when "Hide" is checked.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>

            <?php Settings::section_close(); ?>

            <?php if (class_exists('\\AWG_AIG\\Agent\\Agent')) :
                $awg_agents = get_posts([
                    'post_type'   => \AWG_AIG\Agent\Agent::CPT,
                    'post_status' => 'publish',
                    'numberposts' => 200,
                    'orderby'     => 'title',
                    'order'       => 'ASC',
                ]);
            ?>
            <?php Settings::section_open('tpl_discuss', __('Discuss result with agent', 'authorwings-ai-tools'), false, __('Offer a chat button on the result so visitors can refine the output', 'authorwings-ai-tools')); ?>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label" for="awg_aig_result_agent_id"><?php echo esc_html__('Agent', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" id="awg_aig_result_agent_id" name="awg_aig[result_agent_id]">
                        <option value="0" <?php selected((int) ($m['result_agent_id'] ?? 0), 0); ?>><?php echo esc_html__('— None (no Discuss button) —', 'authorwings-ai-tools'); ?></option>
                        <?php foreach ($awg_agents as $awg_ag) : ?>
                            <option value="<?php echo esc_attr($awg_ag->ID); ?>" <?php selected((int) ($m['result_agent_id'] ?? 0), (int) $awg_ag->ID); ?>><?php echo esc_html(get_the_title($awg_ag) !== '' ? get_the_title($awg_ag) : ('#' . $awg_ag->ID)); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php
                        printf(
                            /* translators: %s: link to the AI Agents screen */
                            esc_html__('Pick a published agent from %s. The button opens an in-place chat seeded with the generated result.', 'authorwings-ai-tools'),
                            '<a href="' . esc_url(admin_url('edit.php?post_type=' . \AWG_AIG\Agent\Agent::CPT)) . '">' . esc_html__('AI Agents', 'authorwings-ai-tools') . '</a>'
                        );
                    ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label" for="awg_aig_discuss_label"><?php echo esc_html__('Button label', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" id="awg_aig_discuss_label" name="awg_aig[discuss_label]" value="<?php echo esc_attr($m['discuss_label'] ?? ''); ?>" placeholder="<?php echo esc_attr__('Discuss with assistant', 'authorwings-ai-tools'); ?>">
                    <p class="description"><?php echo esc_html__('Shown on the result button. Leave blank for the default.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>

            <?php Settings::section_close(); ?>
            <?php endif; ?>

            <?php Settings::section_open('tpl_styles', __('Style & Appearance', 'authorwings-ai-tools'), false, __('Colors, spacing, button styling, and field sizes', 'authorwings-ai-tools')); ?>

            <p style="margin:0 0 12px;">
                <label class="awg-label" style="display:flex;align-items:center;gap:8px;">
                    <input type="checkbox" id="awg-use-global-styles" name="awg_aig[use_global_styles]" value="1" <?php checked((int) ($m['use_global_styles'] ?? 1), 1); ?>>
                    <?php echo esc_html__('Use global style settings from AuthorWings AI → Settings', 'authorwings-ai-tools'); ?>
                </label>
                <span class="description" style="display:block;margin-left:26px;"><?php echo esc_html__('While checked, the per-template style fields below are ignored. Uncheck to override colors/spacing for this template only.', 'authorwings-ai-tools'); ?></span>
            </p>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label" style="display:flex;align-items:center;gap:8px;">
                        <input type="checkbox" id="awg-use-global-field-sizes" name="awg_aig[use_global_field_sizes]" value="1" <?php checked((int) ($m['use_global_field_sizes'] ?? 1), 1); ?>>
                        <?php echo esc_html__('Use global field sizes', 'authorwings-ai-tools'); ?>
                    </label>
                    <p class="description"><?php echo esc_html__('Turn this off to override the default input height and textarea rows for this template only.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col awg-fieldsize-override">
                    <label class="awg-label"><?php echo esc_html__('Input Height (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="32" max="80" name="awg_aig[style_input_height]" value="<?php echo esc_attr((int) $m['style_input_height']); ?>">
                </div>
                <div class="awg-col awg-fieldsize-override">
                    <label class="awg-label"><?php echo esc_html__('Textarea Rows', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="2" max="20" name="awg_aig[style_textarea_rows]" value="<?php echo esc_attr((int) $m['style_textarea_rows']); ?>">
                </div>
            </div>

            <div class="awg-grid awg-style-override">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Background Color', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[style_bg_color]" value="#<?php echo esc_attr(ltrim($m['style_bg_color'], '#')); ?>" data-default-color="<?php echo esc_attr($palette_for('style_bg_color')); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Text Color', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[style_text_color]" value="#<?php echo esc_attr(ltrim($m['style_text_color'], '#')); ?>" data-default-color="<?php echo esc_attr($palette_for('style_text_color')); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Border Color', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[style_border_color]" value="#<?php echo esc_attr(ltrim($m['style_border_color'], '#')); ?>" data-default-color="<?php echo esc_attr($palette_for('style_border_color')); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Accent Color', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[style_accent_color]" value="#<?php echo esc_attr(ltrim($m['style_accent_color'], '#')); ?>" data-default-color="<?php echo esc_attr($palette_for('style_accent_color')); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Padding (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="0" max="80" name="awg_aig[style_padding]" value="<?php echo esc_attr((int) $m['style_padding']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Margin (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="0" max="80" name="awg_aig[style_margin]" value="<?php echo esc_attr((int) $m['style_margin']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Border Radius (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="0" max="40" name="awg_aig[style_radius]" value="<?php echo esc_attr((int) $m['style_radius']); ?>">
                </div>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Icon Class', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[button_icon_class]" value="<?php echo esc_attr($m['button_icon_class'] ?? ''); ?>" placeholder="dashicons dashicons-admin-tools">
                    <p class="description"><?php echo esc_html__('Use Dashicons classes. Leave empty to hide icon.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Icon Size (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="10" max="40" name="awg_aig[button_icon_size]" value="<?php echo esc_attr((int) ($m['button_icon_size'] ?? 18)); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Icon Position', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[button_icon_position]">
                        <option value="before" <?php selected(($m['button_icon_position'] ?? 'before'), 'before'); ?>><?php echo esc_html__('Before Label', 'authorwings-ai-tools'); ?></option>
                        <option value="after" <?php selected(($m['button_icon_position'] ?? 'before'), 'after'); ?>><?php echo esc_html__('After Label', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Icon Extra CSS Class', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="awg_aig[button_icon_css_class]" value="<?php echo esc_attr($m['button_icon_css_class'] ?? ''); ?>" placeholder="my-custom-icon">
                </div>
            </div>

            <div class="awg-grid awg-style-override">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Background', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[style_button_bg_color]" value="#<?php echo esc_attr(ltrim($m['style_button_bg_color'], '#')); ?>" data-default-color="<?php echo esc_attr($palette_for('style_button_bg_color')); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Text Color', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[style_button_text_color]" value="#<?php echo esc_attr(ltrim($m['style_button_text_color'], '#')); ?>" data-default-color="<?php echo esc_attr($palette_for('style_button_text_color')); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Border Color', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-color-picker" type="text" name="awg_aig[style_button_border_color]" value="#<?php echo esc_attr(ltrim($m['style_button_border_color'], '#')); ?>" data-default-color="<?php echo esc_attr($palette_for('style_button_border_color')); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Padding Y (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="6" max="30" name="awg_aig[style_button_padding_y]" value="<?php echo esc_attr((int) $m['style_button_padding_y']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Padding X (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="8" max="40" name="awg_aig[style_button_padding_x]" value="<?php echo esc_attr((int) $m['style_button_padding_x']); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Button Radius (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="0" max="20" name="awg_aig[style_button_radius]" value="<?php echo esc_attr((int) $m['style_button_radius']); ?>">
                </div>
            </div>

            <?php Settings::section_close(); ?>

            <?php Settings::section_open('tpl_fields', __('Fields', 'authorwings-ai-tools'), false, __('Inputs shown to users on the form', 'authorwings-ai-tools')); ?>

            <h3 style="margin:0 0 10px;"><?php echo esc_html__('Fields (Add unlimited inputs)', 'authorwings-ai-tools'); ?></h3>
            <p class="description"><?php echo esc_html__('Supported types: text, textarea, select, number, email, checkbox, radio, file. For checkbox, select, and radio, provide options one per line or comma-separated. Checkbox without options works as a single yes/no field. For File, set the allowed file types and max size in the field row — visitors can upload a manuscript, brief, spreadsheet or image, and its text is extracted and sent to the AI as part of {{fields}}.', 'authorwings-ai-tools'); ?></p>

            <div id="awg-fields" class="awg-fields">
                <?php foreach ($m['fields'] as $i => $f): ?>
                    <?php $this->render_field_row($i, $f); ?>
                <?php endforeach; ?>
            </div>

            <button type="button" class="button" id="awg-add-field"><?php echo esc_html__('+ Add Field', 'authorwings-ai-tools'); ?></button>
            <p id="awg-fields-custom-note" class="description" style="display:none;color:#a55;margin-top:8px;"><?php echo esc_html__('Design Mode is set to Custom HTML, so these Fields are ignored on the front-end — the form comes from the Custom Form HTML box below. They stay saved in case you switch back.', 'authorwings-ai-tools'); ?></p>

            <?php Settings::section_close(); ?>

            <?php Settings::section_open('tpl_custom_html', __('Custom Form HTML', 'authorwings-ai-tools'), false, __('Used only when Design Mode = Custom HTML', 'authorwings-ai-tools')); ?>

            <?php
            $awg_custom_starter = "<div class=\"awg-aig__field\">\n  <label class=\"awg-aig__label\">Genre</label>\n  <input class=\"awg-aig__input\" type=\"text\" name=\"genre\" data-awg-label=\"Genre\" placeholder=\"e.g. Fantasy\" required>\n</div>\n\n<div class=\"awg-aig__field\">\n  <label class=\"awg-aig__label\">Keywords</label>\n  <textarea class=\"awg-aig__input\" name=\"keywords\" rows=\"4\" data-awg-label=\"Keywords\"></textarea>\n</div>\n\n<div class=\"awg-aig__actions\">\n  <button type=\"submit\" class=\"awg-aig__btn\"><span>Generate</span></button>\n</div>";
            ?>

            <div id="awg-custom-html-wrap">
                <p id="awg-custom-html-off-note" class="description" style="display:none;color:#777;"><?php echo esc_html__('This box is only used when Design Mode (top of Form Basics) is set to Custom HTML.', 'authorwings-ai-tools'); ?></p>

                <p class="description" style="margin-bottom:6px;"><?php echo esc_html__('Write any form markup you want. Rules:', 'authorwings-ai-tools'); ?></p>
                <ul class="description" style="margin:0 0 10px 18px;list-style:disc;">
                    <li><?php echo esc_html__('Give every input/textarea/select a name attribute — each one is sent to the AI as {{fields}}.', 'authorwings-ai-tools'); ?></li>
                    <li><?php echo esc_html__('Optional: add data-awg-label="Nice Label" to control how a field appears in the prompt. Without it the name is used (book_genre shows as "Book Genre").', 'authorwings-ai-tools'); ?></li>
                    <li><?php echo esc_html__('For several checkboxes sharing one field, use name="things[]".', 'authorwings-ai-tools'); ?></li>
                    <li><?php echo esc_html__('Include a submit button with class="awg-aig__btn" type="submit" so it gets the loading state.', 'authorwings-ai-tools'); ?></li>
                    <li><?php echo esc_html__('Your User Prompt template still applies — {{fields}} is replaced with all your inputs. Scripts and on* event handlers are stripped for security.', 'authorwings-ai-tools'); ?></li>
                </ul>

                <textarea class="awg-input" name="awg_aig[custom_html]" rows="16" spellcheck="false" style="width:100%;font-family:Menlo,Consolas,monospace;font-size:12px;line-height:1.5;" placeholder="<?php echo esc_attr($awg_custom_starter); ?>"><?php echo esc_textarea($m['custom_html'] ?? ''); ?></textarea>

                <p class="description" style="margin-top:8px;"><?php echo esc_html__('Starter you can copy, paste and edit:', 'authorwings-ai-tools'); ?></p>
                <pre style="background:#f6f7f7;border:1px solid #dcdcde;padding:10px;overflow:auto;font-size:12px;"><?php echo esc_html($awg_custom_starter); ?></pre>
            </div>

            <?php Settings::section_close(); ?>

            <script>
            (function(){
                var sel = document.getElementById('awg-design-mode');
                if (!sel) { return; }
                var customWrap = document.getElementById('awg-custom-html-wrap');
                var offNote    = document.getElementById('awg-custom-html-off-note');
                var fieldsWrap = document.getElementById('awg-fields');
                var addField   = document.getElementById('awg-add-field');
                var fieldsNote = document.getElementById('awg-fields-custom-note');
                function sync(){
                    var custom = (sel.value === 'custom_html');
                    if (customWrap) { customWrap.style.opacity = custom ? '1' : '0.5'; }
                    if (offNote)    { offNote.style.display = custom ? 'none' : 'block'; }
                    if (fieldsWrap) { fieldsWrap.style.opacity = custom ? '0.5' : '1'; }
                    if (addField)   { addField.style.opacity = custom ? '0.5' : '1'; }
                    if (fieldsNote) { fieldsNote.style.display = custom ? 'block' : 'none'; }
                }
                sel.addEventListener('change', sync);
                sync();
            })();
            </script>

            <?php Settings::section_open('tpl_model', __('AI Model & Limits', 'authorwings-ai-tools'), false, __('Model, tokens, rate limit, cache, guest access', 'authorwings-ai-tools')); ?>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Model (optional)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" list="awg-aig-models-tpl" name="awg_aig[model]" value="<?php echo esc_attr($m['model']); ?>" placeholder="<?php echo esc_attr__('Leave empty to use global default', 'authorwings-ai-tools'); ?>">
                    <datalist id="awg-aig-models-tpl">
                        <option value="gpt-5"></option>
                        <option value="gpt-5-mini"></option>
                        <option value="gpt-5-nano"></option>
                        <option value="gpt-4.1"></option>
                        <option value="gpt-4.1-mini"></option>
                        <option value="gpt-4o"></option>
                        <option value="gpt-4o-mini"></option>
                        <option value="o4-mini"></option>
                        <option value="o3"></option>
                        <option value="o3-mini"></option>
                        <option value="claude-opus-4-8"></option>
                        <option value="claude-opus-4-7"></option>
                        <option value="claude-sonnet-4-6"></option>
                        <option value="claude-haiku-4-5-20251001"></option>
                        <option value="deepseek-v4-flash"></option>
                        <option value="deepseek-v4-pro"></option>
                        <option value="deepseek-chat"></option>
                        <option value="deepseek-reasoner"></option>
                    </datalist>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Max Output Tokens', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="1" max="8000" name="awg_aig[max_output_tokens]" value="<?php echo esc_attr($m['max_output_tokens']); ?>">
                    <p class="description"><?php echo esc_html__('Cap the model\'s reply length. Blurb ≈ 300, full article ≈ 3000.', 'authorwings-ai-tools'); ?></p>
                </div>
                <?php
                // v5.7.9: all agent modes were removed from templates. A template
                // is always a normal one-shot generator now; agent_id and
                // agent_standalone are forced to 0 on save and in get_template_meta,
                // so any agent settings left from older versions are ignored.
                // Conversational chatbots live under AuthorWings AI → AI Agents.
                ?>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Download Format', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[output_format]">
                        <option value="text" <?php selected($m['output_format'], 'text'); ?>><?php echo esc_html__('Text (.txt)', 'authorwings-ai-tools'); ?></option>
                        <option value="pdf" <?php selected($m['output_format'], 'pdf'); ?>><?php echo esc_html__('PDF', 'authorwings-ai-tools'); ?></option>
                    </select>
                    <p class="description"><?php echo esc_html__('What the result’s “Download” button saves: Text = a plain .txt file; PDF = a formatted PDF (opens the print dialog → Save as PDF).', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Result Style', 'authorwings-ai-tools'); ?></label>
                    <?php $awg_rm = (($m['render_mode'] ?? 'document') === 'plain') ? 'plain' : 'document'; ?>
                    <select class="awg-input" name="awg_aig[render_mode]">
                        <option value="plain" <?php selected($awg_rm, 'plain'); ?>><?php echo esc_html__('Plain text', 'authorwings-ai-tools'); ?></option>
                        <option value="document" <?php selected($awg_rm, 'document'); ?>><?php echo esc_html__('Editorial', 'authorwings-ai-tools'); ?></option>
                    </select>
                    <p class="description"><?php echo esc_html__('How results are laid out. Plain text is one clean prose block — best for a blurb, bio or single answer. Editorial composes whatever the AI returns: it shows a flat menu of options as copyable cards, and richer output (sections, ratings, checklists, redline edits, before/after, stat grids, tag chips) as a polished document. Editorial replaces the old Auto, Card list and Document styles.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>

            <?php
            // v5.4.85: Result blocks palette. This is the full toolbox of every
            // block Editorial can render, so the prompt author can see what's
            // available and drop the matching instruction straight into Rules.
            // Two groups:
            //   'instruct' — only appear if the prompt explicitly asks for them.
            //   'auto'     — render whenever the AI naturally produces the shape;
            //                the snippet is an optional nudge to steer the AI there.
            // Each block: 'label' = name shown, 'desc' = one-line hint,
            // 'prompt' = the line appended to the Rules field on Insert.
            $awg_block_groups = self::result_blocks_palette();
            ?>
            <div class="awg-field awg-blocks">
                <label class="awg-label"><?php echo esc_html__('Result blocks (Editorial)', 'authorwings-ai-tools'); ?></label>
                <p class="description awg-blocks-intro"><?php echo esc_html__('The full set of blocks Editorial can render. Use this as a menu while you write your prompt: click "Insert" on any block to drop its instruction into the Rules field below, then edit it however you like. Each instruction is conditional — it tells the AI to use the block only when the content genuinely calls for it, so a tool never invents a rewrite, score or quote just to fill a block.', 'authorwings-ai-tools'); ?></p>
                <?php foreach ($awg_block_groups as $awg_gkey => $awg_group) : ?>
                    <div class="awg-blocks-group">
                        <span class="awg-blocks-grouptitle"><?php echo esc_html($awg_group['title']); ?></span>
                        <div class="awg-blocks-list">
                            <?php foreach ($awg_group['blocks'] as $awg_bkey => $awg_b) : ?>
                                <div class="awg-block-row">
                                    <div class="awg-block-row__main">
                                        <span class="awg-block-row__label"><?php echo esc_html($awg_b['label']); ?></span>
                                        <span class="awg-block-row__desc"><?php echo esc_html($awg_b['desc']); ?></span>
                                    </div>
                                    <code class="awg-block-row__prompt" title="<?php echo esc_attr($awg_b['prompt']); ?>"><?php echo esc_html($awg_b['prompt']); ?></code>
                                    <button type="button" class="button button-small awg-block-insert" data-awg-insert="<?php echo esc_attr($awg_b['prompt']); ?>"><?php echo esc_html__('Insert', 'authorwings-ai-tools'); ?></button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Template Rate Limit (per minute per IP)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="0" max="99999" name="awg_aig[rate_per_min]" value="<?php echo esc_attr($m['rate_per_min']); ?>">
                    <p class="description"><?php echo esc_html__('0 = inherit global rate limit. If set, the tighter of template and global wins.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Allow Guests', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[allow_guests]">
                        <option value="-1" <?php selected($m['allow_guests'], -1); ?>><?php echo esc_html__('Inherit Global', 'authorwings-ai-tools'); ?></option>
                        <option value="1" <?php selected($m['allow_guests'], 1); ?>><?php echo esc_html__('Allow Guests', 'authorwings-ai-tools'); ?></option>
                        <option value="0" <?php selected($m['allow_guests'], 0); ?>><?php echo esc_html__('Login Required', 'authorwings-ai-tools'); ?></option>
                    </select>
                    <p class="description"><?php echo esc_html__('Whether non-logged-in visitors can run this tool. Inherit uses the global default in Settings.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Reject Gibberish Input', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[gibberish_check]">
                        <option value="global" <?php selected($m['gibberish_check'], 'global'); ?>><?php echo esc_html__('Inherit Global', 'authorwings-ai-tools'); ?></option>
                        <option value="on" <?php selected($m['gibberish_check'], 'on'); ?>><?php echo esc_html__('On — block random characters', 'authorwings-ai-tools'); ?></option>
                        <option value="off" <?php selected($m['gibberish_check'], 'off'); ?>><?php echo esc_html__('Off — accept any input', 'authorwings-ai-tools'); ?></option>
                    </select>
                    <p class="description"><?php echo esc_html__('Block keyboard-mashing in text fields before it reaches the AI. Turn Off for tools that take codes, slugs, or non-Latin input. Inherit uses the global Settings default.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label">
                        <input type="checkbox" name="awg_aig[debug_admin]" value="1" <?php checked($m['debug_admin'], 1); ?>>
                        <?php echo esc_html__('Debug (admins only)', 'authorwings-ai-tools'); ?>
                    </label>
                    <p class="description"><?php echo esc_html__('When ON, logged-in admins see the raw OpenAI API response on errors. Leave OFF in production — visitors never see this regardless.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>

            <?php
            // Membership integration: Required Plan field. Only renders when the
            // AuthorWings Membership plugin is active. The meta key
            // _awg_mem_required_plan is what the membership plugin reads to
            // gate template visibility and generation.
            if (defined('AWG_MEM_VERSION')) :
                $awg_mem_required_plan = get_post_meta($post->ID, '_awg_mem_required_plan', true) ?: 'free';
                $awg_mem_plan_options  = [
                    'free'      => __('Free — everyone can use', 'authorwings-ai-tools'),
                    'basic'     => __('Basic and above', 'authorwings-ai-tools'),
                    'pro'       => __('Pro and above', 'authorwings-ai-tools'),
                    'publisher' => __('Publisher only', 'authorwings-ai-tools'),
                ];
            ?>
            <div class="awg-grid" style="margin-top:12px;padding:12px;background:#f0f7ff;border:1px solid #d1e3fa;border-radius:6px;">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Required Membership Plan', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="awg_aig[required_plan]">
                        <?php foreach ($awg_mem_plan_options as $awg_mem_slug => $awg_mem_label) : ?>
                            <option value="<?php echo esc_attr($awg_mem_slug); ?>" <?php selected($awg_mem_required_plan, $awg_mem_slug); ?>>
                                <?php echo esc_html($awg_mem_label); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php echo esc_html__('Controls which membership plan is needed to access this tool in the member dashboard and in the front-end gate.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>
            <?php endif; ?>

            <?php Settings::section_close(); ?>

            <?php Settings::section_open('tpl_usage', __('Usage Insights', 'authorwings-ai-tools'), false, __('Run count and last generated time', 'authorwings-ai-tools')); ?>

            <p class="description">
                <?php
                    $usage_count = (int) get_post_meta($post->ID, '_awg_aig_usage_count', true);
                    $last_generated = (string) get_post_meta($post->ID, '_awg_aig_last_generated', true);
                    $last_label = $last_generated ? wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime($last_generated)) : __('—', 'authorwings-ai-tools');
                    echo esc_html(sprintf(__('Total runs: %1$s | Last generated: %2$s', 'authorwings-ai-tools'), $usage_count, $last_label));
                ?>
            </p>

            <?php Settings::section_close(); ?>

            <?php Settings::section_open('tpl_prompt', __('Prompt', 'authorwings-ai-tools'), false, __('System, rules, and user prompt template', 'authorwings-ai-tools')); ?>

            <div class="awg-grid">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('System Prompt', 'authorwings-ai-tools'); ?></label>
                    <textarea class="awg-textarea" name="awg_aig[system_prompt]"><?php echo esc_textarea($m['system_prompt']); ?></textarea>
                    <label style="display:block;margin-top:8px;">
                        <input type="checkbox" name="awg_aig[apply_global_prompt]" value="1" <?php checked((int) $m['apply_global_prompt'], 1); ?>>
                        <?php echo esc_html__('Apply the Global Prompt from AuthorWings AI → Settings before this system prompt', 'authorwings-ai-tools'); ?>
                    </label>
                    <p class="description"><?php echo esc_html__('On by default. Uncheck to run this tool with only its own system prompt above. Tip: put shared rules (tone, language, do/don\'t lists) in the Global System Prompt under AuthorWings AI → Settings so every tool inherits them from one place.', 'authorwings-ai-tools'); ?></p>
                    <p class="description"><?php echo esc_html__('Formatting is now automatic and scoped by Result Style: Plain text tools receive no block guidance, while Editorial tools automatically receive the formatting-hygiene line plus only the block-formatting rules for the blocks they actually use. Nothing extra to tick, and the same rule is never sent twice.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Rules (used in prompt as {{rules}})', 'authorwings-ai-tools'); ?></label>
                    <textarea class="awg-textarea" name="awg_aig[rules]"><?php echo esc_textarea($m['rules']); ?></textarea>
                </div>
            </div>

            <label class="awg-label" style="margin-top:12px;"><?php echo esc_html__('User Prompt Template', 'authorwings-ai-tools'); ?></label>
            <textarea class="awg-textarea" name="awg_aig[user_prompt]"><?php echo esc_textarea($m['user_prompt']); ?></textarea>
            <p class="description">
                <?php echo esc_html__('Placeholders: {{task}}, {{count}}, {{fields}}, {{rules}}.', 'authorwings-ai-tools'); ?>
                <br><?php echo esc_html__('All field inputs are automatically converted into {{fields}} and sent to GPT.', 'authorwings-ai-tools'); ?>
            </p>

            <?php
            // v5.4.14: Final Prompt Preview pane.
            //
            // Mirrors the assembly logic in class-ajax.php::generate() and
            // class-renderer.php::fields_to_text() so the admin can see
            // exactly what the model will receive without needing to run
            // a generation. Sample field values come from each field's
            // "Default" — when no default is set, the placeholder text
            // [KEY] is substituted so the admin can see where each input
            // would land in the prompt.
            //
            // Auto-refresh: any change to the prompts, rules, task, count,
            // or field defs re-renders both panels. No save/reload needed.
            //
            // Implementation note: this is presentational only. Nothing
            // here gets stored or sent — it's a JS-only DOM read of the
            // form values. If the server-side assembly ever changes,
            // update this JS to match (the comment block at the top of
            // generate() in class-ajax.php cross-references this).
            ?>
            <div class="awg-prompt-preview" style="margin-top:18px;border:1px solid #c3c4c7;border-radius:6px;background:#f6f7f7;">
                <div style="padding:10px 12px;border-bottom:1px solid #dcdcde;background:#fff;border-radius:6px 6px 0 0;display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <strong style="font-size:13px;"><?php echo esc_html__('Final Prompt Preview (what GPT receives)', 'authorwings-ai-tools'); ?></strong>
                    <span id="awg-preview-stats" style="font-size:11px;color:#646970;margin-left:auto;"></span>
                </div>
                <p class="description" style="margin:8px 12px 4px;font-size:11px;">
                    <?php echo esc_html__('Real submissions replace the sample values below with user-entered input. Samples use each field\'s "Default" — fields without a default show as [KEY] so you can spot them.', 'authorwings-ai-tools'); ?>
                </p>
                <div style="padding:6px 12px 12px;">
                    <label style="display:block;font-size:11px;font-weight:600;color:#646970;text-transform:uppercase;letter-spacing:.04em;margin:8px 0 4px;">
                        <?php echo esc_html__('System message', 'authorwings-ai-tools'); ?>
                    </label>
                    <textarea id="awg-preview-system" readonly rows="8" style="width:100%;font-family:Consolas,Monaco,monospace;font-size:12px;background:#fff;border:1px solid #dcdcde;padding:6px 8px;border-radius:4px;resize:vertical;"></textarea>

                    <label style="display:block;font-size:11px;font-weight:600;color:#646970;text-transform:uppercase;letter-spacing:.04em;margin:10px 0 4px;">
                        <?php echo esc_html__('User message', 'authorwings-ai-tools'); ?>
                    </label>
                    <textarea id="awg-preview-user" readonly rows="12" style="width:100%;font-family:Consolas,Monaco,monospace;font-size:12px;background:#fff;border:1px solid #dcdcde;padding:6px 8px;border-radius:4px;resize:vertical;"></textarea>

                    <p style="margin:8px 0 0;font-size:11px;color:#646970;">
                        <?php
                        printf(
                            /* translators: %s: max_output_tokens field name */
                            esc_html__('Length here is the INPUT prompt only. The model\'s reply is capped separately by %s in the AI Model & Limits section.', 'authorwings-ai-tools'),
                            '<code>Max Output Tokens</code>'
                        );
                        ?>
                    </p>
                </div>
            </div>

            <?php
            // v5.7.9: feed the preview the same site-wide prompt pieces the
            // generate handler appends, so "Final Prompt Preview" matches what
            // the model actually receives (global prompt + the two formatting
            // lines), not just the System/User text typed above.
            $awg_pv_settings = get_option(Plugin::OPT, []);
            if (!is_array($awg_pv_settings)) { $awg_pv_settings = []; }
            $awg_pv = [
                'globalPrompt' => trim((string) ($awg_pv_settings['global_prompt'] ?? '')),
                'hygiene'      => Renderer::effective_format_hygiene($awg_pv_settings),
                // v5.8.3: site-wide override (if the admin replaced the rules text),
                // else the per-block fragments the preview injects on demand.
                'fmtOverride'  => trim((string) ($awg_pv_settings['format_rules'] ?? '')),
                'fragments'    => array_values(Renderer::format_fragments()),
            ];
            ?>
            <script>
            (function(){
                'use strict';
                var AWG_PV = <?php echo wp_json_encode($awg_pv, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_SLASHES); ?>;
                // Wait until the DOM is settled — the field rows are PHP-rendered
                // so they're already present on first paint, but the field
                // template clone uses __INDEX__ that we don't want to render.
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', init);
                } else {
                    init();
                }

                function init() {
                    var sysEl  = document.getElementById('awg-preview-system');
                    var userEl = document.getElementById('awg-preview-user');
                    var stats  = document.getElementById('awg-preview-stats');
                    if (!sysEl || !userEl) return;

                    // Mirror class-renderer.php::fields_to_text() exactly.
                    // Returns the {{fields}} block string.
                    function buildFieldsText() {
                        var rows  = document.querySelectorAll('#awg-fields .awg-field-row');
                        var lines = [];
                        rows.forEach(function(row){
                            // Field rows inside the <template id="awg-field-template">
                            // never reach the live DOM, so we don't need to skip __INDEX__.
                            var keyEl   = row.querySelector('input[name$="[key]"]');
                            var labelEl = row.querySelector('input[name$="[label]"]');
                            var typeEl  = row.querySelector('select[name$="[type]"]');
                            var defEl   = row.querySelector('input[name$="[default]"]');
                            if (!keyEl) return;

                            var key = (keyEl.value || '').trim();
                            if (!key) return;

                            // Mirror sanitize_key — lowercase, only [a-z0-9_].
                            // We don't need to mutate the value, just bail on truly empty.
                            var safeKey = key.toLowerCase().replace(/[^a-z0-9_]/g, '');
                            if (!safeKey) return;

                            var label = (labelEl && labelEl.value) ? labelEl.value : safeKey;
                            var type  = (typeEl  && typeEl.value)  ? typeEl.value  : 'text';
                            var def   = (defEl   && defEl.value)   ? defEl.value   : '';

                            // Sample value: use the default the admin set; if
                            // none, show [KEY] so the admin sees where this
                            // input would land in the final prompt.
                            var val;
                            if (def === '') {
                                val = '[' + safeKey.toUpperCase() + ']';
                            } else {
                                val = def;
                            }

                            // Server collapses single-line textareas like other
                            // fields; multi-line textareas get rendered on a
                            // separate block so the model sees paragraph structure.
                            if (type === 'textarea' && val.indexOf('\n') !== -1) {
                                lines.push('- ' + label + ':\n' + val);
                            } else {
                                lines.push('- ' + label + ': ' + val);
                            }
                        });
                        if (lines.length === 0) return '(No inputs provided)';
                        return lines.join('\n');
                    }

                    function val(selector) {
                        var el = document.querySelector(selector);
                        return el ? (el.value || '') : '';
                    }

                    // Approximate token count. OpenAI's published rule of
                    // thumb is ~4 characters per token for English; we round
                    // up so the admin doesn't undercount.
                    function estimateTokens(text) {
                        return Math.ceil((text || '').length / 4);
                    }

                    function render() {
                        var sys      = val('textarea[name="awg_aig[system_prompt]"]');
                        var userTpl  = val('textarea[name="awg_aig[user_prompt]"]');
                        var rules    = val('textarea[name="awg_aig[rules]"]');
                        var task     = val('input[name="awg_aig[task]"]');
                        var countRaw = val('input[name="awg_aig[count]"]');
                        // Mirror (string)(int) cast on the server side.
                        var count = String(parseInt(countRaw, 10) || 0);

                        var fieldsText = buildFieldsText();

                        // v5.4.71: pre-expand {{task}}/{{count}} inside the Rules
                        // text first, mirroring class-ajax.php — otherwise a
                        // {{count}} written in Rules would render unresolved here
                        // while the server resolves it (or vice-versa).
                        var rulesExpanded = rules
                            .split('{{task}}').join(task)
                            .split('{{count}}').join(count);

                        // Order matters — match the server's str_replace exactly.
                        var userMsg = userTpl
                            .split('{{task}}').join(task)
                            .split('{{count}}').join(count)
                            .split('{{fields}}').join(fieldsText)
                            .split('{{rules}}').join(rulesExpanded);

                        // Assemble the full system message exactly like the
                        // server (class-ajax.php): optional global prompt first,
                        // then the tool's system prompt, then the two formatting
                        // lines that are always appended.
                        var applyGlobalEl = document.querySelector('input[name="awg_aig[apply_global_prompt]"]');
                        var applyGlobal = applyGlobalEl ? applyGlobalEl.checked : true;
                        // v5.8.3: formatting is automatic and scoped by Result Style.
                        // Plain text → nothing. Editorial → hygiene + only the block
                        // rules for blocks this tool uses (and not already inline).
                        var modeEl = document.querySelector('select[name="awg_aig[render_mode]"]');
                        var renderMode = modeEl ? modeEl.value : 'document';
                        var sysParts = [];
                        if (applyGlobal && AWG_PV.globalPrompt) { sysParts.push(AWG_PV.globalPrompt); }
                        if (sys) { sysParts.push(sys); }
                        if (renderMode !== 'plain') {
                            var ctx = (rules + '\n' + userTpl + '\n' + sys).toLowerCase();
                            if (AWG_PV.hygiene && ctx.indexOf('never mention formatting') === -1) {
                                sysParts.push(AWG_PV.hygiene);
                            }
                            if (AWG_PV.fmtOverride) {
                                sysParts.push(AWG_PV.fmtOverride);
                            } else {
                                (AWG_PV.fragments || []).forEach(function(frag){
                                    var used = (frag.use || []).some(function(n){
                                        return n && ctx.indexOf(String(n).toLowerCase()) !== -1;
                                    });
                                    if (!used) { return; }
                                    if (frag.have && ctx.indexOf(String(frag.have).toLowerCase()) !== -1) { return; }
                                    sysParts.push(frag.text);
                                });
                            }
                        }
                        var fullSys = sysParts.join('\n\n');

                        sysEl.value  = fullSys;
                        userEl.value = userMsg;

                        if (stats) {
                            var total = fullSys.length + userMsg.length;
                            stats.textContent =
                                total.toLocaleString() + ' chars · ~' +
                                estimateTokens(fullSys + userMsg).toLocaleString() + ' tokens (rough)';
                        }
                    }

                    // Live updates: any input/change on the form re-renders.
                    // Scoped to the post editor container so we don't run on
                    // every keystroke elsewhere on the page.
                    var container = document.getElementById('post-body-content') || document.body;
                    container.addEventListener('input',  function(e){
                        if (e.target && e.target.name && e.target.name.indexOf('awg_aig[') === 0) {
                            render();
                        }
                    });
                    container.addEventListener('change', function(e){
                        if (e.target && e.target.name && e.target.name.indexOf('awg_aig[') === 0) {
                            render();
                        }
                    });
                    // Add/Remove Field re-renders too (delegated above through
                    // the input/change listeners — but those don't fire for
                    // DOM additions/removals, so listen for clicks too).
                    container.addEventListener('click', function(e){
                        var t = e.target;
                        if (!t) return;
                        if (t.id === 'awg-add-field' || (t.classList && t.classList.contains('awg-remove-field'))) {
                            // Defer one tick so the DOM mutation completes first.
                            setTimeout(render, 0);
                        }
                    });

                    render(); // first paint
                }
            })();
            </script>

            <?php Settings::section_close(); ?>

            <p class="description" style="margin-top:14px;">
                <?php echo esc_html__('Shortcode for this template:', 'authorwings-ai-tools'); ?>
                <code>[awg_generator id="<?php echo intval($post->ID); ?>"]</code>
            </p>

            <template id="awg-field-template">
                <?php $this->render_field_row('__INDEX__', [
                    'key' => '',
                    'label' => '',
                    'type' => 'text',
                    'required' => 0,
                    'placeholder' => '',
                    'options' => '',
                    'default' => '',
                    'icon_class' => '',
                    'icon_size' => 16,
                    'icon_position' => 'before_label',
                    'width' => 'full',
                    'file_types' => '',
                    'file_max_mb' => 0,
                ], true); ?>
            </template>
        </div>
        <?php
    }

    private function render_field_row($i, array $f, bool $is_template = false): void {
        $idx = $i;
        $name = function ($k) use ($idx) {
            return "awg_aig[fields][{$idx}][{$k}]";
        };

        $key = sanitize_key($f['key'] ?? '');
        $label = $f['label'] ?? '';
        $type = $f['type'] ?? 'text';
        $required = !empty($f['required']) ? 1 : 0;
        $placeholder = $f['placeholder'] ?? '';
        $options = $f['options'] ?? '';
        $default = $f['default'] ?? '';
        $icon_class = $f['icon_class'] ?? '';
        $icon_size = max(10, min(30, intval($f['icon_size'] ?? 16)));
        $icon_position = in_array(($f['icon_position'] ?? 'before_label'), ['before_label', 'after_label', 'before_input', 'after_input'], true) ? ($f['icon_position'] ?? 'before_label') : 'before_label';
        // v5.4.21: per-field layout width (full / half / third).
        $width_raw = $f['width'] ?? 'full';
        $width = in_array($width_raw, ['full', 'half', 'third'], true) ? $width_raw : 'full';
        // v5.4.69: upload-field config (only meaningful when Type = file).
        $file_types = (string) ($f['file_types'] ?? '');
        $file_max_mb = max(0, min(50, intval($f['file_max_mb'] ?? 0)));
        ?>
        <div class="awg-field-row" data-index="<?php echo esc_attr($idx); ?>">
            <div class="awg-field-row__top">
                <strong><?php echo esc_html__('Field', 'authorwings-ai-tools'); ?></strong>
                <button type="button" class="button-link-delete awg-remove-field"><?php echo esc_html__('Remove', 'authorwings-ai-tools'); ?></button>
            </div>

            <div class="awg-grid awg-grid--fields">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Key (unique)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="<?php echo esc_attr($name('key')); ?>" value="<?php echo esc_attr($key); ?>" placeholder="e.g., genre" <?php echo $is_template ? '' : 'required'; ?>>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Label', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="<?php echo esc_attr($name('label')); ?>" value="<?php echo esc_attr($label); ?>" placeholder="e.g., Genre">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Type', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="<?php echo esc_attr($name('type')); ?>">
                        <?php foreach (['text','textarea','select','number','email','checkbox','radio','file'] as $t): ?>
                            <option value="<?php echo esc_attr($t); ?>" <?php selected($type, $t); ?>><?php echo esc_html($t); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Required', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="<?php echo esc_attr($name('required')); ?>">
                        <option value="0" <?php selected($required, 0); ?>><?php echo esc_html__('No', 'authorwings-ai-tools'); ?></option>
                        <option value="1" <?php selected($required, 1); ?>><?php echo esc_html__('Yes', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
            </div>

            <div class="awg-grid awg-grid--fields">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Placeholder', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="<?php echo esc_attr($name('placeholder')); ?>" value="<?php echo esc_attr($placeholder); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Default Value', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="<?php echo esc_attr($name('default')); ?>" value="<?php echo esc_attr($default); ?>">
                </div>
                <div class="awg-col awg-col--wide">
                    <label class="awg-label"><?php echo esc_html__('Options (for checkbox/select/radio) — one per line', 'authorwings-ai-tools'); ?></label>
                    <textarea class="awg-textarea awg-textarea--small" name="<?php echo esc_attr($name('options')); ?>"><?php echo esc_textarea($options); ?></textarea>
                </div>
            </div>

            <div class="awg-grid awg-grid--fields">
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Field Icon Class', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="<?php echo esc_attr($name('icon_class')); ?>" value="<?php echo esc_attr($icon_class); ?>" placeholder="dashicons dashicons-edit">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Field Icon Size (px)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="10" max="30" name="<?php echo esc_attr($name('icon_size')); ?>" value="<?php echo esc_attr($icon_size); ?>">
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Field Icon Position', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="<?php echo esc_attr($name('icon_position')); ?>">
                        <option value="before_label" <?php selected($icon_position, 'before_label'); ?>><?php echo esc_html__('Before Label', 'authorwings-ai-tools'); ?></option>
                        <option value="after_label" <?php selected($icon_position, 'after_label'); ?>><?php echo esc_html__('After Label', 'authorwings-ai-tools'); ?></option>
                        <option value="before_input" <?php selected($icon_position, 'before_input'); ?>><?php echo esc_html__('Before Input', 'authorwings-ai-tools'); ?></option>
                        <option value="after_input" <?php selected($icon_position, 'after_input'); ?>><?php echo esc_html__('After Input', 'authorwings-ai-tools'); ?></option>
                    </select>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Width', 'authorwings-ai-tools'); ?></label>
                    <select class="awg-input" name="<?php echo esc_attr($name('width')); ?>">
                        <option value="full" <?php selected($width, 'full'); ?>><?php echo esc_html__('Full width (1 per row)', 'authorwings-ai-tools'); ?></option>
                        <option value="half" <?php selected($width, 'half'); ?>><?php echo esc_html__('Half — ½ (2 per row)', 'authorwings-ai-tools'); ?></option>
                        <option value="third" <?php selected($width, 'third'); ?>><?php echo esc_html__('Third — ⅓ (3 per row)', 'authorwings-ai-tools'); ?></option>
                    </select>
                    <p class="description"><?php echo esc_html__('On phones every field is full width; Half/Third only pair up on wider screens.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>

            <?php // v5.4.69: upload-field settings. Shown only when Type = file (toggled by admin.js). ?>
            <div class="awg-grid awg-grid--fields awg-file-settings" style="<?php echo $type === 'file' ? '' : 'display:none;'; ?>">
                <div class="awg-col awg-col--wide">
                    <label class="awg-label"><?php echo esc_html__('Allowed File Types (for File fields)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="text" name="<?php echo esc_attr($name('file_types')); ?>" value="<?php echo esc_attr($file_types); ?>" placeholder="pdf, doc, docx, txt, rtf, odt, md, csv, zip, jpg, png">
                    <p class="description"><?php echo esc_html__('Comma-separated extensions. Leave blank for a sensible document default (txt, pdf, doc, docx, rtf, odt, md, csv). Only safe types are ever accepted, even if you add others.', 'authorwings-ai-tools'); ?></p>
                </div>
                <div class="awg-col">
                    <label class="awg-label"><?php echo esc_html__('Max File Size (MB)', 'authorwings-ai-tools'); ?></label>
                    <input class="awg-input" type="number" min="1" max="50" name="<?php echo esc_attr($name('file_max_mb')); ?>" value="<?php echo esc_attr($file_max_mb > 0 ? $file_max_mb : 10); ?>">
                    <p class="description"><?php echo esc_html__('1–50 MB. Text is extracted from documents (txt, csv, docx, xlsx, pptx, html…) and sent to the AI; other files (pdf, images, zip) are passed as a reference link.', 'authorwings-ai-tools'); ?></p>
                </div>
            </div>
        </div>
        <?php
    }

    public function save(int $post_id, $post): void {
        if (!is_object($post) || $post->post_type !== $this->cpt) { return; }
        if (!isset($_POST['awg_aig_nonce']) || !wp_verify_nonce($_POST['awg_aig_nonce'], 'awg_aig_save')) { return; }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) { return; }
        if (!current_user_can('edit_post', $post_id)) { return; }

        $in = $_POST['awg_aig'] ?? [];
        if (!is_array($in)) { $in = []; }

        // v5.4.12: pass false here as well. Disabled inputs (when "Use global"
        // is ticked) don't POST a value, so save falls back to $m[...] — and if
        // that view had been merged with globals, the global value would be
        // written over the user's saved per-template color.
        $m = $this->renderer->get_template_meta($post_id, false);

        $m['form_title'] = sanitize_text_field($in['form_title'] ?? $m['form_title']);
        $m['form_description'] = sanitize_text_field($in['form_description'] ?? $m['form_description']);
        $m['task'] = sanitize_text_field($in['task'] ?? $m['task']);
        $m['button_label'] = sanitize_text_field($in['button_label'] ?? $m['button_label']);
        $m['title_icon_class'] = $this->sanitize_icon_class($in['title_icon_class'] ?? '');
        $m['title_icon_size'] = max(10, min(40, intval($in['title_icon_size'] ?? 20)));
        $m['title_icon_position'] = in_array(($in['title_icon_position'] ?? 'before'), ['before', 'after'], true) ? ($in['title_icon_position'] ?? 'before') : 'before';
        // v5.4.24: per-template header design overrides ('global' defers to Settings).
        $m['form_design'] = in_array(($in['form_design'] ?? 'global'), ['global', 'branded', 'plain'], true) ? ($in['form_design'] ?? 'global') : 'global';
        $m['header_icon_position'] = in_array(($in['header_icon_position'] ?? 'global'), ['global', 'top', 'left'], true) ? ($in['header_icon_position'] ?? 'global') : 'global';
        $m['title_font'] = in_array(($in['title_font'] ?? 'global'), ['global', 'serif', 'sans'], true) ? ($in['title_font'] ?? 'global') : 'global';
        // v5.4.26: per-template branded header overrides.
        $m['brand_eyebrow_mode'] = in_array(($in['brand_eyebrow_mode'] ?? 'global'), ['global', 'custom'], true) ? ($in['brand_eyebrow_mode'] ?? 'global') : 'global';
        $m['brand_eyebrow'] = sanitize_text_field($in['brand_eyebrow'] ?? '');
        $m['header_show_rule'] = in_array(($in['header_show_rule'] ?? 'global'), ['global', 'yes', 'no'], true) ? ($in['header_show_rule'] ?? 'global') : 'global';
        $m['header_subtitle_italic'] = in_array(($in['header_subtitle_italic'] ?? 'global'), ['global', 'yes', 'no'], true) ? ($in['header_subtitle_italic'] ?? 'global') : 'global';
        foreach (['brand_title_color', 'brand_subtitle_color', 'brand_eyebrow_color', 'brand_badge_bg_color', 'brand_badge_icon_color', 'brand_rule_color'] as $bk) {
            $raw = strtolower(trim((string) ($in[$bk] ?? '')));
            $raw = ltrim($raw, '#');
            if (preg_match('/^[0-9a-f]{3}$/', $raw)) { $raw = $raw[0].$raw[0].$raw[1].$raw[1].$raw[2].$raw[2]; }
            $m[$bk] = preg_match('/^[0-9a-f]{6}$/', $raw) ? $raw : ''; // blank = inherit global
        }
        $m['count'] = max(1, min(50, intval($in['count'] ?? $m['count'])));
        $m['disclaimer_text'] = sanitize_text_field($in['disclaimer_text'] ?? $m['disclaimer_text']);
        // v5.4.27: result heading + empty-state placeholder are now editable.
        // Both fall back to the existing default when left blank.
        $awg_success = sanitize_text_field($in['success_title'] ?? '');
        $m['success_title'] = $awg_success !== '' ? $awg_success : ($m['success_title'] ?? 'Result');
        $awg_placeholder = sanitize_text_field($in['placeholder_output'] ?? '');
        $m['placeholder_output'] = $awg_placeholder !== '' ? $awg_placeholder : ($m['placeholder_output'] ?? '');
        $m['hide_cta'] = isset($in['hide_cta']) ? 1 : 0;
        // v5.4.13: wp_unslash before wp_kses_post. The save_post hook gets
        // raw $_POST which WordPress's magic-quotes layer has slashed; kses's
        // attribute parser misreads `href=\"...\"` and strips the URL.
        $cta_override_raw = isset($in['cta_text_override']) ? (string) wp_unslash($in['cta_text_override']) : '';
        $m['cta_text_override'] = trim(wp_kses_post($cta_override_raw));

        // v5.9.0: "Discuss result with agent" — stored as a plain id + label.
        $m['result_agent_id'] = max(0, (int) ($in['result_agent_id'] ?? 0));
        $m['discuss_label']   = sanitize_text_field((string) ($in['discuss_label'] ?? ''));

        // v5.9.6: design mode + custom form markup. The Custom Form HTML box now
        // behaves like the WordPress core "Custom HTML" block in posts/pages:
        // editors who can post unfiltered_html (typically admins on single-site
        // installs) may save RAW markup including <script>/<style>; everyone else
        // is still run through the form-aware kses allowlist (strips scripts /
        // event handlers, keeps form tags + inline styles). wp_unslash first so
        // the save_post magic-quotes layer doesn't corrupt attribute quoting.
        $m['design_mode'] = in_array(($in['design_mode'] ?? 'standard'), ['standard', 'custom_html'], true) ? ($in['design_mode'] ?? 'standard') : 'standard';
        $custom_html_raw = isset($in['custom_html']) ? (string) wp_unslash($in['custom_html']) : '';
        $m['custom_html'] = current_user_can('unfiltered_html')
            ? $custom_html_raw
            : Renderer::sanitize_custom_form_html($custom_html_raw);

        // v5.4.9: show_copy/show_download/show_clear removed — always shown on front-end.
        $m['use_global_styles'] = isset($in['use_global_styles']) ? 1 : 0;
        $m['use_global_field_sizes'] = isset($in['use_global_field_sizes']) ? 1 : 0;
        // Any valid hex (3 or 6 digit, with or without #) is accepted.
        $m['style_bg_color']            = Settings::sanitize_hex_bare($in['style_bg_color']            ?? $m['style_bg_color'],            $m['style_bg_color']);
        $m['style_text_color']          = Settings::sanitize_hex_bare($in['style_text_color']          ?? $m['style_text_color'],          $m['style_text_color']);
        $m['style_border_color']        = Settings::sanitize_hex_bare($in['style_border_color']        ?? $m['style_border_color'],        $m['style_border_color']);
        $m['style_accent_color']        = Settings::sanitize_hex_bare($in['style_accent_color']        ?? $m['style_accent_color'],        $m['style_accent_color']);
        $m['style_padding'] = max(0, min(80, intval($in['style_padding'] ?? $m['style_padding'])));
        $m['style_margin'] = max(0, min(80, intval($in['style_margin'] ?? $m['style_margin'])));
        $m['style_radius'] = max(0, min(40, intval($in['style_radius'] ?? $m['style_radius'])));
        $m['style_button_bg_color']     = Settings::sanitize_hex_bare($in['style_button_bg_color']     ?? $m['style_button_bg_color'],     $m['style_button_bg_color']);
        $m['style_button_text_color']   = Settings::sanitize_hex_bare($in['style_button_text_color']   ?? $m['style_button_text_color'],   $m['style_button_text_color']);
        $m['style_button_border_color'] = Settings::sanitize_hex_bare($in['style_button_border_color'] ?? $m['style_button_border_color'], $m['style_button_border_color']);
        $m['style_button_padding_y'] = max(6, min(30, intval($in['style_button_padding_y'] ?? $m['style_button_padding_y'])));
        $m['style_button_padding_x'] = max(8, min(40, intval($in['style_button_padding_x'] ?? $m['style_button_padding_x'])));
        $m['style_button_radius'] = max(0, min(20, intval($in['style_button_radius'] ?? $m['style_button_radius'])));
        $m['button_icon_class'] = $this->sanitize_icon_class($in['button_icon_class'] ?? '');
        $m['button_icon_size'] = max(10, min(40, intval($in['button_icon_size'] ?? 18)));
        $m['button_icon_position'] = in_array(($in['button_icon_position'] ?? 'before'), ['before', 'after'], true) ? ($in['button_icon_position'] ?? 'before') : 'before';
        $m['button_icon_css_class'] = $this->sanitize_icon_class($in['button_icon_css_class'] ?? '');
        $m['style_input_height'] = max(32, min(80, intval($in['style_input_height'] ?? $m['style_input_height'])));
        $m['style_textarea_rows'] = max(2, min(20, intval($in['style_textarea_rows'] ?? $m['style_textarea_rows'])));

        $m['model'] = sanitize_text_field($in['model'] ?? '');
        // v5.7.9: agent modes were removed from templates. Force both flags off
        // so a saved template always runs as a normal one-shot generator. Any
        // other agent_* values already in $m (from get_template_meta) carry over
        // untouched and are ignored everywhere — we don't wipe them, we just
        // stop acting on them.
        $m['agent_id'] = 0;
        $m['agent_standalone'] = 0;
        // v5.4.7: temperature, temperature_mode, send_temperature all removed.
        // OpenAI uses each model's own default. Use the `awg_openai_payload`
        // filter if you need per-tool control on non-reasoning models.
        $m['max_output_tokens'] = max(1, min(8000, intval($in['max_output_tokens'] ?? $m['max_output_tokens'])));

        // Download format: 'text' (plain .txt) or 'pdf' (formatted PDF). Anything
        // else (including legacy 'html'/'json') falls back to 'text'.
        $m['output_format'] = in_array(($in['output_format'] ?? 'text'), ['text','pdf'], true) ? ($in['output_format'] ?? 'text') : 'text';
        // v5.4.81: per-template result layout. Only two styles remain — 'plain'
        // and 'document' (Editorial). Any legacy value (auto/cards/list) collapses
        // to Editorial, which renders flat option-lists as cards and richer output
        // as a document.
        $m['render_mode'] = (($in['render_mode'] ?? 'document') === 'plain') ? 'plain' : 'document';

        // v5.4.6: rate_per_min minimum is now 0 (= inherit global). cache_seconds removed.
        $m['rate_per_min'] = max(0, intval($in['rate_per_min'] ?? $m['rate_per_min']));
        $m['allow_guests'] = in_array((int) ($in['allow_guests'] ?? $m['allow_guests']), [-1, 0, 1], true) ? (int) ($in['allow_guests'] ?? $m['allow_guests']) : -1;
        // v5.4.48: per-template gibberish guard — 'global' | 'on' | 'off'.
        $m['gibberish_check'] = in_array(($in['gibberish_check'] ?? $m['gibberish_check'] ?? 'global'), ['global', 'on', 'off'], true) ? ($in['gibberish_check'] ?? $m['gibberish_check'] ?? 'global') : 'global';
        $m['debug_admin'] = isset($in['debug_admin']) ? 1 : 0;

        // Membership integration: save the required plan slug to its own meta
        // key so the membership plugin can read it without depending on this
        // plugin's $m blob. Only runs when the membership plugin is active so
        // we don't pollute meta on sites that don't use it. Also writes a
        // sensible default for _awg_mem_category which the dashboard uses for
        // grouping tools (defaults to "AI Tools").
        if (defined('AWG_MEM_VERSION')) {
            $awg_mem_allowed_plans = ['free', 'basic', 'pro', 'publisher'];
            $awg_mem_submitted     = sanitize_key((string) ($in['required_plan'] ?? 'free'));
            $awg_mem_required      = in_array($awg_mem_submitted, $awg_mem_allowed_plans, true) ? $awg_mem_submitted : 'free';
            update_post_meta($post_id, '_awg_mem_required_plan', $awg_mem_required);
            // Only set the category default if not already set, so admins who
            // edit it manually in the database aren't overwritten on each save.
            if (get_post_meta($post_id, '_awg_mem_category', true) === '') {
                update_post_meta($post_id, '_awg_mem_category', 'AI Tools');
            }
        }

        // v5.4.13: prompts are PLAIN TEXT sent to OpenAI, not HTML displayed in
        // a page. wp_kses_post would HTML-encode `&` to `&amp;` and strip any
        // `<word>` it doesn't recognize as a valid tag — corrupting every prompt
        // that contains those characters. sanitize_textarea_field keeps the text
        // intact while still stripping anything dangerous. wp_unslash removes
        // WP's magic-quotes backslashes that the save_post hook leaves on $_POST.
        $m['system_prompt'] = sanitize_textarea_field(wp_unslash($in['system_prompt'] ?? $m['system_prompt']));
        $m['rules']         = sanitize_textarea_field(wp_unslash($in['rules']         ?? $m['rules']));
        $m['user_prompt']   = sanitize_textarea_field(wp_unslash($in['user_prompt']   ?? $m['user_prompt']));
        // v5.4.49: opt-in (default on) to the global system prompt. Unchecked
        // checkboxes are absent from the POST, so a missing key means "off".
        $m['apply_global_prompt'] = isset($in['apply_global_prompt']) ? 1 : 0;

        // Fields. v5.7.0: field validation now lives on the renderer
        // (sanitize_fields_array) so the Build Assistant's
        // create_generator_template tool validates fields through the exact
        // same path — no drift between human- and AI-built templates.
        $m['fields'] = $this->renderer->sanitize_fields_array($in['fields'] ?? []);

        update_post_meta($post_id, '_awg_aig_template', $m);
    }

    private function sanitize_icon_class($value): string {
        $class = trim((string) $value);
        if ($class === '') {
            return '';
        }
        $parts = preg_split('/\s+/', $class);
        $parts = array_map('sanitize_html_class', array_filter($parts, static function ($part) {
            return is_string($part) && $part !== '';
        }));
        return trim(implode(' ', $parts));
    }
}
