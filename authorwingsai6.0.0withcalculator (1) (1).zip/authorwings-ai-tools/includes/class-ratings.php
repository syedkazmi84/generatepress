<?php
/**
 * Ratings module for AuthorWings AI Tools.
 *
 * Per-template 5-star ratings:
 *  - One rating record per template (CPT post). Multiple host pages embedding
 *    the same template share its rating, as they should (same tool = same rating).
 *  - Auto-renders inside each generator form on the front end — no shortcode needed.
 *  - Optional shortcode [awg_rating id="123"] for manual placement anywhere.
 *  - IP-locked submissions via a custom table with UNIQUE (post_id, ip_hash).
 *  - Admin "base count" + "base average" seed so totals can be primed.
 *  - Admin-editable real totals and one-click reset.
 *  - Schema.org AggregateRating JSON-LD injected into <head>. When a host page
 *    contains a generator, the schema uses the TEMPLATE's rating (not the host
 *    page's own meta) — which is what Google needs to attach stars to the tool.
 *
 * @package AWG_AIG
 */

namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Ratings {

    const TABLE     = 'awg_ratings';     // wpdb table suffix
    const NONCE     = 'awg_rating_nonce';
    const SHORTCODE = 'awg_rating';
    const COOKIE    = 'awg_rated';       // marker cookie prefix

    const DB_VERSION_OPT = 'awg_rating_db_version';
    const DB_VERSION     = '1.0';

    // Per-post meta keys (post can be CPT template OR any post/page)
    const META_ENABLED     = '_awg_rating_enabled';      // 0/1 (default 1 for CPT, 0 for others)
    const META_BASE_COUNT  = '_awg_rating_base_count';   // int (seed votes)
    const META_BASE_AVG    = '_awg_rating_base_avg';     // float (seed average)
    const META_SCHEMA_TYPE = '_awg_rating_schema_type';  // string
    const META_SCHEMA_NAME = '_awg_rating_schema_name';  // string (overrides post title in JSON-LD)
    const META_HEADING     = '_awg_rating_heading';      // string (widget heading text)
    const META_THANKS      = '_awg_rating_thanks';       // string (thank-you message)

    // v5.4.4: Schema enrichment fields — give admin per-template control of
    // pricing, application category, and description so the same plugin can
    // serve AI tools, generators, writing tools, plugins, services, ebooks,
    // courses, etc. with correct, content-appropriate JSON-LD.
    const META_APP_CATEGORY = '_awg_app_category';        // string (applicationCategory, software types only)
    const META_DESCRIPTION  = '_awg_schema_description';  // string (overrides post excerpt in schema)
    const META_PRICING_MODEL = '_awg_pricing_model';      // '', 'free', 'paid'  (empty = omit offers block)
    const META_PRICE         = '_awg_price';              // float
    const META_PRICE_CURRENCY = '_awg_price_currency';    // string (ISO 4217, e.g. USD)
    // Note: real_count and real_sum are computed from the awg_ratings table
    // on every read (see get_aggregates). They are NOT stored as post_meta to
    // avoid race conditions and to keep the table as the single source of truth.

    public function register(): void {

        // Lazy install for upgrades that didn't run activation
        add_action('admin_init', [$this, 'maybe_install']);

        // Front-end shortcode + assets
        add_shortcode(self::SHORTCODE, [$this, 'shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);

        // AJAX submit
        add_action('wp_ajax_awg_rating_submit',        [$this, 'ajax_submit']);
        add_action('wp_ajax_nopriv_awg_rating_submit', [$this, 'ajax_submit']);

        // Schema.org JSON-LD into <head>
        add_action('wp_head', [$this, 'output_schema'], 20);

        // Admin: metabox + overview page + actions.
        // Priority 20 on admin_menu so Settings::menu (priority 10) creates
        // the parent menu first — this prevents the 404 some hosts hit when
        // the submenu is registered before its parent exists.
        add_action('add_meta_boxes', [$this, 'register_metabox']);
        add_action('save_post',      [$this, 'save_metabox'], 10, 2);
        add_action('admin_menu',     [$this, 'register_admin_menu'], 20);
        add_action('admin_post_awg_rating_admin_save',  [$this, 'handle_admin_save']);
        add_action('admin_post_awg_rating_admin_reset', [$this, 'handle_admin_reset']);

        // Clean up rating rows when a post is permanently deleted, so we
        // don't accumulate orphans pointing at non-existent posts.
        add_action('before_delete_post', [$this, 'on_post_delete']);
    }

    /** Delete this post's rating rows when the post itself is hard-deleted. */
    public function on_post_delete(int $post_id): void {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $wpdb->delete($table, ['post_id' => $post_id], ['%d']);
    }

    /**
     * Install the ratings table. Called from Plugin::activate and lazily from
     * maybe_install when upgrading in place without a deactivate/reactivate.
     */
    public static function install(): void {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id BIGINT UNSIGNED NOT NULL,
            ip_hash CHAR(64) NOT NULL,
            stars TINYINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY post_ip (post_id, ip_hash),
            KEY post_id (post_id)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        update_option(self::DB_VERSION_OPT, self::DB_VERSION);
    }

    public function maybe_install(): void {
        if ((string) get_option(self::DB_VERSION_OPT, '') !== self::DB_VERSION) {
            self::install();
        }
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    /** Hashed visitor IP (privacy-preserving and used as dedup key). */
    private function ip_hash(): string {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
        // v5.4.31: honour the same trusted-proxy filter the generator uses, so
        // both surfaces resolve the client IP identically. Safe default is
        // REMOTE_ADDR; see Ajax::ip() for the X-Forwarded-For spoofing caveat.
        $ip = (string) apply_filters('awg_aig_client_ip', $ip);
        $ip = preg_replace('/[^0-9a-fA-F:\.]/', '', $ip);
        if ($ip === null || $ip === '') { $ip = '0.0.0.0'; }
        return hash('sha256', $ip . '|' . wp_salt('auth'));
    }

    private function ip_has_rated(int $post_id): bool {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $found = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE post_id = %d AND ip_hash = %s LIMIT 1",
            $post_id, $this->ip_hash()
        ));
        return !empty($found);
    }

    /**
     * Effective totals = real + admin-set base.
     *
     * Real counts are computed FROM the awg_ratings table — that table is the
     * single source of truth. Storing them in post_meta would race when two
     * votes land simultaneously (read 5, write 6, both threads write 6 instead
     * of 7), and would also drift from the table if admins edited counts by
     * hand. Querying the table on every read costs one indexed COUNT/SUM,
     * which is cheap and correct.
     *
     * @return array{count:int, sum:float, avg:float, real_count:int, real_sum:int}
     */
    public function get_aggregates(int $post_id): array {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT COUNT(*) AS cnt, COALESCE(SUM(stars), 0) AS sm
             FROM {$table} WHERE post_id = %d",
            $post_id
        ));
        $real_count = $row ? (int) $row->cnt : 0;
        $real_sum   = $row ? (int) $row->sm  : 0;

        $base_count = max(0, (int) get_post_meta($post_id, self::META_BASE_COUNT, true));
        $base_avg   = (float) get_post_meta($post_id, self::META_BASE_AVG, true);
        $base_avg   = $base_count > 0 ? max(1.0, min(5.0, $base_avg)) : 0.0;

        $eff_count = $real_count + $base_count;
        $eff_sum   = $real_sum + ($base_count * $base_avg);
        $eff_avg   = $eff_count > 0 ? ($eff_sum / $eff_count) : 0.0;

        return [
            'count'      => $eff_count,
            'sum'        => $eff_sum,
            'avg'        => round($eff_avg, 1),
            'real_count' => $real_count,
            'real_sum'   => $real_sum,
        ];
    }

    /**
     * Is rating enabled for this post?
     *
     * Defaults: enabled on the template CPT (so every generator auto-shows the
     * widget unless the admin opts out); disabled on regular posts and pages
     * (the [awg_rating] shortcode is opt-in there).
     */
    public function is_enabled(int $post_id): bool {
        $meta = get_post_meta($post_id, self::META_ENABLED, true);
        if ($meta === '0' || $meta === 0) return false;
        if ($meta === '1' || $meta === 1) return true;

        // Unset — fall back to post-type-based default
        $type = get_post_type($post_id);
        return $type === Plugin::CPT;
    }

    // ---------------------------------------------------------------------
    // Front-end assets
    // ---------------------------------------------------------------------
    public function register_assets(): void {
        wp_register_style(
            'awg-rating',
            plugins_url('assets/rating.css', AWG_AIG_FILE),
            [],
            AWG_AIG_VERSION
        );
        wp_register_script(
            'awg-rating',
            plugins_url('assets/rating.js', AWG_AIG_FILE),
            [],
            AWG_AIG_VERSION,
            true
        );
        wp_localize_script('awg-rating', 'AWG_RATING', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce(self::NONCE),
            'i18n'    => [
                'thanks'  => __('Thanks for your rating!', 'authorwings-ai-tools'),
                'already' => __('You have already rated this.', 'authorwings-ai-tools'),
                'error'   => __('Could not submit rating. Please try again.', 'authorwings-ai-tools'),
                'votes'   => __('votes', 'authorwings-ai-tools'),
                'vote'    => __('vote', 'authorwings-ai-tools'),
            ],
        ]);
    }

    // ---------------------------------------------------------------------
    // Render widget — public API used by both the auto-injector and the shortcode.
    // ---------------------------------------------------------------------
    public function render_widget(int $post_id, array $opts = []): string {
        if ($post_id <= 0) return '';
        if (!$this->is_enabled($post_id)) return '';

        $opts = array_merge([
            'heading' => '',
            'compact' => false,
        ], $opts);

        // Enqueue only when widget actually renders
        wp_enqueue_style('awg-rating');
        wp_enqueue_script('awg-rating');

        $agg     = $this->get_aggregates($post_id);
        $heading = trim((string) $opts['heading']);
        if ($heading === '') {
            $heading = (string) get_post_meta($post_id, self::META_HEADING, true);
        }
        if ($heading === '') {
            $heading = __('Rate this tool', 'authorwings-ai-tools');
        }

        // Cookie hint + IP check. The cookie is a quick UI signal; the IP
        // check is the source of truth and the AJAX layer is the final gate.
        $cookie_voted = !empty($_COOKIE[self::COOKIE . '_' . $post_id]);
        $ip_voted     = $this->ip_has_rated($post_id);
        $voted        = $cookie_voted || $ip_voted;

        $count_fmt  = number_format_i18n($agg['count']);
        $avg_fmt    = number_format_i18n($agg['avg'], 1);
        $votes_word = $agg['count'] === 1
            ? __('vote', 'authorwings-ai-tools')
            : __('votes', 'authorwings-ai-tools');
        $has_votes  = $agg['count'] > 0;

        $compact_class = !empty($opts['compact']) ? ' awg-rating--compact' : '';

        ob_start();
        ?>
        <div class="awg-rating<?php echo esc_attr($compact_class); ?>"
             data-post-id="<?php echo esc_attr($post_id); ?>"
             data-avg="<?php echo esc_attr($agg['avg']); ?>"
             data-count="<?php echo esc_attr($agg['count']); ?>"
             data-voted="<?php echo $voted ? '1' : '0'; ?>">

            <?php if (!empty($heading)): ?>
                <div class="awg-rating__heading"><?php echo esc_html($heading); ?></div>
            <?php endif; ?>

            <div class="awg-rating__row">
                <div class="awg-rating__stars" role="radiogroup" aria-label="<?php echo esc_attr__('Star rating', 'authorwings-ai-tools'); ?>">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <button type="button"
                                class="awg-rating__star"
                                data-value="<?php echo $i; ?>"
                                aria-label="<?php echo esc_attr(sprintf(_n('%d star', '%d stars', $i, 'authorwings-ai-tools'), $i)); ?>"
                                <?php echo $voted ? 'disabled' : ''; ?>>
                            <svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true">
                                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.27 5.82 22 7 14.14l-5-4.87 6.91-1.01L12 2z"/>
                            </svg>
                        </button>
                    <?php endfor; ?>
                </div>

                <div class="awg-rating__summary">
                    <?php if ($has_votes): ?>
                        <span class="awg-rating__value"><?php echo esc_html($avg_fmt); ?></span>
                        <span class="awg-rating__sep">/</span>
                        <span class="awg-rating__max">5</span>
                        <span class="awg-rating__count">(<?php echo esc_html($count_fmt); ?> <?php echo esc_html($votes_word); ?>)</span>
                    <?php else: ?>
                        <span class="awg-rating__count awg-rating__count--empty"><?php esc_html_e('Be the first to rate', 'authorwings-ai-tools'); ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="awg-rating__msg" aria-live="polite"></div>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    /**
     * Shortcode entry point. Defaults to the current post if no id given,
     * which matches user expectations for [awg_rating] used on a regular page.
     */
    public function shortcode($atts): string {
        $atts = shortcode_atts([
            'id'      => 0,
            'heading' => '',
            'compact' => 0,
        ], $atts, self::SHORTCODE);

        $post_id = intval($atts['id']);
        if ($post_id <= 0) {
            $post_id = (int) get_the_ID();
        }
        if ($post_id <= 0) return '';

        return $this->render_widget($post_id, [
            'heading' => (string) $atts['heading'],
            'compact' => !empty($atts['compact']),
        ]);
    }

    // ---------------------------------------------------------------------
    // AJAX: submit a rating
    // ---------------------------------------------------------------------
    public function ajax_submit(): void {
        check_ajax_referer(self::NONCE, 'nonce');

        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        $stars   = isset($_POST['stars'])   ? intval($_POST['stars'])   : 0;

        // Only allow rating published, publicly-visible content — stops an anonymous
        // visitor from seeding rows against drafts, private posts, or arbitrary IDs.
        $rated_post = $post_id > 0 ? get_post($post_id) : null;
        if (!$rated_post || $rated_post->post_status !== 'publish') {
            wp_send_json_error(['message' => __('Invalid post.', 'authorwings-ai-tools')], 400);
        }
        if (!$this->is_enabled($post_id)) {
            wp_send_json_error(['message' => __('Rating is disabled for this item.', 'authorwings-ai-tools')], 403);
        }
        if ($stars < 1 || $stars > 5) {
            wp_send_json_error(['message' => __('Invalid star value.', 'authorwings-ai-tools')], 400);
        }

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $hash  = $this->ip_hash();

        // Per-IP throttle across ALL posts: cap how many ratings one address can
        // submit per hour, so a rotated/forged IP can't stuff the table by walking
        // post IDs (each post is still one-vote-per-IP via the UNIQUE key below).
        $rl_key   = 'awg_aig_rate_sub_' . $hash;
        $rl_count = (int) get_transient($rl_key);
        if ($rl_count >= 30) {
            wp_send_json_error(['message' => __('Too many ratings submitted from your connection. Please try again later.', 'authorwings-ai-tools')], 429);
        }

        if ($this->ip_has_rated($post_id)) {
            $agg = $this->get_aggregates($post_id);
            wp_send_json_error([
                'message' => __('You have already rated this.', 'authorwings-ai-tools'),
                'already' => true,
                'avg'     => $agg['avg'],
                'count'   => $agg['count'],
            ], 409);
        }

        $inserted = $wpdb->insert(
            $table,
            [
                'post_id'    => $post_id,
                'ip_hash'    => $hash,
                'stars'      => $stars,
                'user_id'    => (int) get_current_user_id(),
                'created_at' => current_time('mysql'),
            ],
            ['%d', '%s', '%d', '%d', '%s']
        );

        if (!$inserted) {
            // UNIQUE key tripped — treat as already-rated.
            $agg = $this->get_aggregates($post_id);
            wp_send_json_error([
                'message' => __('You have already rated this.', 'authorwings-ai-tools'),
                'already' => true,
                'avg'     => $agg['avg'],
                'count'   => $agg['count'],
            ], 409);
        }

        // Count this successful submission toward the per-IP hourly throttle.
        set_transient($rl_key, $rl_count + 1, HOUR_IN_SECONDS);

        // No need to update post_meta counts — get_aggregates reads them
        // directly from the table on next read. This avoids the read-modify-write
        // race that would otherwise lose votes under concurrent submission.

        // Cookie marker for instant UX feedback on reload
        $cookie_name = self::COOKIE . '_' . $post_id;
        setcookie(
            $cookie_name, '1',
            time() + YEAR_IN_SECONDS,
            COOKIEPATH ?: '/', COOKIE_DOMAIN,
            is_ssl(), true
        );

        $agg = $this->get_aggregates($post_id);
        $thanks = (string) get_post_meta($post_id, self::META_THANKS, true);
        if ($thanks === '') {
            $thanks = __('Thanks for your rating!', 'authorwings-ai-tools');
        }

        wp_send_json_success([
            'message' => $thanks,
            'avg'     => $agg['avg'],
            'count'   => $agg['count'],
        ]);
    }

    // ---------------------------------------------------------------------
    // Schema.org JSON-LD output
    //
    // When the current page contains an [awg_generator] shortcode or block,
    // emit schema for the FIRST embedded template's rating. That way Google
    // attaches the stars to the page that actually contains the tool, using
    // the tool's data — which is exactly what produces the rich snippet
    // shown in the project brief.
    //
    // When no generator is on the page, fall back to the page's own rating
    // (only useful if the admin manually placed [awg_rating] there).
    // ---------------------------------------------------------------------
    public function output_schema(): void {
        if (!is_singular()) return;
        $current_post_id = (int) get_queried_object_id();
        if ($current_post_id <= 0) return;

        $template_id = $this->find_first_template_on_page($current_post_id);
        if ($template_id > 0) {
            $this->emit_schema($template_id, get_permalink($current_post_id));
            return;
        }

        // Fallback: page's own rating
        if ($this->is_enabled($current_post_id)) {
            $this->emit_schema($current_post_id, get_permalink($current_post_id));
        }
    }

    /**
     * Scan a post's content for the first embedded generator template id.
     * Checks both shortcodes and Gutenberg blocks.
     */
    private function find_first_template_on_page(int $post_id): int {
        $post = get_post($post_id);
        if (!$post || empty($post->post_content)) return 0;

        $content = (string) $post->post_content;

        // 1) Shortcode form: [awg_generator id="42"] or [awg_generator id=42]
        if (preg_match('/\[awg_generator\b[^\]]*\bid\s*=\s*["\']?(\d+)["\']?/i', $content, $m)) {
            $tpl_id = (int) $m[1];
            if ($tpl_id > 0 && get_post_status($tpl_id) === 'publish' && get_post_type($tpl_id) === Plugin::CPT) {
                return $tpl_id;
            }
        }

        // 2) Gutenberg block: <!-- wp:awg/generator {"id":42} -->
        if (function_exists('has_block') && has_block('awg/generator', $content) && function_exists('parse_blocks')) {
            $tpl_id = $this->find_template_in_blocks(parse_blocks($content));
            if ($tpl_id > 0) return $tpl_id;
        }

        return 0;
    }

    private function find_template_in_blocks(array $blocks): int {
        foreach ($blocks as $block) {
            if (($block['blockName'] ?? '') === 'awg/generator') {
                // The block defines its attribute as `templateId` (see class-block.php),
                // NOT `id`. Reading `id` here would silently fail on every block-embedded
                // generator.
                $id = (int) ($block['attrs']['templateId'] ?? 0);
                if ($id > 0 && get_post_status($id) === 'publish' && get_post_type($id) === Plugin::CPT) {
                    return $id;
                }
            }
            if (!empty($block['innerBlocks']) && is_array($block['innerBlocks'])) {
                $found = $this->find_template_in_blocks($block['innerBlocks']);
                if ($found > 0) return $found;
            }
        }
        return 0;
    }

    /** Emit one AggregateRating JSON-LD block for $post_id with the given URL. */
    private function emit_schema(int $post_id, string $url): void {
        $data = $this->build_schema_data($post_id, $url);
        if ($data === null) return;

        // Keep the default forward-slash escaping (do NOT use JSON_UNESCAPED_SLASHES):
        // it turns "</script>" into "<\/script>", which prevents a stray closing tag
        // in any admin/imported field from breaking out of this JSON-LD block.
        echo "\n<script type=\"application/ld+json\">"
            . wp_json_encode($data, JSON_UNESCAPED_UNICODE)
            . "</script>\n";
    }

    /**
     * v5.4.5: Build the JSON-LD data array for a post.
     *
     * Extracted from emit_schema() so the admin preview pane can show the
     * exact same payload that will ship to Google — single source of truth,
     * no risk of preview and production drifting apart.
     *
     * @return array|null The schema data, or null if the post has no schema to emit.
     */
    public function build_schema_data(int $post_id, string $url): ?array {
        if (!$this->is_enabled($post_id)) return null;

        $agg = $this->get_aggregates($post_id);
        // Google requires count >= 1 for AggregateRating rich snippets.
        if ($agg['count'] < 1) return null;

        $schema_type = (string) get_post_meta($post_id, self::META_SCHEMA_TYPE, true);
        if ($schema_type === '') $schema_type = 'SoftwareApplication';

        $name = (string) get_post_meta($post_id, self::META_SCHEMA_NAME, true);
        if ($name === '') {
            $name = get_the_title($post_id);
        }

        $data = [
            '@context' => 'https://schema.org',
            '@type'    => $schema_type,
            'name'     => $name,
            'url'      => $url,
            'aggregateRating' => [
                '@type'       => 'AggregateRating',
                'ratingValue' => (string) $agg['avg'],
                'ratingCount' => (string) $agg['count'],
                'bestRating'  => '5',
                'worstRating' => '1',
            ],
        ];

        // v5.4.4: Admin-controlled description. Falls back to post excerpt if blank.
        $description = (string) get_post_meta($post_id, self::META_DESCRIPTION, true);
        if ($description === '') {
            $excerpt = has_excerpt($post_id) ? get_the_excerpt($post_id) : '';
            $description = (string) $excerpt;
        }
        if ($description !== '') {
            $data['description'] = wp_strip_all_tags($description);
        }

        // v5.4.13: applicationCategory & operatingSystem only apply to
        // software-type schemas. MobileApplication removed — it was never
        // exposed in the dropdown or the save allowlist, so the check was dead.
        $is_software = in_array($schema_type, ['SoftwareApplication', 'WebApplication'], true);
        if ($is_software) {
            $app_category = (string) get_post_meta($post_id, self::META_APP_CATEGORY, true);
            if ($app_category === '') $app_category = 'UtilitiesApplication';
            $data['applicationCategory'] = $app_category;
            $data['operatingSystem']     = 'Any';
        }

        // v5.4.13: Pricing block — only emit when admin has set a pricing model.
        $pricing_model = (string) get_post_meta($post_id, self::META_PRICING_MODEL, true);
        $offer_types   = ['SoftwareApplication', 'WebApplication', 'Service', 'Product', 'Course'];
        if ($pricing_model !== '' && in_array($schema_type, $offer_types, true)) {
            $currency = (string) get_post_meta($post_id, self::META_PRICE_CURRENCY, true);
            if ($currency === '') $currency = 'USD';
            $price = (string) get_post_meta($post_id, self::META_PRICE, true);
            if ($pricing_model === 'free' || $price === '') {
                $price = '0';
            }
            $data['offers'] = [
                '@type'         => 'Offer',
                'price'         => $price,
                'priceCurrency' => $currency,
            ];
        }

        return apply_filters('awg_rating_schema', $data, $post_id);
    }

    // ---------------------------------------------------------------------
    // Admin metabox — shows on template CPT (primary use) and on regular
    // posts/pages (for the optional shortcode placement).
    // ---------------------------------------------------------------------
    public function register_metabox(): void {
        // Always include the plugin's CPT; the rest are public post types.
        $types = get_post_types(['public' => true], 'names');
        $types[Plugin::CPT] = Plugin::CPT;
        unset($types['attachment']);

        foreach ($types as $type) {
            add_meta_box(
                'awg_rating_metabox',
                __('AuthorWings Rating', 'authorwings-ai-tools'),
                [$this, 'render_metabox'],
                $type,
                'side',
                'default'
            );
        }
    }

    public function render_metabox($post): void {
        wp_nonce_field('awg_rating_metabox', 'awg_rating_metabox_nonce');

        $is_template = ($post->post_type === Plugin::CPT);

        // Defaults match is_enabled() logic
        $enabled = get_post_meta($post->ID, self::META_ENABLED, true);
        if ($enabled === '') {
            $enabled = $is_template ? 1 : 0;
        } else {
            $enabled = (int) $enabled;
        }

        $base_count  = (int)   get_post_meta($post->ID, self::META_BASE_COUNT, true);
        $base_avg    = (float) get_post_meta($post->ID, self::META_BASE_AVG, true);
        $schema_type = (string) get_post_meta($post->ID, self::META_SCHEMA_TYPE, true);
        if ($schema_type === '') $schema_type = 'SoftwareApplication';
        $schema_name = (string) get_post_meta($post->ID, self::META_SCHEMA_NAME, true);
        $heading     = (string) get_post_meta($post->ID, self::META_HEADING, true);
        $thanks      = (string) get_post_meta($post->ID, self::META_THANKS, true);

        // v5.4.4: new schema fields
        $app_category   = (string) get_post_meta($post->ID, self::META_APP_CATEGORY, true);
        $description    = (string) get_post_meta($post->ID, self::META_DESCRIPTION, true);
        $pricing_model  = (string) get_post_meta($post->ID, self::META_PRICING_MODEL, true);
        $price          = (string) get_post_meta($post->ID, self::META_PRICE, true);
        $price_currency = (string) get_post_meta($post->ID, self::META_PRICE_CURRENCY, true);
        if ($price_currency === '') $price_currency = 'USD';

        $agg = $this->get_aggregates($post->ID);

        // v5.4.4: expanded @type list covers all current and roadmap content types
        // on authorwings.com — AI tools, generators, writing tools, plugins,
        // services, ebooks/templates, courses, articles. Filterable for future
        // additions without editing the plugin.
        $schema_options = apply_filters('awg_schema_types', [
            'SoftwareApplication' => __('SoftwareApplication (plugins, apps)', 'authorwings-ai-tools'),
            'WebApplication'      => __('WebApplication (AI tools, generators)', 'authorwings-ai-tools'),
            'Product'             => __('Product (ebooks, templates)', 'authorwings-ai-tools'),
            'Service'             => __('Service (editing, formatting)', 'authorwings-ai-tools'),
            'Course'              => __('Course', 'authorwings-ai-tools'),
            'CreativeWork'        => __('CreativeWork', 'authorwings-ai-tools'),
            'Article'             => __('Article (blog posts, guides)', 'authorwings-ai-tools'),
        ]);

        // Application categories (Schema.org softwareApplicationCategory enum).
        // Only shown when @type is a software-type. Filterable.
        $app_categories = apply_filters('awg_app_categories', [
            ''                          => __('— Default (UtilitiesApplication) —', 'authorwings-ai-tools'),
            'BusinessApplication'       => __('Business', 'authorwings-ai-tools'),
            'DesignApplication'         => __('Design', 'authorwings-ai-tools'),
            'DeveloperApplication'      => __('Developer', 'authorwings-ai-tools'),
            'EducationalApplication'    => __('Educational', 'authorwings-ai-tools'),
            'EntertainmentApplication'  => __('Entertainment', 'authorwings-ai-tools'),
            'LifestyleApplication'      => __('Lifestyle', 'authorwings-ai-tools'),
            'MultimediaApplication'     => __('Multimedia', 'authorwings-ai-tools'),
            'ProductivityApplication'   => __('Productivity', 'authorwings-ai-tools'),
            'UtilitiesApplication'      => __('Utilities', 'authorwings-ai-tools'),
        ]);

        // Common currencies, with PKR/INR up-front for the AuthorWings audience.
        $currencies = apply_filters('awg_price_currencies', [
            'USD' => 'USD ($)',
            'EUR' => 'EUR (€)',
            'GBP' => 'GBP (£)',
            'PKR' => 'PKR (₨)',
            'INR' => 'INR (₹)',
            'AUD' => 'AUD ($)',
            'CAD' => 'CAD ($)',
            'JPY' => 'JPY (¥)',
        ]);
        ?>
        <?php if ($is_template): ?>
            <p style="margin:4px 0 10px;padding:8px;background:#e7f4e9;border-left:3px solid #1a8038;font-size:12px;">
                <strong><?php esc_html_e('Template rating', 'authorwings-ai-tools'); ?></strong><br>
                <?php esc_html_e('The widget will auto-render inside this template\'s generator form on every page that uses it.', 'authorwings-ai-tools'); ?>
            </p>
        <?php else: ?>
            <p style="margin:4px 0 10px;padding:8px;background:#fffbe5;border-left:3px solid #dba617;font-size:12px;">
                <?php esc_html_e('On a regular post/page, the widget only shows where you place the shortcode.', 'authorwings-ai-tools'); ?>
            </p>
        <?php endif; ?>

        <p>
            <label>
                <input type="checkbox" name="awg_rating[enabled]" value="1" <?php checked($enabled, 1); ?>>
                <strong><?php esc_html_e('Enable rating widget', 'authorwings-ai-tools'); ?></strong>
            </label>
        </p>

        <p style="margin:8px 0;padding:8px;background:#f6f7f7;border-left:3px solid #2271b1;font-size:12px;">
            <?php
            printf(
                /* translators: 1: avg stars, 2: total votes, 3: real submitted votes */
                esc_html__('Showing %1$s ★ from %2$s votes (real: %3$d).', 'authorwings-ai-tools'),
                esc_html(number_format_i18n($agg['avg'], 1)),
                esc_html(number_format_i18n($agg['count'])),
                (int) $agg['real_count']
            );
            ?>
        </p>

        <p>
            <label><strong><?php esc_html_e('Base votes (seed)', 'authorwings-ai-tools'); ?></strong></label>
            <input type="number" min="0" step="1" style="width:100%"
                   name="awg_rating[base_count]" value="<?php echo esc_attr($base_count); ?>">
            <span class="description"><?php esc_html_e('Added to real submissions. Use to give new tools a credible starting count.', 'authorwings-ai-tools'); ?></span>
        </p>

        <p>
            <label><strong><?php esc_html_e('Base average (1.0 – 5.0)', 'authorwings-ai-tools'); ?></strong></label>
            <input type="number" min="0" max="5" step="0.1" style="width:100%"
                   name="awg_rating[base_avg]" value="<?php echo esc_attr($base_avg); ?>">
            <span class="description"><?php esc_html_e('0 = no override (use real ratings only). Or enter 1.0–5.0 to seed an average.', 'authorwings-ai-tools'); ?></span>
        </p>

        <hr>
        <p style="font-size:11px;font-weight:600;color:#666;text-transform:uppercase;letter-spacing:.04em;margin:6px 0;">
            <?php esc_html_e('Schema identity', 'authorwings-ai-tools'); ?>
        </p>

        <p>
            <label><strong><?php esc_html_e('Schema.org @type', 'authorwings-ai-tools'); ?></strong></label>
            <select name="awg_rating[schema_type]" id="awg_schema_type" style="width:100%">
                <?php foreach ($schema_options as $k => $v): ?>
                    <option value="<?php echo esc_attr($k); ?>" <?php selected($schema_type, $k); ?>>
                        <?php echo esc_html($v); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <span class="description"><?php esc_html_e('Controls the JSON-LD type emitted for Google rich snippets.', 'authorwings-ai-tools'); ?></span>
        </p>

        <p class="awg-software-only">
            <label><strong><?php esc_html_e('Application category', 'authorwings-ai-tools'); ?></strong></label>
            <select name="awg_rating[app_category]" style="width:100%">
                <?php foreach ($app_categories as $k => $v): ?>
                    <option value="<?php echo esc_attr($k); ?>" <?php selected($app_category, $k); ?>>
                        <?php echo esc_html($v); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <span class="description"><?php esc_html_e('Only used for software-type schemas. e.g. Business for writing tools, Productivity for plugins.', 'authorwings-ai-tools'); ?></span>
        </p>

        <p>
            <label><strong><?php esc_html_e('Schema name override', 'authorwings-ai-tools'); ?></strong></label>
            <input type="text" style="width:100%"
                   name="awg_rating[schema_name]"
                   placeholder="<?php echo esc_attr(get_the_title($post->ID)); ?>"
                   value="<?php echo esc_attr($schema_name); ?>">
            <span class="description"><?php esc_html_e('Leave blank to use the post title.', 'authorwings-ai-tools'); ?></span>
        </p>

        <p>
            <label><strong><?php esc_html_e('Description', 'authorwings-ai-tools'); ?></strong></label>
            <textarea name="awg_rating[description]" rows="3" style="width:100%"
                      placeholder="<?php esc_attr_e('Short description for Google rich result snippet.', 'authorwings-ai-tools'); ?>"><?php echo esc_textarea($description); ?></textarea>
            <span class="description"><?php esc_html_e('Leave blank to use the post excerpt.', 'authorwings-ai-tools'); ?></span>
        </p>

        <hr>
        <p style="font-size:11px;font-weight:600;color:#1a8038;text-transform:uppercase;letter-spacing:.04em;margin:6px 0;">
            <?php esc_html_e('Pricing & offer', 'authorwings-ai-tools'); ?>
        </p>

        <p>
            <label><strong><?php esc_html_e('Pricing model', 'authorwings-ai-tools'); ?></strong></label>
            <select name="awg_rating[pricing_model]" id="awg_pricing_model" style="width:100%">
                <option value=""     <?php selected($pricing_model, '');     ?>><?php esc_html_e('— Not set (omit from schema) —', 'authorwings-ai-tools'); ?></option>
                <option value="free" <?php selected($pricing_model, 'free'); ?>><?php esc_html_e('Free', 'authorwings-ai-tools'); ?></option>
                <option value="paid" <?php selected($pricing_model, 'paid'); ?>><?php esc_html_e('Paid', 'authorwings-ai-tools'); ?></option>
            </select>
            <span class="description"><?php esc_html_e('Only Service, Product, Course and software types emit an offers block in JSON-LD.', 'authorwings-ai-tools'); ?></span>
        </p>

        <p class="awg-paid-only">
            <label><strong><?php esc_html_e('Price', 'authorwings-ai-tools'); ?></strong></label>
            <input type="number" min="0" step="0.01" style="width:100%"
                   name="awg_rating[price]" value="<?php echo esc_attr($price); ?>"
                   placeholder="9.99">
        </p>

        <p class="awg-paid-only">
            <label><strong><?php esc_html_e('Currency', 'authorwings-ai-tools'); ?></strong></label>
            <select name="awg_rating[price_currency]" style="width:100%">
                <?php foreach ($currencies as $k => $v): ?>
                    <option value="<?php echo esc_attr($k); ?>" <?php selected($price_currency, $k); ?>>
                        <?php echo esc_html($v); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>

        <hr>
        <p style="font-size:11px;font-weight:600;color:#666;text-transform:uppercase;letter-spacing:.04em;margin:6px 0;">
            <?php esc_html_e('Widget display', 'authorwings-ai-tools'); ?>
        </p>

        <p>
            <label><strong><?php esc_html_e('Widget heading', 'authorwings-ai-tools'); ?></strong></label>
            <input type="text" style="width:100%"
                   name="awg_rating[heading]"
                   placeholder="<?php esc_attr_e('Rate this tool', 'authorwings-ai-tools'); ?>"
                   value="<?php echo esc_attr($heading); ?>">
        </p>

        <p>
            <label><strong><?php esc_html_e('Thank-you message', 'authorwings-ai-tools'); ?></strong></label>
            <input type="text" style="width:100%"
                   name="awg_rating[thanks]"
                   placeholder="<?php esc_attr_e('Thanks for your rating!', 'authorwings-ai-tools'); ?>"
                   value="<?php echo esc_attr($thanks); ?>">
        </p>

        <?php if (!$is_template): ?>
            <p style="margin-top:10px;padding:8px;background:#fffbe5;border-left:3px solid #dba617;font-size:12px;">
                <strong><?php esc_html_e('Shortcode:', 'authorwings-ai-tools'); ?></strong>
                <code style="display:block;margin-top:4px;">[<?php echo esc_html(self::SHORTCODE); ?>]</code>
            </p>
        <?php endif; ?>

        <?php
        // v5.4.5: Google search preview pane — live SERP mock + JSON-LD viewer + Rich Results Test launcher.
        // Pulls actual JSON-LD via build_schema_data so the preview can never lie about what ships.
        $permalink   = get_permalink($post->ID) ?: '';
        $host        = $permalink ? (string) wp_parse_url($permalink, PHP_URL_HOST) : '';
        $is_local    = $host && (preg_match('/\.(local|test|localhost)$/i', $host) || $host === 'localhost' || $host === '127.0.0.1');
        $is_public   = ($post->post_status === 'publish') && !$is_local && $host !== '';
        $schema_data = $this->build_schema_data($post->ID, $permalink);
        $schema_json = $schema_data ? wp_json_encode($schema_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : '';

        // Currency symbols for the preview card. Falls back to the ISO code.
        $currency_symbols = ['USD'=>'$','EUR'=>'€','GBP'=>'£','PKR'=>'₨','INR'=>'₹','AUD'=>'A$','CAD'=>'C$','JPY'=>'¥'];

        // Initial preview values — JS will override on form change but server-side render gives accurate first paint.
        $preview_title    = $schema_name !== '' ? $schema_name : get_the_title($post->ID);
        $preview_desc     = $description;
        if ($preview_desc === '' && has_excerpt($post->ID)) $preview_desc = get_the_excerpt($post->ID);
        $preview_stars    = number_format_i18n($agg['avg'], 1);
        $preview_count    = (int) $agg['count'];
        $preview_show_price = ($pricing_model !== '');
        $preview_price_text = '';
        if ($preview_show_price) {
            $sym = $currency_symbols[$price_currency] ?? ($price_currency . ' ');
            if ($pricing_model === 'free' || $price === '' || (float) $price === 0.0) {
                $preview_price_text = __('Free', 'authorwings-ai-tools');
            } else {
                $preview_price_text = $sym . $price;
            }
        }
        $test_url = 'https://search.google.com/test/rich-results?url=' . rawurlencode($permalink);
        ?>

        <hr>
        <p style="font-size:11px;font-weight:600;color:#2271b1;text-transform:uppercase;letter-spacing:.04em;margin:6px 0;">
            <?php esc_html_e('Google search preview', 'authorwings-ai-tools'); ?>
        </p>

        <?php if (!$schema_data): ?>
            <p style="padding:8px;background:#fffbe5;border-left:3px solid #dba617;font-size:12px;">
                <?php esc_html_e('Preview unavailable: rating widget disabled, or no ratings exist yet. Google requires at least 1 vote (real or seeded) before it can show stars.', 'authorwings-ai-tools'); ?>
            </p>
        <?php else: ?>
            <div id="awg-serp-preview" style="background:#fff;border:1px solid #dadce0;border-radius:8px;padding:10px 12px;font-family:arial,sans-serif;margin-bottom:8px;">
                <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px;">
                    <div style="width:16px;height:16px;border-radius:50%;background:#f1f3f4;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:600;color:#5f6368;"><?php echo esc_html(strtoupper(substr($host ?: 'A', 0, 1))); ?></div>
                    <div style="font-size:12px;color:#202124;" data-awg-host><?php echo esc_html($host ?: 'yoursite.com'); ?></div>
                </div>
                <div style="font-size:11px;color:#4d5156;margin-bottom:2px;word-break:break-all;" data-awg-url><?php echo esc_html($permalink ?: ''); ?></div>
                <div style="font-size:16px;color:#1a0dab;line-height:1.3;margin-bottom:4px;" data-awg-title><?php echo esc_html($preview_title); ?></div>
                <div style="display:flex;align-items:center;gap:4px;flex-wrap:wrap;font-size:12px;color:#4d5156;margin-bottom:4px;">
                    <span style="color:#f9ab00;letter-spacing:1px;" data-awg-stars-vis>★★★★★</span>
                    <span><span data-awg-stars><?php echo esc_html($preview_stars); ?></span> · <span data-awg-count><?php echo esc_html(number_format_i18n($preview_count)); ?></span> <?php esc_html_e('votes', 'authorwings-ai-tools'); ?></span>
                    <span data-awg-price-wrap style="<?php echo $preview_show_price ? '' : 'display:none'; ?>">·&nbsp;<span data-awg-price><?php echo esc_html($preview_price_text); ?></span></span>
                </div>
                <div style="font-size:12px;color:#4d5156;line-height:1.5;" data-awg-desc><?php echo esc_html($preview_desc); ?></div>
            </div>

            <div style="display:flex;gap:6px;margin-bottom:6px;">
                <a id="awg-test-google" href="<?php echo $is_public ? esc_url($test_url) : '#'; ?>"
                   target="_blank" rel="noopener"
                   class="button button-primary"
                   style="flex:1;text-align:center;<?php echo $is_public ? '' : 'pointer-events:none;opacity:0.55;'; ?>"
                   <?php if (!$is_public): ?>title="<?php esc_attr_e('Publish on a public URL first — Google can\'t crawl drafts or localhost', 'authorwings-ai-tools'); ?>"<?php endif; ?>>
                    <?php esc_html_e('Test with Google ↗', 'authorwings-ai-tools'); ?>
                </a>
                <button type="button" id="awg-toggle-json" class="button" style="flex:1;">
                    <?php esc_html_e('View JSON-LD', 'authorwings-ai-tools'); ?>
                </button>
            </div>

            <?php if (!$is_public): ?>
                <p style="font-size:11px;color:#646970;margin:4px 0 8px;">
                    <span class="dashicons dashicons-info" style="font-size:14px;height:14px;width:14px;vertical-align:-2px;"></span>
                    <?php
                    if ($post->post_status !== 'publish') {
                        esc_html_e('Publish this post — Google can only test live URLs.', 'authorwings-ai-tools');
                    } elseif ($is_local) {
                        esc_html_e('You\'re on a local site. Push to a public URL to test with Google.', 'authorwings-ai-tools');
                    }
                    ?>
                </p>
            <?php endif; ?>

            <div id="awg-json-view" style="display:none;margin-top:6px;">
                <textarea readonly style="width:100%;height:180px;font-family:Consolas,Monaco,monospace;font-size:11px;background:#f6f7f7;border:1px solid #dcdcde;padding:6px;"><?php echo esc_textarea($schema_json); ?></textarea>
                <p style="margin:4px 0 0;">
                    <button type="button" id="awg-copy-json" class="button button-small"><?php esc_html_e('Copy', 'authorwings-ai-tools'); ?></button>
                    <span id="awg-copy-status" style="font-size:11px;color:#1a8038;margin-left:6px;"></span>
                </p>
            </div>
        <?php endif; ?>

        <script>
        // v5.4.4: progressive enhancement — hide irrelevant fields based on selection.
        // v5.4.5: live SERP preview + JSON-LD toggle + copy button.
        (function(){
            var softwareTypes = ['SoftwareApplication','WebApplication','MobileApplication'];
            var typeSel       = document.getElementById('awg_schema_type');
            var priceSel      = document.getElementById('awg_pricing_model');

            function toggle() {
                if (!typeSel || !priceSel) return;
                var isSoftware = softwareTypes.indexOf(typeSel.value) !== -1;
                var isPaid     = (priceSel.value === 'paid');
                document.querySelectorAll('.awg-software-only').forEach(function(el){
                    el.style.display = isSoftware ? '' : 'none';
                });
                document.querySelectorAll('.awg-paid-only').forEach(function(el){
                    el.style.display = isPaid ? '' : 'none';
                });
            }
            if (typeSel)  typeSel.addEventListener('change', toggle);
            if (priceSel) priceSel.addEventListener('change', toggle);
            toggle();

            // ---- Live SERP preview ----
            var preview = document.getElementById('awg-serp-preview');
            if (preview) {
                var symbols = <?php echo wp_json_encode($currency_symbols); ?>;
                var fallbackTitle = <?php echo wp_json_encode(get_the_title($post->ID)); ?>;
                var fallbackDesc  = <?php echo wp_json_encode(has_excerpt($post->ID) ? get_the_excerpt($post->ID) : ''); ?>;

                function val(name) {
                    var el = document.querySelector('[name="awg_rating[' + name + ']"]');
                    return el ? el.value : '';
                }
                function setText(sel, text) {
                    var el = preview.querySelector(sel);
                    if (el) el.textContent = text;
                }

                function updatePreview() {
                    var title = val('schema_name').trim() || fallbackTitle;
                    var desc  = val('description').trim() || fallbackDesc;
                    setText('[data-awg-title]', title);
                    setText('[data-awg-desc]', desc);

                    var pm = val('pricing_model');
                    var wrap = preview.querySelector('[data-awg-price-wrap]');
                    if (pm === '') {
                        if (wrap) wrap.style.display = 'none';
                    } else {
                        if (wrap) wrap.style.display = '';
                        var priceText;
                        var raw = parseFloat(val('price'));
                        if (pm === 'free' || isNaN(raw) || raw === 0) {
                            priceText = <?php echo wp_json_encode(__('Free', 'authorwings-ai-tools')); ?>;
                        } else {
                            var cur = val('price_currency') || 'USD';
                            var sym = symbols[cur] || (cur + ' ');
                            priceText = sym + raw.toFixed(2);
                        }
                        setText('[data-awg-price]', priceText);
                    }
                }
                ['schema_name','description','pricing_model','price','price_currency'].forEach(function(n){
                    var el = document.querySelector('[name="awg_rating[' + n + ']"]');
                    if (el) {
                        el.addEventListener('input',  updatePreview);
                        el.addEventListener('change', updatePreview);
                    }
                });
            }

            // ---- JSON-LD viewer toggle ----
            var jsonBtn = document.getElementById('awg-toggle-json');
            var jsonBox = document.getElementById('awg-json-view');
            if (jsonBtn && jsonBox) {
                jsonBtn.addEventListener('click', function(){
                    var open = jsonBox.style.display !== 'none';
                    jsonBox.style.display = open ? 'none' : 'block';
                    jsonBtn.textContent   = open
                        ? <?php echo wp_json_encode(__('View JSON-LD', 'authorwings-ai-tools')); ?>
                        : <?php echo wp_json_encode(__('Hide JSON-LD', 'authorwings-ai-tools')); ?>;
                });
            }

            // ---- Copy JSON-LD ----
            var copyBtn = document.getElementById('awg-copy-json');
            if (copyBtn) {
                copyBtn.addEventListener('click', function(){
                    var ta = jsonBox.querySelector('textarea');
                    if (!ta) return;
                    ta.select();
                    try {
                        document.execCommand('copy');
                        var s = document.getElementById('awg-copy-status');
                        if (s) {
                            s.textContent = <?php echo wp_json_encode(__('Copied!', 'authorwings-ai-tools')); ?>;
                            setTimeout(function(){ s.textContent = ''; }, 1800);
                        }
                    } catch(e) {}
                });
            }
        })();
        </script>
        <?php
    }

    public function save_metabox(int $post_id, $post): void {
        if (!isset($_POST['awg_rating_metabox_nonce'])) return;
        if (!wp_verify_nonce($_POST['awg_rating_metabox_nonce'], 'awg_rating_metabox')) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id)) return;
        if (!current_user_can('edit_post', $post_id)) return;

        $in = isset($_POST['awg_rating']) && is_array($_POST['awg_rating']) ? $_POST['awg_rating'] : [];

        update_post_meta($post_id, self::META_ENABLED, isset($in['enabled']) ? 1 : 0);
        update_post_meta($post_id, self::META_BASE_COUNT, max(0, (int) ($in['base_count'] ?? 0)));

        $avg = (float) ($in['base_avg'] ?? 0);
        $avg = $avg > 0 ? max(1.0, min(5.0, $avg)) : 0.0;
        update_post_meta($post_id, self::META_BASE_AVG, $avg);

        // v5.4.13: derive the allowlist from the same filter the dropdown
        // uses, so anything a site adds via `awg_schema_types` is actually
        // accepted on save (previously the dropdown was filterable but the
        // save list was hardcoded, silently reverting custom types).
        $allowed = array_keys((array) apply_filters('awg_schema_types', [
            'SoftwareApplication' => '',
            'WebApplication'      => '',
            'Product'             => '',
            'Service'             => '',
            'Course'              => '',
            'CreativeWork'        => '',
            'Article'             => '',
        ]));
        $type = (string) ($in['schema_type'] ?? 'SoftwareApplication');
        if (!in_array($type, $allowed, true)) $type = 'SoftwareApplication';
        update_post_meta($post_id, self::META_SCHEMA_TYPE, $type);

        update_post_meta($post_id, self::META_SCHEMA_NAME, sanitize_text_field((string) ($in['schema_name'] ?? '')));
        update_post_meta($post_id, self::META_HEADING,     sanitize_text_field((string) ($in['heading']     ?? '')));
        update_post_meta($post_id, self::META_THANKS,      sanitize_text_field((string) ($in['thanks']      ?? '')));

        // v5.4.4: new schema-enrichment fields.
        // Application category — empty allowed (means "use default").
        $allowed_cats = ['', 'BusinessApplication', 'DesignApplication', 'DeveloperApplication',
                        'EducationalApplication', 'EntertainmentApplication', 'LifestyleApplication',
                        'MultimediaApplication', 'ProductivityApplication', 'UtilitiesApplication'];
        $cat = (string) ($in['app_category'] ?? '');
        if (!in_array($cat, $allowed_cats, true)) $cat = '';
        update_post_meta($post_id, self::META_APP_CATEGORY, $cat);

        // Description — short text, stripped of tags. Use sanitize_textarea_field
        // to keep newlines but kill any HTML.
        update_post_meta($post_id, self::META_DESCRIPTION, sanitize_textarea_field((string) ($in['description'] ?? '')));

        // Pricing model — empty means "omit from schema entirely" (safe default for upgrades).
        $pm = (string) ($in['pricing_model'] ?? '');
        if (!in_array($pm, ['', 'free', 'paid'], true)) $pm = '';
        update_post_meta($post_id, self::META_PRICING_MODEL, $pm);

        // Price — non-negative float. Store as plain string to preserve "9.99" formatting
        // in JSON-LD (Google accepts both string and number for price).
        $raw_price = (string) ($in['price'] ?? '');
        if ($raw_price === '') {
            update_post_meta($post_id, self::META_PRICE, '');
        } else {
            $price_num = max(0.0, (float) $raw_price);
            update_post_meta($post_id, self::META_PRICE, number_format($price_num, 2, '.', ''));
        }

        // Currency — ISO 4217 three-letter code. Allowlist with filter so users
        // can extend without editing the plugin.
        $allowed_currencies = array_keys(apply_filters('awg_price_currencies', [
            'USD' => '', 'EUR' => '', 'GBP' => '', 'PKR' => '',
            'INR' => '', 'AUD' => '', 'CAD' => '', 'JPY' => '',
        ]));
        $cur = strtoupper((string) ($in['price_currency'] ?? 'USD'));
        if (!in_array($cur, $allowed_currencies, true)) $cur = 'USD';
        update_post_meta($post_id, self::META_PRICE_CURRENCY, $cur);
    }

    // ---------------------------------------------------------------------
    // Admin overview page — lists templates + any rated regular posts.
    //
    // Registered at admin_menu priority 20 so Settings (priority 10) has
    // already created the parent menu. Without this, some hosts return a
    // 404 when clicking the submenu link.
    // ---------------------------------------------------------------------
    public function register_admin_menu(): void {
        add_submenu_page(
            'edit.php?post_type=' . Plugin::CPT,
            __('Ratings', 'authorwings-ai-tools'),
            __('Ratings', 'authorwings-ai-tools'),
            'manage_options',
            'awg-ratings',
            [$this, 'render_admin_page'],
            40 // v5.4.28: sits with AI Submissions in the "engagement data" group.
        );
    }

    public function render_admin_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'authorwings-ai-tools'));
        }

        global $wpdb;

        // Build the post list. Include:
        //  (a) every published template (so the admin can seed brand-new tools
        //      that have no rating data yet), AND
        //  (b) any non-template post that has rating-related meta (someone used
        //      the [awg_rating] shortcode there).
        //
        // Both queries exclude trashed posts and WordPress's auto-draft state
        // so the list only shows items the admin would expect to manage.
        $excluded_statuses = ['trash', 'auto-draft'];
        $status_placeholders = implode(',', array_fill(0, count($excluded_statuses), '%s'));

        $template_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_type = %s AND post_status NOT IN ({$status_placeholders})
             ORDER BY ID DESC",
            array_merge([Plugin::CPT], $excluded_statuses)
        ));

        $other_post_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT pm.post_id FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key IN (%s, %s, %s)
               AND p.post_type != %s
               AND p.post_status NOT IN ({$status_placeholders})
             ORDER BY pm.post_id DESC",
            array_merge(
                [self::META_BASE_COUNT, self::META_BASE_AVG, self::META_ENABLED, Plugin::CPT],
                $excluded_statuses
            )
        ));

        $post_ids = array_unique(array_merge(
            array_map('intval', (array) $template_ids),
            array_map('intval', (array) $other_post_ids)
        ));

        $saved_notice = isset($_GET['saved']) ? __('Rating updated.', 'authorwings-ai-tools') : '';
        $reset_notice = isset($_GET['reset']) ? __('Rating reset.', 'authorwings-ai-tools')   : '';

        ?>
        <div class="wrap">
            <h1><?php esc_html_e('AuthorWings Ratings', 'authorwings-ai-tools'); ?></h1>

            <?php if ($saved_notice): ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html($saved_notice); ?></p></div>
            <?php endif; ?>
            <?php if ($reset_notice): ?>
                <div class="notice notice-warning is-dismissible"><p><?php echo esc_html($reset_notice); ?></p></div>
            <?php endif; ?>

            <p class="description">
                <?php esc_html_e('Star ratings live on the template itself, so every page embedding that template shares the same rating.', 'authorwings-ai-tools'); ?>
                <?php esc_html_e('"Real votes" come from visitors; "Base votes" is your seed value (combined into the public count).', 'authorwings-ai-tools'); ?>
            </p>

            <?php if (empty($post_ids)): ?>
                <p><em><?php
                    printf(
                        /* translators: %s: edit URL */
                        esc_html__('No ratings yet. Open a template and enable the rating widget in the sidebar metabox — or visit %s.', 'authorwings-ai-tools'),
                        '<a href="' . esc_url(admin_url('edit.php?post_type=' . Plugin::CPT)) . '">' . esc_html__('Templates', 'authorwings-ai-tools') . '</a>'
                    );
                ?></em></p>
            <?php else: ?>

                <?php // Render the save-forms OUTSIDE the table so inputs bind
                      // to them via HTML5 form attribute. Keeps markup valid. ?>
                <?php foreach ($post_ids as $pid): $pid = (int) $pid; ?>
                    <form id="awg-rating-save-<?php echo esc_attr($pid); ?>"
                          method="post"
                          action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
                          style="display:none;">
                        <input type="hidden" name="action" value="awg_rating_admin_save">
                        <input type="hidden" name="post_id" value="<?php echo esc_attr($pid); ?>">
                        <?php wp_nonce_field('awg_rating_admin_save_' . $pid); ?>
                    </form>
                <?php endforeach; ?>

                <table class="widefat striped" style="margin-top:14px;">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Template / Post', 'authorwings-ai-tools'); ?></th>
                            <th><?php esc_html_e('Type', 'authorwings-ai-tools'); ?></th>
                            <th><?php esc_html_e('Status', 'authorwings-ai-tools'); ?></th>
                            <th style="text-align:center;"><?php esc_html_e('Displayed', 'authorwings-ai-tools'); ?></th>
                            <th><?php esc_html_e('Real votes', 'authorwings-ai-tools'); ?></th>
                            <th><?php esc_html_e('Base (count / avg)', 'authorwings-ai-tools'); ?></th>
                            <th style="width:200px;"><?php esc_html_e('Actions', 'authorwings-ai-tools'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($post_ids as $pid):
                        $pid  = (int) $pid;
                        $post = get_post($pid);
                        if (!$post) continue;
                        $agg        = $this->get_aggregates($pid);
                        $enabled    = $this->is_enabled($pid);
                        $base_count = (int)   get_post_meta($pid, self::META_BASE_COUNT, true);
                        $base_avg   = (float) get_post_meta($pid, self::META_BASE_AVG, true);
                        $form_id    = 'awg-rating-save-' . $pid;
                        $is_tpl     = ($post->post_type === Plugin::CPT);
                    ?>
                        <tr>
                            <td>
                                <strong><a href="<?php echo esc_url(get_edit_post_link($pid)); ?>"><?php echo esc_html(get_the_title($pid) ?: '(no title)'); ?></a></strong>
                            </td>
                            <td>
                                <?php if ($is_tpl): ?>
                                    <span style="background:#e7f4e9;color:#1a8038;padding:2px 6px;border-radius:3px;font-size:11px;"><?php esc_html_e('Template', 'authorwings-ai-tools'); ?></span>
                                <?php else: ?>
                                    <span style="background:#f0f0f1;color:#50575e;padding:2px 6px;border-radius:3px;font-size:11px;"><?php echo esc_html($post->post_type); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($enabled): ?>
                                    <span style="color:#1a8038;">●</span> <?php esc_html_e('On', 'authorwings-ai-tools'); ?>
                                <?php else: ?>
                                    <span style="color:#aaa;">●</span> <?php esc_html_e('Off', 'authorwings-ai-tools'); ?>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:center;">
                                <?php if ($agg['count'] > 0): ?>
                                    <strong style="font-size:15px;"><?php echo esc_html(number_format_i18n($agg['avg'], 1)); ?> ★</strong><br>
                                    <small><?php echo esc_html(number_format_i18n($agg['count'])); ?></small>
                                <?php else: ?>
                                    <small style="color:#999;"><?php esc_html_e('No ratings', 'authorwings-ai-tools'); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                printf(
                                    /* translators: 1: real vote count, 2: real sum of stars */
                                    esc_html__('%1$d votes / %2$d stars', 'authorwings-ai-tools'),
                                    (int) $agg['real_count'],
                                    (int) $agg['real_sum']
                                );
                                ?>
                                <br><small style="color:#999;"><?php esc_html_e('(read-only)', 'authorwings-ai-tools'); ?></small>
                            </td>
                            <td>
                                <input form="<?php echo esc_attr($form_id); ?>" type="number" min="0" step="1" name="base_count"
                                       value="<?php echo esc_attr($base_count); ?>" style="width:80px;"> /
                                <input form="<?php echo esc_attr($form_id); ?>" type="number" min="0" max="5" step="0.1" name="base_avg"
                                       value="<?php echo esc_attr($base_avg); ?>" style="width:60px;">
                            </td>
                            <td>
                                <button form="<?php echo esc_attr($form_id); ?>" type="submit" class="button button-primary"><?php esc_html_e('Save', 'authorwings-ai-tools'); ?></button>
                                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;margin-left:4px;">
                                    <input type="hidden" name="action" value="awg_rating_admin_reset">
                                    <input type="hidden" name="post_id" value="<?php echo esc_attr($pid); ?>">
                                    <?php wp_nonce_field('awg_rating_admin_reset_' . $pid); ?>
                                    <button type="submit" class="button" onclick="return confirm('<?php esc_attr_e('Reset all real votes and IP records for this item?', 'authorwings-ai-tools'); ?>')"><?php esc_html_e('Reset', 'authorwings-ai-tools'); ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

            <?php endif; ?>

            <h2 style="margin-top:30px;"><?php esc_html_e('How it works', 'authorwings-ai-tools'); ?></h2>
            <ol>
                <li><?php esc_html_e('Open any template (AuthorWings AI → Templates → edit). In the sidebar "AuthorWings Rating" box, the widget is on by default. Set "Base votes" and "Base average" if you want to seed the count.', 'authorwings-ai-tools'); ?></li>
                <li><?php esc_html_e('The star widget will auto-render inside that template\'s generator form on every page using it — no shortcode needed.', 'authorwings-ai-tools'); ?></li>
                <li><?php
                    printf(
                        /* translators: %s: shortcode */
                        esc_html__('To add a rating to a regular post or page (not a template), drop %s anywhere in the content. Configure it via the same sidebar metabox on that post.', 'authorwings-ai-tools'),
                        '<code>[' . esc_html(self::SHORTCODE) . ']</code>'
                    );
                ?></li>
                <li><?php esc_html_e('Google picks up the AggregateRating JSON-LD automatically from the page head. Use the Rich Results Test to verify, then request re-indexing in Search Console.', 'authorwings-ai-tools'); ?></li>
            </ol>
        </div>
        <?php
    }

    public function handle_admin_save(): void {
        if (!current_user_can('manage_options')) wp_die(esc_html__('Not allowed.', 'authorwings-ai-tools'));
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        check_admin_referer('awg_rating_admin_save_' . $post_id);

        if ($post_id <= 0 || !get_post($post_id)) wp_die(esc_html__('Invalid post.', 'authorwings-ai-tools'));

        $base_count = max(0, intval($_POST['base_count'] ?? 0));
        $base_avg   = (float) ($_POST['base_avg'] ?? 0);
        $base_avg   = $base_count > 0 ? max(1.0, min(5.0, $base_avg)) : 0.0;

        update_post_meta($post_id, self::META_BASE_COUNT, $base_count);
        update_post_meta($post_id, self::META_BASE_AVG,   $base_avg);

        wp_safe_redirect(add_query_arg('saved', 1, admin_url('edit.php?post_type=' . Plugin::CPT . '&page=awg-ratings')));
        exit;
    }

    public function handle_admin_reset(): void {
        if (!current_user_can('manage_options')) wp_die(esc_html__('Not allowed.', 'authorwings-ai-tools'));
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
        check_admin_referer('awg_rating_admin_reset_' . $post_id);

        if ($post_id <= 0) wp_die(esc_html__('Invalid post.', 'authorwings-ai-tools'));

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE;
        $wpdb->delete($table, ['post_id' => $post_id], ['%d']);

        // Real counts are derived from the table — deleting rows is sufficient.

        wp_safe_redirect(add_query_arg('reset', 1, admin_url('edit.php?post_type=' . Plugin::CPT . '&page=awg-ratings')));
        exit;
    }
}
