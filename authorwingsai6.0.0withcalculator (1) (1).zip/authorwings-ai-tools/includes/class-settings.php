<?php
namespace AWG_AIG;

if (!defined('ABSPATH')) { exit; }

final class Settings {
    /** @var string */
    private $opt_key;

    public function __construct(string $opt_key) {
        $this->opt_key = $opt_key;
    }

    /**
     * AuthorWings.com brand palette (used as factory defaults).
     * Bare hex (no leading #) is the on-disk storage format.
     */
    public static function brand_palette(): array {
        // v5.4.26: these are the warm "branded" palette values that, until now,
        // were hardcoded in Renderer::branded_palette_css() and overrode the
        // pickers. They are now the factory defaults for the editable pickers,
        // so the branded design is fully driven by Settings + per-template
        // colours while a fresh install still looks identical to before.
        return [
            // Container & text
            'global_style_bg_color'                 => 'f2ead9',  // warm cream card
            'global_style_text_color'               => '33291c',  // deep warm brown body text
            'global_style_border_color'             => 'e5dac4',  // soft cream border
            'global_style_accent_color'             => 'c8794f',  // AuthorWings terracotta accent
            'global_style_input_bg_color'           => 'fdfaf3',  // near-white cream input field
            'global_style_placeholder_color'        => 'a8967c',  // muted warm gray
            'global_style_required_color'           => 'c0653f',  // terracotta error indicator

            // Primary "Generate" button (deep publishing navy)
            'global_style_button_bg_color'          => '10243c',  // deep navy
            'global_style_button_text_color'        => 'f7efe2',  // warm cream text
            'global_style_button_border_color'      => '10243c',
            'global_style_button_hover_bg_color'    => '1b3a5c',  // lighter navy on hover
            'global_style_button_hover_text_color'  => 'f7efe2',
            'global_style_button_active_bg_color'   => '0a1a2d',  // darker navy on press
            'global_style_focus_ring_color'         => '10243c',  // navy glow

            // Action buttons (Copy / Download / Clear / Regenerate)
            'global_style_action_btn_bg_color'      => '10243c',  // navy secondary action
            'global_style_action_btn_text_color'    => 'f7efe2',
            'global_style_action_btn_border_color'  => '10243c',
            'global_style_action_btn_hover_bg_color'   => '0a1a2d', // darker navy on hover
            'global_style_action_btn_hover_text_color' => 'f7efe2',

            // Result output area
            'global_style_output_bg_color'          => 'fdfaf3',
            'global_style_output_gradient_top_color' => 'fdfaf3',
            'global_style_output_gradient_bot_color' => 'efe6d6',  // soft cream tint at bottom
            'global_style_code_bg_color'            => 'efe6d6',   // cream code block
            'global_style_badge_bg_color'           => 'ece0cd',   // warm cream pill
            'global_style_badge_text_color'         => '7a5230',   // warm brown text on the pill
            'global_style_shadow_color'             => '503c1e',   // warm brown at low alpha → soft shadow
        ];
    }

    /**
     * v5.4.26: the PREVIOUS factory palette (white card / navy / sage). Kept
     * only so the one-time palette migration can recognise an install that has
     * never customised its colours and upgrade it to the warm branded defaults
     * above. Values an admin deliberately changed are never touched.
     */
    public static function legacy_brand_palette(): array {
        return [
            'global_style_bg_color'                 => 'ffffff',
            'global_style_text_color'               => '10243c',
            'global_style_border_color'             => 'e8decf',
            'global_style_accent_color'             => '7e9374',
            'global_style_input_bg_color'           => 'fbf8f2',
            'global_style_placeholder_color'        => '8b7e6f',
            'global_style_required_color'           => 'c97a5e',
            'global_style_button_bg_color'          => '10243c',
            'global_style_button_text_color'        => 'ffffff',
            'global_style_button_border_color'      => '10243c',
            'global_style_button_hover_bg_color'    => '7e9374',
            'global_style_button_hover_text_color'  => 'ffffff',
            'global_style_button_active_bg_color'   => '0a1a2d',
            'global_style_focus_ring_color'         => '7e9374',
            'global_style_action_btn_bg_color'      => '7e9374',
            'global_style_action_btn_text_color'    => 'ffffff',
            'global_style_action_btn_border_color'  => '7e9374',
            'global_style_action_btn_hover_bg_color'   => '10243c',
            'global_style_action_btn_hover_text_color' => 'ffffff',
            'global_style_output_bg_color'          => 'ffffff',
            'global_style_output_gradient_top_color' => 'ffffff',
            'global_style_output_gradient_bot_color' => 'fbf8f2',
            'global_style_code_bg_color'            => 'f2eae0',
            'global_style_badge_bg_color'           => 'e1e8d8',
            'global_style_badge_text_color'         => '10243c',
            'global_style_shadow_color'             => '10243c',
            // radii that branded forced to 20/12
            'global_style_radius'                   => 14,
            'global_style_button_radius'            => 10,
        ];
    }

    public function defaults(): array {
        return array_merge([
            'api_key' => '',
            'anthropic_api_key' => '',
            'deepseek_api_key' => '',
            'default_model' => 'gpt-5-mini',
            // v5.7.0: the Build Assistant (admin Build Assistant page) can run on
            // its own model, independent of the site-wide default the front-end
            // tools use. Blank = fall back to default_model. Routing + API key
            // follow the model id exactly like every other model field.
            'builder_model' => '',
            // v5.7.9: Build Assistant control panel. A master on/off switch for
            // the whole Build Assistant page, explicit switches for each write
            // power it has (creating draft templates / draft posts), and a cap on
            // its response length. All on by default so existing installs behave
            // exactly as before.
            'builder_enabled' => 1,
            'builder_allow_template' => 1,
            'builder_allow_post' => 1,
            'builder_max_tokens' => 2000,
            // Editable overrides for the assistant's prompt. Blank = built-in
            // default for that section. The base persona plus the (still
            // write-power-gated) template and post rule sections. Data-safety
            // guarantees live in code, not these strings, so a bad edit can be
            // undone by clearing the box.
            'builder_system_prompt' => '',
            'builder_template_prompt' => '',
            'builder_post_prompt' => '',
            'timeout' => 45,
            // v5.4.61: stream the model's response token-by-token (Server-Sent
            // Events) so results type in live instead of appearing all at once.
            // On by default; front.js falls back to the classic one-shot request
            // automatically on hosts where streaming is blocked.
            'enable_streaming' => 1,
            // v5.4.49: a single "global prompt" prepended to EVERY template's
            // own system prompt before the model call, so shared rules (tone,
            // language, formatting, do/don't lists) live in one place instead of
            // being repeated in each tool. Blank by default — existing installs
            // behave exactly as before. Templates can opt out individually.
            'global_prompt' => '',
            // v5.7.9: the two formatting lines appended to every generation are
            // now editable site-wide. Blank = built-in default (see Renderer).
            'format_hygiene' => '',
            'format_rules' => '',
            'allow_guests' => 1,
            // v5.4.11: default lowered from 60 → 10. A legitimate user
            // clicking Generate/Regenerate to compare outputs stays well
            // under 10/min; the previous default of 60 effectively meant
            // "no rate limit" against accidental loops, misbehaving bots,
            // or button-spammers, and every successful generation costs
            // real OpenAI tokens. Existing installs keep their saved value
            // — this only affects fresh activations until an admin re-saves
            // the settings page.
            'global_rate_per_min' => 10,
            // v5.4.31: optional SITE-WIDE daily ceiling on generations across
            // ALL visitors/IPs. The per-IP limiter above caps any one visitor's
            // burst, but a distributed (many-IP) flood against a guest-enabled
            // tool could still run up the OpenAI bill. This is a hard backstop on
            // total successful generations per calendar day (site timezone).
            // 0 = disabled (default) — existing installs are unaffected.
            'global_daily_cap' => 0,
            // v5.4.48: gibberish / keyboard-mashing guard. When on, text and
            // textarea answers that look like random characters (long consonant
            // runs, repeated chars, near-zero vowel ratio) are rejected on the
            // server BEFORE the billable AI call — and mirrored client-side for
            // instant feedback — so junk input never costs a generation. This is
            // a Latin-script heuristic ONLY; non-Latin scripts (CJK, Arabic,
            // Cyrillic, …) are deliberately left untouched to avoid false
            // positives. Templates can override this (on/off/inherit).
            'gibberish_check' => 1,
            // Trimmed answers shorter than this are never scored, so short
            // legitimate tokens ("AI", "Q3", a short name) always pass.
            'gibberish_min_length' => 4,
            // v5.4.6: global_cache_seconds removed — AI tools should always
            // return fresh output; caching identical-input → identical-output
            // confuses users who expect a fresh generation each click.
            'enable_gclid' => 1,
            'enable_utm' => 1,
            'store_submissions' => 0,
            'store_ip' => 0,
            'submissions_retention_days' => 0,

            // Post-result Call-to-Action (shown below tool results).
            'cta_enabled' => 1,
            'cta_text' => 'Liked the results? Check our book cost calculator, priced transparently in line with Editorial Freelancers Association industry rates. <a href="/book-cost-calculator/">Book Cost Calculator.</a>',

            // v5.9.9: Cookie Consent / GDPR notice. A simple, site-wide banner that
            // tells visitors the site uses cookies and lets them dismiss it; the
            // choice is remembered (cookie + localStorage) so it shows once. Off by
            // default — existing installs are unaffected until an admin enables it.
            'cookie_consent_enabled'        => 0,
            'cookie_consent_message'        => 'This website uses cookies to ensure you get the best experience on our website.',
            'cookie_consent_button_text'    => 'Got it!',
            // v5.9.18: optional "Reject" button. GDPR/ePrivacy requires refusing
            // to be as easy as accepting, so when the banner asks for consent to
            // non-essential (analytics / advertising) cookies a reject button must
            // be shown alongside Accept. Both choices are recorded and broadcast
            // (JS event + dataLayer + a cookie value) so tag managers / analytics
            // can honour the decision. Leave off for a plain "we use cookies"
            // notice that sets no non-essential cookies.
            'cookie_consent_show_reject'    => 0,
            'cookie_consent_reject_text'    => 'Reject',
            'cookie_consent_learn_text'     => 'Learn more',
            'cookie_consent_learn_url'      => '',
            'cookie_consent_position'       => 'bottom', // bottom | top
            'cookie_consent_bg_color'       => '211c17', // banner background (bare hex)
            'cookie_consent_text_color'     => 'ffffff', // banner text
            'cookie_consent_button_bg'      => 'c8794f', // accept button background
            'cookie_consent_button_text_color' => 'ffffff', // accept button text

            'global_style_padding' => 16,
            'global_style_margin' => 12,
            // Per-side Container Spacing (v5.9.8). These fall back to the legacy
            // single padding/margin values above when first introduced so existing
            // sites keep their current look.
            'global_style_padding_top'    => 16,
            'global_style_padding_right'  => 16,
            'global_style_padding_bottom' => 16,
            'global_style_padding_left'   => 16,
            'global_style_margin_top'     => 12,
            'global_style_margin_right'   => 12,
            'global_style_margin_bottom'  => 12,
            'global_style_margin_left'    => 12,
            'global_style_radius' => 20,
            'global_style_button_padding_y' => 10,
            'global_style_button_padding_x' => 14,
            'global_style_button_radius' => 12,
            'global_style_input_height' => 44,
            'global_style_textarea_rows' => 5,

            // v5.4.45: AI Tools hub card layout. Controls how tool cards AND
            // category cards present their feature image on the [awg_tools] hub.
            // Cards without an image fall back to the icon + accent style.
            'hub_card_layout' => 'square',       // tool cards:     square | banner | cover
            'hub_cat_layout'  => 'square',       // category cards: square | banner | cover

            // v5.4.24: default form header design (applies globally; each
            // template can override it). 'branded' draws an icon badge, title,
            // optional eyebrow + accent rule, and a subtitle, with a coordinated
            // warm palette. 'plain' keeps the simple title + description look.
            'form_design' => 'branded',          // branded | plain
            'header_icon_position' => 'top',     // top | left
            'title_font' => 'serif',             // serif | sans
            'brand_eyebrow' => 'AuthorWings',    // small label above the title ('' hides it)
            'header_show_rule' => 1,             // accent rule under the title (top layout)
            'header_subtitle_italic' => 1,       // render the description as an italic subtitle

            // v5.4.26: branded-only header colours. Each is a bare hex; leaving
            // a field blank lets the CSS fall back to the accent/text colour, so
            // these only need setting when an admin wants the header element to
            // differ from the main palette. Per-template overrides mirror these.
            'brand_title_color'      => '211c17', // header title (branded)
            'brand_subtitle_color'   => '8a7a5f', // header subtitle (branded)
            'brand_eyebrow_color'    => 'b06a45', // eyebrow label (branded)
            'brand_badge_bg_color'   => 'c8794f', // icon badge background (branded)
            'brand_badge_icon_color' => 'ffffff', // icon badge glyph colour (branded)
            'brand_rule_color'       => 'c8794f', // accent rule under the title (branded)
        ], self::brand_palette());
    }

    public function get(): array {
        $saved = get_option($this->opt_key, []);
        if (!is_array($saved)) { $saved = []; }
        $merged = array_merge($this->defaults(), $saved);

        // Back-compat (v5.9.8): the Container Spacing controls became per-side.
        // For options saved before this change, the per-side keys are absent, so
        // inherit each side from the legacy single padding/margin value the admin
        // had set. This keeps existing installs looking identical until the admin
        // deliberately edits a side.
        foreach (['top', 'right', 'bottom', 'left'] as $side) {
            if (!array_key_exists('global_style_padding_' . $side, $saved)) {
                $merged['global_style_padding_' . $side] = (int) $merged['global_style_padding'];
            }
            if (!array_key_exists('global_style_margin_' . $side, $saved)) {
                $merged['global_style_margin_' . $side] = (int) $merged['global_style_margin'];
            }
        }

        return $merged;
    }

    public function register(): void {
        register_setting('awg_aig_group', $this->opt_key, [
            'type' => 'array',
            'sanitize_callback' => [$this, 'sanitize'],
        ]);
    }

    /**
     * v5.4.26: one-time migration. Now that the branded design reads the colour
     * pickers instead of a hardcoded override, an install that was relying on
     * the old white/navy/sage factory defaults would suddenly render with those
     * colours instead of the warm branded palette. This walks the saved option
     * and, for any colour/radius still sitting at the PREVIOUS factory default
     * (i.e. never deliberately changed), upgrades it to the new warm default.
     * Anything the admin customised is left untouched. Runs once.
     */
    public function maybe_migrate_palette(): void {
        $done = get_option('awg_aig_palette_version', 0);
        if ((int) $done >= 2) { return; }

        $saved = get_option($this->opt_key, []);
        if (is_array($saved) && !empty($saved)) {
            $legacy = self::legacy_brand_palette();
            $fresh  = array_merge(self::brand_palette(), [
                'global_style_radius'        => 20,
                'global_style_button_radius' => 12,
            ]);
            foreach ($legacy as $key => $legacy_val) {
                if (!array_key_exists($key, $saved) || !isset($fresh[$key])) { continue; }
                // Normalise hex comparison; radii compare as ints.
                if (is_string($legacy_val) && preg_match('/^[0-9a-f]{3,6}$/i', (string) $legacy_val)) {
                    if (self::sanitize_hex_bare($saved[$key], $legacy_val) === self::sanitize_hex_bare($legacy_val, $legacy_val)) {
                        $saved[$key] = $fresh[$key];
                    }
                } elseif ((int) $saved[$key] === (int) $legacy_val) {
                    $saved[$key] = $fresh[$key];
                }
            }
            update_option($this->opt_key, $saved);
        }

        update_option('awg_aig_palette_version', 2);
    }

    /**
     * Normalize any hex (with or without #, 3 or 6 digits) to a 6-digit bare
     * lowercase hex. Returns $default (bare hex) if input is invalid.
     */
    public static function sanitize_hex_bare($value, string $default): string {
        $value = strtolower(trim((string) $value));
        $value = ltrim($value, '#');
        if (preg_match('/^[0-9a-f]{3}$/', $value)) {
            $value = $value[0].$value[0].$value[1].$value[1].$value[2].$value[2];
        }
        if (preg_match('/^[0-9a-f]{6}$/', $value)) {
            return $value;
        }
        return ltrim(strtolower($default), '#');
    }

    /**
     * The full list of color setting keys handled by this settings page.
     * Used by sanitize() and by the form renderer.
     */
    public static function color_keys(): array {
        return array_keys(self::brand_palette());
    }

    public function sanitize($input): array {
        $d = $this->defaults();
        if (!is_array($input)) { $input = []; }

        // Allow a one-click reset back to the AuthorWings palette.
        $reset = !empty($input['_awg_reset_palette']);

        $out = [];
        $out['api_key'] = sanitize_text_field($input['api_key'] ?? $d['api_key']);
        $out['anthropic_api_key'] = sanitize_text_field($input['anthropic_api_key'] ?? $d['anthropic_api_key']);
        $out['deepseek_api_key'] = sanitize_text_field($input['deepseek_api_key'] ?? $d['deepseek_api_key']);
        $out['default_model'] = sanitize_text_field($input['default_model'] ?? $d['default_model']);
        $out['builder_model'] = sanitize_text_field($input['builder_model'] ?? $d['builder_model']);
        // v5.7.9: Build Assistant control panel.
        $out['builder_enabled'] = isset($input['builder_enabled']) ? 1 : 0;
        $out['builder_allow_template'] = isset($input['builder_allow_template']) ? 1 : 0;
        $out['builder_allow_post'] = isset($input['builder_allow_post']) ? 1 : 0;
        $out['builder_max_tokens'] = max(256, min(8000, intval($input['builder_max_tokens'] ?? $d['builder_max_tokens'])));
        $out['builder_system_prompt'] = trim(sanitize_textarea_field((string) ($input['builder_system_prompt'] ?? $d['builder_system_prompt'])));
        $out['builder_template_prompt'] = trim(sanitize_textarea_field((string) ($input['builder_template_prompt'] ?? $d['builder_template_prompt'])));
        $out['builder_post_prompt'] = trim(sanitize_textarea_field((string) ($input['builder_post_prompt'] ?? $d['builder_post_prompt'])));
        // v5.4.49: global prompt — multi-line plain text, newlines preserved so
        // the admin can write paragraph/bulleted instructions.
        $out['global_prompt'] = trim(sanitize_textarea_field((string) ($input['global_prompt'] ?? $d['global_prompt'])));
        $out['format_hygiene'] = trim(sanitize_textarea_field((string) ($input['format_hygiene'] ?? $d['format_hygiene'])));
        $out['format_rules'] = trim(sanitize_textarea_field((string) ($input['format_rules'] ?? $d['format_rules'])));
        $out['timeout'] = max(10, min(120, intval($input['timeout'] ?? $d['timeout'])));
        $out['enable_streaming'] = isset($input['enable_streaming']) ? 1 : 0;
        $out['allow_guests'] = isset($input['allow_guests']) ? 1 : 0;
        $out['global_rate_per_min'] = max(1, intval($input['global_rate_per_min'] ?? $d['global_rate_per_min']));
        // v5.4.31: site-wide daily generation cap. 0 = disabled. Upper bound is
        // generous (1,000,000) so it never silently clips a high-traffic site
        // that deliberately sets a large ceiling.
        $out['global_daily_cap'] = max(0, min(1000000, intval($input['global_daily_cap'] ?? $d['global_daily_cap'])));
        // v5.4.48: gibberish guard toggle + minimum length below which values
        // are exempt from scoring.
        $out['gibberish_check'] = isset($input['gibberish_check']) ? 1 : 0;
        $out['gibberish_min_length'] = max(0, min(50, intval($input['gibberish_min_length'] ?? $d['gibberish_min_length'])));
        // v5.4.6: global_cache_seconds removed from settings
        $out['enable_gclid'] = isset($input['enable_gclid']) ? 1 : 0;
        $out['enable_utm'] = isset($input['enable_utm']) ? 1 : 0;
        $out['store_submissions'] = isset($input['store_submissions']) ? 1 : 0;
        $out['store_ip'] = isset($input['store_ip']) ? 1 : 0;
        $out['submissions_retention_days'] = max(0, min(3650, intval($input['submissions_retention_days'] ?? $d['submissions_retention_days'])));

        // CTA: allow safe HTML so admins can include a link inside the message.
        $out['cta_enabled'] = isset($input['cta_enabled']) ? 1 : 0;
        $cta_raw = isset($input['cta_text']) ? (string) $input['cta_text'] : $d['cta_text'];
        $out['cta_text'] = trim(wp_kses_post($cta_raw));

        // v5.9.9: Cookie Consent / GDPR notice.
        $out['cookie_consent_enabled'] = isset($input['cookie_consent_enabled']) ? 1 : 0;
        $cc_msg = isset($input['cookie_consent_message']) ? (string) $input['cookie_consent_message'] : $d['cookie_consent_message'];
        $out['cookie_consent_message'] = trim(wp_kses_post($cc_msg));
        $out['cookie_consent_button_text'] = sanitize_text_field($input['cookie_consent_button_text'] ?? $d['cookie_consent_button_text']);
        $out['cookie_consent_show_reject'] = isset($input['cookie_consent_show_reject']) ? 1 : 0;
        $out['cookie_consent_reject_text'] = sanitize_text_field($input['cookie_consent_reject_text'] ?? $d['cookie_consent_reject_text']);
        $out['cookie_consent_learn_text']  = sanitize_text_field($input['cookie_consent_learn_text'] ?? $d['cookie_consent_learn_text']);
        $out['cookie_consent_learn_url']   = esc_url_raw(trim((string) ($input['cookie_consent_learn_url'] ?? $d['cookie_consent_learn_url'])));
        $out['cookie_consent_position']    = in_array(($input['cookie_consent_position'] ?? $d['cookie_consent_position']), ['bottom', 'top'], true) ? ($input['cookie_consent_position'] ?? $d['cookie_consent_position']) : $d['cookie_consent_position'];
        foreach (['cookie_consent_bg_color', 'cookie_consent_text_color', 'cookie_consent_button_bg', 'cookie_consent_button_text_color'] as $ck) {
            $out[$ck] = self::sanitize_hex_bare($input[$ck] ?? $d[$ck], $d[$ck]);
        }

        // Color fields: every slot accepts any valid hex color.
        foreach (self::color_keys() as $key) {
            if ($reset) {
                $out[$key] = $d[$key];
            } else {
                $out[$key] = self::sanitize_hex_bare($input[$key] ?? $d[$key], $d[$key]);
            }
        }

        $out['global_style_padding'] = max(0, min(80, intval($input['global_style_padding'] ?? $d['global_style_padding'])));
        $out['global_style_margin']  = max(0, min(80, intval($input['global_style_margin'] ?? $d['global_style_margin'])));

        // Per-side Container Spacing (v5.9.8). Each side falls back to the legacy
        // single padding/margin value when its dedicated input is missing, so old
        // forms and freshly migrated sites keep working.
        foreach (['top', 'right', 'bottom', 'left'] as $side) {
            $pad_key = 'global_style_padding_' . $side;
            $mar_key = 'global_style_margin_' . $side;
            $out[$pad_key] = max(0, min(80, intval($input[$pad_key] ?? $out['global_style_padding'])));
            $out[$mar_key] = max(0, min(80, intval($input[$mar_key] ?? $out['global_style_margin'])));
        }
        // Keep the legacy single values in sync with the per-side inputs so other
        // code paths that still read them stay sensible (use the top side).
        if (isset($input['global_style_padding_top'])) {
            $out['global_style_padding'] = $out['global_style_padding_top'];
        }
        if (isset($input['global_style_margin_top'])) {
            $out['global_style_margin'] = $out['global_style_margin_top'];
        }

        $out['global_style_radius']  = max(0, min(40, intval($input['global_style_radius'] ?? $d['global_style_radius'])));
        $out['global_style_button_padding_y'] = max(6, min(30, intval($input['global_style_button_padding_y'] ?? $d['global_style_button_padding_y'])));
        $out['global_style_button_padding_x'] = max(8, min(40, intval($input['global_style_button_padding_x'] ?? $d['global_style_button_padding_x'])));
        $out['global_style_button_radius']    = max(0, min(20, intval($input['global_style_button_radius'] ?? $d['global_style_button_radius'])));
        $out['global_style_input_height']     = max(32, min(80, intval($input['global_style_input_height'] ?? $d['global_style_input_height'])));
        $out['global_style_textarea_rows']    = max(2, min(20, intval($input['global_style_textarea_rows'] ?? $d['global_style_textarea_rows'])));

        // v5.4.24: form header design.
        $out['form_design']           = in_array(($input['form_design'] ?? $d['form_design']), ['branded', 'plain'], true) ? ($input['form_design'] ?? $d['form_design']) : $d['form_design'];
        $out['header_icon_position']  = in_array(($input['header_icon_position'] ?? $d['header_icon_position']), ['top', 'left'], true) ? ($input['header_icon_position'] ?? $d['header_icon_position']) : $d['header_icon_position'];
        $out['title_font']            = in_array(($input['title_font'] ?? $d['title_font']), ['serif', 'sans'], true) ? ($input['title_font'] ?? $d['title_font']) : $d['title_font'];
        $out['hub_card_layout']       = in_array(($input['hub_card_layout'] ?? $d['hub_card_layout']), ['square', 'banner', 'cover'], true) ? ($input['hub_card_layout'] ?? $d['hub_card_layout']) : $d['hub_card_layout'];
        $out['hub_cat_layout']        = in_array(($input['hub_cat_layout'] ?? $d['hub_cat_layout']), ['square', 'banner', 'cover'], true) ? ($input['hub_cat_layout'] ?? $d['hub_cat_layout']) : $d['hub_cat_layout'];
        $out['brand_eyebrow']         = sanitize_text_field($input['brand_eyebrow'] ?? $d['brand_eyebrow']);
        $out['header_show_rule']      = isset($input['header_show_rule']) ? 1 : 0;
        $out['header_subtitle_italic']= isset($input['header_subtitle_italic']) ? 1 : 0;
        // v5.4.26: branded-only header colours.
        foreach (['brand_title_color', 'brand_subtitle_color', 'brand_eyebrow_color', 'brand_badge_bg_color', 'brand_badge_icon_color', 'brand_rule_color'] as $bk) {
            $out[$bk] = self::sanitize_hex_bare($input[$bk] ?? $d[$bk], $d[$bk]);
        }
        return $out;
    }

    public function menu(): void {
        // Top-level menu: AuthorWings AI
        add_menu_page(
            __('AuthorWings AI', 'authorwings-ai-tools'),
            __('AuthorWings AI', 'authorwings-ai-tools'),
            'manage_options',
            'edit.php?post_type=awg_ai_template',
            null,
            'dashicons-lightbulb',
            56
        );

        // v5.4.28: explicit submenu positions so the menu order is intentional
        // and grouped (generators → engagement data → membership → config →
        // maintenance), instead of incidental to which module registers first.
        // Other modules (Ratings 40, membership 50/60/70/90, Export/Import 100)
        // pass matching positions. Sparse, unique values leave room to insert.

        // Templates (list)
        add_submenu_page(
            'edit.php?post_type=awg_ai_template',
            __('Templates', 'authorwings-ai-tools'),
            __('Templates', 'authorwings-ai-tools'),
            'manage_options',
            'edit.php?post_type=awg_ai_template',
            '',
            10
        );

        // Add New Template: intentionally NOT a submenu item (v5.4.28). The
        // Templates list screen already has an "Add New" button, and the CPT's
        // own add-new screen is reachable from there, so a dedicated menu row
        // was redundant. Removed at the site owner's request.

        // AI Submissions
        add_submenu_page(
            'edit.php?post_type=awg_ai_template',
            __('AI Submissions', 'authorwings-ai-tools'),
            __('AI Submissions', 'authorwings-ai-tools'),
            'manage_options',
            'edit.php?post_type=awg_ai_submission',
            '',
            30
        );

        // Settings
        $hook = add_submenu_page(
            'edit.php?post_type=awg_ai_template',
            __('Settings', 'authorwings-ai-tools'),
            __('Settings', 'authorwings-ai-tools'),
            'manage_options',
            'awg-aig-settings',
            [$this, 'page'],
            80
        );

        // Enqueue the WordPress native color picker on this screen only.
        if ($hook) {
            add_action('admin_print_scripts-' . $hook, [$this, 'enqueue_color_picker']);
        }
    }

    /**
     * Enqueue wp-color-picker + tiny init script on the settings screen.
     * Also wires up the "Test API Key" button and pulls in admin.css/admin.js
     * for the collapsible section behavior.
     */
    public function enqueue_color_picker(): void {
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_script('jquery');

        // Reuse the same admin CSS/JS the template editor uses — gives us
        // the collapsible section styles + toggle script here too.
        wp_enqueue_style('awg-aig-admin', plugins_url('assets/admin.css', AWG_AIG_FILE), [], AWG_AIG_VERSION);
        wp_enqueue_script('awg-aig-admin', plugins_url('assets/admin.js', AWG_AIG_FILE), ['jquery', 'wp-color-picker'], AWG_AIG_VERSION, true);

        wp_add_inline_script('wp-color-picker',
            'jQuery(function($){$(".awg-color-picker").wpColorPicker();});'
        );

        $script = <<<'JS'
jQuery(function($){
    $('.awg-aig-test-btn').on('click', function(e){
        e.preventDefault();
        var $btn     = $(this);
        var provider = $btn.data('provider') || 'openai';
        var $out     = $('#' + $btn.data('result'));
        var apiKey   = $('#' + $btn.data('key')).val() || '';
        var model    = $('input[name$="[default_model]"]').val() || '';
        $btn.prop('disabled', true);
        $out.css('color','#646970').text('Testing…');
        $.post(ajaxurl, {
            action:   'awg_aig_test_key',
            nonce:    $btn.data('nonce'),
            api_key:  apiKey,
            model:    model,
            provider: provider
        }).done(function(res){
            if (res && res.success) {
                $out.css('color','#2e7d32').text('✓ ' + (res.data && res.data.message ? res.data.message : 'OK'));
            } else {
                var msg = (res && res.data && res.data.message) ? res.data.message : 'Test failed.';
                $out.css('color','#b32d2e').text('✗ ' + msg);
            }
        }).fail(function(xhr){
            var msg = 'Test failed.';
            try {
                var j = JSON.parse(xhr.responseText);
                if (j && j.data && j.data.message) msg = j.data.message;
            } catch(e){}
            $out.css('color','#b32d2e').text('✗ ' + msg);
        }).always(function(){
            $btn.prop('disabled', false);
        });
    });
});
JS;
        wp_add_inline_script('wp-color-picker', $script);
    }

    /**
     * Simple landing screen for the top-level menu.
     */
    public function landing(): void {
        if (!current_user_can('manage_options')) { return; }
        $templates_url = admin_url('edit.php?post_type=awg_ai_template');
        wp_safe_redirect($templates_url);
        exit;
    }

    /**
     * Output the opening markup for a collapsible section.
     * Pair every call with section_close().
     */
    public static function section_open(string $key, string $title, bool $open = false, string $hint = ''): void {
        $expanded = $open ? 'true' : 'false';
        ?>
        <section class="awg-section" data-section-key="<?php echo esc_attr($key); ?>">
            <button type="button" class="awg-section__toggle" aria-expanded="<?php echo esc_attr($expanded); ?>">
                <span class="awg-section__title"><?php echo esc_html($title); ?></span>
                <?php if ($hint !== ''): ?><span class="awg-section__hint"><?php echo esc_html($hint); ?></span><?php endif; ?>
                <span class="awg-section__chevron" aria-hidden="true"></span>
            </button>
            <div class="awg-section__body">
        <?php
    }

    public static function section_close(): void {
        ?>
            </div>
        </section>
        <?php
    }

    /**
     * Print a color picker row.
     * Stored value is bare hex; the picker expects a leading '#'.
     * `data-default-color` is the AuthorWings brand default for this key —
     * that's what the wp-color-picker "Default" button restores to.
     */
    private function color_row(string $key, string $label, string $value, string $description = ''): void {
        $hex = '#' . ltrim($value, '#');
        $palette = self::brand_palette();
        $default_hex = '#' . ltrim($palette[$key] ?? $value, '#');
        ?>
        <tr>
            <th scope="row"><?php echo esc_html($label); ?></th>
            <td>
                <input type="text"
                       class="awg-color-picker"
                       name="<?php echo esc_attr($this->opt_key); ?>[<?php echo esc_attr($key); ?>]"
                       value="<?php echo esc_attr($hex); ?>"
                       data-default-color="<?php echo esc_attr($default_hex); ?>" />
                <?php if ($description): ?>
                    <p class="description"><?php echo esc_html($description); ?></p>
                <?php endif; ?>
            </td>
        </tr>
        <?php
    }

    public function page(): void {
        if (!current_user_can('manage_options')) { return; }
        $s = $this->get();
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__('AuthorWings AI — Global Settings', 'authorwings-ai-tools'); ?></h1>
            <?php if (isset($_GET['awg_deleted'])):
                $n = max(0, (int) $_GET['awg_deleted']); ?>
                <div class="notice notice-success is-dismissible">
                    <p><?php
                        echo esc_html(sprintf(
                            /* translators: %d: number of submissions deleted */
                            __('Deleted %d submissions.', 'authorwings-ai-tools'),
                            $n
                        ));
                    ?></p>
                </div>
            <?php endif; ?>
            <?php
            // v5.4.28: Membership Settings now live here as a second tab rather
            // than a separate submenu item. The tab only appears when the
            // membership engine is active. Each tab posts to options.php with
            // its own settings group, so saving from either tab is unchanged.
            $awg_mem_active = defined('AWG_MEM_VERSION') && function_exists('awg_aig_mem_render_settings_page');
            $awg_tab  = ($awg_mem_active && isset($_GET['tab']) && $_GET['tab'] === 'membership') ? 'membership' : 'ai';
            $awg_base = admin_url('edit.php?post_type=' . Plugin::CPT . '&page=awg-aig-settings');
            ?>
            <?php if ($awg_mem_active): ?>
                <h2 class="nav-tab-wrapper" style="margin-bottom:16px;">
                    <a href="<?php echo esc_url($awg_base); ?>" class="nav-tab <?php echo $awg_tab === 'ai' ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('AI Settings', 'authorwings-ai-tools'); ?></a>
                    <a href="<?php echo esc_url(add_query_arg('tab', 'membership', $awg_base)); ?>" class="nav-tab <?php echo $awg_tab === 'membership' ? 'nav-tab-active' : ''; ?>"><?php echo esc_html__('Membership', 'authorwings-ai-tools'); ?></a>
                </h2>
            <?php endif; ?>

            <?php if ($awg_tab === 'membership'): ?>

                <?php awg_aig_mem_render_settings_page(true); ?>

            <?php else: ?>

            <?php
            // Master Membership on/off switch. Rendered here in the always-visible
            // "AI Settings" tab (NOT the Membership tab, which disappears when the
            // engine is off) so membership can always be turned back on. Its own
            // self-contained form, owned by the membership module.
            if (function_exists('awg_aig_mem_render_master_toggle')) {
                awg_aig_mem_render_master_toggle();
            }

            // Master Pricing Calculator on/off switch. Same always-visible tab,
            // its own self-contained form owned by the bundled calculator module.
            if (function_exists('awg_aig_calc_render_master_toggle')) {
                awg_aig_calc_render_master_toggle();
            }
            ?>

            <form method="post" action="options.php">
                <?php settings_fields('awg_aig_group'); ?>

                <?php self::section_open('connection', __('Connection', 'authorwings-ai-tools'), false); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('OpenAI API Key', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="password" style="width:420px" id="awg-aig-api-key"
                                   name="<?php echo esc_attr($this->opt_key); ?>[api_key]"
                                   value="<?php echo esc_attr($s['api_key']); ?>"
                                   autocomplete="off" />
                            <button type="button" class="button awg-aig-test-btn" id="awg-aig-test-key"
                                    data-provider="openai" data-key="awg-aig-api-key" data-result="awg-aig-test-key-result"
                                    data-nonce="<?php echo esc_attr(wp_create_nonce('awg_aig_test_key')); ?>">
                                <?php echo esc_html__('Test Connection', 'authorwings-ai-tools'); ?>
                            </button>
                            <span id="awg-aig-test-key-result" style="margin-left:10px;"></span>
                            <p class="description"><?php echo esc_html__('For GPT models (ids starting with “gpt”, “o3”, “o4”, etc.). Stored in WP options, never exposed to the frontend.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Anthropic (Claude) API Key', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="password" style="width:420px" id="awg-aig-anthropic-key"
                                   name="<?php echo esc_attr($this->opt_key); ?>[anthropic_api_key]"
                                   value="<?php echo esc_attr($s['anthropic_api_key']); ?>"
                                   autocomplete="off" />
                            <button type="button" class="button awg-aig-test-btn" id="awg-aig-test-key-anthropic"
                                    data-provider="anthropic" data-key="awg-aig-anthropic-key" data-result="awg-aig-test-key-anthropic-result"
                                    data-nonce="<?php echo esc_attr(wp_create_nonce('awg_aig_test_key')); ?>">
                                <?php echo esc_html__('Test Connection', 'authorwings-ai-tools'); ?>
                            </button>
                            <span id="awg-aig-test-key-anthropic-result" style="margin-left:10px;"></span>
                            <p class="description"><?php echo esc_html__('For Claude models (ids starting with “claude”). Get a key at console.anthropic.com — this is separate from a Claude.ai subscription. Stored in WP options, never exposed to the frontend.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('DeepSeek API Key', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="password" style="width:420px" id="awg-aig-deepseek-key"
                                   name="<?php echo esc_attr($this->opt_key); ?>[deepseek_api_key]"
                                   value="<?php echo esc_attr($s['deepseek_api_key']); ?>"
                                   autocomplete="off" />
                            <button type="button" class="button awg-aig-test-btn" id="awg-aig-test-key-deepseek"
                                    data-provider="deepseek" data-key="awg-aig-deepseek-key" data-result="awg-aig-test-key-deepseek-result"
                                    data-nonce="<?php echo esc_attr(wp_create_nonce('awg_aig_test_key')); ?>">
                                <?php echo esc_html__('Test Connection', 'authorwings-ai-tools'); ?>
                            </button>
                            <span id="awg-aig-test-key-deepseek-result" style="margin-left:10px;"></span>
                            <p class="description"><?php echo esc_html__('For DeepSeek models (ids starting with “deepseek”). Get a key at platform.deepseek.com — note the API requires a topped-up balance. Stored in WP options, never exposed to the frontend.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Default Model', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="text" style="width:260px" list="awg-aig-models"
                                   name="<?php echo esc_attr($this->opt_key); ?>[default_model]"
                                   value="<?php echo esc_attr($s['default_model']); ?>" />
                            <datalist id="awg-aig-models">
                                <option value="gpt-5"></option>
                                <option value="gpt-5-mini"></option>
                                <option value="gpt-5-nano"></option>
                                <option value="gpt-4.1"></option>
                                <option value="gpt-4.1-mini"></option>
                                <option value="gpt-4o"></option>
                                <option value="gpt-4o-mini"></option>
                                <option value="o4-mini"></option>
                                <option value="o3"></option>
                                <option value="o3-mini"></option>
                                <option value="claude-opus-4-8"></option>
                                <option value="claude-opus-4-7"></option>
                                <option value="claude-sonnet-4-6"></option>
                                <option value="claude-haiku-4-5-20251001"></option>
                                <option value="deepseek-v4-flash"></option>
                                <option value="deepseek-v4-pro"></option>
                                <option value="deepseek-chat"></option>
                                <option value="deepseek-reasoner"></option>
                            </datalist>
                            <p class="description"><?php echo esc_html__('Pick a suggested model or type any model id. Ids starting with “claude” use your Anthropic key; ids starting with “deepseek” use your DeepSeek key; everything else uses your OpenAI key. Templates can override this.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('HTTP Timeout (seconds)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="10" max="120"
                                   name="<?php echo esc_attr($this->opt_key); ?>[timeout]"
                                   value="<?php echo esc_attr($s['timeout']); ?>" />
                        </td>
                    </tr>
                </table>
                <?php self::section_close(); ?>

                <?php self::section_open('build_assistant', __('Build Assistant', 'authorwings-ai-tools'), false, __('Enable, model, write powers, response length', 'authorwings-ai-tools')); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Enable Build Assistant', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[builder_enabled]" value="1" <?php checked(!empty($s['builder_enabled'])); ?> />
                                <?php echo esc_html__('Show the Build Assistant page and allow it to run.', 'authorwings-ai-tools'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('When off, the Build Assistant menu item is hidden and its chat is disabled. Your existing tools and templates are unaffected.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Build Assistant Model', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="text" style="width:260px" list="awg-aig-models"
                                   name="<?php echo esc_attr($this->opt_key); ?>[builder_model]"
                                   value="<?php echo esc_attr($s['builder_model']); ?>"
                                   placeholder="<?php echo esc_attr__('Leave blank to use the Default Model', 'authorwings-ai-tools'); ?>" />
                            <p class="description"><?php echo esc_html__('Model used by the admin Build Assistant only (the chat that helps you design tools and can create draft templates). Leave blank to use the Default Model in Connection. Same routing rules: “claude…” uses your Anthropic key, “deepseek…” your DeepSeek key, otherwise OpenAI.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Write powers', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label style="display:block;margin-bottom:6px;">
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[builder_allow_template]" value="1" <?php checked(!empty($s['builder_allow_template'])); ?> />
                                <?php echo esc_html__('Allow it to create generator templates (saved as drafts).', 'authorwings-ai-tools'); ?>
                            </label>
                            <label style="display:block;">
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[builder_allow_post]" value="1" <?php checked(!empty($s['builder_allow_post'])); ?> />
                                <?php echo esc_html__('Allow it to create blog posts (saved as drafts).', 'authorwings-ai-tools'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('These let the assistant write to your database. New content is always saved as a draft for you to review and publish. Turn either off to make the assistant advise only.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Max response tokens', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="256" max="8000" step="1"
                                   name="<?php echo esc_attr($this->opt_key); ?>[builder_max_tokens]"
                                   value="<?php echo esc_attr($s['builder_max_tokens']); ?>" />
                            <p class="description"><?php echo esc_html__('Upper limit on the length of each Build Assistant reply (256–8000). Lower values reduce cost; the default is 2000.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <?php
                    $awg_rt = '\\AWG_AIG\\Agent\\Agent_Runtime';
                    $awg_has_rt = class_exists($awg_rt);
                    $awg_base_default = $awg_has_rt ? \AWG_AIG\Agent\Agent_Runtime::default_builder_system_prompt() : '';
                    $awg_tpl_default  = $awg_has_rt ? trim(\AWG_AIG\Agent\Agent_Runtime::builder_template_instructions()) : '';
                    $awg_post_default = $awg_has_rt ? trim(\AWG_AIG\Agent\Agent_Runtime::builder_post_instructions()) : '';
                    $awg_builder_preview = $awg_has_rt ? \AWG_AIG\Agent\Agent_Runtime::builder_prompt_preview() : '';
                    ?>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Assistant instructions', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <p class="description" style="margin-top:0;"><?php echo esc_html__('Every part of the assistant\'s prompt is editable below. Leave any box blank to use its built-in default. Your data stays safe whatever you write here: new templates and posts are always created as drafts by the code itself, not by these instructions — so a bad edit can simply be cleared to reset.', 'authorwings-ai-tools'); ?></p>

                            <p><strong><?php echo esc_html__('Base instructions (persona & house style)', 'authorwings-ai-tools'); ?></strong></p>
                            <textarea name="<?php echo esc_attr($this->opt_key); ?>[builder_system_prompt]" rows="7" class="large-text code" placeholder="<?php echo esc_attr__('Leave blank to use the built-in base instructions.', 'authorwings-ai-tools'); ?>"><?php echo esc_textarea($s['builder_system_prompt']); ?></textarea>
                            <?php if ($awg_base_default !== ''): ?>
                            <details style="margin-top:6px;">
                                <summary style="cursor:pointer;"><?php echo esc_html__('View / copy the built-in default', 'authorwings-ai-tools'); ?></summary>
                                <textarea rows="7" class="large-text code" readonly onclick="this.select()" style="margin-top:6px;background:#f6f7f7;"><?php echo esc_textarea($awg_base_default); ?></textarea>
                            </details>
                            <?php endif; ?>

                            <p style="margin-top:14px;"><strong><?php echo esc_html__('Template-creation rules', 'authorwings-ai-tools'); ?></strong> — <?php echo esc_html__('added only while “create generator templates” is on above.', 'authorwings-ai-tools'); ?></p>
                            <textarea name="<?php echo esc_attr($this->opt_key); ?>[builder_template_prompt]" rows="7" class="large-text code" placeholder="<?php echo esc_attr__('Leave blank to use the built-in template-creation rules.', 'authorwings-ai-tools'); ?>"><?php echo esc_textarea($s['builder_template_prompt']); ?></textarea>
                            <?php if ($awg_tpl_default !== ''): ?>
                            <details style="margin-top:6px;">
                                <summary style="cursor:pointer;"><?php echo esc_html__('View / copy the built-in default', 'authorwings-ai-tools'); ?></summary>
                                <textarea rows="9" class="large-text code" readonly onclick="this.select()" style="margin-top:6px;background:#f6f7f7;"><?php echo esc_textarea($awg_tpl_default); ?></textarea>
                            </details>
                            <?php endif; ?>

                            <p style="margin-top:14px;"><strong><?php echo esc_html__('Post-creation rules', 'authorwings-ai-tools'); ?></strong> — <?php echo esc_html__('added only while “create blog posts” is on above.', 'authorwings-ai-tools'); ?></p>
                            <textarea name="<?php echo esc_attr($this->opt_key); ?>[builder_post_prompt]" rows="4" class="large-text code" placeholder="<?php echo esc_attr__('Leave blank to use the built-in post-creation rules.', 'authorwings-ai-tools'); ?>"><?php echo esc_textarea($s['builder_post_prompt']); ?></textarea>
                            <?php if ($awg_post_default !== ''): ?>
                            <details style="margin-top:6px;">
                                <summary style="cursor:pointer;"><?php echo esc_html__('View / copy the built-in default', 'authorwings-ai-tools'); ?></summary>
                                <textarea rows="4" class="large-text code" readonly onclick="this.select()" style="margin-top:6px;background:#f6f7f7;"><?php echo esc_textarea($awg_post_default); ?></textarea>
                            </details>
                            <?php endif; ?>

                            <?php if ($awg_builder_preview !== ''): ?>
                            <details style="margin-top:14px;">
                                <summary style="cursor:pointer;font-weight:600;"><?php echo esc_html__('Preview the full prompt actually sent (read-only)', 'authorwings-ai-tools'); ?></summary>
                                <textarea rows="14" class="large-text code" readonly style="margin-top:6px;background:#f6f7f7;"><?php echo esc_textarea($awg_builder_preview); ?></textarea>
                                <p class="description"><?php echo esc_html__('Your three sections (or their defaults) assembled with the auto-generated Result-block list, exactly as the assistant receives them for the current write-power settings. Save to refresh.', 'authorwings-ai-tools'); ?></p>
                            </details>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                <?php self::section_close(); ?>

                <?php self::section_open('global_prompt', __('Global Prompt', 'authorwings-ai-tools'), false, __('Shared instructions sent with every tool', 'authorwings-ai-tools')); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Global System Prompt', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <textarea name="<?php echo esc_attr($this->opt_key); ?>[global_prompt]" rows="6" style="width:100%;max-width:640px;" placeholder="<?php echo esc_attr__('e.g. Always write in British English. Be concise. Never add disclaimers or mention that you are an AI.', 'authorwings-ai-tools'); ?>"><?php echo esc_textarea($s['global_prompt']); ?></textarea>
                            <p class="description"><?php echo esc_html__('Prepended to every template’s own system prompt before the model call, so shared rules (tone, language, formatting, do/don’t lists) live in one place. Leave blank to disable. Individual templates can opt out on their own edit screen.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <?php
                    $awg_hygiene_default = class_exists('\\AWG_AIG\\Renderer') ? \AWG_AIG\Renderer::default_format_hygiene() : '';
                    $awg_fmtrules_default = class_exists('\\AWG_AIG\\Renderer') ? \AWG_AIG\Renderer::default_format_rules() : '';
                    ?>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Formatting hygiene', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <textarea name="<?php echo esc_attr($this->opt_key); ?>[format_hygiene]" rows="4" style="width:100%;max-width:640px;" placeholder="<?php echo esc_attr__('Leave blank to use the built-in default shown below.', 'authorwings-ai-tools'); ?>"><?php echo esc_textarea($s['format_hygiene']); ?></textarea>
                            <p class="description"><?php echo esc_html__('Appended to every generation. Keeps internal block/markup names out of the reader-facing output. Leave blank to use the built-in default.', 'authorwings-ai-tools'); ?></p>
                            <?php if ($awg_hygiene_default !== ''): ?>
                            <details style="margin-top:6px;">
                                <summary style="cursor:pointer;"><?php echo esc_html__('View / copy the built-in default', 'authorwings-ai-tools'); ?></summary>
                                <textarea rows="4" style="width:100%;max-width:640px;margin-top:6px;background:#f6f7f7;" readonly onclick="this.select()"><?php echo esc_textarea($awg_hygiene_default); ?></textarea>
                            </details>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Block-formatting rules', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <textarea name="<?php echo esc_attr($this->opt_key); ?>[format_rules]" rows="6" style="width:100%;max-width:640px;" placeholder="<?php echo esc_attr__('Leave blank to use the built-in default shown below.', 'authorwings-ai-tools'); ?>"><?php echo esc_textarea($s['format_rules']); ?></textarea>
                            <p class="description"><?php echo esc_html__('Appended to every generation. Refines HOW a result block is formatted when the AI uses one (it never forces a block). Leave blank to use the built-in default.', 'authorwings-ai-tools'); ?></p>
                            <?php if ($awg_fmtrules_default !== ''): ?>
                            <details style="margin-top:6px;">
                                <summary style="cursor:pointer;"><?php echo esc_html__('View / copy the built-in default', 'authorwings-ai-tools'); ?></summary>
                                <textarea rows="7" style="width:100%;max-width:640px;margin-top:6px;background:#f6f7f7;" readonly onclick="this.select()"><?php echo esc_textarea($awg_fmtrules_default); ?></textarea>
                            </details>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                <?php self::section_close(); ?>

                <?php self::section_open('behavior', __('Generator Behavior', 'authorwings-ai-tools'), false, __('Guests, rate limits, caching', 'authorwings-ai-tools')); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Allow Guests', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[allow_guests]" value="1" <?php checked($s['allow_guests'], 1); ?> />
                                <?php echo esc_html__('Guests can use generators (AJAX)', 'authorwings-ai-tools'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Stream Responses (live typing)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[enable_streaming]" value="1" <?php checked($s['enable_streaming'], 1); ?> />
                                <?php echo esc_html__('Show the AI result as it is generated, word by word, instead of waiting for the whole reply.', 'authorwings-ai-tools'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('Feels much faster for visitors. Works with OpenAI, Claude and DeepSeek. If your host blocks streaming, the tool automatically falls back to the standard one-shot request — no action needed.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Global Rate Limit (per minute per IP)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="1" max="99999"
                                   name="<?php echo esc_attr($this->opt_key); ?>[global_rate_per_min]"
                                   value="<?php echo esc_attr($s['global_rate_per_min']); ?>" />
                            <p class="description"><?php echo esc_html__('Default per-minute cap. Templates may set their own limit; the tighter of the two applies.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Site-Wide Daily Cap (all visitors)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="0" max="1000000"
                                   name="<?php echo esc_attr($this->opt_key); ?>[global_daily_cap]"
                                   value="<?php echo esc_attr($s['global_daily_cap']); ?>" />
                            <p class="description"><?php echo esc_html__('Maximum total successful generations per day across every visitor combined (resets at midnight, site timezone). A backstop against distributed abuse running up your OpenAI bill. 0 = no daily cap.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Reject Gibberish Input', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[gibberish_check]" value="1" <?php checked($s['gibberish_check'], 1); ?> />
                                <?php echo esc_html__('Block text/textarea answers that look like random keyboard mashing before they reach the AI.', 'authorwings-ai-tools'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('Catches obvious nonsense like "asdfghjkl" or "aaaaaaa" so it never costs a generation. Latin-script only — other scripts (Chinese, Arabic, Cyrillic, …) are never flagged. Individual templates can override this.', 'authorwings-ai-tools'); ?></p>
                            <label style="display:inline-block;margin-top:8px;">
                                <?php echo esc_html__('Minimum length to check', 'authorwings-ai-tools'); ?>
                                <input type="number" min="0" max="50" style="width:80px;"
                                       name="<?php echo esc_attr($this->opt_key); ?>[gibberish_min_length]"
                                       value="<?php echo esc_attr($s['gibberish_min_length']); ?>" />
                            </label>
                            <p class="description"><?php echo esc_html__('Answers shorter than this are always allowed, so short legitimate values (a name, "AI", "Q3") are never blocked.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php self::section_close(); ?>

                <?php self::section_open('tracking', __('Tracking & Submissions', 'authorwings-ai-tools'), false, __('GCLID, UTM, storage, retention', 'authorwings-ai-tools')); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php echo esc_html__('Include GCLID Hidden Field', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[enable_gclid]" value="1" <?php checked($s['enable_gclid'], 1); ?> />
                                <?php echo esc_html__('Capture gclid from URL parameters and attach it to generator submissions.', 'authorwings-ai-tools'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Include UTM Hidden Fields', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[enable_utm]" value="1" <?php checked($s['enable_utm'], 1); ?> />
                                <?php echo esc_html__('Capture utm_source, utm_medium, utm_campaign, utm_term, utm_content from URL parameters and attach them to submissions.', 'authorwings-ai-tools'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('Stored only when "Store Submissions in Admin" is also enabled.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Store Submissions in Admin', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[store_submissions]" value="1" <?php checked($s['store_submissions'], 1); ?> />
                                <?php echo esc_html__('Save each successful generation as an admin-only record.', 'authorwings-ai-tools'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('This stores inputs and AI output. Use only if you need audit/history.', 'authorwings-ai-tools'); ?></p>
                            <label style="display:block;margin-top:6px;">
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[store_ip]" value="1" <?php checked($s['store_ip'], 1); ?> />
                                <?php echo esc_html__('Also store IP address (privacy sensitive).', 'authorwings-ai-tools'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Submission Retention (days)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="0" max="3650"
                                   name="<?php echo esc_attr($this->opt_key); ?>[submissions_retention_days]"
                                   value="<?php echo esc_attr($s['submissions_retention_days']); ?>" />
                            <p class="description"><?php echo esc_html__('Auto-delete submissions older than this many days. 0 = keep forever.', 'authorwings-ai-tools'); ?></p>
                            <p style="margin-top:10px;">
                                <?php
                                $delete_url = wp_nonce_url(
                                    admin_url('admin-post.php?action=awg_aig_delete_all_submissions'),
                                    'awg_aig_delete_all_submissions'
                                );
                                $sub_count = (int) wp_count_posts(Plugin::SUB_CPT)->publish;
                                ?>
                                <a href="<?php echo esc_url($delete_url); ?>"
                                   class="button button-secondary"
                                   onclick="return confirm('<?php echo esc_js(__('Permanently delete ALL stored submissions? This cannot be undone.', 'authorwings-ai-tools')); ?>');">
                                    <?php
                                    echo esc_html(sprintf(
                                        /* translators: %d: submission count */
                                        __('Delete All Submissions (%d)', 'authorwings-ai-tools'),
                                        $sub_count
                                    ));
                                    ?>
                                </a>
                            </p>
                        </td>
                    </tr>
                </table>
                <?php self::section_close(); ?>

                <?php self::section_open('cta', __('Post-Result CTA', 'authorwings-ai-tools'), false, __('Shown below every tool result', 'authorwings-ai-tools')); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row" colspan="2">
                            <p class="description" style="font-weight:400;margin:0 0 8px;">
                                <?php echo esc_html__('Shown below the result block on every generator. Individual templates can override the text or hide it on their own edit screen.', 'authorwings-ai-tools'); ?>
                            </p>
                        </th>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Enable CTA Globally', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[cta_enabled]" value="1" <?php checked($s['cta_enabled'], 1); ?> />
                                <?php echo esc_html__('Show the CTA below tool results.', 'authorwings-ai-tools'); ?>
                            </label>
                            <p class="description"><?php echo esc_html__('Off here disables it everywhere. On here means it shows on every template unless that template hides it.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('CTA Message (HTML allowed)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <textarea name="<?php echo esc_attr($this->opt_key); ?>[cta_text]" rows="4" style="width:100%;max-width:640px;"><?php echo esc_textarea($s['cta_text']); ?></textarea>
                            <p class="description">
                                <?php echo wp_kses(
                                    __('Safe HTML such as <code>&lt;a href="…"&gt;</code>, <code>&lt;strong&gt;</code>, and <code>&lt;em&gt;</code> is allowed. Example: <code>Liked the results? Check our &lt;a href="/book-cost-calculator/"&gt;Book Cost Calculator&lt;/a&gt;.</code>', 'authorwings-ai-tools'),
                                    ['code' => []]
                                ); ?>
                            </p>
                        </td>
                    </tr>
                </table>
                <?php self::section_close(); ?>

                <?php self::section_open('cookie_consent', __('Cookie Consent (GDPR)', 'authorwings-ai-tools'), false, __('EU Cookie Law / GDPR notice bar', 'authorwings-ai-tools')); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row" colspan="2">
                            <p class="description" style="font-weight:400;margin:0 0 8px;">
                                <?php echo esc_html__('A simple way to show your website complies with the EU Cookie Law / GDPR. Shows a dismissible notice bar to first-time visitors; once they accept, the choice is remembered so it never shows again.', 'authorwings-ai-tools'); ?>
                            </p>
                        </th>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Enable Cookie Notice', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[cookie_consent_enabled]" value="1" <?php checked($s['cookie_consent_enabled'], 1); ?> />
                                <?php echo esc_html__('Show the cookie consent bar to visitors.', 'authorwings-ai-tools'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Message (HTML allowed)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <textarea name="<?php echo esc_attr($this->opt_key); ?>[cookie_consent_message]" rows="3" style="width:100%;max-width:640px;"><?php echo esc_textarea($s['cookie_consent_message']); ?></textarea>
                            <p class="description"><?php echo wp_kses(__('Safe HTML such as <code>&lt;a href="…"&gt;</code> and <code>&lt;strong&gt;</code> is allowed.', 'authorwings-ai-tools'), ['code' => []]); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Accept Button Text', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="text" style="width:260px"
                                   name="<?php echo esc_attr($this->opt_key); ?>[cookie_consent_button_text]"
                                   value="<?php echo esc_attr($s['cookie_consent_button_text']); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Reject Button', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label style="display:inline-flex;align-items:center;gap:8px;margin-bottom:8px;">
                                <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[cookie_consent_show_reject]" value="1" <?php checked($s['cookie_consent_show_reject'], 1); ?> />
                                <?php echo esc_html__('Show a "Reject" button next to Accept.', 'authorwings-ai-tools'); ?>
                            </label>
                            <br />
                            <input type="text" style="width:260px"
                                   name="<?php echo esc_attr($this->opt_key); ?>[cookie_consent_reject_text]"
                                   value="<?php echo esc_attr($s['cookie_consent_reject_text']); ?>" />
                            <p class="description" style="max-width:640px;">
                                <?php echo esc_html__('Required whenever the notice asks for consent to non-essential (analytics / advertising) cookies: refusing must be as easy as accepting. The visitor\'s choice is saved and broadcast so your tag manager / analytics can honour it (a JavaScript "awg-cookie-consent" event, a dataLayer push, and the awg_cookie_consent cookie set to "accept" or "reject"). Note: this plugin sets no tracking cookies itself, so blocking your analytics/ad scripts on "reject" must be wired where those scripts load (e.g. Google Tag Manager Consent Mode).', 'authorwings-ai-tools'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('"Learn more" Link', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="text" style="width:260px;margin-right:8px"
                                   placeholder="<?php echo esc_attr__('Learn more', 'authorwings-ai-tools'); ?>"
                                   name="<?php echo esc_attr($this->opt_key); ?>[cookie_consent_learn_text]"
                                   value="<?php echo esc_attr($s['cookie_consent_learn_text']); ?>" />
                            <input type="url" style="width:340px"
                                   placeholder="https://example.com/privacy-policy/"
                                   name="<?php echo esc_attr($this->opt_key); ?>[cookie_consent_learn_url]"
                                   value="<?php echo esc_attr($s['cookie_consent_learn_url']); ?>" />
                            <p class="description"><?php echo esc_html__('Optional. Link to your privacy / cookie policy. Leave the URL blank to hide the link.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Position', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <select name="<?php echo esc_attr($this->opt_key); ?>[cookie_consent_position]">
                                <option value="bottom" <?php selected($s['cookie_consent_position'], 'bottom'); ?>><?php echo esc_html__('Bottom of the screen', 'authorwings-ai-tools'); ?></option>
                                <option value="top" <?php selected($s['cookie_consent_position'], 'top'); ?>><?php echo esc_html__('Top of the screen', 'authorwings-ai-tools'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <?php
                    $cc_defaults = $this->defaults();
                    $cc_colors = [
                        'cookie_consent_bg_color'          => __('Bar Background', 'authorwings-ai-tools'),
                        'cookie_consent_text_color'        => __('Bar Text', 'authorwings-ai-tools'),
                        'cookie_consent_button_bg'         => __('Button Background', 'authorwings-ai-tools'),
                        'cookie_consent_button_text_color' => __('Button Text', 'authorwings-ai-tools'),
                    ];
                    foreach ($cc_colors as $cc_key => $cc_label):
                        $cc_hex = '#' . ltrim($s[$cc_key], '#');
                        $cc_default = '#' . ltrim($cc_defaults[$cc_key] ?? $s[$cc_key], '#');
                    ?>
                    <tr>
                        <th scope="row"><?php echo esc_html($cc_label); ?></th>
                        <td>
                            <input type="text" class="awg-color-picker"
                                   name="<?php echo esc_attr($this->opt_key); ?>[<?php echo esc_attr($cc_key); ?>]"
                                   value="<?php echo esc_attr($cc_hex); ?>"
                                   data-default-color="<?php echo esc_attr($cc_default); ?>" />
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
                <?php self::section_close(); ?>

                <?php self::section_open('hub_layout', __('AI Tools hub', 'authorwings-ai-tools'), false, __('How tool and category cards look on the [awg_tools] hub', 'authorwings-ai-tools')); ?>
                <table class="form-table" role="presentation"><tbody>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Tool cards', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <select name="<?php echo esc_attr($this->opt_key); ?>[hub_card_layout]">
                                <option value="square" <?php selected($s['hub_card_layout'], 'square'); ?>><?php echo esc_html__('Square thumbnail — compact, icon-sized image', 'authorwings-ai-tools'); ?></option>
                                <option value="banner" <?php selected($s['hub_card_layout'], 'banner'); ?>><?php echo esc_html__('Top banner — image across the top of the card', 'authorwings-ai-tools'); ?></option>
                                <option value="cover" <?php selected($s['hub_card_layout'], 'cover'); ?>><?php echo esc_html__('Full image + title overlay — image fills the card', 'authorwings-ai-tools'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('How tool cards look. Tools use their Featured Image; without one they fall back to the icon + accent style. (Locked tool cards always stay compact so the upgrade prompt is readable.)', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Category cards', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <select name="<?php echo esc_attr($this->opt_key); ?>[hub_cat_layout]">
                                <option value="square" <?php selected($s['hub_cat_layout'], 'square'); ?>><?php echo esc_html__('Square thumbnail — compact, icon-sized image', 'authorwings-ai-tools'); ?></option>
                                <option value="banner" <?php selected($s['hub_cat_layout'], 'banner'); ?>><?php echo esc_html__('Top banner — image across the top of the card', 'authorwings-ai-tools'); ?></option>
                                <option value="cover" <?php selected($s['hub_cat_layout'], 'cover'); ?>><?php echo esc_html__('Full image + title overlay — image fills the card', 'authorwings-ai-tools'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('How category cards look. Categories use their Card image; without one they fall back to the icon + accent style.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                </tbody></table>
                <?php self::section_close(); ?>

                <?php self::section_open('form_design', __('Header & Branding', 'authorwings-ai-tools'), false, __('Header layout, icon badge, title font, eyebrow, and branded colors', 'authorwings-ai-tools')); ?>
                <table class="form-table" role="presentation"><tbody>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Header design', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <select name="<?php echo esc_attr($this->opt_key); ?>[form_design]">
                                <option value="branded" <?php selected($s['form_design'], 'branded'); ?>><?php echo esc_html__('Branded — icon badge, title, subtitle (recommended)', 'authorwings-ai-tools'); ?></option>
                                <option value="plain" <?php selected($s['form_design'], 'plain'); ?>><?php echo esc_html__('Plain — simple title + description', 'authorwings-ai-tools'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Branded applies a coordinated header and warm palette to every tool. Individual templates can override this below their title fields.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Icon position', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <select name="<?php echo esc_attr($this->opt_key); ?>[header_icon_position]">
                                <option value="top" <?php selected($s['header_icon_position'], 'top'); ?>><?php echo esc_html__('Top — centered, above the title', 'authorwings-ai-tools'); ?></option>
                                <option value="left" <?php selected($s['header_icon_position'], 'left'); ?>><?php echo esc_html__('Left — before the title', 'authorwings-ai-tools'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Title font', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <select name="<?php echo esc_attr($this->opt_key); ?>[title_font]">
                                <option value="serif" <?php selected($s['title_font'], 'serif'); ?>><?php echo esc_html__('Serif (elegant)', 'authorwings-ai-tools'); ?></option>
                                <option value="sans" <?php selected($s['title_font'], 'sans'); ?>><?php echo esc_html__('Sans (modern)', 'authorwings-ai-tools'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Eyebrow label', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="text" class="regular-text" name="<?php echo esc_attr($this->opt_key); ?>[brand_eyebrow]" value="<?php echo esc_attr($s['brand_eyebrow']); ?>" placeholder="AuthorWings">
                            <p class="description"><?php echo esc_html__('Small uppercase label shown above the title. Leave blank to hide it.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Extras', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[header_show_rule]" value="1" <?php checked((int) $s['header_show_rule'], 1); ?>> <?php echo esc_html__('Show accent rule under the title (top layout)', 'authorwings-ai-tools'); ?></label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[header_subtitle_italic]" value="1" <?php checked((int) $s['header_subtitle_italic'], 1); ?>> <?php echo esc_html__('Render the description as an italic subtitle', 'authorwings-ai-tools'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row" colspan="2" style="padding-bottom:0;"><h3 style="margin:0;"><?php echo esc_html__('Branded header colors', 'authorwings-ai-tools'); ?></h3>
                            <p class="description" style="font-weight:400;"><?php echo esc_html__('Colors for the branded header elements. Each template can override these below its title fields.', 'authorwings-ai-tools'); ?></p>
                        </th>
                    </tr>
                    <?php
                    $this->color_row('brand_title_color',      __('Header title', 'authorwings-ai-tools'),        $s['brand_title_color']);
                    $this->color_row('brand_subtitle_color',   __('Header subtitle', 'authorwings-ai-tools'),     $s['brand_subtitle_color']);
                    $this->color_row('brand_eyebrow_color',    __('Eyebrow label', 'authorwings-ai-tools'),       $s['brand_eyebrow_color']);
                    $this->color_row('brand_badge_bg_color',   __('Icon badge background', 'authorwings-ai-tools'), $s['brand_badge_bg_color']);
                    $this->color_row('brand_badge_icon_color', __('Icon badge glyph', 'authorwings-ai-tools'),    $s['brand_badge_icon_color']);
                    $this->color_row('brand_rule_color',       __('Accent rule', 'authorwings-ai-tools'),         $s['brand_rule_color']);
                    ?>
                </tbody></table>
                <?php self::section_close(); ?>

                <?php self::section_open('colors', __('Style & Appearance', 'authorwings-ai-tools'), false, __('Colors, spacing, button styling, and field sizes', 'authorwings-ai-tools')); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row" colspan="2">
                            <p class="description" style="font-weight:400;margin:0 0 8px;">
                                <?php echo esc_html__('Pick any color for any part of the generator. Defaults match the AuthorWings.com brand palette.', 'authorwings-ai-tools'); ?>
                            </p>
                            <p>
                                <label style="background:#f6f7f7;border:1px solid #c3c4c7;border-radius:4px;padding:4px 8px;display:inline-flex;align-items:center;gap:6px;cursor:pointer;">
                                    <input type="checkbox" name="<?php echo esc_attr($this->opt_key); ?>[_awg_reset_palette]" value="1">
                                    <?php echo esc_html__('Reset all colors back to AuthorWings defaults on save', 'authorwings-ai-tools'); ?>
                                </label>
                            </p>
                        </th>
                    </tr>

                    <tr><th colspan="2"><h3 style="margin:8px 0 0;"><?php echo esc_html__('Container & Text', 'authorwings-ai-tools'); ?></h3></th></tr>
                    <?php
                    $this->color_row('global_style_bg_color',     __('Background', 'authorwings-ai-tools'),           $s['global_style_bg_color']);
                    $this->color_row('global_style_text_color',   __('Text / Headings', 'authorwings-ai-tools'),      $s['global_style_text_color']);
                    $this->color_row('global_style_border_color', __('Border', 'authorwings-ai-tools'),               $s['global_style_border_color']);
                    $this->color_row('global_style_accent_color', __('Accent (icons, links)', 'authorwings-ai-tools'), $s['global_style_accent_color']);
                    $this->color_row('global_style_input_bg_color',    __('Input Background', 'authorwings-ai-tools'),       $s['global_style_input_bg_color']);
                    $this->color_row('global_style_placeholder_color', __('Placeholder Text', 'authorwings-ai-tools'),       $s['global_style_placeholder_color']);
                    $this->color_row('global_style_required_color',    __('Required / Error Indicator', 'authorwings-ai-tools'), $s['global_style_required_color']);
                    ?>

                    <tr>
                        <th scope="row"><?php echo esc_html__('Container Spacing', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <fieldset style="margin:0 0 10px;">
                                <legend style="font-weight:600;margin-bottom:4px;"><?php echo esc_html__('Padding', 'authorwings-ai-tools'); ?></legend>
                                <label style="display:inline-block;margin:0 14px 4px 0;"><?php echo esc_html__('Top', 'authorwings-ai-tools'); ?> <input type="number" style="width:64px;" min="0" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_padding_top]" value="<?php echo esc_attr($s['global_style_padding_top']); ?>" /></label>
                                <label style="display:inline-block;margin:0 14px 4px 0;"><?php echo esc_html__('Right', 'authorwings-ai-tools'); ?> <input type="number" style="width:64px;" min="0" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_padding_right]" value="<?php echo esc_attr($s['global_style_padding_right']); ?>" /></label>
                                <label style="display:inline-block;margin:0 14px 4px 0;"><?php echo esc_html__('Bottom', 'authorwings-ai-tools'); ?> <input type="number" style="width:64px;" min="0" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_padding_bottom]" value="<?php echo esc_attr($s['global_style_padding_bottom']); ?>" /></label>
                                <label style="display:inline-block;margin:0 14px 4px 0;"><?php echo esc_html__('Left', 'authorwings-ai-tools'); ?> <input type="number" style="width:64px;" min="0" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_padding_left]" value="<?php echo esc_attr($s['global_style_padding_left']); ?>" /></label>
                            </fieldset>
                            <fieldset style="margin:0 0 10px;">
                                <legend style="font-weight:600;margin-bottom:4px;"><?php echo esc_html__('Margin', 'authorwings-ai-tools'); ?></legend>
                                <label style="display:inline-block;margin:0 14px 4px 0;"><?php echo esc_html__('Top', 'authorwings-ai-tools'); ?> <input type="number" style="width:64px;" min="0" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_margin_top]" value="<?php echo esc_attr($s['global_style_margin_top']); ?>" /></label>
                                <label style="display:inline-block;margin:0 14px 4px 0;"><?php echo esc_html__('Right', 'authorwings-ai-tools'); ?> <input type="number" style="width:64px;" min="0" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_margin_right]" value="<?php echo esc_attr($s['global_style_margin_right']); ?>" /></label>
                                <label style="display:inline-block;margin:0 14px 4px 0;"><?php echo esc_html__('Bottom', 'authorwings-ai-tools'); ?> <input type="number" style="width:64px;" min="0" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_margin_bottom]" value="<?php echo esc_attr($s['global_style_margin_bottom']); ?>" /></label>
                                <label style="display:inline-block;margin:0 14px 4px 0;"><?php echo esc_html__('Left', 'authorwings-ai-tools'); ?> <input type="number" style="width:64px;" min="0" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_margin_left]" value="<?php echo esc_attr($s['global_style_margin_left']); ?>" /></label>
                            </fieldset>
                            <label><?php echo esc_html__('Radius', 'authorwings-ai-tools'); ?> <input type="number" min="0" max="40" name="<?php echo esc_attr($this->opt_key); ?>[global_style_radius]" value="<?php echo esc_attr($s['global_style_radius']); ?>" /></label>
                        </td>
                    </tr>

                    <tr><th colspan="2"><h3 style="margin:8px 0 0;"><?php echo esc_html__('Primary Generate Button', 'authorwings-ai-tools'); ?></h3></th></tr>
                    <?php
                    $this->color_row('global_style_button_bg_color',          __('Background', 'authorwings-ai-tools'),          $s['global_style_button_bg_color']);
                    $this->color_row('global_style_button_text_color',        __('Text', 'authorwings-ai-tools'),                $s['global_style_button_text_color']);
                    $this->color_row('global_style_button_border_color',      __('Border', 'authorwings-ai-tools'),              $s['global_style_button_border_color']);
                    $this->color_row('global_style_button_hover_bg_color',    __('Hover / Focus Background', 'authorwings-ai-tools'), $s['global_style_button_hover_bg_color']);
                    $this->color_row('global_style_button_hover_text_color',  __('Hover / Focus Text', 'authorwings-ai-tools'),  $s['global_style_button_hover_text_color']);
                    $this->color_row('global_style_button_active_bg_color',   __('Active (pressed) Background', 'authorwings-ai-tools'), $s['global_style_button_active_bg_color']);
                    $this->color_row('global_style_focus_ring_color',         __('Focus Ring (outline glow)', 'authorwings-ai-tools'),   $s['global_style_focus_ring_color']);
                    ?>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Button Spacing', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <label><?php echo esc_html__('Padding Y', 'authorwings-ai-tools'); ?> <input type="number" min="6" max="30" name="<?php echo esc_attr($this->opt_key); ?>[global_style_button_padding_y]" value="<?php echo esc_attr($s['global_style_button_padding_y']); ?>" /></label>
                            <label style="margin-left:14px;"><?php echo esc_html__('Padding X', 'authorwings-ai-tools'); ?> <input type="number" min="8" max="40" name="<?php echo esc_attr($this->opt_key); ?>[global_style_button_padding_x]" value="<?php echo esc_attr($s['global_style_button_padding_x']); ?>" /></label>
                            <label style="margin-left:14px;"><?php echo esc_html__('Radius', 'authorwings-ai-tools'); ?> <input type="number" min="0" max="20" name="<?php echo esc_attr($this->opt_key); ?>[global_style_button_radius]" value="<?php echo esc_attr($s['global_style_button_radius']); ?>" /></label>
                        </td>
                    </tr>

                    <tr><th colspan="2"><h3 style="margin:8px 0 0;"><?php echo esc_html__('Action Buttons (Copy / Download / Clear / Regenerate)', 'authorwings-ai-tools'); ?></h3></th></tr>
                    <?php
                    $this->color_row('global_style_action_btn_bg_color',          __('Background', 'authorwings-ai-tools'),         $s['global_style_action_btn_bg_color']);
                    $this->color_row('global_style_action_btn_text_color',        __('Text', 'authorwings-ai-tools'),               $s['global_style_action_btn_text_color']);
                    $this->color_row('global_style_action_btn_border_color',      __('Border', 'authorwings-ai-tools'),             $s['global_style_action_btn_border_color']);
                    $this->color_row('global_style_action_btn_hover_bg_color',    __('Hover Background', 'authorwings-ai-tools'),   $s['global_style_action_btn_hover_bg_color']);
                    $this->color_row('global_style_action_btn_hover_text_color',  __('Hover Text', 'authorwings-ai-tools'),         $s['global_style_action_btn_hover_text_color']);
                    ?>

                    <tr><th colspan="2"><h3 style="margin:8px 0 0;"><?php echo esc_html__('Result Output Area', 'authorwings-ai-tools'); ?></h3></th></tr>
                    <?php
                    $this->color_row('global_style_output_bg_color',           __('Output Background', 'authorwings-ai-tools'),         $s['global_style_output_bg_color']);
                    $this->color_row('global_style_output_gradient_top_color', __('Output Gradient Top', 'authorwings-ai-tools'),       $s['global_style_output_gradient_top_color']);
                    $this->color_row('global_style_output_gradient_bot_color', __('Output Gradient Bottom', 'authorwings-ai-tools'),    $s['global_style_output_gradient_bot_color']);
                    $this->color_row('global_style_code_bg_color',             __('Code Block Background', 'authorwings-ai-tools'),     $s['global_style_code_bg_color']);
                    $this->color_row('global_style_badge_bg_color',            __('Result Badge Background', 'authorwings-ai-tools'),   $s['global_style_badge_bg_color']);
                    $this->color_row('global_style_badge_text_color',          __('Result Badge Text', 'authorwings-ai-tools'),         $s['global_style_badge_text_color']);
                    $this->color_row('global_style_shadow_color',              __('Shadow Tint', 'authorwings-ai-tools'),                $s['global_style_shadow_color'], __('Used for the subtle drop shadow under output cards.', 'authorwings-ai-tools'));
                    ?>

                    <tr><th colspan="2"><h3 style="margin:8px 0 0;"><?php echo esc_html__('Field Sizes', 'authorwings-ai-tools'); ?></h3>
                        <p class="description" style="font-weight:400;"><?php echo esc_html__('Defaults for every template; each template can override these.', 'authorwings-ai-tools'); ?></p>
                    </th></tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Default Input Height (px)', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="32" max="80" name="<?php echo esc_attr($this->opt_key); ?>[global_style_input_height]" value="<?php echo esc_attr($s['global_style_input_height']); ?>" />
                            <p class="description"><?php echo esc_html__('Used by all templates when “Use global field sizes” is enabled.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php echo esc_html__('Default Textarea Rows', 'authorwings-ai-tools'); ?></th>
                        <td>
                            <input type="number" min="2" max="20" name="<?php echo esc_attr($this->opt_key); ?>[global_style_textarea_rows]" value="<?php echo esc_attr($s['global_style_textarea_rows']); ?>" />
                            <p class="description"><?php echo esc_html__('Templates can still override these values individually.', 'authorwings-ai-tools'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php self::section_close(); ?>

                <?php submit_button(__('Save Settings', 'authorwings-ai-tools')); ?>
            </form>

            <hr>
            <h2><?php echo esc_html__('Usage', 'authorwings-ai-tools'); ?></h2>
            <ul>
                <li><?php echo esc_html__('Create template: AuthorWings AI Templates → Add New', 'authorwings-ai-tools'); ?></li>
                <li><?php echo esc_html__('Shortcode:', 'authorwings-ai-tools'); ?> <code>[awg_generator id="123"]</code></li>
                <li><?php echo esc_html__('Gutenberg: Add block “AuthorWings AI” and select template', 'authorwings-ai-tools'); ?></li>
            </ul>
            <p class="description"><?php echo esc_html__('Owner: AuthorWings (authorwings.com)', 'authorwings-ai-tools'); ?></p>

            <?php endif; // end AI-tab branch ?>
        </div>
        <?php
    }

}
