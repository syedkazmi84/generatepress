(function(){
  "use strict";

  var NL  = String.fromCharCode(10),  CR  = String.fromCharCode(13),
      TAB = String.fromCharCode(9),    FF  = String.fromCharCode(12),
      VT  = String.fromCharCode(11),   NBSP = String.fromCharCode(160),
      ZW  = String.fromCharCode(0x200b,0x200c,0x200d,0xfeff),
      WS  = " " + TAB + NL + CR + FF + VT;

  var reZeroWidthG = new RegExp("[" + ZW + "]", "g"),
      reZeroWidth  = new RegExp("[" + ZW + "]"),
      reNbspG      = new RegExp(NBSP, "g"),
      reWSG        = new RegExp("[" + WS + "]+", "g"),
      reCRLF       = new RegExp(CR + NL + "?", "g"),
      reMultiNL    = new RegExp(NL + "{3,}", "g"),
      reSplitPara  = new RegExp(NL + NL + "+");

  var BULLETS = String.fromCharCode(0x2022,0x2023,0x25cf,0x25aa,0x25e6,0x2043,0xb7,0x2013,0x2014) + "*",
      reBullet = new RegExp("^([" + WS + "]*)([" + BULLETS + "-])[" + WS + "]+"),
      reNumber = new RegExp("^([" + WS + "]*)([0-9]+)[.)][" + WS + "]+");

  function clean(s){ return String(s).replace(reZeroWidthG,"").replace(reNbspG," "); }
  function esc(s){ return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
  function onlyWS(s){ return clean(s).replace(reWSG,"") === ""; }
  function toArr(nl){ var a=[]; for(var i=0;i<nl.length;i++) a.push(nl[i]); return a; }

  var PLATFORMS = {
    amazon:           { label:"Amazon",                  allowed:["b","i","u","p","br","ul","ol","li","h4","h5","h6"], limit:4000 },
    amazon_editorial: { label:"Amazon Editorial Review", allowed:["b","i","p","br","ul","ol","li"],                                    limit:4000 },
    bn:               { label:"Barnes & Noble",          allowed:["b","i","p","br","ul","li"],                                         limit:5000 },
    kobo:             { label:"Kobo",                    allowed:["b","i","p","br"],                                                   limit:5000 }
  };

  /* Brand marks recreated as lightweight inline SVG using each retailer's own colours
     (Amazon smile, orange review stars, B&N green + orange ampersand, Rakuten Kobo red).
     Built backslash-free. */
  var STARS = String.fromCharCode(0x2605,0x2605,0x2605,0x2605,0x2605);
  var BADGES = {
    amazon:           { bg:"#FFFFFF", svg:'<svg viewBox="0 0 40 36"><text x="20" y="23" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="24" fill="#232F3E">a</text><path d="M7 28 C 16 34, 24 34, 33 28" fill="none" stroke="#FF9900" stroke-width="3" stroke-linecap="round"></path><path d="M33 28 l 0 -4 l -4 1.4 z" fill="#FF9900"></path></svg>' },
    amazon_editorial: { bg:"#FFFFFF", svg:'<svg viewBox="0 0 84 30"><text x="42" y="13" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="700" font-size="11" fill="#232F3E">amazon</text><text x="42" y="26" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="13" fill="#FF9900" letter-spacing="1">' + STARS + '</text></svg>' },
    bn:               { bg:"#FFFFFF", svg:'<svg viewBox="0 0 64 30"><text x="32" y="23" text-anchor="middle" font-family="Georgia,serif" font-weight="700" font-size="23"><tspan fill="#1A4D2E">B</tspan><tspan fill="#D2861B">&amp;</tspan><tspan fill="#1A4D2E">N</tspan></text></svg>' },
    kobo:             { bg:"#E2231A", svg:'<svg viewBox="0 0 56 22"><text x="28" y="17" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-weight="800" font-size="17" fill="#FFFFFF" letter-spacing="-0.5">kobo</text></svg>' }
  };

  var SKINS = {
    amazon:           { skin:"amazon",           label:"",                 sub:"", more:"Read more", chrome:true,  stars:"#DE7921", count:"4.6 (1,204)", titleSize:"24px", byline:'<span style="color:#565959">by </span><span style="color:#007185">Author Name</span> <span style="color:#565959">(Author)</span> &nbsp;<span style="color:#565959">Format:</span> Kindle Edition' },
    amazon_editorial: { skin:"amazon_editorial", label:"Editorial Reviews", sub:"Review", more:"", chrome:false, stars:"#DE7921", count:"", titleSize:"", byline:"" },
    bn:               { skin:"bn",               label:"Overview",          sub:"", more:"Read More", chrome:true, stars:"#e5a823", count:"4.6 | 312 reviews", titleSize:"22px", byline:'by <span style="color:#006341">Author Name</span>' },
    kobo:             { skin:"kobo",             label:"Synopsis",          sub:"", more:"Show more", chrome:true, stars:"#caa53d", count:"4.6", titleSize:"21px", byline:'<span style="color:#555">by Author Name</span>' }
  };

  var ALIAS  = { strong:"b", em:"i" },
      INLINE = { b:1, i:1, u:1 },
      KEEP   = { b:1,i:1,u:1,p:1,h4:1,h5:1,h6:1,ul:1,ol:1,li:1 };

  function mapChildren(el, set){
    var out=[], ch=el.childNodes;
    for(var i=0;i<ch.length;i++){ var r=sanitize(ch[i],set); for(var j=0;j<r.length;j++) out.push(r[j]); }
    return out;
  }
  function sanitize(node, set){
    if(node.nodeType===3){ var v=clean(node.nodeValue); return v?[document.createTextNode(v)]:[]; }
    if(node.nodeType!==1) return [];
    var tag = node.tagName.toLowerCase();
    if(ALIAS[tag]) tag = ALIAS[tag];
    if(tag==="span" || tag==="font"){
      var kids = mapChildren(node,set); if(!kids.length) return [];
      var st=node.style||{}, fw=(st.fontWeight||"")+"", fs=(st.fontStyle||"")+"",
          td=(st.textDecoration||"")+" "+(st.textDecorationLine||""), wrap=[];
      if(/(bold|[6-9]00)/.test(fw) && set.has("b")) wrap.push("b");
      if(fs==="italic" && set.has("i")) wrap.push("i");
      if(td.indexOf("underline")>=0 && set.has("u")) wrap.push("u");
      var s=kids;
      for(var w=0;w<wrap.length;w++){ var c=document.createElement(wrap[w]); for(var k=0;k<s.length;k++) c.appendChild(s[k]); s=[c]; }
      return s;
    }
    if(tag==="script"||tag==="style"||tag==="img"||tag==="svg") return [];
    if(tag==="a"||tag==="table"||tag==="thead"||tag==="tbody"||tag==="tr"||tag==="td"||tag==="th"||tag==="tfoot") return mapChildren(node,set);
    if(/^h[1-6]$/.test(tag) && !set.has(tag)) tag = "p";
    if(tag==="div"||tag==="section"||tag==="article"||tag==="blockquote"||tag==="pre"){
      if(node.querySelector && node.querySelector("p,div,ul,ol,li,h1,h2,h3,h4,h5,h6,hr,section,article,blockquote,pre,table"))
        return mapChildren(node,set);
      tag = "p";
    }
    if(tag==="ol" && !set.has("ol")) tag = set.has("ul") ? "ul" : null;
    if(tag==="ul" && !set.has("ul")) tag = null;
    if(tag==="li" && !set.has("ul") && !set.has("ol")) tag = "p";
    if(tag==="br") return set.has("br") ? [document.createElement("br")] : [];
    if(tag==="hr") return set.has("hr") ? [document.createElement("hr")] : [];
    if(INLINE[tag] && !set.has(tag)) return mapChildren(node,set);
    if(tag===null || !KEEP[tag]) return mapChildren(node,set);
    var out=document.createElement(tag), s=mapChildren(node,set);
    for(var m=0;m<s.length;m++) out.appendChild(s[m]);
    var hasBr = out.querySelector && out.querySelector("br");
    var empty = tag!=="br" && !hasBr && (!out.children||!out.children.length) && onlyWS(out.textContent);
    return empty ? [] : [out];
  }

  function firstText(nodes){
    for(var i=0;i<nodes.length;i++){ var n=nodes[i];
      if(n.nodeType===3 && n.nodeValue.trim()!=="") return n;
      if(n.nodeType===1){ var r=firstText(toArr(n.childNodes)); if(r) return r; }
    }
    return null;
  }
  function liItems(el){
    var out=[], ch=el.children;
    for(var i=0;i<ch.length;i++) if(ch[i].tagName && ch[i].tagName.toLowerCase()==="li") out.push(toArr(ch[i].childNodes));
    return out;
  }
  function groupBlocks(nodes){
    var out=[], acc=null;
    function flush(){
      if(!acc) return;
      var has=false;
      for(var i=0;i<acc.length;i++){ var a=acc[i];
        if(a.nodeType===3 && clean(a.nodeValue).trim()!==""){ has=true; break; }
        if(a.nodeType===1){ if(a.tagName.toLowerCase()==="br") continue; if(a.textContent.trim()!==""){ has=true; break; } }
      }
      if(has) out.push({type:"p", nodes:acc});
      acc=null;
    }
    for(var i=0;i<nodes.length;i++){ var n=nodes[i];
      if(n.nodeType===1){ var t=n.tagName.toLowerCase();
        if(t==="p"){
          flush();
          if(n.querySelector && n.querySelector("ul,ol,li,h1,h2,h3,h4,h5,h6,hr,p")){
            var inner=groupBlocks(toArr(n.childNodes));
            for(var q=0;q<inner.length;q++) out.push(inner[q]);
          } else {
            out.push({type:"p", nodes:toArr(n.childNodes)});
          }
        }
        else if(/^h[1-6]$/.test(t)){ flush(); out.push({type:t, nodes:toArr(n.childNodes)}); }
        else if(t==="ul"||t==="ol"){ flush(); out.push({type:t, items:liItems(n)}); }
        else if(t==="hr"){ flush(); out.push({type:"hr"}); }
        else if(t==="br"){ flush(); }
        else { acc||(acc=[]); acc.push(n); }
      } else if(n.nodeType===3){ acc||(acc=[]); acc.push(n); }
    }
    flush();
    return out;
  }

  function isMarker(line){ return reBullet.test(line) || reNumber.test(line); }
  function textToNodes(text){
    text = clean(text).replace(reCRLF, NL).replace(reMultiNL, NL+NL);
    var nodes=[];
    text.split(reSplitPara).forEach(function(block){
      if(onlyWS(block)) return;
      var lines = block.split(NL);
      var nonEmpty = lines.filter(function(l){ return l.trim()!==""; });
      var markers  = nonEmpty.filter(isMarker);
      if(markers.length>=2 && markers.length*2>=nonEmpty.length){
        nonEmpty.forEach(function(l){ var p=document.createElement("p"); p.appendChild(document.createTextNode(l)); nodes.push(p); });
      } else {
        var p=document.createElement("p");
        lines.forEach(function(l,k){ if(k) p.appendChild(document.createElement("br")); p.appendChild(document.createTextNode(l)); });
        nodes.push(p);
      }
    });
    return nodes;
  }

  function detectList(nodes){
    var ft=firstText(nodes); if(!ft) return null;
    var kind=null;
    if(reNumber.test(ft.nodeValue)) kind="ol";
    else if(reBullet.test(ft.nodeValue)) kind="ul";
    if(!kind) return null;
    var clone=[]; for(var i=0;i<nodes.length;i++) clone.push(nodes[i].cloneNode(true));
    var first=firstText(clone);
    if(first) first.nodeValue = first.nodeValue.replace(kind==="ol"?reNumber:reBullet, "");
    return { kind:kind, nodes:clone };
  }
  function mergeLists(blocks, set){
    if(!set.has("ul") && !set.has("ol")) return blocks;
    var out=[], i=0;
    while(i<blocks.length){ var b=blocks[i];
      if(b.type==="p"){ var d=detectList(b.nodes);
        if(d && set.has(d.kind)){
          var items=[d.nodes], j=i+1;
          while(j<blocks.length && blocks[j].type==="p"){
            var d2=detectList(blocks[j].nodes);
            if(!d2 || d2.kind!==d.kind) break;
            items.push(d2.nodes); j++;
          }
          out.push({type:d.kind, items:items}); i=j; continue;
        }
      }
      out.push(b); i++;
    }
    return out;
  }

  function serializeInline(nodes){
    var s="";
    for(var i=0;i<nodes.length;i++){ var n=nodes[i];
      if(n.nodeType===3) s += esc(clean(n.nodeValue));
      else if(n.nodeType===1){ var t=n.tagName.toLowerCase();
        s += t==="br" ? "<br>" : (INLINE[t] ? "<"+t+">"+serializeInline(toArr(n.childNodes))+"</"+t+">" : serializeInline(toArr(n.childNodes)));
      }
    }
    return s;
  }
  function buildHTML(blocks, mode){
    var out=[], acc=[];
    function flush(){ if(acc.length){ out.push(acc.join("<br>"+NL)); acc=[]; } }
    for(var i=0;i<blocks.length;i++){ var b=blocks[i];
      if(b.type==="p"){ var s=serializeInline(b.nodes).trim(); if(!s) continue; mode==="compact"?acc.push(s):out.push("<p>"+s+"</p>"); }
      else if(/^h[1-6]$/.test(b.type)){ if(mode==="compact") flush(); var s=serializeInline(b.nodes).trim(); if(s) out.push("<"+b.type+">"+s+"</"+b.type+">"); }
      else if(b.type==="hr"){ if(mode==="compact") flush(); out.push("<hr>"); }
      else if(b.type==="ul"||b.type==="ol"){
        if(mode==="compact") flush();
        var li=[]; for(var k=0;k<b.items.length;k++){ var s=serializeInline(b.items[k]).trim(); if(s) li.push("<li>"+s+"</li>"); }
        if(!li.length) continue;
        out.push("<"+b.type+">"); for(var z=0;z<li.length;z++) out.push(li[z]); out.push("</"+b.type+">");
      }
    }
    if(mode==="compact") flush();
    return out.join(NL);
  }

  var $ = function(id){ return document.getElementById(id); };
  var editor=$("bdf-editor"), preview=$("bdf-preview"), output=$("bdf-output"),
      counter=$("bdf-counter"), note=$("bdf-note");
  var platformKey="amazon", spacing="standard";
  function allowedSet(){ return new Set(PLATFORMS[platformKey].allowed); }

  var canExec = typeof document.execCommand==="function";
  try{ document.execCommand("styleWithCSS",false,false); }catch(e){}
  try{ document.execCommand("defaultParagraphSeparator",false,"p"); }catch(e){}

  (function(){
    var host=$("bdf-platforms");
    Object.keys(PLATFORMS).forEach(function(key){
      var b=document.createElement("button");
      b.type="button"; b.dataset.platform=key;
      var bd=BADGES[key];
      if(bd){
        var pill=document.createElement("span");
        pill.className="bdf-pill";
        pill.style.background=bd.bg;
        pill.innerHTML=bd.svg;
        pill.setAttribute("aria-hidden","true");
        b.appendChild(pill);
      }
      var lab=document.createElement("span");
      lab.textContent=PLATFORMS[key].label;
      b.appendChild(lab);
      b.setAttribute("aria-pressed", key===platformKey?"true":"false");
      b.addEventListener("click",function(){
        platformKey=key;
        var kids=host.children;
        for(var i=0;i<kids.length;i++) kids[i].setAttribute("aria-pressed", kids[i].dataset.platform===key?"true":"false");
        syncToolbar(); render();
      });
      host.appendChild(b);
    });
  })();

  var spacingBtn;
  var TOOLS=[
    { group:"text", label:"<b>B</b>", aria:"Bold",      needs:"b", act:function(){ inlineWrap("b"); } },
    { group:"text", label:"<i>I</i>", aria:"Italic",    needs:"i", act:function(){ inlineWrap("i"); } },
    { group:"text", label:"<u>U</u>", aria:"Underline", needs:"u", act:function(){ inlineWrap("u"); } },
    { group:"size", label:"H4", aria:"Heading (largest)", needs:"h4", title:"Heading - H4 is the largest. Headings only render on Amazon; other retailers show them as normal text.", act:function(){ blockFormat("h4"); } },
    { group:"size", label:"H5", aria:"Heading (medium)", needs:"h5", title:"Heading (medium). Amazon only.", act:function(){ blockFormat("h5"); } },
    { group:"size", label:"H6", aria:"Heading (smallest)", needs:"h6", title:"Heading - H6 is the smallest, about body-text size. Amazon only.", act:function(){ blockFormat("h6"); } },
    { group:"size", label:"Normal", aria:"Normal text (reset size)", needs:null, act:function(){ blockFormat("p"); } },
    { group:"list", label:String.fromCharCode(0x2022)+" List", aria:"Bullet list", needs:"ul", act:function(){ listFormat("ul"); } },
    { group:"list", label:"1. List", aria:"Numbered list", needs:"ol", act:function(){ listFormat("ol"); } },
    { group:"misc", label:"Clear", aria:"Clear formatting (strip to plain text)", needs:null, act:function(){ loadText(editor.innerText||editor.textContent||""); } },
    { group:"misc", label:"Undo", aria:"Undo", needs:null, id:"bdf-undo", act:function(){ undo(); } },
    { group:"misc", label:"Redo", aria:"Redo", needs:null, id:"bdf-redo", act:function(){ redo(); } }
  ];
  (function(){
    var host=$("bdf-toolbar"), groups={};
    function group(name){ if(!groups[name]){ groups[name]=document.createElement("div"); groups[name].className="bdf-group"; host.appendChild(groups[name]); } return groups[name]; }
    TOOLS.forEach(function(tool){
      var b=document.createElement("button");
      b.type="button"; b.innerHTML=tool.label; b.setAttribute("aria-label",tool.aria);
      if(tool.title) b.title=tool.title; if(tool.id) b.id=tool.id;
      b.dataset.needs = tool.needs||"";
      b.addEventListener("mousedown",function(e){ e.preventDefault(); });
      b.addEventListener("click",function(){ tool.act(); });
      group(tool.group).appendChild(b);
    });
    var sg=group("spacing");
    spacingBtn=document.createElement("button");
    spacingBtn.type="button";
    spacingBtn.title="Standard: Enter starts a new paragraph with spacing. Compact: paragraphs joined with <br> and no extra gap. Tip: Shift+Enter inserts a line break.";
    spacingBtn.addEventListener("click",toggleSpacing);
    sg.appendChild(spacingBtn);
    updateSpacing();
  })();

  (function(){
    var ICONS=[
      {code:0x2713,name:"Check mark"},  {code:0x2605,name:"Star"},       {code:0x25cf,name:"Bullet"},
      {code:0x25c6,name:"Diamond"},     {code:0x2122,name:"Trademark"},  {code:0x00a9,name:"Copyright"},
      {code:0x00ae,name:"Registered"},  {code:0x2665,name:"Heart"},      {code:0x2460,name:"Circled 1"},
      {code:0x2461,name:"Circled 2"},   {code:0x2462,name:"Circled 3"},  {code:0x2463,name:"Circled 4"}
    ];
    var host=$("bdf-icons");
    ICONS.forEach(function(ic){
      var ch=String.fromCharCode(ic.code);
      var b=document.createElement("button");
      b.type="button"; b.textContent=ch;
      b.setAttribute("aria-label","Insert "+ic.name); b.title=ic.name;
      b.addEventListener("mousedown",function(e){ e.preventDefault(); });
      b.addEventListener("click",function(){ insertIcon(ch); });
      host.appendChild(b);
    });
  })();

  function updateSpacing(){
    spacingBtn.textContent="Spacing: "+(spacing==="standard"?"Standard":"Compact");
    spacingBtn.setAttribute("aria-label","Paragraph spacing, currently "+spacing+". Click to toggle.");
    $("bdf-spacing-hint").textContent = spacing==="standard"
      ? "Standard spacing: each paragraph becomes its own <p> block with spacing."
      : "Compact spacing: paragraphs are separated with <br> and no extra gap.";
  }
  function toggleSpacing(){ spacing = spacing==="standard"?"compact":"standard"; updateSpacing(); render(); }

  function syncToolbar(){
    var set=allowedSet(), btns=$("bdf-toolbar").querySelectorAll("button[data-needs]");
    for(var i=0;i<btns.length;i++){
      var need=btns[i].dataset.needs, ok=!need||set.has(need);
      btns[i].disabled=!ok;
      btns[i].setAttribute("aria-disabled", ok?"false":"true");
    }
  }

  function focusExec(cmd,val){ editor.focus(); if(canExec){ try{ return document.execCommand(cmd,false,val||null); }catch(e){} } return false; }
  function saveSel(){ var s=window.getSelection(); return s&&s.rangeCount&&editor.contains(s.anchorNode)?s.getRangeAt(0).cloneRange():null; }
  function restoreSel(r){ if(r){ var s=window.getSelection(); s.removeAllRanges(); s.addRange(r); } }
  function afterEdit(){ pushHistory(); render(); }

  var EXEC = { b:"bold", i:"italic", u:"underline" };
  function inlineWrap(tag){
    if(!allowedSet().has(tag)) return;
    var cmd = EXEC[tag] || "bold", r=saveSel();
    if(!focusExec(cmd)){
      restoreSel(r);
      var s=window.getSelection(); if(!s||!s.rangeCount) return;
      var rg=s.getRangeAt(0); if(rg.collapsed) return;
      var el=document.createElement(tag);
      try{ rg.surroundContents(el); }catch(e){ var frag=rg.extractContents(); el.appendChild(frag); rg.insertNode(el); }
    }
    afterEdit();
  }
  function blockFormat(tag){
    if(tag!=="p" && !allowedSet().has(tag)) return;
    var r=saveSel();
    if(!focusExec("formatBlock", tag.toUpperCase())){
      restoreSel(r);
      var s=window.getSelection(); if(!s||!s.rangeCount) return;
      var node=s.getRangeAt(0).startContainer;
      while(node && node!==editor && node.parentNode!==editor) node=node.parentNode;
      if(!node || node===editor) return;
      var el=document.createElement(tag);
      while(node.firstChild) el.appendChild(node.firstChild);
      node.parentNode.replaceChild(el,node);
    }
    afterEdit();
  }
  function listFormat(tag){
    if(!allowedSet().has(tag)) return;
    var cmd = tag==="ul"?"insertUnorderedList":"insertOrderedList", r=saveSel();
    if(!focusExec(cmd)){
      restoreSel(r);
      var s=window.getSelection(); if(!s||!s.rangeCount) return;
      var text=s.toString(); if(!text) return;
      var el=document.createElement(tag);
      text.split(NL).forEach(function(line){ if(line.trim()){ var li=document.createElement("li"); li.appendChild(document.createTextNode(line)); el.appendChild(li); } });
      var rg=s.getRangeAt(0); rg.deleteContents(); rg.insertNode(el);
    }
    afterEdit();
  }

  function insertIcon(ch){
    editor.focus();
    var r=saveSel();
    if(!focusExec("insertText", ch)){
      restoreSel(r);
      var s=window.getSelection();
      if(s&&s.rangeCount){
        var rg=s.getRangeAt(0); rg.deleteContents();
        var t=document.createTextNode(ch); rg.insertNode(t);
        rg.setStartAfter(t); rg.collapse(true); s.removeAllRanges(); s.addRange(rg);
      } else {
        editor.appendChild(document.createTextNode(ch));
      }
    }
    afterEdit();
  }

  var hist=[], hi=-1, inputTimer=null;
  function pushHistory(){
    var h=editor.innerHTML;
    if(hist[hi]===h) return;
    hist=hist.slice(0,hi+1); hist.push(h); hi=hist.length-1;
    if(hist.length>100){ hist.shift(); hi--; }
    syncUndo();
  }
  function syncUndo(){ var u=$("bdf-undo"), r=$("bdf-redo"); if(u) u.disabled=hi<=0; if(r) r.disabled=hi>=hist.length-1; }
  function undo(){ if(hi>0){ hi--; editor.innerHTML=hist[hi]; syncUndo(); render(); } }
  function redo(){ if(hi<hist.length-1){ hi++; editor.innerHTML=hist[hi]; syncUndo(); render(); } }

  function loadText(text){
    editor.innerHTML="";
    var nodes=textToNodes(text);
    for(var i=0;i<nodes.length;i++) editor.appendChild(nodes[i]);
    pushHistory(); render();
  }

  function previewTitle(){
    var el=$("bdf-f-book_title");
    var t = el && el.value ? el.value.trim() : "";
    return t || "Your Book Title: A Novel";
  }
  function previewStars(color){
    var FULL=String.fromCharCode(0x2605);
    return '<span class="bdf-skin-stars" style="color:'+color+'">'+FULL+FULL+FULL+FULL+'</span>'
         + '<span class="bdf-skin-stars-off">'+FULL+'</span>';
  }
  function retailerFrame(html, key){
    var sk=SKINS[key] || SKINS.amazon;
    var body='<div class="bdf-skin-body">'
           + (html || '<span class="bdf-empty">Your formatted description will appear here...</span>')
           + '</div>';
    var parts=[];
    if(sk.chrome){
      parts.push('<div class="bdf-skin-title" style="font-size:'+sk.titleSize+'">'+esc(previewTitle())+'</div>');
      if(sk.byline) parts.push('<div class="bdf-skin-byline">'+sk.byline+'</div>');
      parts.push('<div class="bdf-skin-rating">'+previewStars(sk.stars)+' <span class="bdf-skin-count">'+sk.count+'</span></div>');
    }
    if(sk.label) parts.push('<div class="bdf-skin-seclabel">'+sk.label+'</div>');
    if(sk.sub)   parts.push('<div class="bdf-skin-sub">'+sk.sub+'</div>');
    parts.push(body);
    if(sk.more && html) parts.push('<div class="bdf-skin-more">'+sk.more+'</div>');
    return '<div class="bdf-skin bdf-skin-'+sk.skin+'">'+parts.join("")+'</div>';
  }

  function buildHtmlFor(key){
    var set=new Set(PLATFORMS[key].allowed);
    var blocks=mergeLists(groupBlocks(mapChildren(editor,set)), set);
    return buildHTML(blocks, spacing);
  }
  function render(){
    var html=buildHtmlFor(platformKey);
    output.textContent=html;

    if(html){
      preview.innerHTML = retailerFrame(html, platformKey);
    } else {
      preview.innerHTML = '<p class="bdf-preview-hint">Type or paste your description above to preview it as it will appear on '
        + PLATFORMS[platformKey].label + '.</p>';
    }

    var n=html.length, limit=PLATFORMS[platformKey].limit;
    counter.textContent = n+" / "+limit+" characters (incl. tags)";
    counter.className="bdf-counter";
    if(n>limit) counter.classList.add("over"); else if(n>limit-200) counter.classList.add("warn");
  }

  function looksMessy(html){
    var h=html.toLowerCase();
    if(h.indexOf("style=")>=0||h.indexOf("class=")>=0||h.indexOf("id=")>=0) return true;
    var t=["<div","<span","<font","<table","<img","<o:p","<script","<style","<h1","<h2","<h3","<h4","<h5","<h6"];
    for(var i=0;i<t.length;i++) if(h.indexOf(t[i])>=0) return true;
    if(reZeroWidth.test(html)||html.indexOf(NBSP)>=0) return true;
    return false;
  }
  function insertNodes(nodes){
    var s=window.getSelection();
    if(!s||!s.rangeCount){ for(var i=0;i<nodes.length;i++) editor.appendChild(nodes[i]); return; }
    var rg=s.getRangeAt(0); rg.deleteContents();
    var frag=document.createDocumentFragment();
    for(var i=0;i<nodes.length;i++) frag.appendChild(nodes[i]);
    var last=frag.lastChild;
    rg.insertNode(frag);
    if(last){ rg.setStartAfter(last); rg.collapse(true); s.removeAllRanges(); s.addRange(rg); }
  }
  editor.addEventListener("paste",function(e){
    e.preventDefault();
    var cd=e.clipboardData||window.clipboardData;
    var html=cd&&cd.getData?cd.getData("text/html"):"", nodes, messy=false;
    if(html){
      if(looksMessy(html)) messy=true;
      var tmp=document.createElement("div"); tmp.innerHTML=html;
      nodes=mapChildren(tmp, allowedSet());
    } else {
      var txt=cd&&cd.getData?cd.getData("text/plain"):"";
      if(reZeroWidth.test(txt)||txt.indexOf(NBSP)>=0) messy=true;
      nodes=textToNodes(txt);
    }
    insertNodes(nodes);
    if(messy) note.classList.add("show");
    pushHistory(); render();
  });

  function selectOutput(){ var r=document.createRange(); r.selectNodeContents(output); var s=window.getSelection(); s.removeAllRanges(); s.addRange(r); }
  function flashCopy(msg){ var el=$("bdf-copy-status"); el.textContent=msg; setTimeout(function(){ el.textContent=""; },2000); }
  $("bdf-copy").addEventListener("click",function(){
    var text=output.textContent;
    function ok(){ flashCopy("Copied!"); }
    function fallback(){ selectOutput(); try{ document.execCommand("copy"); ok(); }catch(e){ flashCopy("Press Ctrl/Cmd+C to copy"); selectOutput(); } }
    if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(ok,fallback); else fallback();
  });

  $("bdf-note-dismiss").addEventListener("click",function(){ note.classList.remove("show"); });
  editor.addEventListener("input",function(){ clearTimeout(inputTimer); inputTimer=setTimeout(pushHistory,400); render(); });
  editor.addEventListener("blur", pushHistory);
  window.bdfLoadText=function(t){ loadText(String(t==null?"":t)); };
  window.addEventListener("message",function(e){ var d=e.data; if(d&&typeof d==="object"&&d.type==="bdf-load"&&typeof d.text==="string") loadText(d.text); });

  syncToolbar(); pushHistory(); render();
})();

(function(){
  var banner=document.getElementById("bdf-js-check");
  if(banner&&banner.parentNode) banner.parentNode.removeChild(banner);
  var tabWrite=document.getElementById("bdf-tab-write"),
      tabFormat=document.getElementById("bdf-tab-format"),
      paneWrite=document.getElementById("bdf-pane-write"),
      paneFormat=document.getElementById("bdf-pane-format");
  function show(which){
    var w = which==="write";
    paneWrite.classList.toggle("bdf-hidden", !w);
    paneFormat.classList.toggle("bdf-hidden", w);
    tabWrite.setAttribute("aria-pressed", w?"true":"false");
    tabFormat.setAttribute("aria-pressed", w?"false":"true");
    tabWrite.disabled=w; tabFormat.disabled=!w;
    var res=document.querySelectorAll(".awg-aig__result, .awg-aig__result-actions");
    for(var i=0;i<res.length;i++) res[i].classList.toggle("bdf-hidden", !w);
    if(!w){
      var ed=document.getElementById("bdf-editor");
      if(ed && (ed.textContent||"").trim()===""){
        var src=document.querySelector(".awg-aig__output"), raw="";
        if(src){ if(window.jQuery) raw=window.jQuery(src).data("raw-text")||""; if(!raw) raw=(src.innerText||src.textContent||"").trim(); }
        if(raw && typeof window.bdfLoadText==="function") window.bdfLoadText(raw);
      }
    }
  }
  if(tabWrite&&tabFormat&&paneWrite&&paneFormat){
    tabWrite.addEventListener("click",function(){ show("write"); });
    tabFormat.addEventListener("click",function(){ show("format"); });
    window.bdfShowFormat=function(){ show("format"); };
    window.bdfShowWrite =function(){ show("write"); };
    show("write");
  }
})();
