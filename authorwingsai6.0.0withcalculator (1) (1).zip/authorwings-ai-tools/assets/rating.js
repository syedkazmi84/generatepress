/* AuthorWings Rating widget — front-end JS (vanilla, no jQuery)
 * Handles hover preview, click-to-submit, and "already rated" state.
 * Re-scans the DOM on demand because the widget is sometimes injected
 * after the page loads (inside a generator form rendered by the renderer).
 */
(function () {
    'use strict';

    if (typeof window.AWG_RATING === 'undefined') return;
    var CFG = window.AWG_RATING;

    function paintStars(widget, value, lock) {
        var stars = widget.querySelectorAll('.awg-rating__star');
        for (var i = 0; i < stars.length; i++) {
            var v = parseInt(stars[i].getAttribute('data-value'), 10);
            stars[i].classList.toggle(lock ? 'is-active' : 'is-hover', v <= value);
            if (!lock) stars[i].classList.remove('is-active');
        }
        if (lock) {
            for (var j = 0; j < stars.length; j++) {
                stars[j].classList.remove('is-hover');
            }
        }
    }

    function clearHover(widget) {
        var stars = widget.querySelectorAll('.awg-rating__star');
        for (var i = 0; i < stars.length; i++) stars[i].classList.remove('is-hover');
    }

    function showAvgState(widget) {
        var avg = parseFloat(widget.getAttribute('data-avg')) || 0;
        paintStars(widget, Math.round(avg), true);
    }

    function updateSummary(widget, avg, count) {
        widget.setAttribute('data-avg', avg);
        widget.setAttribute('data-count', count);

        var summary = widget.querySelector('.awg-rating__summary');
        if (!summary) {
            showAvgState(widget);
            return;
        }

        var avgDisplay = (Math.round(avg * 10) / 10).toFixed(1);
        var word = count === 1 ? CFG.i18n.vote : CFG.i18n.votes;
        var countDisplay;
        try { countDisplay = count.toLocaleString(); } catch (e) { countDisplay = String(count); }

        // When the widget was rendered with zero votes, it shows an "empty"
        // placeholder instead of the value/sep/max/count spans. After the
        // first vote arrives, rebuild the full summary in place.
        if (count > 0) {
            summary.innerHTML =
                '<span class="awg-rating__value">' + avgDisplay + '</span>' +
                '<span class="awg-rating__sep">/</span>' +
                '<span class="awg-rating__max">5</span>' +
                '<span class="awg-rating__count">(' + countDisplay + ' ' + word + ')</span>';
        }
        showAvgState(widget);
    }

    function lockWidget(widget, msg, msgClass) {
        widget.setAttribute('data-voted', '1');
        var stars = widget.querySelectorAll('.awg-rating__star');
        for (var i = 0; i < stars.length; i++) stars[i].setAttribute('disabled', 'disabled');
        var msgEl = widget.querySelector('.awg-rating__msg');
        if (msgEl) {
            msgEl.className = 'awg-rating__msg ' + (msgClass || '');
            msgEl.textContent = msg || '';
        }
    }

    function submitRating(widget, value) {
        var postId = widget.getAttribute('data-post-id');
        var msgEl  = widget.querySelector('.awg-rating__msg');

        paintStars(widget, value, true);

        var data = new URLSearchParams();
        data.append('action',  'awg_rating_submit');
        data.append('nonce',   CFG.nonce);
        data.append('post_id', postId);
        data.append('stars',   String(value));

        fetch(CFG.ajaxurl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: data.toString()
        })
            .then(function (r) { return r.json().catch(function () { return null; }); })
            .then(function (resp) {
                if (resp && resp.success) {
                    updateSummary(widget, resp.data.avg, resp.data.count);
                    lockWidget(widget, resp.data.message || CFG.i18n.thanks, '');
                } else if (resp && resp.data && resp.data.already) {
                    if (typeof resp.data.avg !== 'undefined' && typeof resp.data.count !== 'undefined') {
                        updateSummary(widget, resp.data.avg, resp.data.count);
                    }
                    lockWidget(widget, resp.data.message || CFG.i18n.already, 'is-info');
                } else {
                    showAvgState(widget);
                    if (msgEl) {
                        msgEl.className = 'awg-rating__msg is-error';
                        msgEl.textContent = (resp && resp.data && resp.data.message) || CFG.i18n.error;
                    }
                }
            })
            .catch(function () {
                showAvgState(widget);
                if (msgEl) {
                    msgEl.className = 'awg-rating__msg is-error';
                    msgEl.textContent = CFG.i18n.error;
                }
            });
    }

    function bindWidget(widget) {
        if (widget.dataset.awgBound === '1') return;
        widget.dataset.awgBound = '1';

        showAvgState(widget);

        var voted = widget.getAttribute('data-voted') === '1';
        if (voted) {
            lockWidget(widget, CFG.i18n.already, 'is-info');
            return;
        }

        var stars = widget.querySelectorAll('.awg-rating__star');
        for (var i = 0; i < stars.length; i++) {
            (function (star) {
                star.addEventListener('mouseenter', function () {
                    if (widget.getAttribute('data-voted') === '1') return;
                    clearHover(widget);
                    paintStars(widget, parseInt(star.getAttribute('data-value'), 10), false);
                });
                star.addEventListener('mouseleave', function () {
                    if (widget.getAttribute('data-voted') === '1') return;
                    showAvgState(widget);
                });
                star.addEventListener('focus', function () {
                    if (widget.getAttribute('data-voted') === '1') return;
                    clearHover(widget);
                    paintStars(widget, parseInt(star.getAttribute('data-value'), 10), false);
                });
                star.addEventListener('blur', function () {
                    if (widget.getAttribute('data-voted') === '1') return;
                    showAvgState(widget);
                });
                star.addEventListener('click', function (e) {
                    e.preventDefault();
                    if (widget.getAttribute('data-voted') === '1') return;
                    var v = parseInt(star.getAttribute('data-value'), 10);
                    if (v >= 1 && v <= 5) submitRating(widget, v);
                });
            })(stars[i]);
        }
    }

    function init() {
        var widgets = document.querySelectorAll('.awg-rating');
        for (var i = 0; i < widgets.length; i++) bindWidget(widgets[i]);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
