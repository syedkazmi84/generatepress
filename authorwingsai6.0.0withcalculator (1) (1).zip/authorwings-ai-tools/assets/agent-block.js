(function (wp) {
  if (!wp || !wp.blocks) return;

  var registerBlockType = wp.blocks.registerBlockType;
  var InspectorControls = (wp.blockEditor || wp.editor).InspectorControls;
  var PanelBody = wp.components.PanelBody;
  var SelectControl = wp.components.SelectControl;
  var el = wp.element.createElement;
  var Fragment = wp.element.Fragment;
  var __ = (wp.i18n && wp.i18n.__) ? wp.i18n.__ : function (s) { return s; };

  var DATA = window.AWG_AGENT_BLOCK || { agents: [] };

  registerBlockType("awg/agent", {
    title: __("AuthorWings AI Agent", "authorwings-ai-tools"),
    icon: "format-chat",
    category: "widgets",
    attributes: {
      agentId: { type: "number", default: 0 },
    },

    edit: function (props) {
      var agentId = props.attributes.agentId;

      var options = [{ label: __("Select an agent…", "authorwings-ai-tools"), value: 0 }];
      (DATA.agents || []).forEach(function (a) {
        options.push({ label: a.title || ("#" + a.id), value: a.id });
      });

      return el(
        Fragment,
        {},
        el(
          InspectorControls,
          {},
          el(
            PanelBody,
            { title: __("Agent", "authorwings-ai-tools"), initialOpen: true },
            el(SelectControl, {
              label: __("Agent", "authorwings-ai-tools"),
              value: agentId,
              options: options,
              onChange: function (val) {
                props.setAttributes({ agentId: parseInt(val, 10) || 0 });
              },
            })
          )
        ),
        el(
          "div",
          { className: "awg-block-preview" },
          agentId
            ? __("AuthorWings AI Agent selected:", "authorwings-ai-tools") + " #" + agentId
            : __("Select an agent from the block sidebar settings.", "authorwings-ai-tools")
        )
      );
    },

    save: function () {
      return null; // dynamic render via PHP
    },
  });
})(window.wp);
