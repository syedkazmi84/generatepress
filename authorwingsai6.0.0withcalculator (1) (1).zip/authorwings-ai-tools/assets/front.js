(function($){
  const UTM_KEYS = ['utm_source','utm_medium','utm_campaign','utm_term','utm_content'];

  function getStoredGclid() {
    const params = new URLSearchParams(window.location.search);
    const gclid = params.get('gclid');
    if (gclid) {
      try {
        sessionStorage.setItem('awg_aig_gclid', gclid);
      } catch (e) {}
      return gclid;
    }
    try {
      return sessionStorage.getItem('awg_aig_gclid') || '';
    } catch (e) {
      return '';
    }
  }

  function getStoredUtm() {
    const params = new URLSearchParams(window.location.search);
    const result = {};
    UTM_KEYS.forEach(function(key){
      const fromUrl = params.get(key);
      if (fromUrl) {
        try { sessionStorage.setItem('awg_aig_' + key, fromUrl); } catch (e) {}
        result[key] = fromUrl;
      } else {
        try { result[key] = sessionStorage.getItem('awg_aig_' + key) || ''; } catch (e) { result[key] = ''; }
      }
    });
    return result;
  }

  function applyGclid($wrap) {
    const gclid = getStoredGclid();
    if (gclid) {
      const $field = $wrap.find('input[name="gclid"]');
      if ($field.length) $field.val(gclid);
    }
    // UTMs
    const utms = getStoredUtm();
    UTM_KEYS.forEach(function(key){
      if (!utms[key]) return;
      const $f = $wrap.find('input.awg-aig__utm[data-utm-key="' + key + '"]');
      if ($f.length) $f.val(utms[key]);
    });
  }

  function normalizeName(name){
    return (name || '').replace(/\[\]$/, '');
  }

  function collect($wrap){
    const fields = {};
    const labels = {};

    // v5.4.19: in Custom HTML design mode the admin writes free-form markup, so
    // the .awg-aig__input class may be absent. Collect every named control inside
    // the form instead. Standard mode keeps the original class-based selector so
    // its behaviour is byte-for-byte unchanged.
    const isCustom = ($wrap.attr('data-design-mode') === 'custom');
    const selector = isCustom
      ? '.awg-aig__form input[name], .awg-aig__form select[name], .awg-aig__form textarea[name]'
      : '.awg-aig__input, .awg-aig__choice';

    $wrap.find(selector).each(function(){
      const $el = $(this);
      const rawName = $el.attr('name');
      if (!rawName) return;

      const name = normalizeName(rawName);
      const type = (($el.attr('type') || '').toLowerCase());

      // Optional per-field label hint (custom mode only). Used purely to format
      // the {{fields}} block; the server prettifies the name when absent.
      if (isCustom) {
        const lbl = $el.attr('data-awg-label');
        if (lbl && typeof labels[name] === 'undefined') labels[name] = lbl;
      }

      // v5.4.69: upload fields can't post their binary through the JSON
      // generate request, so the file is uploaded ahead of time (on change) and
      // the server returns a token. The token — not the browser's fake path —
      // is what we submit; the server swaps it back for the extracted text.
      if (type === 'file') {
        fields[name] = $el.data('awgToken') || '';
        return;
      }

      if (type === 'checkbox') {
        if (rawName.slice(-2) === '[]') {
          if (!Array.isArray(fields[name])) fields[name] = [];
          if ($el.is(':checked')) fields[name].push($el.val() || '1');
          return;
        }
        fields[name] = $el.is(':checked') ? ($el.val() || '1') : '';
        return;
      }

      if (type === 'radio') {
        if ($el.is(':checked')) {
          fields[name] = $el.val();
        } else if (typeof fields[name] === 'undefined') {
          fields[name] = '';
        }
        return;
      }

      fields[name] = $el.val();
    });

    // Stash label hints for the submit handler to send alongside the fields.
    try { $wrap.data('awgLabels', labels); } catch (e) {}
    return fields;
  }

  // v5.4.48: client-side mirror of the server gibberish guard
  // (class-ajax.php::looks_like_gibberish). Gives instant feedback and saves a
  // round-trip, but is NOT authoritative — the server re-checks every request.
  // Deliberately conservative: only flags a value when EVERY judged word looks
  // like keyboard mashing, and only for Latin-dominant text.
  function looksLikeGibberish(value, minLen){
    var v = (value == null ? '' : String(value)).trim();
    if (v === '' || v.length < Math.max(1, minLen || 0)) return false;

    // An absurd run of one repeated character ("aaaaaa", "!!!!!!").
    if (/(.)\1{5,}/.test(v)) return true;

    // Non-Latin guard: bail unless at least half the letters are A–Z, so other
    // scripts (CJK, Arabic, Cyrillic, …) are never flagged. Falls back cleanly
    // on browsers without Unicode property escapes.
    var letters;
    try {
      letters = v.replace(/[^\p{L}]/gu, '');
    } catch (e) {
      letters = v.replace(/[^A-Za-z]/g, '');
    }
    if (!letters) return false;
    var latin = letters.replace(/[^A-Za-z]/g, '');
    if (latin.length < letters.length / 2) return false;

    var words = v.split(/\s+/);
    var eligible = 0, suspect = 0;
    for (var i = 0; i < words.length; i++){
      var alpha = words[i].replace(/[^A-Za-z]/g, '');
      var len = alpha.length;
      if (len < 4) continue;
      eligible++;
      var lower = alpha.toLowerCase();
      var vowels = (lower.match(/[aeiouy]/g) || []).length;
      var ratio = vowels / len;
      var noVowels = vowels === 0;
      var longRun = /[bcdfghjklmnpqrstvwxz]{6,}/.test(lower);
      var lowVowelLong = len >= 7 && ratio < 0.20;
      if (noVowels || longRun || lowVowelLong) suspect++;
    }
    return eligible > 0 && suspect === eligible;
  }

  // Scan the form's free-text inputs and return the labels of any that look
  // like gibberish. Honors the per-template data-attributes set by the renderer.
  function findGibberishFields($wrap){
    if (String($wrap.attr('data-gibberish')) !== '1') return [];
    var minLen = parseInt($wrap.attr('data-gibberish-min'), 10);
    if (isNaN(minLen)) minLen = 0;
    var skip = ['gclid', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'];
    var bad = [];
    $wrap.find('.awg-aig__form textarea, .awg-aig__form input').each(function(){
      var $el = $(this);
      var name = normalizeName($el.attr('name') || '');
      if (!name || skip.indexOf(name) !== -1) return;
      var tag = (this.tagName || '').toLowerCase();
      var type = ($el.attr('type') || 'text').toLowerCase();
      // Only judge free text — never email/number/url/select/checkbox/etc.
      if (tag !== 'textarea' && type !== 'text' && type !== 'search' && type !== '') return;
      if (!looksLikeGibberish($el.val(), minLen)) return;

      var label = $el.attr('data-awg-label') || '';
      if (!label) {
        var id = $el.attr('id');
        if (id) {
          var $lab = $wrap.find('label[for="' + id + '"]');
          if ($lab.length) label = $.trim($lab.first().text());
        }
      }
      if (!label) label = name;
      if (bad.indexOf(label) === -1) bad.push(label);
    });
    return bad;
  }

  function status($wrap, msg, err, cta){
    const $s = $wrap.find('.awg-aig__status');
    $s.empty().text(msg || '');
    $s.toggleClass('is-error', !!err);
    // When a blocked generation returns an upgrade target (the membership gate
    // sends upgrade_url / upgrade_label for limit-reached and plan-locked
    // tools), surface it as a real button beneath the message instead of
    // dropping it. The URL is server-escaped; the label is set as a text node.
    if (cta && cta.url) {
      const $a = $('<a/>', {
        'class': 'awg-aig__upgrade',
        href: cta.url,
        text: cta.label || 'Upgrade your plan'
      });
      $s.append($a);
    }
  }

  // Rotating "thinking" messages shown next to the pulsing dot while a
  // generation is in flight. Each message holds for THINKING_INTERVAL_MS,
  // and the last one persists until the response arrives.
  const THINKING_MESSAGES = [
    'Analyzing your inputs',
    'Generating content',
    'Polishing the output',
    'Almost there'
  ];
  const THINKING_INTERVAL_MS = 3200;

  // Skeleton mirrors the actual result-card layout: a small badge
  // circle + 1-2 text lines per "item", repeated 4 times. This makes
  // the loader visually predict the shape of the upcoming list output
  // so the transition from skeleton → real content is seamless instead
  // of a layout pop. For non-list outputs the cards still read as
  // sensible paragraph placeholders.
  function buildSkeletonHTML(){
    const cards = [
      ['80%', '55%'],
      ['92%', '48%'],
      ['75%', '60%'],
      ['85%', '52%']
    ];
    let html = '<div class="awg-aig__skeleton" aria-hidden="true">';
    html += '<div class="awg-aig__skeleton-thinking">';
    html += '<span class="awg-aig__skeleton-thinking-icon"></span>';
    html += '<span class="awg-aig__skeleton-thinking-text">' + THINKING_MESSAGES[0] + '</span>';
    html += '<span class="awg-aig__skeleton-thinking-dots"><span></span><span></span><span></span></span>';
    html += '</div>';
    html += '<div class="awg-aig__skeleton-cards">';
    cards.forEach(function(widths){
      html += '<div class="awg-aig__skeleton-card">';
      html += '<div class="awg-aig__skeleton-card-badge"></div>';
      html += '<div class="awg-aig__skeleton-card-lines">';
      widths.forEach(function(w){
        html += '<div class="awg-aig__skeleton-line" style="width:' + w + ';"></div>';
      });
      html += '</div></div>';
    });
    html += '</div></div>';
    return html;
  }

  function showSkeleton($wrap){
    if (!$wrap || !$wrap.length) return;
    const $res = $wrap.find('.awg-aig__result');
    const $out = $wrap.find('.awg-aig__output');
    if (!$res.length || !$out.length) return;

    // Make the result panel visible even on the very first run
    // (previously it stayed hidden until success, leaving the user
    // staring at nothing during the wait).
    $res.prop('hidden', false).addClass('is-busy');
    $wrap.find('.awg-aig__result-count').remove();
    // Root-level state class so CSS can fade elements that live
    // OUTSIDE the result panel (rating widget, etc.) while a
    // generation is in flight.
    $wrap.addClass('is-generating');

    // Inject skeleton if not already present
    if (!$out.find('.awg-aig__skeleton').length) {
      $out.append(buildSkeletonHTML());
    }

    // Scroll the result panel into view immediately so the user
    // sees the loading state instead of staying scrolled on the
    // form. Used on both first generate and regenerate (regenerate
    // routes through the same submit handler).
    setTimeout(function(){
      const el = $res.get(0);
      if (!el) return;
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);

    // Rotate the thinking message every THINKING_INTERVAL_MS, stopping
    // on the last entry. Interval id is stored on the wrap so a second
    // generation (e.g. rapid regenerate) doesn't leak timers.
    const prev = $wrap.data('awgThinkingInterval');
    if (prev) clearInterval(prev);

    let index = 0;
    const $text = $out.find('.awg-aig__skeleton-thinking-text');
    const interval = setInterval(function(){
      if (index >= THINKING_MESSAGES.length - 1) {
        clearInterval(interval);
        $wrap.removeData('awgThinkingInterval');
        return;
      }
      index += 1;
      $text.addClass('is-fading');
      setTimeout(function(){
        $text.text(THINKING_MESSAGES[index]).removeClass('is-fading');
      }, 220);
    }, THINKING_INTERVAL_MS);

    $wrap.data('awgThinkingInterval', interval);
  }

  function hideSkeleton($wrap){
    if (!$wrap || !$wrap.length) return;
    const interval = $wrap.data('awgThinkingInterval');
    if (interval) {
      clearInterval(interval);
      $wrap.removeData('awgThinkingInterval');
    }
    $wrap.find('.awg-aig__result').removeClass('is-busy');
    $wrap.removeClass('is-generating');
    $wrap.find('.awg-aig__skeleton').remove();
  }

  // v5.4.10: clears any stale result from the output area and hides the
  // result panel after an error. Without this, the CSS rule that hides
  // previous output only applies during .is-busy state — removing the
  // class on error un-hid the stale result alongside the error message,
  // making it look like "rate limited but the result still generated".
  function showErrorState($wrap){
    if (!$wrap || !$wrap.length) return;
    const $out = $wrap.find('.awg-aig__output');
    const $res = $wrap.find('.awg-aig__result');
    $out.empty();
    $out.removeData('raw-text');
    $out.removeAttr('data-format');
    $out.removeClass('is-formatted');
    // Hide the entire result panel so there's no "ghost" empty card next
    // to the error banner. The status banner lives outside this panel.
    $res.prop('hidden', true).removeClass('is-busy');
  }

  function escapeHtml(value){
    return String(value || '').replace(/[&<>"']/g, function(char){
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
      }[char] || char;
    });
  }

  function applyInlineFormatting(value){
    return awgInlineMarkup(escapeHtml(value || ''));
  }

  // v5.4.88: the markdown/inline pass, split out so it can also run over text
  // that is ALREADY HTML-escaped (e.g. the Before/After diff, which escapes each
  // word-token itself). `text` MUST be escaped before it reaches here — this pass
  // never escapes, so calling it on raw input would leave it unescaped.
  function awgInlineMarkup(text){
    // v5.4.67: protect inline code spans BEFORE any emphasis runs. Previously
    // bold/italic were applied first, so markup INSIDE backticks (e.g. `a**b**`)
    // was wrongly turned into <strong>/<em>. Swap each span for a placeholder,
    // format everything else, then restore the spans verbatim as <code> at the
    // end. The NUL sentinel never occurs in real model output.
    const codeSpans = [];
    text = text.replace(/`([^`]+)`/g, function(_m, code){
      codeSpans.push(code);
      return '\u0000C' + (codeSpans.length - 1) + '\u0000';
    });

    // v5.4.67: backslash-escaped markdown punctuation (\* \~ \` \\ \[ \] \( \) \#)
    // is held as a placeholder so the emphasis passes below skip it, then the
    // bare literal character is restored — so "\*literal\*" shows real asterisks.
    const escapes = [];
    text = text.replace(/\\([*~`\\\[\]()#])/g, function(_m, ch){
      escapes.push(ch);
      return '\u0000E' + (escapes.length - 1) + '\u0000';
    });

    // ***bold italic*** must run before **bold** and *italic*.
    text = text.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/\*(.+?)\*/g, '<em>$1</em>');
    // v5.4.67: ~~strikethrough~~.
    text = text.replace(/~~(.+?)~~/g, '<del>$1</del>');
    // v5.4.80: CriticMarkup redline — {--deleted--} / {++inserted++} render as
    // tracked-change del/ins so copy-edit tools can show the exact edit inline.
    // Classed separately from plain ~~strike~~ so only redline gets the red/green
    // change colours. Non-greedy so adjacent edits on one line stay distinct.
    text = text.replace(/\{--([\s\S]+?)--\}/g, '<del class="awg-aig__del">$1</del>');
    text = text.replace(/\{\+\+([\s\S]+?)\+\+\}/g, '<ins class="awg-aig__ins">$1</ins>');
    // v5.4.50: gracefully handle a markdown bold the model left UNCLOSED.
    // This is common when the response is truncated mid-word by the token cap
    // (e.g. "...suggests **Annih") — previously the dangling "**" rendered as
    // literal asterisks. Bold to the end of the segment instead, then drop any
    // stray "**" that still remains so no raw asterisks ever leak through.
    // Single "*" is left untouched on purpose (it is ambiguous — e.g. "5 * 3").
    text = text.replace(/\*\*([^*]+)$/, '<strong>$1</strong>');
    text = text.replace(/\*\*/g, '');
    // v5.4.62: render markdown links [label](url) as real anchors. Runs after
    // escapeHtml, so label/url are already entity-safe; we additionally restrict
    // the scheme to http(s) / mailto / relative so javascript: and data: URLs
    // can never become a live link (they fall back to plain label text).
    text = text.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, function(match, label, url){
      if (!/^(https?:\/\/|mailto:|\/|#)/i.test(url)) return label;
      return '<a href="' + url + '" target="_blank" rel="noopener nofollow">' + label + '</a>';
    });

    // Restore escaped literals, then code spans (last, so their content is never
    // touched by any pass above).
    text = text.replace(/\u0000E(\d+)\u0000/g, function(_m, i){ return escapes[+i]; });
    text = text.replace(/\u0000C(\d+)\u0000/g, function(_m, i){ return '<code>' + codeSpans[+i] + '</code>'; });
    return text;
  }

  // v5.4.51: decide how a result should be presented.
  //   'list'     – the output is purely a flat list of options (titles,
  //                taglines, names). Rendered as the interactive option cards
  //                with a per-item copy button — you copy one at a time.
  //   'document' – the output is structured long-form (an analysis, an
  //                article, a blurb): it has headings and/or paragraphs.
  //                Rendered as a clean, professional document with NO per-line
  //                copy buttons or badges — it reads as one cohesive piece.
  function detectResultMode(lines){
    var headings = 0, prose = 0, listItems = 0;
    for (var i = 0; i < lines.length; i++){
      var line = String(lines[i] || '').trim();
      if (!line) continue;
      if (/^(#{1,4})\s+.+$/.test(line)) { headings++; continue; }
      if (/^[-*_]{3,}$/.test(line)) continue;                 // horizontal rule
      if (/^\d+[.)]\s+.+$/.test(line)) { listItems++; continue; }
      if (/^[-*•]\s+.+$/.test(line)) { listItems++; continue; }
      if (/^\*\*[^*]+\*\*:?\s*$/.test(line)) { headings++; continue; } // bold-only heading
      prose++;
    }
    // A heading is a strong "this is a document" signal. Otherwise a list of
    // options stays in copyable-cards mode, tolerating a single short preamble
    // line (e.g. "Here are 5 titles:") so a clean option list isn't demoted to
    // a plain document just because the model added one intro sentence.
    if (headings > 0) return 'document';
    if (listItems >= 1 && prose === 0) return 'list';
    if (listItems >= 2 && prose <= 1) return 'list';
    return 'document';
  }

  // v5.4.81: there are now only two Result Styles — Plain and Editorial. The
  // template's choice is surfaced as data-render-mode on the output element.
  // 'plain' -> the minimal prose renderer; EVERYTHING else (including the legacy
  // 'auto'/'cards'/'list'/'document' values stored before this version, and a
  // missing attribute) -> Editorial. Editorial decides per list whether to show
  // copyable option-cards or numbered point-rows, so old "Card list" tools keep
  // their copy buttons without a separate top-level mode.
  function pinnedMode($out){
    var m = ($out && $out.attr) ? String($out.attr('data-render-mode') || '').toLowerCase() : '';
    if (m === 'plain') return 'plain';
    return 'document';
  }

  // v5.4.81: true only when an Editorial result rendered to NOTHING but option
  // cards — no eyebrows, point-rows, rating, callouts, structured blocks, tables,
  // quotes or code. Such a result gets the tight .is-list card treatment; any
  // mixed or richer result gets the .is-document treatment (cards still style
  // correctly inside it, since their CSS is global).
  function resultIsPureList($out){
    if (!$out || !$out.find) return false;
    if ($out.find('.awg-aig__result-item').length === 0) return false;
    return $out.find('.awg-aig__doc-eyebrow, .awg-aig__pts, .awg-aig__rating, .awg-aig__checks, .awg-aig__stats, .awg-aig__tags, .awg-aig__ba, .awg-aig__scorecard, .awg-aig__callout, .awg-aig__pc, .awg-aig__steps, .awg-aig__pull, h2, h3, h4, table, blockquote, pre').length === 0;
  }

  // v5.8.1: keyword-based sentiment classification removed. Result formatting is
  // now purely structure-driven — a heading is a heading and a paragraph is a
  // paragraph, with no behavior inferred from the words used. An intentional
  // callout is still available via an explicit ```note / ```tip fenced block.

  // v5.4.87: the per-point status-icon SVGs (green tick / red cross at the end of
  // each numbered point) were removed by request — the statusIconSvg() generator
  // and its .awg-aig__pt-ic CSS are gone. The pass/fail Checklist block
  // (.awg-aig__checks) renders its own circular icons and is unaffected.

  function pad2(n){ return n < 10 ? '0' + n : '' + n; }

  // Known analyzer section labels — used to recognise headings even when the
  // model writes them as plain text (no ## / ** markup), so every section gets
  // the eyebrow label + status icon consistently across runs.
  var AWG_HEAD_WORDS = 'what works|what may limit it|what(?:\'|’)?s working|what(?:\'|’)?s not working|strengths?|weaknesses?|limitations?|risks?|pros|cons|editing recommendations?|formatting suggestions?|suggested improvements?|suggested revisions?|revised samples?|suggestions?|improvements?|recommendations?|final recommendation|verdict|in summary|summary|overview|conclusion|bottom line|best fit|clarity(?: and readability)?|readability|hook(?: and engagement)?|engagement|audience(?: and genre fit)?|genre fit|overall(?: assessment)?|key takeaways?|takeaways?';
  var AWG_HEAD_STANDALONE = new RegExp('^\\s*(?:[#*_]+\\s*)?(' + AWG_HEAD_WORDS + ')\\s*(?:[#*_]+)?\\s*:?\\s*$', 'i');
  // An inline lead-in heading like "Verdict: Keep", "**Verdict:** Keep" or
  // "Overall — Solid". The colon/dash separator is REQUIRED (so a normal
  // sentence that merely starts with "Recommendation"/"Summary" is not mistaken
  // for a heading), and stray ** around the label or colon are tolerated.
  var AWG_HEAD_INLINE = new RegExp('^\\s*\\*{0,2}\\s*(verdict|final recommendation|recommendation|overall(?: assessment)?|in summary|summary|bottom line|conclusion|overview|suggested improvements?|suggestions?|key takeaways?)\\s*\\*{0,2}\\s*[:\\-—]\\s*\\*{0,2}\\s*(\\S[\\s\\S]*)$', 'i');

  // Detect an "Overall Rating: 9/10" style score so it can be shown as a stat.
  function findRating(lines){
    for (var i = 0; i < lines.length; i++){
      var ln = lines[i];
      if (!/\b(rating|score)\b/i.test(ln)) continue;
      var m = ln.match(/(\d+(?:\.\d+)?)\s*\/\s*(\d+)/);
      var skip = [i];
      if (!m){
        for (var j = i + 1; j < lines.length; j++){
          if (!lines[j].trim()) continue;
          var m2 = lines[j].match(/^[\s*_>#-]*(\d+(?:\.\d+)?)\s*\/\s*(\d+)[\s*_]*$/);
          if (m2){ m = m2; skip.push(j); }
          break;
        }
      }
      if (m){
        var score = parseFloat(m[1]);
        var max = parseFloat(m[2]) || 10;
        if (isFinite(score) && isFinite(max) && max > 0 && score <= max){
          return { score: score, max: max, skip: skip };
        }
      }
      // v5.4.93 (M2): the score may appear on a later line — keep scanning the
      // remaining lines instead of giving up after the first rating/score word.
    }
    return null;
  }

  function ratingStatHtml(score, max){
    var pct = Math.max(0, Math.min(100, (score / max) * 100));
    var tier = pct >= 90 ? 'Excellent' : pct >= 75 ? 'Strong' : pct >= 60 ? 'Good' : pct >= 40 ? 'Fair' : 'Needs work';
    var num = (Math.round(score * 10) / 10);
    return '<div class="awg-aig__rating">' +
        '<div class="awg-aig__rating-row">' +
          '<span class="awg-aig__rating-num">' + num + '</span>' +
          '<span class="awg-aig__rating-max">/ ' + max + '</span>' +
          '<span class="awg-aig__rating-pill">' + tier + '</span>' +
        '</div>' +
        '<div class="awg-aig__rating-bar"><span style="width:' + pct + '%"></span></div>' +
      '</div>';
  }

  // v5.4.93 (M1): true only while a live stream is repainting, so the heavy
  // word-level diff (O(words²), re-run every frame) is skipped mid-stream and
  // computed once on the final render. Set/cleared around the live paint below.
  var AWG_LIVE = false;

  // v5.4.80: ```stats fence — each "Label: Value" line becomes a metric cell
  // (big value + small label). For quick at-a-glance numbers: word count,
  // reading level, adverb count, read time. Lines without a separator are
  // ignored so a stray sentence can't break the grid.
  function renderStatGrid(lines){
    var cells = [];
    lines.forEach(function(l){
      var s = String(l || '').trim();
      if (!s) return;
      var m = s.match(/^(.+?)\s*[:=]\s*(.+)$/);
      if (m){ cells.push({ k: m[1].trim(), v: m[2].trim() }); }
    });
    if (!cells.length) return '';
    return '<div class="awg-aig__stats">' + cells.map(function(c){
      return '<div class="awg-aig__stat">' +
          '<div class="awg-aig__stat-v">' + applyInlineFormatting(c.v) + '</div>' +
          '<div class="awg-aig__stat-k">' + applyInlineFormatting(c.k) + '</div>' +
        '</div>';
    }).join('') + '</div>';
  }

  // v5.4.80: ```tags fence — comma- or newline-separated keywords/genres/themes
  // become pill chips. A leading "#" is stripped so "#thriller" and "thriller"
  // read the same.
  function renderTagChips(lines){
    var tags = [];
    lines.join('\n').split(/[\n,]+/).forEach(function(t){
      var s = String(t || '').trim().replace(/^#/, '').trim();
      if (s) tags.push(s);
    });
    if (!tags.length) return '';
    return '<div class="awg-aig__tags">' + tags.map(function(t){
      return '<span class="awg-aig__tag">' + applyInlineFormatting(t) + '</span>';
    }).join('') + '</div>';
  }

  // v5.4.88: word-level diff between the before and after text so the change is
  // visible at a glance — removed words are flagged in the Before pane, added
  // words in the After pane. A classic LCS keeps the shared words aligned; only
  // the genuine edits get highlighted. Tokens include their trailing space so a
  // multi-word change reads as one continuous highlight rather than choppy pills.
  function awgDiffSides(beforeStr, afterStr){
    var a = String(beforeStr).split(/(\s+)/);
    var b = String(afterStr).split(/(\s+)/);
    var n = a.length, m = b.length, i, j;
    // LCS length table (suffix form) — both sides are short paragraphs.
    var dp = [];
    for (i = 0; i <= n; i++){ dp[i] = []; for (j = 0; j <= m; j++){ dp[i][j] = 0; } }
    for (i = n - 1; i >= 0; i--){
      for (j = m - 1; j >= 0; j--){
        dp[i][j] = (a[i] === b[j]) ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
    var before = [], after = [];
    i = 0; j = 0;
    while (i < n && j < m){
      if (a[i] === b[j]){ before.push({ t: a[i], c: 0 }); after.push({ t: b[j], c: 0 }); i++; j++; }
      else if (dp[i + 1][j] >= dp[i][j + 1]){ before.push({ t: a[i], c: 1 }); i++; }
      else { after.push({ t: b[j], c: 1 }); j++; }
    }
    while (i < n){ before.push({ t: a[i], c: 1 }); i++; }
    while (j < m){ after.push({ t: b[j], c: 1 }); j++; }
    return { before: before, after: after };
  }

  // Turn a diffed token stream for one pane into HTML: maximal runs of changed
  // tokens are wrapped in a single span (a same-side whitespace token that sits
  // between two changes is pulled into the run so the highlight stays unbroken),
  // and a blank-line token (\n\n) becomes a paragraph break. cls = del | ins.
  function awgRenderDiffSide(tokens, cls){
    var html = '', run = '', open = false;
    function close(){ if (open){ html += '<span class="awg-aig__ba-' + cls + '">' + run + '</span>'; run = ''; open = false; } }
    for (var k = 0; k < tokens.length; k++){
      var tok = tokens[k];
      if (tok.c){
        // v5.4.93 (L1): a changed (added/removed) blank line is still a paragraph
        // break — emit it as one instead of swallowing it into the highlight run,
        // which previously merged both paragraphs inside a single span.
        if (/\n{2,}/.test(tok.t)){ close(); html += '</p><p>'; continue; }
        run += escapeHtml(tok.t); open = true; continue;
      }
      if (open && /^\s+$/.test(tok.t) && !/\n{2,}/.test(tok.t)){
        var next = tokens[k + 1];
        if (next && next.c){ run += escapeHtml(tok.t); continue; }
      }
      close();
      if (/\n{2,}/.test(tok.t)){ html += '</p><p>'; }
      else { html += escapeHtml(tok.t); }
    }
    close();
    // Run the inline markdown pass over the assembled (already-escaped) HTML so
    // bold/italic/code/links inside a compare block still render — the diff
    // escaped each token but did not format it. Emphasis that sits wholly inside
    // one run (the common case) formats correctly even though spans are present.
    return '<p>' + awgInlineMarkup(html) + '</p>';
  }

  // v5.4.80: ```compare fence — a separator line (===, ---, ~~~ or "vs") splits
  // the author's original (before) from the revision (after), shown side by side.
  // v5.4.88: the two sides are word-diffed so the exact change is highlighted in
  // place. No separator → fall back to a code block so nothing is silently lost.
  function renderBeforeAfter(lines){
    // v5.4.93 (H1): split on EVERY separator line, not just the first. A model
    // that packs several original/revision pairs into one compare block now
    // renders as stacked Before/After rows instead of leaking a literal "===" and
    // a jumbled single pane. With the companion prompt change (one pair per
    // block) the common case is still a single separator → one pair, unchanged.
    var sep = /^(={2,}|-{3,}|~{3,}|vs\.?)$/i;
    var segments = [], seg = [];
    lines.forEach(function(l){
      if (sep.test(String(l || '').trim())){ segments.push(seg); seg = []; return; }
      seg.push(l);
    });
    segments.push(seg);
    // No separator at all → nothing to compare; show verbatim so nothing is lost.
    if (segments.length < 2){
      return '<pre><code>' + lines.map(escapeHtml).join('\n') + '</code></pre>';
    }

    // ~400 words/side keeps the O(words²) LCS table cheap. v5.4.93 (M1): the diff
    // is also skipped while a stream is live (AWG_LIVE) — it re-runs every frame,
    // so we show plain prose during streaming and diff once on the final render.
    var DIFF_WORD_CAP = 400;
    var paneFmt = function(t){
      return t.split(/\n{2,}/).map(function(p){
        return '<p>' + applyInlineFormatting(p.replace(/\n/g, ' ').trim()) + '</p>';
      }).join('');
    };
    var row = function(beforeStr, afterStr){
      var b = String(beforeStr || '').trim(), a = String(afterStr || '').trim();
      if (!b && !a) return '';
      var beforeHtml, afterHtml;
      var tooBig = b.split(/\s+/).length > DIFF_WORD_CAP || a.split(/\s+/).length > DIFF_WORD_CAP;
      if (b && a && !tooBig && !AWG_LIVE){
        var d = awgDiffSides(b, a);
        beforeHtml = awgRenderDiffSide(d.before, 'del');
        afterHtml = awgRenderDiffSide(d.after, 'ins');
      } else {
        beforeHtml = paneFmt(b); afterHtml = paneFmt(a);
      }
      return '<div class="awg-aig__ba">' +
          '<div class="awg-aig__ba-side awg-aig__ba-before"><div class="awg-aig__ba-cap">Before</div>' + beforeHtml + '</div>' +
          '<div class="awg-aig__ba-side awg-aig__ba-after"><div class="awg-aig__ba-cap">After</div>' + afterHtml + '</div>' +
        '</div>';
    };

    // Pair segments sequentially: (0,1), (2,3), … A lone trailing segment pairs
    // with an empty side so its text still shows.
    var rows = [];
    for (var i = 0; i < segments.length; i += 2){
      var html = row(segments[i].join('\n'), (segments[i + 1] || []).join('\n'));
      if (html) rows.push(html);
    }
    if (!rows.length){
      return '<pre><code>' + lines.map(escapeHtml).join('\n') + '</code></pre>';
    }
    return rows.join('');
  }

  // v5.4.88: ```fixcards fence — actionable line notes. Each card quotes the
  // problem line, shows the suggested rewrite, an optional why-note, and a
  // one-click "Copy fix" button that copies just the rewrite. Cards are split on
  // a blank line; within a card the first line is the problem, the line marked
  // with a leading >>, >, ===, → or -> is the fix, and any remaining lines are
  // the note. Surrounding quotes on the problem line are stripped for display.
  function renderFixCards(lines){
    var groups = [], cur = [];
    lines.forEach(function(l){
      var s = String(l || '').trim();
      if (!s){ if (cur.length){ groups.push(cur); cur = []; } return; }
      cur.push(s);
    });
    if (cur.length) groups.push(cur);

    // v5.4.93 (L2): prefer an unambiguous "strong" marker (>>, ===, →, ->) when
    // locating the rewrite line, so a why-note that merely starts with "-" can't
    // be mistaken for the fix. A weak marker (>, -, –, —) is used only as a
    // fallback when no strong marker is present.
    var strong = /^\s*(>>+|={2,}|→|->)\s*/;
    var weak   = /^\s*(>|[-–—])\s*/;
    var marker = /^\s*(>>+|={2,}|→|->|>|[-–—])\s*/;
    var DIFF_CAP = 400;

    var cards = [];
    groups.forEach(function(g){
      var problem = '', fix = '', note = [], k;
      var stripQuotes = function(s){ return String(s).replace(/^\s*["“'']+\s*/, '').replace(/\s*["”'']+\s*$/, '').trim(); };
      var fixIx = -1;
      for (k = 1; k < g.length; k++){ if (strong.test(g[k])){ fixIx = k; break; } }
      if (fixIx === -1){ for (k = 1; k < g.length; k++){ if (weak.test(g[k])){ fixIx = k; break; } } }
      problem = stripQuotes(g[0]);
      if (fixIx === -1){
        // No explicit marker: the second line is the fix, the rest is the note.
        fix = (g[1] || '').trim();
        note = g.slice(2);
      } else {
        fix = g[fixIx].replace(marker, '').trim();
        var consumed = fixIx;
        // v5.4.93 (H2): the model sometimes puts the marker (">>") alone on its
        // own line with the rewrite on the NEXT line. Treat that next line as the
        // fix instead of dropping the card (which used to dump the whole block as
        // raw code).
        if (!fix && g[fixIx + 1] != null){ fix = g[fixIx + 1]; consumed = fixIx + 1; }
        note = g.slice(1, fixIx).concat(g.slice(consumed + 1));
      }
      fix = stripQuotes(fix);
      // Notes can carry their own leading marker (the model often prefixes the
      // why-line with ">>" too); strip it so it doesn't show as literal text.
      var noteHtml = note.map(function(l){ return String(l).replace(marker, '').trim(); })
        .filter(function(l){ return l; }).join(' ').trim();
      if (!problem || !fix) return;
      // v5.4.93 (L6) / v5.4.96: word-level highlight on BOTH sides — only the
      // words that actually changed are flagged (removed words red-struck in the
      // problem line, added words green in the rewrite), instead of colouring the
      // whole problem line red and tinting the whole rewrite box. Falls back to
      // plain text when there's no counterpart to diff against, the passage is
      // huge, or a stream is live. The diff spans add no characters, so "Copy fix"
      // (which reads .text()) still copies the full rewrite.
      var stripP = function(h){ return h.replace(/^<p>/, '').replace(/<\/p>\s*$/, '').replace(/<\/p>\s*<p>/g, '<br>'); };
      var problemHtml, fixHtml;
      if (problem && fix && problem.split(/\s+/).length <= DIFF_CAP && fix.split(/\s+/).length <= DIFF_CAP && !AWG_LIVE){
        var fd = awgDiffSides(problem, fix);
        problemHtml = stripP(awgRenderDiffSide(fd.before, 'del'));
        fixHtml = stripP(awgRenderDiffSide(fd.after, 'ins'));
      } else {
        problemHtml = applyInlineFormatting(problem);
        fixHtml = applyInlineFormatting(fix);
      }
      cards.push(
        '<div class="awg-aig__fix">' +
          '<div class="awg-aig__fix-problem">' + problemHtml + '</div>' +
          '<div class="awg-aig__fix-label">Suggested rewrite</div>' +
          '<div class="awg-aig__fix-new"><span class="awg-aig__fix-text">' + fixHtml + '</span></div>' +
          (noteHtml ? '<div class="awg-aig__fix-note">' + applyInlineFormatting(noteHtml) + '</div>' : '') +
          '<button type="button" class="awg-aig__fix-copy">Copy fix</button>' +
        '</div>'
      );
    });
    if (!cards.length) return '';
    return '<div class="awg-aig__fixcards">' + cards.join('') + '</div>';
  }

  // v5.4.86: ```scorecard fence — each "Label: 8/10" line becomes a labelled
  // mini rating bar, so a critique can score several dimensions at once
  // (Clarity, Pacing, Voice…). Lines without a "n/m" score are ignored so a
  // stray sentence can't break the card. Tier wording matches the single
  // rating bar for consistency.
  function renderScorecard(lines){
    var rows = [];
    lines.forEach(function(l){
      var s = String(l || '').trim();
      if (!s) return;
      var m = s.match(/^(.+?)\s*[:=]\s*(\d+(?:\.\d+)?)\s*\/\s*(\d+)\s*$/);
      if (!m) return;
      var label = m[1].trim();
      var score = parseFloat(m[2]);
      var max = parseFloat(m[3]) || 10;
      if (!isFinite(score) || !isFinite(max) || max <= 0 || score > max) return;
      var pct = Math.max(0, Math.min(100, (score / max) * 100));
      var num = (Math.round(score * 10) / 10);
      rows.push(
        '<div class="awg-aig__sc-row">' +
          '<div class="awg-aig__sc-head">' +
            '<span class="awg-aig__sc-label">' + applyInlineFormatting(label) + '</span>' +
            '<span class="awg-aig__sc-num">' + num + '<span class="awg-aig__sc-max">/' + max + '</span></span>' +
          '</div>' +
          '<div class="awg-aig__sc-bar"><span style="width:' + pct + '%"></span></div>' +
        '</div>'
      );
    });
    if (!rows.length) return '';
    return '<div class="awg-aig__scorecard">' + rows.join('') + '</div>';
  }

  // v5.4.86: callout icon — a small line-art glyph tinted by the box colour
  // (stroke:currentColor) so it recolours cleanly in dark mode.
  function calloutIconSvg(cls){
    var s = 'fill:none;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round;stroke:currentColor;';
    if (cls === 'tip') return '<svg viewBox="0 0 24 24" class="awg-aig__callout-ic" aria-hidden="true"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.7.7 1 1.4 1 2.5h6c0-1.1.3-1.8 1-2.5A6 6 0 0 0 12 3Z" style="' + s + '"/></svg>';
    if (cls === 'warn') return '<svg viewBox="0 0 24 24" class="awg-aig__callout-ic" aria-hidden="true"><path d="M12 3 2 20h20L12 3Z" style="' + s + '"/><path d="M12 10v4M12 17h.01" style="' + s + '"/></svg>';
    return '<svg viewBox="0 0 24 24" class="awg-aig__callout-ic" aria-hidden="true"><circle cx="12" cy="12" r="9" style="' + s + '"/><path d="M12 11v5M12 8h.01" style="' + s + '"/></svg>';
  }

  // v5.4.86: ```tip / ```note / ```warning fence — an admonition box (tinted
  // background + coloured left edge + icon) for guidance that should stand out
  // from the prose. Body keeps paragraph breaks and inline formatting.
  function renderCallout(lines, kind){
    var body = lines.join('\n').trim();
    if (!body) return '';
    var map = {
      tip:     { cls: 'tip',  label: 'Tip' },
      note:    { cls: 'note', label: 'Note' },
      info:    { cls: 'note', label: 'Note' },
      warning: { cls: 'warn', label: 'Warning' },
      caution: { cls: 'warn', label: 'Caution' }
    };
    var k = map[kind] || map.note;
    // A redundant leading "Tip:"/"Note:" label is stripped so it isn't shown twice.
    body = body.replace(new RegExp('^\\**\\s*' + k.label + '\\s*\\**\\s*[:\\-—]\\s*', 'i'), '');
    var paras = body.split(/\n{2,}/).map(function(p){
      return '<p>' + applyInlineFormatting(p.replace(/\n/g, ' ').trim()) + '</p>';
    }).join('');
    return '<div class="awg-aig__callout awg-aig__callout--' + k.cls + '">' +
        '<div class="awg-aig__callout-head">' + calloutIconSvg(k.cls) +
          '<span class="awg-aig__callout-label">' + escapeHtml(k.label) + '</span></div>' +
        '<div class="awg-aig__callout-body">' + paras + '</div>' +
      '</div>';
  }

  // v5.4.86: ```proscons fence — a separator line (===, ---, ~~~ or "vs"), or a
  // "Cons"/"Pros" header, splits the upsides (green) from the downsides (red).
  // Leading bullet markers are stripped so plain or "- " lists both work.
  function renderProsCons(lines){
    var pros = [], cons = [], cur = pros, split = false;
    lines.forEach(function(l){
      var s = String(l || '').trim();
      if (!s) return;
      if (/^(={2,}|-{3,}|~{3,}|vs\.?)$/i.test(s)){ cur = cons; split = true; return; }
      if (/^\**\s*(cons?|against|weaknesses?|limitations?|downsides?|risks?)\s*:?\s*\**$/i.test(s)){ cur = cons; split = true; return; }
      if (/^\**\s*(pros?|for|strengths?|upsides?|benefits?)\s*:?\s*\**$/i.test(s)){ cur = pros; return; }
      cur.push(s.replace(/^[-*•]\s+/, ''));
    });
    if (!pros.length && !cons.length) return '';
    var li = function(arr){
      return arr.map(function(t){ return '<li>' + applyInlineFormatting(t) + '</li>'; }).join('');
    };
    var side = function(cls, cap, arr){
      return '<div class="awg-aig__pc-side awg-aig__pc-' + cls + '">' +
          '<div class="awg-aig__pc-cap">' + cap + '</div><ul>' + li(arr) + '</ul></div>';
    };
    return '<div class="awg-aig__pc">' + side('pros', 'Pros', pros) + side('cons', 'Cons', cons) + '</div>';
  }

  // v5.4.86: ```steps fence — each line becomes a numbered step card for
  // actionable, in-order guidance. Existing "1." / "-" markers are stripped so
  // the numbering is always clean and sequential.
  function renderSteps(lines){
    var steps = [];
    lines.forEach(function(l){
      var s = String(l || '').trim();
      if (!s) return;
      s = s.replace(/^\s*(?:\d+[.)]|[-*•])\s+/, '');
      if (s) steps.push(s);
    });
    if (!steps.length) return '';
    return '<ol class="awg-aig__steps">' + steps.map(function(t){
      return '<li class="awg-aig__step">' +
          '<span class="awg-aig__step-n"></span>' +
          '<span class="awg-aig__step-t">' + applyInlineFormatting(t) + '</span>' +
        '</li>';
    }).join('') + '</ol>';
  }

  // v5.4.86: ```pullquote fence — a large display quote with optional
  // attribution. A line beginning with an em/en dash, a hyphen or "by " is read
  // as the attribution; everything else is the quote body.
  function renderPullQuote(lines){
    var body = [], who = '';
    lines.forEach(function(l){
      var s = String(l || '').trim();
      if (!s) return;
      var m = s.match(/^(?:[—–]\s*|-{1,2}\s+|by\s+)(.+)$/i);
      if (m){ who = m[1].trim(); return; }
      body.push(s);
    });
    var text = body.join(' ').trim();
    if (!text) return '';
    return '<figure class="awg-aig__pull">' +
        '<blockquote class="awg-aig__pull-q">' + applyInlineFormatting(text) + '</blockquote>' +
        (who ? '<figcaption class="awg-aig__pull-by">' + applyInlineFormatting(who) + '</figcaption>' : '') +
      '</figure>';
  }

  function formatPlainTextResult(text, forced){
    const lines = String(text || '').replace(/\r\n/g, '\n').split('\n');
    const mode = (forced === 'list' || forced === 'document') ? forced : detectResultMode(lines);
    const parts = [];
    let paragraph = [];
    let listItems = [];
    let listType = '';
    let tableRows = [];     // buffered "| a | b |" markdown table rows
    let quoteRows = [];     // buffered "> quoted" blockquote lines
    let fenceLines = [];    // v5.4.67: buffered ```fenced code``` body lines
    let inFence = false;    // currently inside an open ``` / ~~~ code fence
    let fenceInfo = '';     // v5.4.80: the fence's info string (stats|tags|compare)
    let cardSeq = 0;        // running number for ordered option-cards (list mode)
    let pointCounter = 0;   // restarts at every section heading
    let sawHeading = false; // v5.4.81: a section heading has appeared in this result
    let proseCount = 0;     // v5.4.81: paragraphs flushed so far (preamble tolerance)

    // Document mode only: pull out the rating as a stat block at the very top.
    const rating = (mode === 'document') ? findRating(lines) : null;
    const skipLine = {};
    if (rating){ rating.skip.forEach(function(ix){ skipLine[ix] = true; }); }

    function flushParagraph(){
      if (!paragraph.length) return;
      const html = applyInlineFormatting(paragraph.join(' '));
      // v5.8.1: paragraphs always render plain — the keyword "verdict" auto-
      // callout was removed. Use an explicit ```note / ```tip block for emphasis.
      parts.push('<p>' + html + '</p>');
      proseCount += 1;
      paragraph = [];
    }

    // Render the buffered markdown table. The "|---|---|" divider row (if any)
    // splits the header from the body; cells get inline formatting. Cells are
    // never decided by length — this is pure structure.
    function flushTable(){
      if (!tableRows.length) return;
      const rows = tableRows.map(function(r){
        return r.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').map(function(c){ return c.trim(); });
      });
      tableRows = [];
      const isDivider = function(cells){
        return cells.length && cells.every(function(c){ return /^:?-{2,}:?$/.test(c.replace(/\s+/g, '')); });
      };
      let sepIdx = -1;
      for (let i = 0; i < rows.length; i++){ if (isDivider(rows[i])){ sepIdx = i; break; } }
      const headRows = sepIdx > 0 ? rows.slice(0, sepIdx) : [];
      const bodyRows = (sepIdx >= 0 ? rows.slice(sepIdx + 1) : rows).filter(function(r){ return !isDivider(r); });
      let html = '<table class="awg-aig__table">';
      if (headRows.length){
        html += '<thead>' + headRows.map(function(cells){
          return '<tr>' + cells.map(function(c){ return '<th>' + applyInlineFormatting(c) + '</th>'; }).join('') + '</tr>';
        }).join('') + '</thead>';
      }
      html += '<tbody>' + bodyRows.map(function(cells){
        return '<tr>' + cells.map(function(c){ return '<td>' + applyInlineFormatting(c) + '</td>'; }).join('') + '</tr>';
      }).join('') + '</tbody></table>';
      parts.push(html);
    }

    // v5.4.67: render a buffered fenced code block as <pre><code>. Content is
    // escaped (never formatted) and kept verbatim so indentation survives. Called
    // on the closing fence, and at the end for an unclosed fence (a response
    // truncated by the token cap, or the in-progress frame during streaming).
    function flushFence(){
      if (fenceLines.length){
        // v5.4.80: a fence tagged ```stats / ```tags / ```compare renders as the
        // matching structured block; everything else stays a verbatim code block.
        // v5.4.89: each structured renderer returns '' when the fenced content
        // doesn't match its expected shape (e.g. a ```stats block with no
        // "Label: Value" lines). In that case we fall back to the verbatim code
        // block below so the AI's text is shown rather than silently dropped.
        var rendered = null;
        if (fenceInfo === 'stats' || fenceInfo === 'metrics') {
          rendered = renderStatGrid(fenceLines);
        } else if (fenceInfo === 'tags' || fenceInfo === 'keywords') {
          rendered = renderTagChips(fenceLines);
        } else if (fenceInfo === 'compare' || fenceInfo === 'ba' || fenceInfo === 'beforeafter') {
          rendered = renderBeforeAfter(fenceLines);
        } else if (fenceInfo === 'scorecard' || fenceInfo === 'scores' || fenceInfo === 'ratings') {
          rendered = renderScorecard(fenceLines);
        } else if (fenceInfo === 'tip' || fenceInfo === 'note' || fenceInfo === 'info' || fenceInfo === 'warning' || fenceInfo === 'caution') {
          rendered = renderCallout(fenceLines, fenceInfo);
        } else if (fenceInfo === 'proscons' || fenceInfo === 'pros-cons' || fenceInfo === 'pros_cons') {
          rendered = renderProsCons(fenceLines);
        } else if (fenceInfo === 'steps' || fenceInfo === 'howto' || fenceInfo === 'how-to') {
          rendered = renderSteps(fenceLines);
        } else if (fenceInfo === 'pullquote' || fenceInfo === 'pull-quote') {
          rendered = renderPullQuote(fenceLines);
        } else if (fenceInfo === 'fixcards' || fenceInfo === 'fix-cards' || fenceInfo === 'fix_cards' || fenceInfo === 'fix' || fenceInfo === 'fixcard' || fenceInfo === 'suggestions' || fenceInfo === 'suggestion' || fenceInfo === 'fixes') {
          rendered = renderFixCards(fenceLines);
        }
        if (rendered) {
          parts.push(rendered);
        } else {
          // Default code block — also the safety net for a structured block whose
          // content didn't parse, so nothing the AI produced is ever lost.
          parts.push('<pre><code>' + fenceLines.map(escapeHtml).join('\n') + '</code></pre>');
        }
        fenceLines = [];
      }
      fenceInfo = '';
      inFence = false;
    }

    // Render the buffered blockquote. A bare ">" line is a paragraph break
    // inside the quote; nested ">>" collapses to a single quote level.
    function flushQuote(){
      if (!quoteRows.length) return;
      const paras = [];
      let cur = [];
      quoteRows.forEach(function(q){
        if (q === ''){ if (cur.length){ paras.push(cur.join(' ')); cur = []; } }
        else { cur.push(q); }
      });
      if (cur.length) paras.push(cur.join(' '));
      quoteRows = [];
      const inner = paras.map(function(p){ return '<p>' + applyInlineFormatting(p) + '</p>'; }).join('');
      parts.push('<blockquote>' + inner + '</blockquote>');
    }

    // Split a bullet into a bold lead-in label + description. Only treats the
    // bold as a label when the remainder is a real description (doesn't start
    // with a comma/conjunction) — avoids "**…strong**, with…" splitting badly.
    function parsePoint(item){
      const m = item.match(/^\*\*(.+?):?\*\*:?\s*([\s\S]*)$/);
      if (m){
        const rest = (m[2] || '').trim();
        if (rest && !/^[,;)–-]/.test(rest)){
          return { title: applyInlineFormatting(m[1].replace(/[:.]\s*$/, '')), desc: applyInlineFormatting(rest), plain: false };
        }
      }
      // Plain-text "Label: description" lead-in (no markdown). Treat the part
      // before the first colon as a sub-heading ONLY when it reads like a real
      // label — a short phrase (<= 6 words), no sentence punctuation, doesn't
      // start with a digit — and a genuine description follows. This keys the
      // styling off STRUCTURE (sub-heading vs paragraph), not sentence length.
      const c = item.match(/^([^:]{2,60}):\s+(\S[\s\S]+)$/);
      if (c){
        const label = c[1].trim();
        const rest = c[2].trim();
        if (label.split(/\s+/).length <= 6 && /[A-Za-z]/.test(label) && !/[.!?]$/.test(label) && !/^\d/.test(label) && rest){
          return { title: applyInlineFormatting(label), desc: applyInlineFormatting(rest), plain: false };
        }
      }
      // Otherwise it's a paragraph-style point with no heading structure →
      // render as a uniform body line. Any intentional inline **bold** is still
      // honoured. Styling is never decided by how short or long the line is.
      return { title: applyInlineFormatting(item), desc: '', plain: true };
    }

    // v5.4.68: render an item's nested sub-bullets (one level) as an indented
    // list. Empty for the common flat case, so non-nested output is unchanged.
    function childrenHtml(children){
      if (!children || !children.length) return '';
      return '<ul class="awg-aig__subitems">' + children.map(function(c){
        return '<li>' + applyInlineFormatting(c) + '</li>';
      }).join('') + '</ul>';
    }

    function flushListAsPoints(){
      const parsed = listItems.map(function(it){ return { item: it.raw, children: it.children, p: parsePoint(it.raw) }; });
      // Consistency guard: use the rich "sub-heading + description" layout for
      // the WHOLE list only when EVERY item actually has that structure. When
      // the model labels just some items (e.g. one "Label: detail" among plain
      // sentences) the rest stay plain — so a single point would otherwise show
      // as a bold sub-heading while its siblings don't. In that mixed case we
      // render every point as a uniform body line, so no item stands out.
      const allLabeled = parsed.length > 0 && parsed.every(function(x){ return !x.p.plain; });
      const rows = parsed.map(function(x){
        pointCounter += 1;
        // v5.4.87: per-point status icons (green tick / red cross) removed by
        // request — numbered editorial points now read as a clean article list
        // with no trailing sign. The pass/fail checklist block (.awg-aig__checks)
        // still keeps its own icons; this only affects the .awg-aig__pts block.
        const title = allLabeled ? x.p.title : applyInlineFormatting(x.item);
        const desc = allLabeled ? x.p.desc : '';
        const titleClass = allLabeled ? 'awg-aig__pt-title' : 'awg-aig__pt-title awg-aig__pt-title--plain';
        return '<div class="awg-aig__pt">' +
            '<div class="awg-aig__pt-num">' + pad2(pointCounter) + '</div>' +
            '<div class="awg-aig__pt-body">' +
              '<div class="' + titleClass + '"><span>' + title + '</span></div>' +
              (desc ? '<div class="awg-aig__pt-desc">' + desc + '</div>' : '') +
              childrenHtml(x.children) +
            '</div>' +
          '</div>';
      });
      parts.push('<div class="awg-aig__pts">' + rows.join('') + '</div>');
    }

    // v5.4.81: Editorial has ONE list block. A bare "menu of options" (a short
    // flat list with no preceding section heading, no rating, and no real
    // surrounding prose) renders as copyable option-cards; anything that belongs
    // to a section renders as numbered point-rows. Decided locally per list so a
    // tool's look is stable across runs — no whole-result mode flip, and the old
    // "Card list" style is now just this branch of Editorial.
    function isOptionList(){
      if (sawHeading || rating || proseCount > 1) return false;
      return listItems.every(function(it){
        if (it.children && it.children.length) return false;   // nested => structured
        var t = String(it.raw || '').trim();
        if (!t || t.length > 90) return false;                 // long => prose point
        if (/[.!?:]$/.test(t)) return false;                   // sentence end => prose
        return parsePoint(t).plain;                            // "Label: desc" => point
      });
    }

    function flushList(){
      if (!listItems.length || !listType) return;
      // v5.4.80: GFM task list "- [x] / - [ ]" → checklist block (pass/fail rows).
      // Only when EVERY item is a task item, so a normal list with one stray
      // "[x]" never half-converts. Works in any mode (cards or document).
      var taskRe = /^\[([ xX])\]\s+(.*)$/;
      var allTasks = listItems.every(function(it){ return taskRe.test(String(it.raw || '').trim()); });
      if (allTasks){
        parts.push('<div class="awg-aig__checks">' + listItems.map(function(it){
          var m = String(it.raw).trim().match(taskRe);
          var done = m[1] !== ' ';
          return '<div class="awg-aig__check">' +
              '<span class="awg-aig__check-ic awg-aig__check-ic--' + (done ? 'ok' : 'no') + '" aria-hidden="true">' + (done ? '✓' : '✕') + '</span>' +
              '<span class="awg-aig__check-txt">' + applyInlineFormatting(m[2]) + '</span>' +
            '</div>';
        }).join('') + '</div>');
        listItems = [];
        listType = '';
        return;
      }
      const isOrdered = listType === 'ol';
      if (isOptionList()) {
        // Option cards: badge + content + per-item copy button. The badge uses
        // a running counter (not the per-list index) so options stay 1,2,3… even
        // when the model separates them with blank lines — which otherwise makes
        // each item its own one-item list and resets every badge to "1".
        parts.push('<div class="awg-aig__result-list awg-aig__result-list--' + (isOrdered ? 'ordered' : 'unordered') + '">' + listItems.map(function(item){
          return '<div class="awg-aig__result-item">' +
            '<div class="awg-aig__result-badge">' + (isOrdered ? (++cardSeq) : '•') + '</div>' +
            '<div class="awg-aig__result-item-content">' + applyInlineFormatting(item.raw) + childrenHtml(item.children) + '</div>' +
            '<button type="button" class="awg-aig__item-copy" aria-label="Copy"><span class="dashicons dashicons-clipboard" aria-hidden="true"></span></button>' +
          '</div>';
        }).join('') + '</div>');
      } else {
        // Document mode: EVERY list renders as the numbered editorial rows, so
        // the look is uniform across sections and results.
        flushListAsPoints();
      }
      listItems = [];
      listType = '';
    }

    // Document headings render as eyebrow labels and restart the point numbering.
    function pushDocHeading(textRaw){
      // v5.4.94: never render a heading that is just an internal block name. The
      // model sometimes labels a block with its own jargon (## FIXCARDS, ## proscons,
      // ## Scorecard), which should never reach the reader. Only the non-English
      // compound forms are dropped, so natural headings like "Pros & Cons",
      // "Checklist" or "Steps" are untouched.
      var key = String(textRaw || '').toLowerCase().replace(/\s+/g, ' ').replace(/[:\s\-–—]+$/, '').trim();
      var BLOCK_WORDS = {
        'fixcards':1,'fixcard':1,'fix-cards':1,'fix_cards':1,'fix cards':1,'suggestion fix cards':1,
        'proscons':1,'pros-cons':1,'pros_cons':1,'scorecard':1,'scorecards':1,
        'pullquote':1,'pull-quote':1,'beforeafter':1,'before-after':1
      };
      if (BLOCK_WORDS[key]) return;
      flushParagraph();
      flushList();
      flushTable();
      flushQuote();
      pointCounter = 0;
      sawHeading = true;
      parts.push('<div class="awg-aig__doc-eyebrow">' + applyInlineFormatting(textRaw) + '</div>');
    }

    // Is the next non-blank line a list item? (used to spot bare headings)
    function nextIsListItem(fromIndex){
      for (var k = fromIndex + 1; k < lines.length; k++){
        var s = String(lines[k] || '').trim();
        if (!s) continue;
        return /^(\d+[.)]\s+|[-*•]\s+)/.test(s);
      }
      return false;
    }

    lines.forEach(function(rawLine, idx){
      if (skipLine[idx]) return;
      const line = String(rawLine || '').trim();
      // v5.4.68: leading-whitespace width (tabs counted as 4) used to detect a
      // nested list item — a bullet indented under the previous top-level item.
      const indent = (String(rawLine).match(/^[ \t]*/)[0] || '').replace(/\t/g, '    ').length;

      // v5.4.67: fenced code blocks (``` or ~~~). While a fence is open every
      // line is taken verbatim (raw, untrimmed — indentation matters in code)
      // until the closing fence. Checked before the blank-line handler so blank
      // lines inside code are preserved.
      const isFenceMarker = /^(```|~~~)/.test(line);
      if (inFence) {
        if (isFenceMarker) { flushFence(); }
        else { fenceLines.push(rawLine); }
        return;
      }
      if (isFenceMarker) {
        flushParagraph();
        flushList();
        flushTable();
        flushQuote();
        inFence = true;
        fenceLines = [];
        // v5.4.80: remember the info string (e.g. ```stats) so the close knows
        // whether to render a code block or one of the structured blocks below.
        fenceInfo = line.replace(/^(```|~~~)/, '').trim().toLowerCase();
        return;
      }

      if (!line) {
        flushParagraph();
        flushList();
        flushTable();
        flushQuote();
        return;
      }

      // Markdown table row: "| a | b |". Buffer consecutive rows; flush on any
      // other block. Requires outer pipes so a stray "a | b" sentence is safe.
      if (/^\|.*\|$/.test(line)) {
        flushParagraph();
        flushList();
        flushQuote();
        tableRows.push(line);
        return;
      }

      // Blockquote line: "> quoted". Buffer consecutive lines; ">>" collapses
      // to one level and a bare ">" is a paragraph break within the quote.
      const quoteMatch = line.match(/^>+\s?(.*)$/);
      if (quoteMatch) {
        flushParagraph();
        flushList();
        flushTable();
        quoteRows.push(quoteMatch[1].trim());
        return;
      }

      const headingMatch = line.match(/^(#{1,4})\s+(.+)$/);
      if (headingMatch) {
        if (mode === 'document') {
          pushDocHeading(headingMatch[2].replace(/\s*[*_#]+\s*$/, ''));
        } else {
          flushParagraph(); flushList(); flushTable(); flushQuote();
          // v5.4.62: accept a single "#" (H1) too. Clamp to h2–h4 so it uses the
          // styled heading sizes (front.css styles h2–h4; a bare h1 would inherit
          // the theme's oversized default).
          const level = Math.min(4, Math.max(2, headingMatch[1].length));
          parts.push('<h' + level + '>' + applyInlineFormatting(headingMatch[2]) + '</h' + level + '>');
        }
        return;
      }

      if (mode === 'document') {
        // Wholly-bold line, a known section label (plain text), or a short
        // bare line followed by a list all act as section headings.
        const boldHeading = line.match(/^\*\*(.+?)\*\*:?\s*$/);
        if (boldHeading) { pushDocHeading(boldHeading[1]); return; }

        if (AWG_HEAD_STANDALONE.test(line)) {
          pushDocHeading(line.replace(/[#*_:]+/g, ' ').trim());
          return;
        }

        const inlineHead = line.match(AWG_HEAD_INLINE);
        if (inlineHead) {
          pushDocHeading(inlineHead[1]);
          paragraph.push(inlineHead[2]);
          return;
        }

        const words = line.split(/\s+/).length;
        if (line.length <= 48 && words <= 7 && !/[.!?,:;]$/.test(line) && !/^[-*•\d]/.test(line) && nextIsListItem(idx)) {
          pushDocHeading(line);
          return;
        }
      }

      if (/^[-*_]{3,}$/.test(line)) {
        flushParagraph();
        flushList();
        flushTable();
        flushQuote();
        parts.push('<hr>');
        return;
      }

      const orderedMatch = line.match(/^\d+[.)]\s+(.+)$/);
      const unorderedMatch = orderedMatch ? null : line.match(/^[-*•]\s+(.+)$/);
      if (orderedMatch || unorderedMatch) {
        const itemText = orderedMatch ? orderedMatch[1] : unorderedMatch[1];
        const thisType = orderedMatch ? 'ol' : 'ul';
        // v5.4.68: an indented bullet under an existing top-level item is a
        // nested sub-item — attach it to that item's children instead of
        // promoting it to its own point (which previously flattened, e.g. broke
        // a 4-step list with sub-details into 8 sibling points). One level deep;
        // deeper indents collapse to this level. Never flushes, so it doesn't
        // split the parent list.
        if (indent >= 2 && listItems.length) {
          listItems[listItems.length - 1].children.push(itemText);
          return;
        }
        flushParagraph();
        flushTable();
        flushQuote();
        if (listType && listType !== thisType) flushList();
        listType = thisType;
        listItems.push({ raw: itemText, children: [] });
        return;
      }

      flushList();
      flushTable();
      flushQuote();
      paragraph.push(line);
    });

    flushParagraph();
    flushList();
    flushTable();
    flushQuote();
    flushFence();   // v5.4.67: close an unclosed fence (truncated / mid-stream)

    let html = parts.join('');
    if (rating){ html = ratingStatHtml(rating.score, rating.max) + html; }
    return html || ('<p>' + applyInlineFormatting(text) + '</p>');
  }


  // v5.4.78: "Plain text" result style. A deliberately minimal renderer for
  // single-answer tools (blurbs, bios, summaries, one ad): blank-line-separated
  // blocks become paragraphs, single newlines become <br> so intentional line
  // breaks are kept, and inline **bold** / *italic* / `code` / [links] are still
  // honoured (and HTML-escaped) via applyInlineFormatting. No cards, eyebrows,
  // numbered points, status icons or rating block — just clean prose. A stray
  // markdown heading is flattened to a bold line so nothing renders as raw "##".
  function formatPlainProse(text){
    var blocks = String(text || '').replace(/\r\n/g, '\n').trim().split(/\n{2,}/);
    var html = blocks.map(function(block){
      var lines = block.split('\n').map(function(line){
        var l = line.trim();
        var h = l.match(/^#{1,6}\s+(.+?)\s*#*$/);
        if (h) return '<strong>' + applyInlineFormatting(h[1]) + '</strong>';
        return applyInlineFormatting(l);
      });
      return '<p>' + lines.join('<br>') + '</p>';
    }).join('');
    return html || ('<p>' + applyInlineFormatting(text) + '</p>');
  }

  function enhanceOutputCards($out){
    // v5.4.51/53: only turn lists into copyable option-cards when the output is a
    // PURE list (a menu of options). If it carries headings, paragraphs, or any
    // document-mode block (eyebrow labels, numbered points, callout), it's an
    // article/analysis — leave its lists alone so it reads as one document.
    if ($out.find('h1, h2, h3, h4, h5, h6, p, blockquote, pre, table, .awg-aig__doc-eyebrow, .awg-aig__pts').length) return;

    $out.find('ol, ul').each(function(){
      const $list = $(this);
      if ($list.closest('.awg-aig__result-item-content').length) return;
      if ($list.hasClass('awg-aig__result-list') || $list.hasClass('awg-aig__doc-list')) return;

      const isOrdered = $list.is('ol');
      const items = [];
      $list.children('li').each(function(index){
        const $li = $(this);
        items.push(
          '<div class="awg-aig__result-item">' +
            '<div class="awg-aig__result-badge">' + (isOrdered ? (index + 1) : '•') + '</div>' +
            '<div class="awg-aig__result-item-content">' + $li.html() + '</div>' +
            '<button type="button" class="awg-aig__item-copy" aria-label="Copy"><span class="dashicons dashicons-clipboard" aria-hidden="true"></span></button>' +
          '</div>'
        );
      });

      if (!items.length) return;
      $list.replaceWith(
        '<div class="awg-aig__result-list awg-aig__result-list--' + (isOrdered ? 'ordered' : 'unordered') + '">' +
          items.join('') +
        '</div>'
      );
    });
  }

  // v5.4.25: show how many list items came back, as a small chip in the
  // result heading. Only for multi-item lists; prose results show nothing.
  function updateResultCount($wrap){
    var $head = $wrap.find('.awg-aig__result-head strong');
    if (!$head.length) return;
    $head.find('.awg-aig__result-count').remove();
    var n = $wrap.find('.awg-aig__output .awg-aig__result-list .awg-aig__result-item').length;
    if (n > 1) {
      $head.append('<span class="awg-aig__result-count">' + n + '</span>');
    }
  }

  function renderOutput($wrap, text, format, skipEntrance){
    const $res = $wrap.find('.awg-aig__result');
    const $out = $wrap.find('.awg-aig__output');
    const safeText = String(text || '');

    // v5.9.0: a fresh result invalidates any open "Discuss with agent" chat.
    if (typeof resetDiscuss === 'function') { resetDiscuss($wrap); }

    $res.prop('hidden', false).removeClass('is-busy');
    $out.attr('data-format', format || 'text');
    $out.data('raw-text', safeText);
    $out.removeClass('is-formatted');
    // v5.4.66: when the result was just streamed live the cards are already on
    // screen, so suppress the staggered entrance animation on this final render
    // to avoid a visible re-fade. Classic (non-streamed) results keep it — that
    // is their first appearance. Re-toggled every render so it never lingers.
    $out.toggleClass('is-instant', !!skipEntrance);

    const pinned = pinnedMode($out);
    if (format === 'html') {
      $out.html(safeText);
    } else if (pinned === 'plain') {
      $out.html(formatPlainProse(safeText));
      $out.addClass('is-formatted');
    } else {
      $out.html(formatPlainTextResult(safeText, pinned));
      $out.addClass('is-formatted');
    }

    enhanceOutputCards($out);
    updateResultCount($wrap);

    // v5.4.51 / v5.4.81: tag the output with its presentation mode so the
    // stylesheet gives a pure option-list the tight card treatment and any
    // richer/mixed Editorial result the document treatment. Now decided purely
    // by what survived rendering: a result is "list" ONLY when it is nothing but
    // option-cards (no eyebrows, point-rows, rating, callouts or the structured
    // blocks). Plain results take neither class.
    var isListMode = (pinned !== 'plain') && resultIsPureList($out);
    $out.toggleClass('is-list', isListMode).toggleClass('is-document', !isListMode);

    setTimeout(function(){
      const el = $res.get(0);
      if (!el) return;
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
  }


  function setButtonLoading($btn, isLoading, loadingText){
    if (!$btn || !$btn.length) return;

    const stateKey = 'awgLoadingState';
    let state = $btn.data(stateKey);

    if (isLoading) {
      if (!state) {
        const $label = $btn.find('span').last();
        const labelHtml = $label.length ? $label.html() : $btn.html();
        state = {
          disabled: $btn.prop('disabled'),
          labelHtml: labelHtml
        };
        $btn.data(stateKey, state);
      }

      $btn.prop('disabled', true).attr('aria-busy', 'true').addClass('is-loading');

      const $label = $btn.find('span').last();
      if ($label.length) {
        $label.text(loadingText || 'Loading...');
      } else {
        $btn.text(loadingText || 'Loading...');
      }
      return;
    }

    if (!state) {
      $btn.prop('disabled', false).removeAttr('aria-busy').removeClass('is-loading');
      return;
    }

    const $label = $btn.find('span').last();
    if ($label.length) {
      $label.html(state.labelHtml);
    } else {
      $btn.html(state.labelHtml);
    }

    $btn.prop('disabled', !!state.disabled);
    if (state.disabled) {
      $btn.attr('aria-busy', 'true');
    } else {
      $btn.removeAttr('aria-busy');
    }
    $btn.removeClass('is-loading').removeData(stateKey);
  }

  function clearLoadingState($wrap){
    if (!$wrap || !$wrap.length) return;
    setButtonLoading($wrap.find('.awg-aig__btn').first(), false);
    setButtonLoading($wrap.find('.awg-aig__regenerate').first(), false);
  }

  // v5.4.14: lock/unlock all result-area action buttons while a request
  // is in flight. Previously these stayed enabled during loading because
  // they used to be hidden by `.awg-aig__result[hidden]`; v5.4.10 made
  // the result panel visible immediately (for the skeleton loader), which
  // exposed the action buttons before there was anything to act on.
  function setActionsBusy($wrap, busy){
    if (!$wrap || !$wrap.length) return;
    var sel = '.awg-aig__copy, .awg-aig__download, .awg-aig__clear, .awg-aig__regenerate';
    $wrap.find(sel).each(function(){
      var $b = $(this);
      $b.prop('disabled', !!busy);
      if (busy) {
        $b.attr('aria-disabled', 'true').addClass('is-busy');
      } else {
        $b.removeAttr('aria-disabled').removeClass('is-busy');
      }
    });
  }

  function parseResponse(raw){
    if (!raw) return null;
    if (typeof raw === 'object') return raw;
    try {
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  }

  // v5.4.61: current page URL, capped, for the "AI Submissions" source column.
  function srcUrl(){
    return (window.location && window.location.href) ? String(window.location.href).slice(0, 2000) : '';
  }

  // v5.4.61: shared completion handlers used by BOTH the streaming and the
  // classic request paths, so a result lands in the same UI state regardless of
  // how it was fetched. They clear the in-flight guard, unlock the action
  // buttons, drop loading/streaming state, then render the result or the error.
  function finishSuccess($wrap, text, format){
    $wrap.data('awgInFlight', false);
    setActionsBusy($wrap, false);
    hideSkeleton($wrap);
    clearLoadingState($wrap);
    // v5.4.66: capture whether this completion follows a live stream BEFORE the
    // class is dropped. If the tokens were already painted on screen, the final
    // render must not replay the card entrance animation — doing so re-fades the
    // already-visible list, which reads as the result "refreshing" on finish.
    var wasStreaming = $wrap.hasClass('is-streaming');
    $wrap.removeClass('is-streaming');
    $wrap.find('.awg-aig__output').removeData('awgLiveActive');
    status($wrap, 'Done', false);
    renderOutput($wrap, text, format || 'text', wasStreaming);
  }

  function finishError($wrap, msg, cta){
    $wrap.data('awgInFlight', false);
    setActionsBusy($wrap, false);
    hideSkeleton($wrap);
    clearLoadingState($wrap);
    $wrap.removeClass('is-streaming');
    $wrap.find('.awg-aig__output').removeData('awgLiveActive');
    showErrorState($wrap);
    status($wrap, msg || 'Error', true, cta || null);
  }

  // Switch the result panel from the skeleton loader to live streaming on the
  // first token: stop the rotating "thinking" copy, clear the skeleton, and mark
  // the output ready to receive incremental text.
  function beginLiveStream($wrap){
    var interval = $wrap.data('awgThinkingInterval');
    if (interval){ clearInterval(interval); $wrap.removeData('awgThinkingInterval'); }
    $wrap.find('.awg-aig__skeleton').remove();
    var $out = $wrap.find('.awg-aig__output');
    $out.empty().data('awgLiveActive', true);
    $wrap.addClass('is-streaming');
    status($wrap, 'Generating...', false);
  }

  // Render the accumulated streaming text. Throttled to one paint per animation
  // frame so a fast token stream can't thrash the formatter. Uses the same
  // markdown formatter as the final result, so the live preview matches.
  function renderLive($wrap, text){
    var $out = $wrap.find('.awg-aig__output');
    if (!$out.data('awgLiveActive')) return;
    $wrap.data('awgLivePending', text);
    if ($wrap.data('awgRafPending')) return;

    // v5.4.93 (M1): each live paint re-parses the WHOLE accumulated response, so
    // coalesce to at most one repaint per ~120ms instead of one per animation
    // frame. A delta arriving during the wait just updates the pending text; the
    // scheduled paint always renders the latest, and the final `done` render
    // supersedes it — so nothing is dropped, but long streams stay smooth.
    var MIN_MS = 120;
    var wait = Math.max(0, MIN_MS - (Date.now() - ($wrap.data('awgLastPaint') || 0)));
    $wrap.data('awgRafPending', true);
    var paint = function(){
      $wrap.data('awgRafPending', false);
      $wrap.data('awgLastPaint', Date.now());
      if (!$out.data('awgLiveActive')) return;
      var livePinned = pinnedMode($out);
      var livePending = $wrap.data('awgLivePending') || '';
      // Skip the expensive word-level diff while streaming (see AWG_LIVE).
      AWG_LIVE = true;
      try {
        $out.html(livePinned === 'plain' ? formatPlainProse(livePending) : formatPlainTextResult(livePending, livePinned)).addClass('is-formatted');
      } finally {
        AWG_LIVE = false;
      }
      // v5.4.62: tag the live output with the same presentation-mode class the
      // final render uses, so the document-scoped styles — crucially the
      // .is-document status-icon sizing — apply DURING streaming. Without this
      // the unscoped SVG icons balloon to full width until the stream finishes.
      var liveList = (livePinned !== 'plain') && resultIsPureList($out);
      $out.toggleClass('is-list', liveList).toggleClass('is-document', !liveList);
    };
    var schedule = function(){
      if (window.requestAnimationFrame) { window.requestAnimationFrame(paint); }
      else { setTimeout(paint, 16); }
    };
    if (wait <= 0) { schedule(); } else { setTimeout(schedule, wait); }
  }

  // Classic one-shot request. Used when streaming is disabled in Settings, when
  // the browser lacks the streaming APIs, or as the automatic fallback when a
  // streaming attempt can't start.
  function legacyGenerate($wrap, templateId, fields){
    $.ajax({
      url: AWG_AIG.ajaxurl,
      method: 'POST',
      dataType: 'text',
      timeout: 60000,
      data: {
        action: 'awg_aig_generate',
        nonce: AWG_AIG.nonce,
        template_id: templateId,
        fields: fields,
        fields_json: JSON.stringify(fields),
        // Optional label hints for Custom HTML mode (empty object in standard mode).
        fields_labels_json: JSON.stringify($wrap.data('awgLabels') || {}),
        source_url: srcUrl()
      }
    })
    .done(function(raw){
      var res = parseResponse(raw);
      if (!res || !res.success) {
        var ed = (res && res.data) ? res.data : {};
        finishError($wrap, ed.message || 'Error', ed.upgrade_url ? { url: ed.upgrade_url, label: ed.upgrade_label } : null);
        return;
      }
      finishSuccess($wrap, res.data.text, res.data.format || 'text');
    })
    .fail(function(xhr){
      var res = parseResponse(xhr && xhr.responseText ? xhr.responseText : null);
      var fd = (res && res.data) ? res.data : {};
      finishError($wrap, fd.message || 'Request failed. Try again.', fd.upgrade_url ? { url: fd.upgrade_url, label: fd.upgrade_label } : null);
    });
  }

  // v5.4.61: streaming request via fetch + ReadableStream. Reads the Server-Sent
  // Events the awg_aig_generate_stream endpoint emits and renders tokens live.
  // Falls back to legacyGenerate() once if the stream can't start (host blocked
  // it, no cURL, or a transport error before any token arrived).
  function streamGenerate($wrap, templateId, fields){
    var rawText = '';
    var gotDelta = false;
    var finished = false;
    var sseBuf = '';

    var body = new URLSearchParams();
    body.append('action', 'awg_aig_generate_stream');
    body.append('nonce', AWG_AIG.nonce);
    body.append('template_id', templateId);
    body.append('fields_json', JSON.stringify(fields));
    body.append('fields_labels_json', JSON.stringify($wrap.data('awgLabels') || {}));
    body.append('source_url', srcUrl());

    function fallback(){
      if (finished) return;
      finished = true;
      legacyGenerate($wrap, templateId, fields);
    }

    function handleEvent(name, dataStr){
      if (!dataStr) return;
      var obj;
      try { obj = JSON.parse(dataStr); } catch (e) { return; }
      if (name === 'delta') {
        if (!gotDelta) { gotDelta = true; beginLiveStream($wrap); }
        rawText += (obj.text || '');
        renderLive($wrap, rawText);
      } else if (name === 'done') {
        finished = true;
        finishSuccess($wrap, (obj.text != null ? obj.text : rawText), obj.format || 'text');
      } else if (name === 'error') {
        // A "fallback" error before any token means streaming couldn't start —
        // quietly retry the classic endpoint. Anything else is a real error
        // (rate limit, auth, provider message) and is shown to the user.
        if (obj.fallback && !gotDelta) { fallback(); return; }
        finished = true;
        finishError($wrap, obj.message, obj.upgrade_url ? { url: obj.upgrade_url, label: obj.upgrade_label } : null);
      }
    }

    // Parse complete "\n\n"-delimited SSE blocks out of the buffer.
    function drain(){
      var blocks = sseBuf.split('\n\n');
      sseBuf = blocks.pop();
      blocks.forEach(function(block){
        var name = 'message', data = [];
        block.split('\n').forEach(function(line){
          if (line.indexOf('event:') === 0) name = line.slice(6).trim();
          // v5.4.93 (L4): per the SSE spec, multiple data: lines in one event are
          // joined with a newline (previously concatenated with nothing, which
          // would corrupt a multi-line payload behind a reformatting proxy).
          else if (line.indexOf('data:') === 0) data.push(line.slice(5).replace(/^\s/, ''));
        });
        handleEvent(name, data.join('\n'));
      });
    }

    fetch(AWG_AIG.ajaxurl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString(),
      credentials: 'same-origin'
    })
    .then(function(resp){
      if (!resp.ok || !resp.body || !resp.body.getReader) { fallback(); return; }
      var reader = resp.body.getReader();
      var decoder = new TextDecoder();
      function pump(){
        return reader.read().then(function(res){
          if (res.done) {
            if (!finished) {
              if (gotDelta) { finishSuccess($wrap, rawText, 'text'); }
              else { fallback(); }
            }
            return;
          }
          sseBuf += decoder.decode(res.value, { stream: true });
          drain();
          if (finished) { try { reader.cancel(); } catch (e) {} return; }
          return pump();
        });
      }
      return pump();
    })
    .catch(function(){
      if (finished) return;
      if (gotDelta) { finishError($wrap, 'Connection interrupted. Please try again.'); }
      else { fallback(); }
    });
  }

  // v5.4.69: is any upload field in this generator still mid-upload?
  function anyUploading($wrap){
    var busy = false;
    $wrap.find('.awg-aig__file').each(function(){
      if ($(this).data('awgUploading')) busy = true;
    });
    return busy;
  }

  // Lock/unlock the Generate button while an upload is in flight.
  function lockSubmit($wrap, lock){
    $wrap.find('.awg-aig__btn').first().prop('disabled', !!lock);
  }

  // v5.4.69: upload an upload-field's file the moment it's chosen. We store the
  // returned token on the input so collect() can submit it with the form. The
  // file stays selected in the input so the browser's native `required` check
  // still passes. Errors clear the input so a failed upload can't be submitted.
  $(document).on('change', '.awg-aig__file', function(){
    var input  = this;
    var $input = $(input);
    var $wrap  = $input.closest('.awg-aig');
    var $fwrap = $input.closest('.awg-aig__file-wrap');
    var $status = $fwrap.find('.awg-aig__file-status');
    var templateId = $wrap.attr('data-template-id');
    var fieldKey   = $input.attr('name');

    $input.removeData('awgToken').removeData('awgUploading');
    $status.removeClass('is-error is-ok').text('');

    if (!input.files || !input.files.length) { return; }
    var file = input.files[0];

    // Client-side size pre-check (the server re-checks authoritatively).
    var maxMb = parseInt($fwrap.attr('data-max-mb'), 10) || 10;
    if (file.size > maxMb * 1024 * 1024) {
      $input.val('');
      $status.addClass('is-error').text('File is too large. Max ' + maxMb + ' MB.');
      return;
    }

    var fd = new FormData();
    fd.append('action', 'awg_aig_upload');
    fd.append('nonce', AWG_AIG.nonce);
    fd.append('template_id', templateId);
    fd.append('field_key', fieldKey);
    fd.append('file', file);

    $input.data('awgUploading', true);
    $status.removeClass('is-error is-ok').text('Uploading…');
    lockSubmit($wrap, true);

    $.ajax({
      url: AWG_AIG.ajaxurl,
      method: 'POST',
      data: fd,
      processData: false,
      contentType: false,
      dataType: 'text',
      timeout: 120000
    })
    .done(function(raw){
      var res = parseResponse(raw);
      if (!res || !res.success) {
        var msg = (res && res.data && res.data.message) ? res.data.message : 'Upload failed.';
        $input.val('').removeData('awgToken');
        $status.removeClass('is-ok').addClass('is-error').text(msg);
        return;
      }
      $input.data('awgToken', res.data.token);
      var label = res.data.name || 'File ready';
      if (res.data.has_text === false) { label += ' (attached as a reference link)'; }
      else if (res.data.truncated) { label += ' (long file — will be truncated)'; }
      $status.removeClass('is-error').addClass('is-ok').text('Ready: ' + label);
    })
    .fail(function(xhr){
      var res = parseResponse(xhr && xhr.responseText ? xhr.responseText : null);
      var msg = (res && res.data && res.data.message) ? res.data.message : 'Upload failed. Try again.';
      $input.val('').removeData('awgToken');
      $status.removeClass('is-ok').addClass('is-error').text(msg);
    })
    .always(function(){
      $input.removeData('awgUploading');
      lockSubmit($wrap, anyUploading($wrap));
    });
  });

  $(document).on('submit', '.awg-aig__form', function(e){
    e.preventDefault();
    const $wrap = $(this).closest('.awg-aig');
    const templateId = parseInt($wrap.data('template-id'), 10);

    if (!templateId) {
      status($wrap, 'Invalid template configuration.', true);
      return;
    }

    // v5.4.69: don't fire while a file is still uploading — the field's token
    // wouldn't be ready yet and the upload would be silently dropped.
    if (anyUploading($wrap)) {
      clearLoadingState($wrap);
      status($wrap, 'Please wait — a file is still uploading.', true);
      return;
    }

    // v5.4.48: instant gibberish guard. Mirrors the server check so obvious
    // keyboard-mashing is caught before we burn a request. Runs before the
    // in-flight guard so a rejected attempt never locks the form. The server
    // re-enforces this regardless, so a tampered DOM gains nothing.
    var gibberishBad = findGibberishFields($wrap);
    if (gibberishBad.length) {
      // Clear any loading state the Regenerate path may have set before it
      // routed back through this handler.
      clearLoadingState($wrap);
      status($wrap, 'This looks like random text. Please enter real words for: ' + gibberishBad.join(', '), true);
      return;
    }

    // v5.4.14: in-flight guard. Without this, the Regenerate button can be
    // spam-clicked while a request is pending — each click queues a new
    // XHR, consuming tokens + rate-limit slots. The Generate button is
    // disabled via setButtonLoading below, but Regenerate is a separate
    // element inside the result panel and was not gated.
    if ($wrap.data('awgInFlight')) return;
    $wrap.data('awgInFlight', true);

    applyGclid($wrap);
    showSkeleton($wrap);
    status($wrap, 'Generating...', false);

    const $submitButton = $(this).find('.awg-aig__btn').first();
    setButtonLoading($submitButton, true, 'Generating...');
    // v5.4.14: also lock Copy/Download/Clear/Regenerate — there's nothing
    // to act on while the skeleton is loading. Unlocked again on finish.
    setActionsBusy($wrap, true);

    const fields = collect($wrap);

    // v5.6.4: tools linked to a published agent open an in-place chat window
    // (styled like the result area) instead of returning a single result. The
    // form inputs become the first message; the visitor then keeps talking to
    // the agent. The server runs the SAME tool gating on every turn.
    if ($wrap.attr('data-agent-mode') === '1') {
      startAgentChat($wrap, templateId, fields);
      return;
    }

    // v5.4.61: stream when enabled in Settings and the browser supports the
    // streaming APIs; otherwise (or on failure) fall back to the classic path.
    var canStream = AWG_AIG.stream && window.fetch && window.ReadableStream && window.TextDecoder && window.URLSearchParams;
    if (canStream) { streamGenerate($wrap, templateId, fields); }
    else { legacyGenerate($wrap, templateId, fields); }
  });

  /* =================================================================== *
   * v5.6.4: "Run via Agent" — in-place conversational chat.
   *
   * When a tool is linked to a published agent the submit handler routes here
   * instead of the single-shot generate path. We reuse the tool's own result
   * card so the chat matches the form's visual language, seed the conversation
   * with the form inputs, then let the visitor keep chatting. Each turn is sent
   * to the awg_aig_agent_chat[_stream] endpoints, which re-run the tool's
   * gating (membership, rate limit, daily cap, usage logging).
   * =================================================================== */

  function awgChatState($wrap){
    var st = $wrap.data('awgChat');
    if (!st) { st = { convo: [], fields: null, templateId: 0, busy: false }; $wrap.data('awgChat', st); }
    return st;
  }

  // Block-aware renderer for a chat bubble: blank lines split paragraphs, single
  // newlines become <br>, and the existing inline markdown pass handles
  // **bold**, *italics*, `code`, links, etc. (escaping happens inside it).
  function renderChatMarkdown(text){
    var blocks = String(text == null ? '' : text).replace(/\r\n/g, '\n').split(/\n{2,}/);
    var html = '';
    for (var i = 0; i < blocks.length; i++){
      var block = blocks[i];
      if (!block.replace(/\s+/g, '')) continue;
      var lines = block.split('\n').map(function(l){ return applyInlineFormatting(l); });
      html += '<p>' + lines.join('<br>') + '</p>';
    }
    return html || '<p></p>';
  }

  function awgPrettyKey(key){
    return String(key).replace(/\[\]$/, '').replace(/[_\-]+/g, ' ').replace(/\b\w/g, function(c){ return c.toUpperCase(); });
  }

  // Build a human-readable "first message" from the submitted fields, using each
  // control's on-screen label where possible. Display only — the server rebuilds
  // the real prompt (with the template System Prompt) from the posted fields.
  function buildFieldsSummary($wrap, fields){
    var parts = [];
    var seen = {};
    var labels = $wrap.data('awgLabels') || {};
    $wrap.find('.awg-aig__form [name]').each(function(){
      var $el = $(this);
      var rawName = $el.attr('name');
      if (!rawName) return;
      var key = rawName.replace(/\[\]$/, '');
      if (key === 'gclid' || /^utm_/.test(key)) return;
      if (seen[key]) return;
      seen[key] = true;

      var val = fields[key];
      if (Array.isArray(val)) val = val.join(', ');
      val = String(val == null ? '' : val).trim();
      if (!val) return;

      var label = '';
      var $field = $el.closest('.awg-aig__field');
      if ($field.length) label = $field.find('.awg-aig__label span').first().text().trim();
      if (!label) label = labels[key] || awgPrettyKey(key);

      parts.push('**' + label + ':** ' + val);
    });
    return parts.join('\n');
  }

  function ensureChatUI($wrap){
    var $result = $wrap.find('.awg-aig__result').first();
    $result.removeAttr('hidden').addClass('awg-aig__result--chat');
    $result.find('.awg-aig__result-actions--bottom').hide();
    $result.find('.awg-aig__cta').hide();
    $result.find('.awg-aig__output').attr('hidden', true).hide().empty();

    if (!$result.find('.awg-aig__chat').length){
      var ph = $wrap.attr('data-chat-placeholder') || 'Reply to keep the conversation going…';
      var html = ''
        + '<div class="awg-aig__chat">'
        + '  <div class="awg-aig__chat-log" role="log" aria-live="polite"></div>'
        + '  <form class="awg-aig__chat-form" autocomplete="off">'
        + '    <textarea class="awg-aig__chat-input" rows="1" placeholder="' + escapeHtml(ph) + '"></textarea>'
        + '    <button type="submit" class="awg-aig__btn awg-aig__chat-send"><span>Send</span></button>'
        + '  </form>'
        + '</div>';
      $result.find('.awg-aig__output').after(html);
    } else {
      $result.find('.awg-aig__chat-log').empty();
    }
    return $result;
  }

  function scrollChat($wrap){
    var log = $wrap.find('.awg-aig__chat-log').first()[0];
    if (log) log.scrollTop = log.scrollHeight;
  }

  // Append a message bubble. For assistant turns we return the inner bubble so the
  // streaming handler can keep repainting it as tokens arrive.
  function appendChatMsg($wrap, role, content, asHtml){
    var $log = $wrap.find('.awg-aig__chat-log').first();
    var cls = (role === 'user') ? 'awg-aig__msg--user' : 'awg-aig__msg--assistant';
    var $msg = $('<div class="awg-aig__msg ' + cls + '"><div class="awg-aig__bubble"></div></div>');
    var $bubble = $msg.find('.awg-aig__bubble');
    if (asHtml) { $bubble.html(content); }
    else { $bubble.html(renderChatMarkdown(content)); }
    $log.append($msg);
    scrollChat($wrap);
    return $bubble;
  }

  function setAgentBusy($wrap, busy){
    var st = awgChatState($wrap);
    st.busy = !!busy;
    $wrap.find('.awg-aig__chat-send').prop('disabled', !!busy);
    var $main = $wrap.find('.awg-aig__form .awg-aig__btn').first();
    setButtonLoading($main, !!busy, 'Working…');
    if (!busy) { $wrap.data('awgInFlight', false); }
  }

  function startAgentChat($wrap, templateId, fields){
    hideSkeleton($wrap);
    status($wrap, '', false);
    var st = awgChatState($wrap);
    st.convo = [];
    st.fields = fields;
    st.templateId = templateId;

    ensureChatUI($wrap);

    var summary = buildFieldsSummary($wrap, fields);
    if (summary) { appendChatMsg($wrap, 'user', summary, false); }

    sendChatTurn($wrap);
  }

  // Send the current conversation (everything after the seeded first message) and
  // stream/await the agent's reply into a fresh assistant bubble.
  function sendChatTurn($wrap){
    var st = awgChatState($wrap);
    if (st.busy) return;
    setAgentBusy($wrap, true);

    var $bubble = appendChatMsg($wrap, 'assistant',
      '<span class="awg-aig__chat-typing"><span></span><span></span><span></span></span>', true);

    var rawText = '';
    var gotDelta = false;
    var settled = false;
    var turns = st.convo.slice();

    function finishOk(text){
      if (settled) return;
      settled = true;
      var finalText = (text != null ? text : rawText);
      $bubble.html(renderChatMarkdown(finalText));
      st.convo.push({ role: 'assistant', content: finalText });
      scrollChat($wrap);
      setAgentBusy($wrap, false);
      $wrap.find('.awg-aig__chat-input').trigger('focus');
    }

    function finishBad(msg){
      if (settled) return;
      settled = true;
      $bubble.attr('class', 'awg-aig__bubble awg-aig__bubble--error').text(msg || 'Something went wrong. Please try again.');
      scrollChat($wrap);
      setAgentBusy($wrap, false);
    }

    var canStream = AWG_AIG.stream && window.fetch && window.ReadableStream && window.TextDecoder && window.URLSearchParams;
    if (canStream){
      awgChatStream($wrap, turns, {
        onDelta: function(t){ if (!gotDelta){ gotDelta = true; $bubble.empty(); } rawText += t; $bubble.html(renderChatMarkdown(rawText)); scrollChat($wrap); },
        onStatus: function(label){ if (!gotDelta){ $bubble.html('<span class="awg-aig__chat-status">' + escapeHtml(label) + '</span>'); scrollChat($wrap); } },
        onDone: finishOk,
        onError: finishBad,
        onFallback: function(){ awgChatLegacy($wrap, turns, finishOk, finishBad); }
      });
    } else {
      awgChatLegacy($wrap, turns, finishOk, finishBad);
    }
  }

  // Streaming transport — mirrors streamGenerate()'s SSE reader.
  function awgChatStream($wrap, turns, cb){
    var st = awgChatState($wrap);
    var sseBuf = '';
    var gotDelta = false;
    var finished = false;

    var body = new URLSearchParams();
    body.append('action', 'awg_aig_agent_chat_stream');
    body.append('nonce', AWG_AIG.nonce);
    body.append('template_id', st.templateId);
    body.append('fields_json', JSON.stringify(st.fields || {}));
    body.append('fields_labels_json', JSON.stringify($wrap.data('awgLabels') || {}));
    body.append('turns_json', JSON.stringify(turns || []));
    body.append('source_url', srcUrl());

    function handleEvent(name, dataStr){
      if (!dataStr) return;
      var obj;
      try { obj = JSON.parse(dataStr); } catch (e) { return; }
      if (name === 'delta'){ gotDelta = true; cb.onDelta(obj.text || ''); }
      else if (name === 'status'){ cb.onStatus(obj.label || ''); }
      else if (name === 'done'){ finished = true; cb.onDone(obj.text != null ? obj.text : null); }
      else if (name === 'error'){
        if (obj.fallback && !gotDelta){ finished = true; cb.onFallback(); return; }
        finished = true;
        cb.onError(obj.message);
      }
    }

    function drain(){
      var blocks = sseBuf.split('\n\n');
      sseBuf = blocks.pop();
      blocks.forEach(function(block){
        var name = 'message', data = [];
        block.split('\n').forEach(function(line){
          if (line.indexOf('event:') === 0) name = line.slice(6).trim();
          else if (line.indexOf('data:') === 0) data.push(line.slice(5).replace(/^\s/, ''));
        });
        handleEvent(name, data.join('\n'));
      });
    }

    fetch(AWG_AIG.ajaxurl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString(),
      credentials: 'same-origin'
    })
    .then(function(resp){
      if (!resp.ok || !resp.body || !resp.body.getReader){ if (!finished){ finished = true; cb.onFallback(); } return; }
      var reader = resp.body.getReader();
      var decoder = new TextDecoder();
      function pump(){
        return reader.read().then(function(res){
          if (res.done){
            if (!finished){ if (gotDelta){ cb.onDone(null); } else { cb.onFallback(); } }
            return;
          }
          sseBuf += decoder.decode(res.value, { stream: true });
          drain();
          if (finished){ try { reader.cancel(); } catch (e) {} return; }
          return pump();
        });
      }
      return pump();
    })
    .catch(function(){
      if (finished) return;
      finished = true;
      if (gotDelta){ cb.onError('Connection interrupted. Please try again.'); }
      else { cb.onFallback(); }
    });
  }

  // Classic (non-streaming) transport.
  function awgChatLegacy($wrap, turns, onDone, onError){
    var st = awgChatState($wrap);
    $.ajax({
      url: AWG_AIG.ajaxurl,
      method: 'POST',
      dataType: 'text',
      timeout: 180000,
      data: {
        action: 'awg_aig_agent_chat',
        nonce: AWG_AIG.nonce,
        template_id: st.templateId,
        fields_json: JSON.stringify(st.fields || {}),
        fields_labels_json: JSON.stringify($wrap.data('awgLabels') || {}),
        turns_json: JSON.stringify(turns || []),
        source_url: srcUrl()
      }
    })
    .done(function(raw){
      var res = parseResponse(raw);
      if (!res || !res.success){
        var ed = (res && res.data) ? res.data : {};
        onError(ed.message || 'The agent could not reply.');
        return;
      }
      onDone(res.data.text);
    })
    .fail(function(xhr){
      var res = parseResponse(xhr && xhr.responseText ? xhr.responseText : null);
      var fd = (res && res.data) ? res.data : {};
      onError(fd.message || 'Request failed. Try again.');
    });
  }

  // Visitor follow-up: push their message, then send the turn.
  $(document).on('submit', '.awg-aig__chat-form', function(e){
    e.preventDefault();
    var $wrap = $(this).closest('.awg-aig');
    var st = awgChatState($wrap);
    if (st.busy) return;
    var $input = $(this).find('.awg-aig__chat-input');
    var msg = String($input.val() || '').trim();
    if (!msg) return;
    $input.val('');
    appendChatMsg($wrap, 'user', msg, false);
    st.convo.push({ role: 'user', content: msg });
    sendChatTurn($wrap);
  });

  // Enter sends, Shift+Enter inserts a newline.
  $(document).on('keydown', '.awg-aig__chat-input', function(e){
    if (e.key === 'Enter' && !e.shiftKey){
      e.preventDefault();
      $(this).closest('.awg-aig__chat-form').trigger('submit');
    }
  });

  $(document).on('click', '.awg-aig__copy', function(){
    const $wrap = $(this).closest('.awg-aig');
    const $btn = $(this);
    const originalLabel = $btn.text();
    const $out = $wrap.find('.awg-aig__output');
    const text = ($out.data('raw-text') || $out.text() || '').toString();

    function setCopiedLabel(){
      const $label = $btn.find('span').last();
      if ($label.length) {
        const originalHtml = $label.html();
        $label.text('Copied');
        setTimeout(function(){
          $label.html(originalHtml);
        }, 2000);
      } else {
        $btn.text('Copied');
        setTimeout(function(){
          $btn.text(originalLabel);
        }, 2000);
      }
    }

    function legacyCopy(value){
      const $temp = $('<textarea readonly></textarea>');
      $temp.css({ position: 'absolute', left: '-9999px', top: '0' });
      $temp.val(value);
      $('body').append($temp);
      $temp[0].select();
      try {
        document.execCommand('copy');
        status($wrap, 'Copied.', false);
        setCopiedLabel();
      } catch (e) {
        status($wrap, 'Copy failed.', true);
      }
      $temp.remove();
    }

    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function(){
        status($wrap, 'Copied.', false);
        setCopiedLabel();
      }).catch(function(){
        legacyCopy(text);
      });
    } else {
      legacyCopy(text);
    }
  });

  // v5.4.25: copy a single result item.
  $(document).on('click', '.awg-aig__item-copy', function(){
    var $btn = $(this);
    var $item = $btn.closest('.awg-aig__result-item');
    var text = ($item.find('.awg-aig__result-item-content').text() || '').trim();
    if (!text) return;
    var $icon = $btn.find('.dashicons');
    function flash(){
      $btn.addClass('is-copied');
      if ($icon.length) { $icon.removeClass('dashicons-clipboard').addClass('dashicons-yes'); }
      setTimeout(function(){
        $btn.removeClass('is-copied');
        if ($icon.length) { $icon.removeClass('dashicons-yes').addClass('dashicons-clipboard'); }
      }, 1500);
    }
    function legacy(){
      var $t = $('<textarea readonly></textarea>').css({ position:'absolute', left:'-9999px', top:'0' }).val(text);
      $('body').append($t); $t[0].select();
      try { document.execCommand('copy'); flash(); } catch (e) {}
      $t.remove();
    }
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(flash).catch(legacy);
    } else {
      legacy();
    }
  });

  // v5.4.88: copy a single fix card's suggested rewrite (the green line only).
  $(document).on('click', '.awg-aig__fix-copy', function(){
    var $btn = $(this);
    var text = ($btn.closest('.awg-aig__fix').find('.awg-aig__fix-text').text() || '').trim();
    if (!text) return;
    var label = $btn.data('label') || $btn.text();
    function flash(){
      if (!$btn.data('label')) $btn.data('label', label);
      $btn.addClass('is-copied').text('Copied');
      setTimeout(function(){ $btn.removeClass('is-copied').text(label); }, 1500);
    }
    function legacy(){
      var $t = $('<textarea readonly></textarea>').css({ position:'absolute', left:'-9999px', top:'0' }).val(text);
      $('body').append($t); $t[0].select();
      try { document.execCommand('copy'); flash(); } catch (e) {}
      $t.remove();
    }
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(flash).catch(legacy);
    } else {
      legacy();
    }
  });

  // --- PDF download (via the browser's print-to-PDF) ------------------------
  // A real, professional PDF with no external library: the result is rendered
  // into a clean, print-styled document in a hidden iframe and the print
  // dialog is opened, where the user picks "Save as PDF". Same approach the
  // Book Cost Calculator already uses for its estimate.

  function awgHtmlEscape(s){
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  // Map the common inline Markdown the generators emit to HTML.
  function awgInlineHtml(s){
    var t = awgHtmlEscape(s);
    t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/__([^_]+)__/g, '<strong>$1</strong>');
    t = t.replace(/\*([^*\s][^*]*?)\*/g, '<em>$1</em>');
    t = t.replace(/(^|\s)_([^_]+)_(?=\s|[.,;:!?)]|$)/g, '$1<em>$2</em>');
    t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
    return t;
  }

  // Convert the raw (Markdown-ish) result text into clean semantic HTML,
  // grouping consecutive bullet/numbered lines into <ul>/<ol>.
  function awgTextToHtmlBody(raw){
    var lines = String(raw == null ? '' : raw).replace(/\r\n?/g, '\n').split('\n');
    var html = '';
    var listType = '';
    function closeList(){ if (listType){ html += '</' + listType + '>'; listType = ''; } }

    for (var i = 0; i < lines.length; i++){
      var line = lines[i].replace(/\s+$/, '');
      var m;
      if (line === ''){ closeList(); continue; }
      if (/^[-=_*]{3,}$/.test(line)){ closeList(); continue; } // horizontal rule
      if ((m = line.match(/^(#{1,6})\s+(.*)$/))){
        closeList();
        var lvl = Math.min(m[1].length, 3);
        html += '<h' + lvl + '>' + awgInlineHtml(m[2]) + '</h' + lvl + '>';
        continue;
      }
      if ((m = line.match(/^\s*[-*•]\s+(.*)$/))){
        if (listType !== 'ul'){ closeList(); html += '<ul>'; listType = 'ul'; }
        html += '<li>' + awgInlineHtml(m[1]) + '</li>';
        continue;
      }
      if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))){
        if (listType !== 'ol'){ closeList(); html += '<ol>'; listType = 'ol'; }
        html += '<li>' + awgInlineHtml(m[1]) + '</li>';
        continue;
      }
      closeList();
      html += '<p>' + awgInlineHtml(line) + '</p>';
    }
    closeList();
    return html;
  }

  // Wrap a body fragment in a professional, print-optimised document. Colours
  // are taken from the tool's own brand palette (its CSS custom properties) so
  // the PDF matches the site; opts = {accent, ink, text, band, border, siteName}.
  function awgBuildPrintDoc(title, bodyHtml, opts){
    opts = opts || {};
    var accent = opts.accent || '#c8794f';
    var ink    = opts.ink    || '#10243c';
    var text   = opts.text   || '#33291c';
    var band   = opts.band   || '#f5f1e8';
    var border = opts.border || '#e5dac4';
    var site   = (opts.siteName || 'AuthorWings').toString();
    var domain = (opts.siteDomain || '').toString();
    var mono   = (site.replace(/^\s+/, '').charAt(0) || 'A').toUpperCase();
    var stamp  = '';
    try { stamp = new Date().toLocaleDateString(undefined, { year:'numeric', month:'long', day:'numeric' }); } catch (e) {}

    var css = ''
      + '@page{size:A4;margin:18mm 20mm 20mm;}'
      + '*{box-sizing:border-box;-webkit-print-color-adjust:exact;print-color-adjust:exact;}'
      + 'html,body{margin:0;padding:0;}'
      + 'body{font-family:Georgia,"Times New Roman",serif;color:' + text + ';font-size:11.5pt;line-height:1.6;}'
      + '.awg-head{display:flex;justify-content:space-between;align-items:center;gap:12px;}'
      + '.awg-brand{display:flex;align-items:center;gap:9px;}'
      + '.awg-brandtext{display:flex;flex-direction:column;line-height:1.2;}'
      + '.awg-mono{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;border-radius:6px;background:' + accent + ';color:#fff;font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:13pt;line-height:1;}'
      + '.awg-brandname{font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:11.5pt;letter-spacing:.4px;color:' + ink + ';}'
      + '.awg-branddomain{font-family:Arial,Helvetica,sans-serif;font-size:8pt;font-weight:600;letter-spacing:.4px;color:' + accent + ';}'
      + '.awg-kicker{font-family:Arial,Helvetica,sans-serif;font-size:8pt;font-weight:700;text-transform:uppercase;letter-spacing:1.6px;color:' + accent + ';}'
      + '.awg-rule{height:2px;background:' + accent + ';border:0;margin:10px 0 22px;}'
      + '.awg-title{font-family:Georgia,serif;font-size:23pt;font-weight:700;color:' + ink + ';line-height:1.2;margin:0;}'
      + '.awg-title-bar{width:52px;height:3px;background:' + accent + ';margin:9px 0 10px;}'
      + '.awg-meta{font-family:Arial,Helvetica,sans-serif;font-size:8.5pt;text-transform:uppercase;letter-spacing:1px;color:#7b7466;margin:0 0 20pt;}'
      + '.awg-body h1,.awg-body h2,.awg-body h3{font-family:Arial,Helvetica,sans-serif;color:' + ink + ';line-height:1.25;page-break-after:avoid;}'
      + '.awg-body h1{font-size:15pt;margin:18pt 0 6pt;}'
      + '.awg-body h2{font-size:13.5pt;margin:16pt 0 5pt;border-bottom:1px solid ' + border + ';padding-bottom:4pt;}'
      + '.awg-body h3{font-size:12pt;color:' + accent + ';margin:13pt 0 4pt;}'
      + '.awg-body p{margin:0 0 9pt;}'
      + '.awg-body ul,.awg-body ol{margin:0 0 9pt 20pt;padding:0;}'
      + '.awg-body li{margin:0 0 5pt;padding-left:2pt;}'
      + '.awg-body li::marker{color:' + accent + ';}'
      + '.awg-body strong{color:' + ink + ';font-weight:700;}'
      + '.awg-body em{font-style:italic;}'
      + '.awg-body code{font-family:Consolas,"Courier New",monospace;font-size:10pt;background:' + band + ';border:1px solid ' + border + ';border-radius:3px;padding:0 3px;}'
      + '.awg-body blockquote{margin:0 0 9pt;padding:2pt 0 2pt 12pt;border-left:3px solid ' + accent + ';color:#6b6456;font-style:italic;}'
      + '.awg-foot{margin-top:26pt;padding-top:8pt;border-top:1px solid ' + border + ';display:flex;justify-content:space-between;gap:10px;font-family:Arial,Helvetica,sans-serif;font-size:8pt;color:#8a8377;letter-spacing:.3px;}';

    var metaText  = stamp ? ('Prepared with AuthorWings AI · ' + stamp) : 'Prepared with AuthorWings AI';
    var footLeft  = domain ? (site + ' · ' + domain) : site;
    var footRight = (stamp ? (stamp + ' · ') : '') + 'Generated by AuthorWings AI';
    var brandText = '<span class="awg-brandname">' + awgHtmlEscape(site) + '</span>'
      + (domain ? '<span class="awg-branddomain">' + awgHtmlEscape(domain) + '</span>' : '');

    return '<!doctype html><html><head><meta charset="utf-8"><title>' + awgHtmlEscape(title) + '</title>'
      + '<style>' + css + '</style></head><body>'
      + '<div class="awg-head">'
      +   '<div class="awg-brand"><span class="awg-mono">' + awgHtmlEscape(mono) + '</span>'
      +     '<span class="awg-brandtext">' + brandText + '</span></div>'
      +   '<div class="awg-kicker">AI-generated document</div>'
      + '</div>'
      + '<hr class="awg-rule">'
      + '<div class="awg-title">' + awgHtmlEscape(title) + '</div>'
      + '<div class="awg-title-bar"></div>'
      + '<div class="awg-meta">' + awgHtmlEscape(metaText) + '</div>'
      + '<div class="awg-body">' + bodyHtml + '</div>'
      + '<div class="awg-foot"><span>' + awgHtmlEscape(footLeft) + '</span><span>' + awgHtmlEscape(footRight) + '</span></div>'
      + '</body></html>';
  }

  // Render a print document in a hidden iframe and open the print dialog
  // (where the user chooses "Save as PDF").
  function awgPrintToPdf(docHtml){
    var iframe = document.createElement('iframe');
    iframe.setAttribute('aria-hidden', 'true');
    iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;';
    document.body.appendChild(iframe);

    var done = false;
    function cleanup(){ if (iframe && iframe.parentNode){ iframe.parentNode.removeChild(iframe); } }
    function go(){
      if (done) { return; }
      done = true;
      try {
        iframe.contentWindow.focus();
        iframe.contentWindow.print();
      } catch (e) {}
      // Give the dialog time to grab the document before we remove the iframe.
      setTimeout(cleanup, 60000);
    }

    var doc = iframe.contentWindow.document;
    doc.open();
    doc.write(docHtml);
    doc.close();

    if (doc.readyState === 'complete'){ setTimeout(go, 250); }
    else { iframe.onload = function(){ setTimeout(go, 250); }; }
  }

  $(document).on('click', '.awg-aig__download', function(){
    const $wrap = $(this).closest('.awg-aig');
    const $out = $wrap.find('.awg-aig__output');
    const format = $out.data('format') || 'text';
    const rawText = ($out.data('raw-text') || '').toString();
    const filenameBase = $wrap.find('.awg-aig__result').data('filename') || 'generator-output';

    if (format === 'pdf'){
      // Formatted PDF via the browser's print dialog (Save as PDF).
      // Just the heading text (drop the item-count chip), fall back to filename.
      let title = ($wrap.find('.awg-aig__result-head strong').clone().children().remove().end().text() || '').trim();
      if (!title){ title = filenameBase.replace(/[-_]+/g, ' ').replace(/\b\w/g, function(c){ return c.toUpperCase(); }); }

      // Pull the tool's own brand palette so the PDF matches the site.
      let cs = null;
      try { cs = window.getComputedStyle($wrap.get(0)); } catch (e) {}
      const brandVar = function(name, fallback){
        if (!cs) { return fallback; }
        const val = (cs.getPropertyValue(name) || '').trim();
        return val || fallback;
      };
      const opts = {
        accent:   brandVar('--awg-accent', '#c8794f'),
        ink:      brandVar('--awg-btn-bg', '#10243c'),
        text:     brandVar('--awg-text',   '#33291c'),
        band:     brandVar('--awg-bg',     '#f5f1e8'),
        border:   brandVar('--awg-border', '#e5dac4'),
        siteName: (window.AWG_AIG && AWG_AIG.siteName) ? AWG_AIG.siteName : (document.title || 'AuthorWings'),
        siteDomain: (window.AWG_AIG && AWG_AIG.siteDomain) ? AWG_AIG.siteDomain : ((location.hostname || '').replace(/^www\./i, ''))
      };

      const bodyHtml = awgTextToHtmlBody(rawText || $out.text() || '');
      awgPrintToPdf(awgBuildPrintDoc(title, bodyHtml, opts));
      status($wrap, 'Opening print dialog — choose “Save as PDF”.', false);
      return;
    }

    // Default: a plain .txt file of the raw result text.
    const payload = rawText || $out.text() || '';
    const blob = new Blob([payload], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filenameBase + '.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    status($wrap, 'Download started.', false);
  });



  $(document).on('click', '.awg-aig__clear', function(){
    const $wrap = $(this).closest('.awg-aig');
    resetDiscuss($wrap);
    $wrap.find('.awg-aig__output').text('');
    $wrap.find('.awg-aig__result-count').remove();
    const formEl = $wrap.find('.awg-aig__form').get(0);
    if (formEl) formEl.reset();
    applyGclid($wrap);
    $wrap.find('.awg-aig__result').prop('hidden', true);
    status($wrap, '', false);
    setTimeout(function(){
      const form = $wrap.find('.awg-aig__form').get(0);
      if (!form) return;
      form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
  });

  $(document).on('click', '.awg-aig__regenerate', function(){
    const $wrap = $(this).closest('.awg-aig');
    const $form = $wrap.find('.awg-aig__form');
    if (!$form.length) return;

    // v5.4.14: bail if a previous request is already in flight. The submit
    // handler also guards this, but checking here means we don't even paint
    // the "Regenerating..." status on a spam-click.
    if ($wrap.data('awgInFlight')) return;

    setButtonLoading($(this), true, 'Regenerating...');
    status($wrap, 'Regenerating...', false);

    // v5.4.14: use requestSubmit() so the browser runs HTML5 constraint
    // validation (required, type=email, etc.) before the submit handler
    // fires. The old $form.trigger('submit') bypassed validation and
    // relied on the server-side "required fields missing" message.
    const formEl = $form.get(0);
    if (formEl && typeof formEl.requestSubmit === 'function') {
      formEl.requestSubmit();
    } else {
      // Old browser fallback — keeps existing behavior on legacy clients.
      $form.trigger('submit');
    }
  });

  /* =====================================================================
   * v5.9.0 — "Discuss result with agent".
   * A result-row button opens an in-place chat with a chosen published agent,
   * seeded with the generated result, and a "Back to result" control restores
   * the output. Turns go to the standalone agent endpoints (awg_agent_chat[_
   * stream]); the server re-validates the agent + gating on every turn. Uses a
   * dedicated composer (.awg-aig__discuss-*) so it never collides with the
   * legacy in-tool chat handlers, but reuses the .awg-aig__chat-log bubbles.
   * ===================================================================== */

  function discussState($wrap){
    var st = $wrap.data('awgDiscuss');
    if (!st){ st = { convo: [], busy: false, threadId: 0, seeded: false, contextSent: false, context: '' }; $wrap.data('awgDiscuss', st); }
    return st;
  }

  function resetDiscuss($wrap){
    var $result = $wrap.find('.awg-aig__result').first();
    $result.removeClass('awg-aig__result--discuss');
    $result.find('.awg-aig__discuss-panel').remove();
    $result.find('.awg-aig__output').removeAttr('hidden').css('display', '');
    $result.find('.awg-aig__result-actions--bottom').css('display', '');
    $result.find('.awg-aig__cta').css('display', '');
    $wrap.removeData('awgDiscuss');
  }

  // Collect the visitor's current form inputs as a readable "Label: value" list.
  function gatherDiscussInputs($wrap){
    var parts = [];
    $wrap.find('.awg-aig__form').find('input, textarea, select').each(function(){
      var $el = $(this);
      var type = ($el.attr('type') || '').toLowerCase();
      if (type === 'hidden' || type === 'submit' || type === 'button') return;
      if (($el.attr('name') || '') === '') return;
      if ((type === 'checkbox' || type === 'radio') && !$el.is(':checked')) return;
      var val = ($el.val() == null ? '' : String($el.val())).trim();
      if (!val) return;
      var label = $el.closest('.awg-aig__field').find('.awg-aig__label span').first().text().trim();
      if (!label) label = $el.attr('name');
      parts.push(label + ': ' + val);
    });
    return parts.join('\n');
  }

  function buildDiscussContext($wrap, resultText){
    var inputs = gatherDiscussInputs($wrap);
    var ctx = 'Background context for your reference only — do NOT summarise, restate, list or comment on any of it unless the user explicitly asks. The user just generated the following with an AI tool on this page.';
    if (inputs) { ctx += '\n\nTheir inputs:\n' + inputs; }
    if (resultText) { ctx += '\n\nThe generated result:\n' + resultText; }
    ctx += '\n\nReply ONLY to the user\'s message below. Answer exactly what they ask and nothing more — if they just greet you, greet them back briefly; do not recap the result or offer a menu of options unless they request it. Use the context above only when their message actually calls for it.';
    return ctx;
  }

  function autosizeDiscuss($input){
    var el = $input.get(0);
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 160) + 'px';
  }

  function setDiscussBusy($wrap, busy){
    var st = discussState($wrap);
    st.busy = !!busy;
    $wrap.find('.awg-aig__discuss-send').prop('disabled', !!busy);
    $wrap.find('.awg-aig__discuss-input').prop('disabled', !!busy);
  }

  // v5.9.5: build (or refresh) the suggested-prompt chips inside the Discuss
  // panel from data-discuss-starters. Hidden once any message has been sent.
  function renderDiscussStarters($wrap){
    var st = discussState($wrap);
    var $box = $wrap.find('.awg-aig__discuss-starters').first();
    if (!$box.length) return;
    if (st.convo && st.convo.length){ $box.empty().hide(); return; }
    if ($box.children().length){ $box.show(); return; }
    var raw = $wrap.attr('data-discuss-starters') || '';
    if (!raw) return;
    var list;
    try { list = JSON.parse(raw); } catch (e) { list = []; }
    if (!list || !list.length) return;
    list.forEach(function(s){
      if (!s) return;
      $('<button type="button" class="awg-aig__discuss-starter"></button>')
        .text(String(s)).appendTo($box);
    });
    $box.show();
  }

  function openDiscuss($wrap){
    var agentId = $wrap.attr('data-discuss-agent-id');
    if (!agentId) return;
    var $result = $wrap.find('.awg-aig__result').first();
    if (!$result.length) return;

    var st = discussState($wrap);

    // Capture the result text BEFORE we hide the output, so we can seed context
    // and restore it on "Back".
    var resultText = $result.find('.awg-aig__output').text().replace(/\s+\n/g, '\n').trim();

    $result.addClass('awg-aig__result--discuss');
    $result.find('.awg-aig__output').attr('hidden', true).hide();
    $result.find('.awg-aig__result-actions--bottom').hide();
    $result.find('.awg-aig__cta').hide();

    if (!$result.find('.awg-aig__discuss-panel').length){
      var ph = $wrap.attr('data-discuss-placeholder') || 'Type your message…';
      var html = ''
        + '<div class="awg-aig__discuss-panel">'
        + '  <div class="awg-aig__discuss-bar">'
        + '    <button type="button" class="awg-aig__discuss-back">&larr; ' + escapeHtml('Back to result') + '</button>'
        + '    <span class="awg-aig__discuss-context">' + escapeHtml('Discussing your result') + '</span>'
        + '  </div>'
        + '  <div class="awg-aig__chat">'
        + '    <div class="awg-aig__chat-log" role="log" aria-live="polite"></div>'
        + '    <div class="awg-aig__discuss-starters"></div>'
        + '    <form class="awg-aig__discuss-form" autocomplete="off">'
        + '      <textarea class="awg-aig__discuss-input" rows="1" placeholder="' + escapeHtml(ph) + '"></textarea>'
        + '      <button type="submit" class="awg-aig__btn awg-aig__discuss-send"><span>' + escapeHtml('Send') + '</span></button>'
        + '    </form>'
        + '  </div>'
        + '</div>';
      $result.append(html);
    } else {
      $result.find('.awg-aig__discuss-panel').show();
    }

    // First open: show the agent greeting and remember the result context.
    if (!st.seeded){
      st.seeded = true;
      st.context = buildDiscussContext($wrap, resultText);
      var greeting = $wrap.attr('data-discuss-greeting') || '';
      if (greeting) { appendChatMsg($wrap, 'assistant', greeting, false); }
    }

    // v5.9.5: render the agent's suggested prompts as clickable chips, mirroring
    // the standalone agent. They show before the first user message and clear
    // once the conversation starts.
    renderDiscussStarters($wrap);

    $result.removeAttr('hidden');
    try { $result.get(0).scrollIntoView({ behavior: 'smooth', block: 'start' }); } catch (e) {}
    $wrap.find('.awg-aig__discuss-input').trigger('focus');
  }

  function discussParams($wrap, action){
    var st = discussState($wrap);
    var p = new URLSearchParams();
    p.set('action', action);
    p.set('nonce', $wrap.attr('data-discuss-nonce') || '');
    p.set('agent_id', $wrap.attr('data-discuss-agent-id') || '0');
    p.set('messages', JSON.stringify(st.convo));
    p.set('thread_id', String(st.threadId || 0));
    return p;
  }

  function discussSend($wrap){
    var st = discussState($wrap);
    if (st.busy) return;
    var $input = $wrap.find('.awg-aig__discuss-input');
    var text = ($input.val() || '').trim();
    if (!text) return;

    $input.val(''); autosizeDiscuss($input);
    $wrap.find('.awg-aig__discuss-starters').empty().hide();
    appendChatMsg($wrap, 'user', text, false);

    // Merge the result context into the first message the agent receives, so the
    // on-screen bubble stays clean while the agent gets full context.
    var sent = text;
    if (!st.contextSent && st.context){ sent = st.context + '\n\n-----\n\n' + text; st.contextSent = true; }
    st.convo.push({ role: 'user', content: sent });

    setDiscussBusy($wrap, true);
    var $bubble = appendChatMsg($wrap, 'assistant',
      '<span class="awg-aig__chat-typing"><span></span><span></span><span></span></span>', true);

    var settled = false, rawText = '', gotDelta = false;

    function finishOk(textOut, threadId){
      if (settled) return; settled = true;
      var finalText = (textOut != null ? textOut : rawText);
      $bubble.html(renderChatMarkdown(finalText));
      st.convo.push({ role: 'assistant', content: finalText });
      if (threadId && threadId > 0) st.threadId = threadId;
      scrollChat($wrap);
      setDiscussBusy($wrap, false);
      $wrap.find('.awg-aig__discuss-input').trigger('focus');
    }
    function finishErr(data){
      if (settled) return; settled = true;
      data = data || {};
      $bubble.attr('class', 'awg-aig__bubble awg-aig__bubble--error').text(data.message || 'Something went wrong. Please try again.');
      if (data.upgrade_url){
        var $a = $('<a class="awg-aig__discuss-upgrade"></a>').attr('href', data.upgrade_url).text(data.upgrade_label || 'Upgrade');
        $bubble.append('<br>').append($a);
      }
      // The failed turn never reached the model; drop it so a retry is clean.
      if (st.convo.length && st.convo[st.convo.length - 1].role === 'user'){ st.convo.pop(); st.contextSent = !!st.contextSent && st.convo.length > 0; }
      scrollChat($wrap);
      setDiscussBusy($wrap, false);
    }

    var canStream = AWG_AIG.stream && window.fetch && window.ReadableStream && window.TextDecoder && window.URLSearchParams;
    if (canStream){
      discussStream($wrap, {
        onDelta: function(t){ if (!gotDelta){ gotDelta = true; $bubble.empty(); } rawText += t; $bubble.html(renderChatMarkdown(rawText)); scrollChat($wrap); },
        onStatus: function(label){ if (!gotDelta){ $bubble.html('<span class="awg-aig__chat-status">' + escapeHtml(label) + '</span>'); scrollChat($wrap); } },
        onDone: finishOk,
        onError: finishErr,
        onFallback: function(){ discussLegacy($wrap, finishOk, finishErr); }
      });
    } else {
      discussLegacy($wrap, finishOk, finishErr);
    }
  }

  function discussStream($wrap, cb){
    var body = discussParams($wrap, 'awg_agent_chat_stream');
    fetch(AWG_AIG.ajaxurl, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString()
    }).then(function(resp){
      if (!resp.ok || !resp.body || !resp.body.getReader){ cb.onFallback(); return; }
      var reader = resp.body.getReader(), dec = new TextDecoder(), buf = '';
      function pump(){
        return reader.read().then(function(r){
          if (r.done) return;
          buf += dec.decode(r.value, { stream: true });
          var blocks = buf.split('\n\n'); buf = blocks.pop();
          blocks.forEach(function(block){
            var evt = 'message', data = null;
            block.split('\n').forEach(function(line){
              if (line.indexOf('event:') === 0) evt = line.slice(6).trim();
              else if (line.indexOf('data:') === 0){ try { data = JSON.parse(line.slice(5).trim()); } catch (e) {} }
            });
            if (evt === 'delta' && data) cb.onDelta(data.text || '');
            else if (evt === 'status' && data) cb.onStatus(data.label || '');
            else if (evt === 'done') cb.onDone(data && data.text, data && data.thread_id);
            else if (evt === 'error'){ if (data && data.fallback) cb.onFallback(); else cb.onError(data || {}); }
          });
          return pump();
        });
      }
      return pump();
    }).catch(function(){ cb.onFallback(); });
  }

  function discussLegacy($wrap, onDone, onError){
    var body = discussParams($wrap, 'awg_agent_chat');
    $.ajax({ url: AWG_AIG.ajaxurl, method: 'POST', data: body.toString(), dataType: 'json' })
      .done(function(j){
        if (j && j.success && j.data){ onDone(j.data.text || '', j.data.thread_id || 0); }
        else { onError((j && j.data) || {}); }
      })
      .fail(function(){ onError({ message: 'Something went wrong. Please try again.' }); });
  }

  $(document).on('click', '.awg-aig__discuss', function(){
    openDiscuss($(this).closest('.awg-aig'));
  });
  $(document).on('click', '.awg-aig__discuss-back', function(){
    var $wrap = $(this).closest('.awg-aig');
    var $result = $wrap.find('.awg-aig__result').first();
    $result.removeClass('awg-aig__result--discuss');
    $result.find('.awg-aig__discuss-panel').hide();
    $result.find('.awg-aig__output').removeAttr('hidden').css('display', '');
    $result.find('.awg-aig__result-actions--bottom').css('display', '');
    $result.find('.awg-aig__cta').css('display', '');
  });
  $(document).on('click', '.awg-aig__discuss-starter', function(){
    var $wrap = $(this).closest('.awg-aig');
    $wrap.find('.awg-aig__discuss-input').val($(this).text());
    discussSend($wrap);
  });
  $(document).on('submit', '.awg-aig__discuss-form', function(e){
    e.preventDefault();
    discussSend($(this).closest('.awg-aig'));
  });
  $(document).on('input', '.awg-aig__discuss-input', function(){ autosizeDiscuss($(this)); });
  $(document).on('keydown', '.awg-aig__discuss-input', function(e){
    if (e.key === 'Enter' && !e.shiftKey){ e.preventDefault(); discussSend($(this).closest('.awg-aig')); }
  });

  $(document).ready(function(){
    $('.awg-aig').each(function(){
      applyGclid($(this));
    });
  });
})(jQuery);
