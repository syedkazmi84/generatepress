(function($){
  function nextIndex($wrap){
    const $rows = $wrap.find('.awg-field-row');
    if ($rows.length === 0) return 0;
    let max = -1;
    $rows.each(function(){
      const idx = parseInt($(this).attr('data-index'), 10);
      if (!isNaN(idx)) max = Math.max(max, idx);
    });
    return max + 1;
  }

  function ensureSortable() {
    if (!$.fn.sortable) return;
    $("#awg-fields").sortable({
      handle: ".awg-field-row__top",
      placeholder: "awg-sort-placeholder",
      forcePlaceholderSize: true
    });
  }

  // Visually disable per-template overrides whenever the corresponding
  // "Use global ..." checkbox is on, so admins don't waste time editing
  // values that the renderer will ignore.
  function applyOverrideState() {
    const stylesOn = $('#awg-use-global-styles').is(':checked');
    $('.awg-style-override')
      .toggleClass('awg-override-disabled', stylesOn)
      .find('input, select, textarea')
      .prop('disabled', stylesOn);
    // The wp-color-picker wraps the original input in extra UI; disable those too.
    $('.awg-style-override .wp-picker-container').each(function(){
      const $c = $(this);
      $c.toggleClass('awg-override-disabled', stylesOn);
      $c.find('button').prop('disabled', stylesOn);
    });

    const sizesOn = $('#awg-use-global-field-sizes').is(':checked');
    $('.awg-fieldsize-override')
      .toggleClass('awg-override-disabled', sizesOn)
      .find('input, select, textarea')
      .prop('disabled', sizesOn);
  }

  $(document).ready(function(){
    ensureSortable();
    // Defer once so wp-color-picker has finished wrapping inputs.
    setTimeout(applyOverrideState, 0);
  });

  $(document).on('change', '#awg-use-global-styles, #awg-use-global-field-sizes', applyOverrideState);

  // Collapsible sections: open/closed state is intentionally NOT persisted
  // across page loads. Every time the admin lands on Settings or the
  // template editor, sections start in the default state the PHP renderer
  // set via Settings::section_open($key, $title, $open). Toggling during
  // the current session works normally; reload returns to defaults.
  $(document).on('click', '.awg-section__toggle', function(e){
    e.preventDefault();
    var $btn      = $(this);
    var expanded  = $btn.attr('aria-expanded') === 'true';
    $btn.attr('aria-expanded', expanded ? 'false' : 'true');
  });

  // One-time cleanup: prior versions persisted section state under
  // 'awg-section-*' keys. Remove them so they don't sit forever in
  // localStorage on users who upgrade.
  $(document).ready(function(){
    try {
      for (var i = localStorage.length - 1; i >= 0; i--) {
        var k = localStorage.key(i);
        if (k && k.indexOf('awg-section-') === 0) {
          localStorage.removeItem(k);
        }
      }
    } catch (e) {}
  });

  $(document).on('click', '#awg-add-field', function(){
    const $fields = $('#awg-fields');
    const tpl = document.getElementById('awg-field-template');
    if (!tpl) return;

    const html = tpl.innerHTML;
    const idx = nextIndex($fields);
    const row = html.split('__INDEX__').join(String(idx));
    $fields.append(row);
    ensureSortable();
  });

  $(document).on('click', '.awg-remove-field', function(){
    $(this).closest('.awg-field-row').remove();
  });

  // v5.4.69: show the upload-field settings (allowed types + max size) only when
  // a row's Type is set to "file". Keeps the row uncluttered for every other type.
  function syncFileSettings($row){
    if (!$row || !$row.length) return;
    var isFile = $row.find('select[name$="[type]"]').val() === 'file';
    $row.find('.awg-file-settings').toggle(isFile);
  }

  $(document).on('change', 'select[name$="[type]"]', function(){
    syncFileSettings($(this).closest('.awg-field-row'));
  });

  $(document).ready(function(){
    $('.awg-field-row').each(function(){ syncFileSettings($(this)); });
  });

  // v5.4.84: "Insert into Rules" for the Result blocks reference. Appends the
  // block's ready instruction to the Rules textarea on its own line (no dupes),
  // focuses it, and fires input/change so the Final Prompt Preview updates.
  $(document).on('click', '.awg-block-insert', function(e){
    e.preventDefault();
    var snippet = $(this).attr('data-awg-insert') || '';
    if (!snippet) return;
    var $rules = $('textarea[name="awg_aig[rules]"]').first();
    if (!$rules.length) return;
    var cur = $rules.val() || '';
    if (cur.indexOf(snippet) !== -1) { $rules.focus(); return; } // already there
    $rules.val((cur.replace(/\s+$/, '') + (cur.trim() ? '\n' : '') + snippet + '\n').replace(/^\n+/, ''));
    $rules.trigger('input').trigger('change').focus();
    var el = $rules.get(0);
    if (el && el.setSelectionRange) { var L = $rules.val().length; el.setSelectionRange(L, L); }
    el.scrollTop = el.scrollHeight;
  });

})(jQuery);
