/**
 * AuthorWings AI — Agent chat.
 *
 * Drives every .awg-agent container (public agents and the admin Build
 * Assistant). Features: live streaming (SSE over fetch) with a stop button,
 * file attachments, and per-user saved conversations with a history sidebar.
 * Falls back to the non-streaming JSON endpoint when streaming is unavailable.
 */
(function () {
  "use strict";

  var CFG = window.AWG_AGENT || {};
  var I18N = CFG.i18n || {};

  function t(key, fallback) {
    return I18N[key] || fallback;
  }

  /* --- tiny, safe markdown -> HTML ----------------------------------- */

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function renderMarkdown(text) {
    var out = [];
    var lines = String(text).replace(/\r\n/g, "\n").split("\n");
    var inCode = false;
    var codeBuf = [];
    var listBuf = [];

    function flushList() {
      if (listBuf.length) {
        out.push("<ul>" + listBuf.join("") + "</ul>");
        listBuf = [];
      }
    }
    function inline(s) {
      s = escapeHtml(s);
      s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, function (_, txt, url) {
        return '<a href="' + url + '" target="_blank" rel="noopener noreferrer">' + txt + "</a>";
      });
      s = s.replace(/`([^`]+)`/g, "<code>$1</code>");
      s = s.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
      s = s.replace(/(^|[^*])\*([^*]+)\*/g, "$1<em>$2</em>");
      return s;
    }

    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];
      if (/^```/.test(line)) {
        if (inCode) {
          out.push("<pre><code>" + escapeHtml(codeBuf.join("\n")) + "</code></pre>");
          codeBuf = [];
          inCode = false;
        } else {
          flushList();
          inCode = true;
        }
        continue;
      }
      if (inCode) { codeBuf.push(line); continue; }
      if (/^\s*[-*]\s+/.test(line)) {
        listBuf.push("<li>" + inline(line.replace(/^\s*[-*]\s+/, "")) + "</li>");
        continue;
      }
      flushList();
      if (/^\s*#{1,3}\s+/.test(line)) {
        out.push("<h4>" + inline(line.replace(/^\s*#{1,3}\s+/, "")) + "</h4>");
      } else if (line.trim() !== "") {
        out.push("<p>" + inline(line) + "</p>");
      }
    }
    if (inCode) out.push("<pre><code>" + escapeHtml(codeBuf.join("\n")) + "</code></pre>");
    flushList();
    return out.join("");
  }

  function post(body) {
    return fetch(CFG.ajaxurl, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: body.toString(),
    }).then(function (r) {
      return r.json().then(function (j) { return { ok: r.ok, json: j }; });
    });
  }

  /** Give a pasted clipboard image a stable, sensible filename for upload. */
  function namePastedFile(blob, type) {
    var ext = String(type || blob.type || "image/png").split("/")[1] || "png";
    ext = ext.replace(/[^a-z0-9]/gi, "").toLowerCase() || "png";
    if (ext === "jpeg") ext = "jpg";
    var name = "pasted-" + Date.now() + "." + ext;
    try {
      return new File([blob], name, { type: blob.type || type || "image/png" });
    } catch (e) {
      // Older browsers: File constructor unavailable — tag the blob directly.
      try { blob.name = name; } catch (e2) {}
      return blob;
    }
  }

  function slugify(s) {
    return (String(s || "chat").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "chat").slice(0, 40);
  }

  function downloadText(filename, text, mime) {
    try {
      var blob = new Blob([text], { type: (mime || "text/plain") + ";charset=utf-8" });
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
    } catch (e) {}
  }

  function copyText(text, btn) {
    function flash() {
      if (!btn) return;
      var old = btn.getAttribute("data-label") || btn.textContent;
      btn.textContent = "✓";
      setTimeout(function () { btn.textContent = old; }, 1200);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(flash, function () {});
    } else {
      var ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand("copy"); flash(); } catch (e) {}
      document.body.removeChild(ta);
    }
  }

  /* --- one agent instance -------------------------------------------- */

  function initAgent(root) {
    if (root.getAttribute("data-awg-ready") === "1") return;
    root.setAttribute("data-awg-ready", "1");

    var agentId = root.getAttribute("data-agent-id") || "0";
    var action = root.getAttribute("data-action") || "awg_agent_chat";
    var greeting = root.getAttribute("data-greeting") || "";
    var isAdmin = action === "awg_agent_admin_chat";
    var allowUploads = root.getAttribute("data-allow-uploads") === "1";
    var maxMb = parseInt(root.getAttribute("data-max-mb") || "10", 10) || 10;
    var canStream = !!CFG.stream && !isAdmin && typeof fetch === "function" && typeof ReadableStream !== "undefined";
    var hasMemory = !!CFG.loggedIn && !isAdmin && root.classList.contains("awg-agent--memory");

    var log = root.querySelector(".awg-agent-log");
    var form = root.querySelector(".awg-agent-form");
    var input = root.querySelector(".awg-agent-input");
    var sendBtn = root.querySelector(".awg-agent-send");
    var stopBtn = root.querySelector(".awg-agent-stop");
    var starterWrap = root.querySelector(".awg-agent-starters");
    var starters = root.querySelectorAll(".awg-agent-starter");
    var attachWrap = root.querySelector(".awg-agent-attachments");
    var fileInput = root.querySelector(".awg-agent-file");
    var sidebar = root.querySelector(".awg-agent-threads");
    var newChatBtn = root.querySelector(".awg-agent-newchat");

    var history = [];
    var busy = false;
    var threadId = 0;
    var attachments = []; // [{token, name}]
    var aborter = null;

    resetChat();

    /* ---- rendering ---- */

    function resetChat() {
      history = [];
      threadId = 0;
      attachments = [];
      if (log) log.innerHTML = "";
      renderAttachments();
      if (starterWrap) starterWrap.style.display = "";
      if (greeting) addMessage("assistant", greeting, false);
    }

    function addMessage(role, content, store, withActions) {
      var row = document.createElement("div");
      row.className = "awg-agent-msg awg-agent-msg--" + (role === "user" ? "user" : "assistant");
      var bubble = document.createElement("div");
      bubble.className = "awg-agent-bubble";
      if (role === "user") {
        bubble.textContent = content;
      } else {
        bubble.innerHTML = renderMarkdown(content);
      }
      row.appendChild(bubble);
      log.appendChild(row);
      if (role === "assistant" && withActions) decorate(row, content);
      log.scrollTop = log.scrollHeight;
      if (store !== false) history.push({ role: role, content: content });
      return bubble;
    }

    /** Append a Copy + Download action bar under an assistant reply. */
    function decorate(row, text) {
      if (!row || row.querySelector(".awg-agent-actions")) return;
      var bar = document.createElement("div");
      bar.className = "awg-agent-actions";

      var copyBtn = document.createElement("button");
      copyBtn.type = "button";
      copyBtn.className = "awg-agent-action";
      copyBtn.textContent = t("copy", "Copy");
      copyBtn.setAttribute("data-label", t("copy", "Copy"));
      copyBtn.addEventListener("click", function () { copyText(text, copyBtn); });

      var dlBtn = document.createElement("button");
      dlBtn.type = "button";
      dlBtn.className = "awg-agent-action";
      dlBtn.textContent = t("download", "Download");
      dlBtn.addEventListener("click", function () {
        downloadText("reply-" + slugify(text.slice(0, 30)) + ".md", text, "text/markdown");
      });

      bar.appendChild(copyBtn);
      bar.appendChild(dlBtn);
      row.appendChild(bar);
    }

    /** Build a Markdown transcript of the whole conversation. */
    function transcript() {
      var lines = ["# " + (root.querySelector(".awg-agent-name") ? root.querySelector(".awg-agent-name").textContent : "Chat"), ""];
      history.forEach(function (m) {
        lines.push((m.role === "assistant" ? "**Assistant:**" : "**You:**"));
        lines.push(m.content);
        lines.push("");
      });
      return lines.join("\n");
    }

    function setBusy(state) {
      busy = state;
      if (sendBtn) sendBtn.style.display = state ? "none" : "";
      if (stopBtn) stopBtn.hidden = !state || !canStream;
      if (input) input.disabled = state;
    }

    function newAssistantBubble() {
      var row = document.createElement("div");
      row.className = "awg-agent-msg awg-agent-msg--assistant";
      var status = document.createElement("div");
      status.className = "awg-agent-status";
      status.style.display = "none";
      var bubble = document.createElement("div");
      bubble.className = "awg-agent-bubble";
      bubble.innerHTML = '<span class="awg-agent-dots"><i></i><i></i><i></i></span>';
      row.appendChild(status);
      row.appendChild(bubble);
      log.appendChild(row);
      log.scrollTop = log.scrollHeight;
      return { row: row, bubble: bubble, status: status };
    }

    /* ---- attachments ---- */

    function renderAttachments() {
      if (!attachWrap) return;
      attachWrap.innerHTML = "";
      attachments.forEach(function (a, idx) {
        var chip = document.createElement("span");
        chip.className = "awg-agent-chip";
        chip.textContent = a.name + " ";
        var x = document.createElement("button");
        x.type = "button";
        x.className = "awg-agent-chip-x";
        x.textContent = "×";
        x.addEventListener("click", function () {
          attachments.splice(idx, 1);
          renderAttachments();
        });
        chip.appendChild(x);
        attachWrap.appendChild(chip);
      });
    }

    function uploadFile(file) {
      if (!file) return;
      if (file.size > maxMb * 1024 * 1024) {
        flashError(file.name + ": " + maxMb + "MB max");
        return;
      }
      var chip = document.createElement("span");
      chip.className = "awg-agent-chip awg-agent-chip--loading";
      chip.textContent = t("uploading", "Uploading…");
      if (attachWrap) attachWrap.appendChild(chip);

      var fd = new FormData();
      fd.append("action", isAdmin ? "awg_agent_admin_upload" : "awg_agent_upload");
      fd.append("nonce", CFG.nonce || "");
      fd.append("agent_id", agentId);
      fd.append("file", file, file.name || "upload");

      fetch(CFG.ajaxurl, { method: "POST", credentials: "same-origin", body: fd })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (chip.parentNode) chip.parentNode.removeChild(chip);
          if (j && j.success && j.data && j.data.token) {
            attachments.push({ token: j.data.token, name: j.data.name || "file" });
            renderAttachments();
          } else {
            flashError((j && j.data && j.data.message) || t("error", "Upload failed."));
          }
        })
        .catch(function () {
          if (chip.parentNode) chip.parentNode.removeChild(chip);
          flashError(t("error", "Upload failed."));
        });
    }

    function flashError(msg) {
      var b = addMessage("assistant", msg, false);
      b.classList.add("awg-agent-error");
    }

    /* ---- sending a turn ---- */

    function send(text) {
      text = (text || "").trim();
      if ((!text && attachments.length === 0) || busy) return;
      if (!text && attachments.length) text = "(see attached file)";

      addMessage("user", text);
      var sentAttachments = attachments.map(function (a) { return a.token; });
      attachments = [];
      renderAttachments();
      if (input) { input.value = ""; autosize(); }
      if (starterWrap) starterWrap.style.display = "none";
      setBusy(true);

      var ui = newAssistantBubble();
      var streamed = "";
      var gotDelta = false;

      var body = new URLSearchParams();
      body.set("nonce", CFG.nonce || "");
      body.set("agent_id", agentId);
      body.set("messages", JSON.stringify(history));
      body.set("thread_id", String(threadId));
      if (sentAttachments.length) body.set("attachments", JSON.stringify(sentAttachments));

      function finishOk(finalText, newThreadId) {
        ui.status.style.display = "none";
        ui.bubble.innerHTML = renderMarkdown(finalText);
        decorate(ui.row, finalText);
        history.push({ role: "assistant", content: finalText });
        if (newThreadId && newThreadId > 0 && newThreadId !== threadId) {
          threadId = newThreadId;
          loadThreads();
        }
        log.scrollTop = log.scrollHeight;
        setBusy(false);
        if (input) input.focus();
      }
      function finishErr(data) {
        data = data || {};
        ui.status.style.display = "none";
        ui.bubble.innerHTML = "";
        ui.bubble.textContent = data.message || t("error", "Something went wrong.");
        ui.bubble.classList.add("awg-agent-error");
        if (data.upgrade_url) {
          var a = document.createElement("a");
          a.className = "awg-agent-upgrade";
          a.href = data.upgrade_url;
          a.textContent = data.upgrade_label || "Upgrade";
          ui.bubble.appendChild(document.createElement("br"));
          ui.bubble.appendChild(a);
        }
        setBusy(false);
      }

      function runJson() {
        var b2 = new URLSearchParams(body.toString());
        b2.set("action", isAdmin ? action : "awg_agent_chat");
        post(b2).then(function (res) {
          if (res.json && res.json.success && res.json.data) {
            finishOk(res.json.data.text || "", res.json.data.thread_id || 0);
          } else {
            finishErr((res.json && res.json.data) || {});
          }
        }).catch(function () {
          finishErr({ message: t("error", "Something went wrong.") });
        });
      }

      if (!canStream) { runJson(); return; }

      // Streaming path (SSE over fetch).
      aborter = new AbortController();
      var sbody = new URLSearchParams(body.toString());
      sbody.set("action", "awg_agent_chat_stream");

      fetch(CFG.ajaxurl, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: sbody.toString(),
        signal: aborter.signal,
      })
        .then(function (resp) {
          if (!resp.body || !resp.body.getReader) { runJson(); return; }
          var reader = resp.body.getReader();
          var decoder = new TextDecoder();
          var buf = "";

          function handleEvent(evt, data) {
            if (evt === "status") {
              ui.status.style.display = "";
              ui.status.textContent = (data && data.label) || t("thinking", "Thinking…");
            } else if (evt === "delta") {
              if (!gotDelta) { gotDelta = true; ui.bubble.innerHTML = ""; ui.status.style.display = "none"; }
              streamed += (data && data.text) || "";
              ui.bubble.innerHTML = renderMarkdown(streamed);
              log.scrollTop = log.scrollHeight;
            } else if (evt === "done") {
              var finalText = (data && data.text) || streamed;
              if (gotDelta) {
                ui.bubble.innerHTML = renderMarkdown(finalText);
                ui.status.style.display = "none";
                decorate(ui.row, finalText);
                history.push({ role: "assistant", content: finalText });
                if (data && data.thread_id && data.thread_id > 0 && data.thread_id !== threadId) {
                  threadId = data.thread_id; loadThreads();
                }
                setBusy(false);
                if (input) input.focus();
              } else {
                typewriter(ui, finalText, (data && data.thread_id) || 0);
              }
            } else if (evt === "error") {
              if (data && data.fallback) { runJson(); }
              else { finishErr(data); }
            }
          }

          function pump() {
            return reader.read().then(function (res) {
              if (res.done) { return; }
              buf += decoder.decode(res.value, { stream: true });
              var blocks = buf.split("\n\n");
              buf = blocks.pop();
              blocks.forEach(function (block) {
                var evt = "message", data = null;
                block.split("\n").forEach(function (line) {
                  if (line.indexOf("event:") === 0) evt = line.slice(6).trim();
                  else if (line.indexOf("data:") === 0) {
                    try { data = JSON.parse(line.slice(5).trim()); } catch (e) {}
                  }
                });
                if (data !== null || evt !== "message") handleEvent(evt, data);
              });
              return pump();
            });
          }
          return pump();
        })
        .catch(function (e) {
          if (e && e.name === "AbortError") {
            // User stopped: keep whatever streamed in.
            if (gotDelta && streamed) {
              history.push({ role: "assistant", content: streamed });
            } else {
              ui.row.parentNode && ui.row.parentNode.removeChild(ui.row);
            }
            setBusy(false);
          } else {
            runJson();
          }
        });
    }

    function typewriter(ui, text, newThreadId) {
      ui.status.style.display = "none";
      var i = 0;
      var step = Math.max(2, Math.round(text.length / 200));
      function tick() {
        i += step;
        ui.bubble.innerHTML = renderMarkdown(text.slice(0, i));
        log.scrollTop = log.scrollHeight;
        if (i < text.length && busy) {
          setTimeout(tick, 16);
        } else {
          ui.bubble.innerHTML = renderMarkdown(text);
          decorate(ui.row, text);
          history.push({ role: "assistant", content: text });
          if (newThreadId && newThreadId > 0 && newThreadId !== threadId) {
            threadId = newThreadId; loadThreads();
          }
          setBusy(false);
          if (input) input.focus();
        }
      }
      tick();
    }

    /* ---- memory / threads ---- */

    function loadThreads() {
      if (!hasMemory || !sidebar) return;
      var b = new URLSearchParams();
      b.set("action", "awg_agent_threads");
      b.set("nonce", CFG.nonce || "");
      b.set("agent_id", agentId);
      post(b).then(function (res) {
        if (!(res.json && res.json.success)) return;
        sidebar.innerHTML = "";
        (res.json.data.threads || []).forEach(function (th) {
          var item = document.createElement("div");
          item.className = "awg-agent-thread" + (th.id === threadId ? " is-active" : "");
          var open = document.createElement("button");
          open.type = "button";
          open.className = "awg-agent-thread-open";
          open.textContent = th.title || "Chat";
          open.addEventListener("click", function () { openThread(th.id); });
          var del = document.createElement("button");
          del.type = "button";
          del.className = "awg-agent-thread-del";
          del.textContent = "🗑";
          del.addEventListener("click", function (e) {
            e.stopPropagation();
            if (!window.confirm(t("deleteQ", "Delete this chat?"))) return;
            deleteThread(th.id);
          });
          item.appendChild(open);
          item.appendChild(del);
          sidebar.appendChild(item);
        });
      });
    }

    function openThread(id) {
      var b = new URLSearchParams();
      b.set("action", "awg_agent_thread");
      b.set("nonce", CFG.nonce || "");
      b.set("agent_id", agentId);
      b.set("thread_id", String(id));
      post(b).then(function (res) {
        if (!(res.json && res.json.success)) return;
        history = [];
        if (log) log.innerHTML = "";
        if (starterWrap) starterWrap.style.display = "none";
        if (greeting) addMessage("assistant", greeting, false);
        (res.json.data.messages || []).forEach(function (m) {
          addMessage(m.role === "assistant" ? "assistant" : "user", m.content, true, m.role === "assistant");
        });
        threadId = res.json.data.thread_id || id;
        loadThreads();
      });
    }

    function deleteThread(id) {
      var b = new URLSearchParams();
      b.set("action", "awg_agent_thread_delete");
      b.set("nonce", CFG.nonce || "");
      b.set("agent_id", agentId);
      b.set("thread_id", String(id));
      post(b).then(function () {
        if (id === threadId) resetChat();
        loadThreads();
      });
    }

    /* ---- input wiring ---- */

    function autosize() {
      if (!input) return;
      input.style.height = "auto";
      input.style.height = Math.min(input.scrollHeight, 160) + "px";
    }

    if (form) {
      form.addEventListener("submit", function (e) {
        e.preventDefault();
        send(input ? input.value : "");
      });
    }
    if (input) {
      input.addEventListener("input", autosize);
      input.addEventListener("keydown", function (e) {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          send(input.value);
        }
      });
    }
    if (stopBtn) {
      stopBtn.addEventListener("click", function () {
        if (aborter) aborter.abort();
      });
    }
    if (fileInput) {
      fileInput.addEventListener("change", function () {
        if (fileInput.files && fileInput.files[0]) uploadFile(fileInput.files[0]);
        fileInput.value = "";
      });
    }

    // Paste-to-upload: a screenshot (or copied image) pasted with Ctrl/⌘+V is
    // uploaded as an attachment instead of being dropped into the textarea. The
    // listener lives on the container so a paste in the textarea bubbles up to
    // it exactly once — binding both would upload every image twice.
    if (allowUploads) {
      root.addEventListener("paste", function (e) {
        var dt = e.clipboardData || window.clipboardData;
        if (!dt || !dt.items) return;
        var seen = false;
        for (var i = 0; i < dt.items.length; i++) {
          var item = dt.items[i];
          if (item.kind === "file" && /^image\//.test(item.type || "")) {
            var blob = item.getAsFile();
            if (blob) {
              uploadFile(namePastedFile(blob, item.type));
              seen = true;
              break; // one image per paste — ignore duplicate clipboard reps
            }
          }
        }
        if (seen) e.preventDefault();
      });
    }
    if (newChatBtn) {
      newChatBtn.addEventListener("click", resetChat);
    }
    Array.prototype.forEach.call(starters, function (btn) {
      btn.addEventListener("click", function () { send(btn.textContent || ""); });
    });

    // Header action: download the whole conversation as Markdown.
    var head = root.querySelector(".awg-agent-head");
    if (head) {
      var dl = document.createElement("button");
      dl.type = "button";
      dl.className = "awg-agent-head-action";
      dl.title = t("downloadChat", "Download conversation");
      dl.setAttribute("aria-label", t("downloadChat", "Download conversation"));
      dl.innerHTML = "⬇";
      dl.addEventListener("click", function () {
        var firstUser = "";
        for (var i = 0; i < history.length; i++) {
          if (history[i].role === "user") { firstUser = history[i].content; break; }
        }
        if (!firstUser) return; // nothing said yet
        downloadText("conversation-" + slugify(firstUser.slice(0, 30)) + ".md", transcript(), "text/markdown");
      });
      head.appendChild(dl);
    }

    if (hasMemory) loadThreads();
  }

  function boot() {
    var nodes = document.querySelectorAll(".awg-agent");
    Array.prototype.forEach.call(nodes, function (n) {
      if (!n.classList.contains("awg-agent--empty")) initAgent(n);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
