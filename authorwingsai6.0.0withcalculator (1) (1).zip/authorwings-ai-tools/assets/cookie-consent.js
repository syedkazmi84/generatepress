/* AuthorWings AI — Cookie Consent (GDPR) notice bar.
   Remembers the visitor's choice ("accept" / "reject") in localStorage + a
   1-year cookie, so the bar is shown only to first-time visitors. The bar is
   printed hidden and revealed here when no choice has been made yet, which keeps
   it correct behind full-page caches / CDNs where the server can't see the
   visitor's cookie.

   When the visitor chooses, the decision is broadcast three ways so a tag
   manager / analytics can honour it:
     - a "awg-cookie-consent" CustomEvent on window (detail.consent)
     - a dataLayer push { event:'awg_cookie_consent', awg_cookie_consent:choice }
     - the awg_cookie_consent cookie set to "accept" or "reject"
   This plugin itself sets no analytics/advertising cookies, so the actual
   blocking of such scripts on "reject" must be wired where those scripts load
   (e.g. Google Tag Manager Consent Mode reading these signals).

   KEY must match Cookie_Consent::STORE_KEY in includes/class-cookie-consent.php. */
(function () {
    'use strict';

    var KEY = 'awg_cookie_consent';

    function init() {
        var bar = document.getElementById('awg-cookie-consent');
        if (!bar) { return; }

        // Expose the current choice for scripts that load after this one.
        window.awgCookieConsent = { get: choice };

        if (choice() !== '') {
            broadcast(choice()); // let late-loading tags read a prior decision
            return;
        }

        bar.hidden = false;
        bar.style.display = 'block';

        bind(bar, '.awg-cookie-consent__accept', 'accept');
        bind(bar, '.awg-cookie-consent__reject', 'reject');
    }

    function bind(bar, selector, decision) {
        var btn = bar.querySelector(selector);
        if (!btn) { return; }
        btn.addEventListener('click', function () {
            remember(decision);
            broadcast(decision);
            bar.style.display = 'none';
            bar.hidden = true;
        });
    }

    /* Returns 'accept', 'reject', or '' when no choice has been stored yet.
       A legacy value of '1' (older versions stored only "dismissed") is treated
       as a prior acceptance so existing visitors are not re-prompted. */
    function choice() {
        var v = '';
        try {
            if (window.localStorage) { v = localStorage.getItem(KEY) || ''; }
        } catch (e) {}
        if (v === '') {
            var m = document.cookie.match(/(?:^|;\s*)awg_cookie_consent=([^;]+)/);
            v = m ? decodeURIComponent(m[1]) : '';
        }
        if (v === '1') { return 'accept'; }
        return (v === 'accept' || v === 'reject') ? v : '';
    }

    function remember(decision) {
        try {
            if (window.localStorage) { localStorage.setItem(KEY, decision); }
        } catch (e) {}
        var exp = new Date();
        exp.setFullYear(exp.getFullYear() + 1);
        document.cookie = KEY + '=' + decision + '; expires=' + exp.toUTCString() + '; path=/; SameSite=Lax';
    }

    function broadcast(decision) {
        try {
            window.dispatchEvent(new CustomEvent('awg-cookie-consent', { detail: { consent: decision } }));
        } catch (e) {}
        try {
            window.dataLayer = window.dataLayer || [];
            window.dataLayer.push({ event: 'awg_cookie_consent', awg_cookie_consent: decision });
        } catch (e) {}
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
