/**
 * AuthorWings AI — lean pricing page behaviour.
 *
 * The shared pricing template renders each plan CTA as a link:
 *   - logged-out visitors  -> register/login, with redirect_to back to
 *                             /pricing/?...&upgrade=SLUG
 *   - logged-in visitors   -> /pricing/?...&upgrade=SLUG (in the full plugin the
 *                             member dashboard read that and started checkout)
 *
 * The lean build has no member dashboard, so this script:
 *   1. For logged-in visitors, intercepts a CTA click and starts Stripe
 *      checkout directly via the awg_mem_upgrade_plan AJAX action.
 *   2. Auto-resumes: if a logged-in visitor lands on the pricing page with
 *      ?upgrade=SLUG (e.g. straight after registering/logging in), it starts
 *      checkout for that plan automatically — no second click needed.
 *   3. Shows the post-checkout success / cancelled notices.
 *
 * Logged-out visitors are left to register/log in first (their CTA is a normal
 * link); checkout resumes for them automatically once they return logged in.
 */
(function () {
	var cfg = window.AWG_MEM_LEAN || {};

	function slugFromHref(href) {
		if (!href) { return ''; }
		try {
			var u = new URL(href, window.location.origin);
			return u.searchParams.get('upgrade') || '';
		} catch (e) {
			var m = /[?&]upgrade=([^&]+)/.exec(href);
			return m ? decodeURIComponent(m[1]) : '';
		}
	}

	function showNotice(text, kind) {
		var wrap = document.querySelector('.awg-mem-pricing') || document.body;
		var n = document.createElement('div');
		n.className = 'awg-mem-lean-notice awg-mem-lean-notice--' + (kind || 'info');
		n.setAttribute('role', 'status');
		n.style.cssText = 'margin:0 auto 20px;max-width:720px;padding:12px 16px;border-radius:10px;font:15px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;' +
			(kind === 'success'
				? 'background:#e7f6ec;color:#0f5132;border:1px solid #b7dfc4;'
				: 'background:#fff4e5;color:#7a4f00;border:1px solid #ffd699;');
		n.textContent = text;
		if (wrap.parentNode) { wrap.parentNode.insertBefore(n, wrap); } else { wrap.prepend(n); }
	}

	function currentBilling() {
		var el = document.querySelector('input[name="awg_mem_billing"]:checked, [data-awg-billing].is-active');
		var b = el ? (el.value || el.getAttribute('data-awg-billing')) : 'monthly';
		return b === 'yearly' ? 'yearly' : 'monthly';
	}

	function startCheckout(slug, billing, anchor, confirmReplace) {
		var original = anchor ? anchor.textContent : '';
		if (anchor) {
			if (anchor.getAttribute('data-busy') === '1') { return; }
			anchor.setAttribute('data-busy', '1');
			anchor.textContent = 'Redirecting…';
		}
		var body = 'action=awg_mem_upgrade_plan' +
			'&nonce=' + encodeURIComponent(cfg.nonce || '') +
			'&plan=' + encodeURIComponent(slug) +
			'&billing=' + encodeURIComponent(billing || 'monthly') +
			(confirmReplace ? '&confirm_replace=1' : '');

		fetch(cfg.ajax_url, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body
		})
			.then(function (r) { return r.json(); })
			.then(function (res) {
				if (res && res.success && res.data && res.data.redirect) {
					window.location.href = res.data.redirect;
					return;
				}
				// The member already has a different plan change scheduled; the
				// server is asking them to confirm replacing it before we proceed.
				if (res && res.data && res.data.needs_confirmation && !confirmReplace) {
					if (anchor) { anchor.textContent = original; anchor.removeAttribute('data-busy'); }
					var ask = (res.data.message) || 'You already have a scheduled plan change. Replace it?';
					if (window.confirm(ask)) {
						startCheckout(slug, billing, anchor, true);
					}
					return;
				}
				// A successful change that needs no redirect (e.g. a scheduled
				// downgrade) still carries a message to show.
				if (res && res.success && res.data && res.data.message) {
					if (anchor) { anchor.textContent = original; anchor.removeAttribute('data-busy'); }
					showNotice(res.data.message, 'success');
					return;
				}
				if (anchor) { anchor.textContent = original; anchor.removeAttribute('data-busy'); }
				showNotice((res && res.data && res.data.message) ? res.data.message : 'Could not start checkout. Please try again.', 'info');
			})
			.catch(function () {
				if (anchor) { anchor.textContent = original; anchor.removeAttribute('data-busy'); }
				showNotice('Network error starting checkout. Please try again.', 'info');
			});
	}

	// ---- Post-checkout return notices ----
	var params;
	try { params = new URLSearchParams(window.location.search); } catch (e) { params = null; }
	var isSuccess = params && params.get('payment') === 'success';
	var isCancelled = params && params.get('cancelled') === '1';
	if (isSuccess) {
		showNotice('Payment received — your plan is being activated. It may take a few seconds to appear.', 'success');
	} else if (isCancelled) {
		showNotice('Checkout cancelled. You can pick a plan whenever you are ready.', 'info');
	}

	// ---- Monthly / Yearly toggle ----
	// Runs for every visitor (logged-out users browsing prices included). The
	// chosen cycle is persisted in sessionStorage so it survives the
	// register/login round-trip and is honoured by the auto-resume below.
	function persistBilling(b) {
		try { if (window.sessionStorage) { sessionStorage.setItem('awg_pending_billing', b); } } catch (e) {}
	}
	function applyBillingView(billing) {
		var cards = document.querySelectorAll('.awg-mem-pricing__card');
		for (var i = 0; i < cards.length; i++) {
			var views = cards[i].querySelectorAll('[data-billing-view]');
			if (!views.length) { continue; }
			// Fall back to the monthly view if a card has no matching cycle
			// (e.g. a paid plan with a monthly price but no yearly price).
			var target = cards[i].querySelector('[data-billing-view="' + billing + '"]') ? billing : 'monthly';
			for (var j = 0; j < views.length; j++) {
				views[j].hidden = (views[j].getAttribute('data-billing-view') !== target);
			}
		}
	}
	// Flip the member's own paid-plan button between "Current plan" (when the
	// toggle matches their billing cycle) and "Switch to monthly/yearly" (when
	// it doesn't). No-op for logged-out visitors (no such button is rendered).
	function applyCurrentPlanCta(billing) {
		var cta = document.querySelector('.awg-mem-pricing__cta[data-awg-current="1"]');
		if (!cta) { return; }
		var cycle = cta.getAttribute('data-awg-current-cycle') || 'monthly';
		var hasYearly = cta.getAttribute('data-awg-has-yearly') === '1';
		var href = cta.getAttribute('data-awg-href') || '';
		// A switch is offered only when the chosen cycle differs from the
		// member's current cycle AND that cycle exists for the plan (every paid
		// plan has monthly; yearly only when it is priced).
		var canSwitch = (billing !== cycle) && (billing === 'monthly' || hasYearly);
		if (canSwitch) {
			cta.classList.remove('awg-mem-pricing__cta--current');
			cta.removeAttribute('aria-disabled');
			if (href) { cta.setAttribute('href', href); }
			cta.textContent = (billing === 'yearly') ? 'Switch to yearly' : 'Switch to monthly';
		} else {
			cta.classList.add('awg-mem-pricing__cta--current');
			cta.setAttribute('aria-disabled', 'true');
			cta.removeAttribute('href');
			cta.textContent = 'Current plan';
		}
	}

	// Initial cycle: explicit URL param, then a persisted choice, else monthly.
	var initialBilling = (params && (params.get('awg_billing') || '')).toLowerCase();
	if (initialBilling !== 'monthly' && initialBilling !== 'yearly') {
		try { initialBilling = (window.sessionStorage && sessionStorage.getItem('awg_pending_billing')) || ''; } catch (e) { initialBilling = ''; }
	}
	if (initialBilling !== 'monthly' && initialBilling !== 'yearly') { initialBilling = 'monthly'; }
	var initialRadio = document.querySelector('input[name="awg_mem_billing"][value="' + initialBilling + '"]');
	if (initialRadio) { initialRadio.checked = true; }
	applyBillingView(initialBilling);
	applyCurrentPlanCta(initialBilling);
	document.addEventListener('change', function (e) {
		var t = e.target;
		if (t && t.name === 'awg_mem_billing') {
			var b = t.value === 'yearly' ? 'yearly' : 'monthly';
			applyBillingView(b);
			applyCurrentPlanCta(b);
			persistBilling(b);
		}
	});

	// Everything below is for logged-in visitors only.
	if (!cfg.logged_in) { return; }

	// ---- Auto-resume checkout after returning from register/login ----
	// If we arrived with ?upgrade=SLUG (and we're not on a payment return),
	// start checkout for that plan automatically. A per-session, per-slug guard
	// prevents a browser "back" from re-triggering an endless redirect.
	if (params && !isSuccess && !isCancelled) {
		var resumeSlug = (params.get('upgrade') || '').toLowerCase();
		if (resumeSlug && resumeSlug !== 'free') {
			var key = 'awg_autocheckout_' + resumeSlug;
			var already = false;
			try { already = window.sessionStorage && sessionStorage.getItem(key) === '1'; } catch (e) {}
			if (!already) {
				try { if (window.sessionStorage) { sessionStorage.setItem(key, '1'); } } catch (e) {}
				startCheckout(resumeSlug, currentBilling(), null);
			}
		}
	}

	// ---- Click handler ----
	document.addEventListener('click', function (e) {
		var a = e.target.closest ? e.target.closest('.awg-mem-pricing__cta') : null;
		if (!a) { return; }
		var slug = slugFromHref(a.getAttribute('href'));
		if (!slug) { return; }
		e.preventDefault();
		startCheckout(slug, currentBilling(), a);
	});
})();
