/* AuthorWings Membership — Dashboard Builder (admin) v3.1.7 */
(function ($) {
    'use strict';

    function serializeRow($row) {
        var type = $row.attr('data-row-type') === 'content' ? 'content' : 'dynamic';
        var row = {
            id:      $row.attr('data-row-id') || '',
            type:    type,
            visible: $row.find('.awg-builder-visible').is(':checked') ? 1 : 0
        };
        if (type === 'content') {
            row.title = $row.find('.awg-builder-title').val() || '';
            row.html  = $row.find('.awg-builder-html').val() || '';
        } else {
            var attrs = {};
            $row.find('.awg-builder-field').each(function () {
                var key   = $(this).attr('data-attr-key');
                var $ctrl = $(this).find('.awg-builder-attr');
                if (!key || !$ctrl.length) { return; }
                if ($ctrl.attr('data-attr-type') === 'toggle') {
                    attrs[key] = $ctrl.is(':checked') ? 1 : 0;
                } else {
                    attrs[key] = $ctrl.val();
                }
            });
            row.attrs = attrs;
        }
        return row;
    }

    function syncTab(tabKey) {
        var $list = $('[data-builder-list="' + tabKey + '"]');
        var rows = [];
        $list.children('.awg-builder-row').each(function () {
            rows.push(serializeRow($(this)));
        });
        $('[data-builder-json="' + tabKey + '"]').val(JSON.stringify(rows));
    }

    function syncAll() {
        $('[data-builder-list]').each(function () {
            syncTab($(this).attr('data-builder-list'));
        });
    }

    $(function () {
        var $wrap = $('.awg-builder-wrap');
        if (!$wrap.length) { return; }

        // Sortable lists (drag to reorder).
        if ($.fn.sortable) {
            $('.awg-builder-list').sortable({
                handle: '.awg-builder-row__handle',
                placeholder: 'awg-builder-row--placeholder',
                forcePlaceholderSize: true,
                axis: 'y',
                tolerance: 'pointer'
            });
        }

        // Tab switching.
        $wrap.on('click', '.awg-builder-tab-btn', function () {
            var tab = $(this).attr('data-builder-tab');
            $('.awg-builder-tab-btn').removeClass('button-primary');
            $(this).addClass('button-primary');
            $('.awg-builder-panel').hide();
            $('[data-builder-panel="' + tab + '"]').show();
        });

        // Add content block.
        $wrap.on('click', '.awg-builder-add-block', function () {
            var tab = $(this).attr('data-builder-add');
            var tpl = $('[data-builder-content-template]').html();
            if (!tpl) { return; }
            var $row = $(tpl).filter('.awg-builder-row').first();
            if (!$row.length) { $row = $('<div>').html(tpl).find('.awg-builder-row').first(); }
            // Unique id per new block so multiple can be added before saving.
            $row.attr('data-row-id', 'custom_' + Date.now());
            $('[data-builder-list="' + tab + '"]').append($row);
        });

        // Remove content block.
        $wrap.on('click', '.awg-builder-remove', function () {
            $(this).closest('.awg-builder-row').remove();
        });

        // Serialize everything into the hidden JSON fields before submit.
        $('.awg-builder-form').on('submit', function () {
            syncAll();
        });
    });

}(jQuery));
