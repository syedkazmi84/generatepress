/**
 * AuthorWings AI — lean member account page behaviour.
 *
 * Powers the self-service buttons on the [awg_account] page:
 *   - "Manage billing"  -> awg_mem_billing_portal AJAX -> redirect to the Stripe
 *                          customer portal (update card, view invoices).
 *   - "Cancel plan"     -> awg_mem_cancel_portal AJAX -> redirect to the Stripe
 *                          customer portal's cancellation flow. Stripe owns the
 *                          confirmation; the webhook moves the member to Free.
 *   - "Update" / "Update card" / inline "Manage billing" links reuse the same
 *     awg_mem_billing_portal endpoint (any element with .awg-acct-billing).
 *
 * All AJAX endpoints exist in the plugin; this only wires the buttons.
 */
(function () {
	var cfg = window.AWG_MEM_ACCT || {};

	function notice(text, kind) {
		var host = document.querySelector('.awg-acct') || document.body;
		var n = document.createElement('div');
		n.className = 'awg-acct-notice';
		n.setAttribute('role', 'status');
		n.style.cssText = 'margin:0 0 16px;padding:12px 16px;border-radius:10px;font:15px/1.4 inherit;' +
			(kind === 'success' ? 'background:#e7f6ec;color:#0f5132;border:1px solid #b7dfc4;' : 'background:#fff4e5;color:#7a4f00;border:1px solid #ffd699;');
		n.textContent = text;
		host.insertBefore(n, host.firstChild);
	}

	function post(action) {
		var body = 'action=' + encodeURIComponent(action) + '&nonce=' + encodeURIComponent(cfg.nonce || '');
		return fetch(cfg.ajax_url, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body
		}).then(function (r) { return r.json(); });
	}

	document.addEventListener('click', function (e) {
		var closest = e.target.closest ? e.target.closest.bind(e.target) : null;
		if (!closest) { return; }

		var portal = closest('.awg-acct-billing');
		if (portal) {
			e.preventDefault();
			if (portal.getAttribute('data-busy') === '1') { return; }
			portal.setAttribute('data-busy', '1');
			var po = portal.textContent;
			portal.textContent = 'Opening…';
			post('awg_mem_billing_portal').then(function (res) {
				if (res && res.success && res.data && res.data.redirect) { window.location.href = res.data.redirect; return; }
				portal.textContent = po; portal.removeAttribute('data-busy');
				notice((res && res.data && res.data.message) || 'Could not open the billing portal.', 'info');
			}).catch(function () {
				portal.textContent = po; portal.removeAttribute('data-busy');
				notice('Network error opening the billing portal.', 'info');
			});
			return;
		}

		var cancel = closest('.awg-acct-cancel');
		if (cancel) {
			e.preventDefault();
			if (cancel.getAttribute('data-busy') === '1') { return; }
			cancel.setAttribute('data-busy', '1');
			var co = cancel.textContent;
			cancel.textContent = 'Opening…';
			post('awg_mem_cancel_portal').then(function (res) {
				if (res && res.success && res.data && res.data.redirect) { window.location.href = res.data.redirect; return; }
				cancel.textContent = co; cancel.removeAttribute('data-busy');
				notice((res && res.data && res.data.message) || 'Could not open the cancellation page.', 'info');
			}).catch(function () {
				cancel.textContent = co; cancel.removeAttribute('data-busy');
				notice('Network error opening the cancellation page.', 'info');
			});
			return;
		}
	});
})();
