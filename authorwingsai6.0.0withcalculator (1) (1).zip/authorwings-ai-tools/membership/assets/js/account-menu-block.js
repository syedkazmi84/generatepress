/**
 * AuthorWings AI — "Account Menu" editor block.
 *
 * Dynamic / server-rendered: the editor shows a placeholder; the live markup is
 * produced by awg_aig_mem_render_account_menu() via the block's render_callback,
 * so it always reflects the current visitor's logged-in state.
 */
(function (blocks, element, i18n) {
	if (!blocks || !element) { return; }
	var el = element.createElement;
	var __ = (i18n && i18n.__) ? i18n.__ : function (s) { return s; };

	blocks.registerBlockType('authorwings/account-menu', {
		title: __('Account Menu', 'authorwings-ai-tools'),
		description: __('Log in / Sign up for visitors, and an account dropdown for members.', 'authorwings-ai-tools'),
		icon: 'admin-users',
		category: 'widgets',
		supports: { html: false, align: ['right'] },
		edit: function () {
			return el(
				'div',
				{
					style: {
						display: 'inline-flex',
						alignItems: 'center',
						gap: '8px',
						padding: '8px 14px',
						border: '1px dashed #c9b79c',
						borderRadius: '10px',
						color: '#5b6b7c',
						font: '13px/1.3 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
					}
				},
				el('span', {
					style: {
						width: '22px', height: '22px', borderRadius: '50%',
						background: '#10243c', color: '#fff',
						display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
						fontSize: '12px', fontWeight: 600
					}
				}, 'A'),
				__('AuthorWings account menu (renders on the live site)', 'authorwings-ai-tools')
			);
		},
		save: function () { return null; }
	});
})(window.wp && window.wp.blocks, window.wp && window.wp.element, window.wp && window.wp.i18n);
