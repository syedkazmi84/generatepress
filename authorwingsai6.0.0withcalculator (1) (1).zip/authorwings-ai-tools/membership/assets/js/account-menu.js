/**
 * AuthorWings AI — header account menu behaviour.
 *
 * - Toggles the avatar dropdown (click), with aria-expanded + outside-click /
 *   Escape to close. Supports more than one menu on a page.
 * - "Manage billing" starts the Stripe customer portal via the existing
 *   awg_mem_billing_portal AJAX action (same endpoint the account page uses),
 *   so it works from any page the menu is placed on.
 *
 * Plain links (My account, Upgrade / Change plan, Log out) navigate normally.
 */
(function () {
	var cfg = window.AWG_MEM_AM || {};

	function closeAll(except) {
		var open = document.querySelectorAll('.awg-am.is-open');
		for (var i = 0; i < open.length; i++) {
			if (open[i] === except) { continue; }
			open[i].classList.remove('is-open');
			var t = open[i].querySelector('.awg-am-trigger');
			if (t) { t.setAttribute('aria-expanded', 'false'); }
		}
	}

	document.addEventListener('click', function (e) {
		if (!e.target.closest) { return; }

		// Toggle.
		var trigger = e.target.closest('.awg-am-trigger');
		if (trigger) {
			e.preventDefault();
			var am = trigger.closest('.awg-am');
			if (!am) { return; }
			var willOpen = !am.classList.contains('is-open');
			closeAll(am);
			am.classList.toggle('is-open', willOpen);
			trigger.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
			return;
		}

		// Manage billing -> Stripe customer portal.
		var bill = e.target.closest('.awg-am-billing');
		if (bill) {
			e.preventDefault();
			if (bill.classList.contains('awg-am-busy')) { return; }
			bill.classList.add('awg-am-busy');
			var label = bill.querySelector('.awg-am-label');
			var orig = label ? label.textContent : '';
			if (label) { label.textContent = 'Opening…'; }

			fetch(cfg.ajax_url, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body: 'action=awg_mem_billing_portal&nonce=' + encodeURIComponent(cfg.nonce || '')
			})
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (res && res.success && res.data && res.data.redirect) {
						window.location.href = res.data.redirect;
						return;
					}
					bill.classList.remove('awg-am-busy');
					if (label) { label.textContent = orig; }
					window.alert((res && res.data && res.data.message) || 'Could not open the billing portal.');
				})
				.catch(function () {
					bill.classList.remove('awg-am-busy');
					if (label) { label.textContent = orig; }
					window.alert('Network error opening the billing portal.');
				});
			return;
		}

		// Click anywhere outside an open panel closes it. Clicks inside the panel
		// (e.g. on a link) are left alone so navigation still works.
		if (!e.target.closest('.awg-am-panel')) {
			closeAll(null);
		}
	});

	document.addEventListener('keydown', function (e) {
		if (e.key !== 'Escape' && e.key !== 'Esc') { return; }
		var open = document.querySelector('.awg-am.is-open');
		if (!open) { return; }
		closeAll(null);
		var t = open.querySelector('.awg-am-trigger');
		if (t) { t.focus(); }
	});
})();
