/* AuthorWings Membership — Dashboard JS v1.2.0 */
(function ($) {
    'use strict';

    const cfg   = window.AWG_MEM || {};
    const ajax  = cfg.ajax_url;
    const nonce = cfg.nonce;
    const s     = cfg.strings || {};

    /*
     * Phase 1 safe-refactor registry
     * These groups document the shared helper surface that later phases will
     * formalize without forcing a large rewrite of the existing dashboard.
     */
    const helperRegistry = {
        modal: ['hoistModalsToBody', 'openModal', 'closeModal'],
        tabs: ['initTabs'],
        async: ['initHistoryLoadMore'],
        feedback: ['showServiceMsg'],
        future: ['focusTrap', 'resetModalState', 'setButtonBusy', 'clearValidationState']
    };
    void helperRegistry;

    // ── Helpers ──────────────────────────────────────────────

    /**
     * v3.1.2 — Generic branded confirm dialog.
     *
     * Replaces native window.confirm() for the cancel-plan, sign-out,
     * delete-book, team-remove, downgrade-to-free, and GDPR flows so
     * destructive actions look like the rest of the dashboard instead
     * of a browser chrome popup. The HTML for #awg-confirm-modal is
     * rendered once per page from render_confirm_modal() in PHP.
     *
     * Usage:
     *   window.AwgMemConfirm.show({
     *     title: 'Cancel your plan?',
     *     message: 'You will keep paid access until your renewal date.',
     *     okLabel: 'Yes, cancel', cancelLabel: 'Keep my plan',
     *     danger: true,
     *     onConfirm: function () { ... }
     *   });
     *
     * Falls back to window.confirm() if the modal markup isn't on the
     * page (e.g. error pages that don't render the Account tab).
     */
    window.AwgMemConfirm = {
        show: function (opts) {
            opts = opts || {};
            var $modal = $('#awg-confirm-modal');
            if (!$modal.length) {
                // Fallback so the page still works if the modal markup is missing.
                if (window.confirm(opts.message || 'Are you sure?')) {
                    if (typeof opts.onConfirm === 'function') { opts.onConfirm(); }
                }
                return;
            }
            $modal.find('[data-awg-confirm-title]').text(opts.title || (s.confirm_title || 'Please confirm'));
            $modal.find('[data-awg-confirm-message]').text(opts.message || '');
            var $ok = $modal.find('[data-awg-confirm-ok]');
            var $cancel = $modal.find('[data-awg-confirm-cancel]');
            $ok.text(opts.okLabel || (s.confirm_ok || 'Confirm'));
            $cancel.text(opts.cancelLabel || (s.confirm_cancel_button || 'Cancel'));
            // Apply danger styling if requested (terracotta primary), else default sage.
            $ok.removeClass('awg-mem-btn--danger awg-mem-btn--primary')
               .addClass(opts.danger ? 'awg-mem-btn--danger' : 'awg-mem-btn--primary');

            // Off then on so repeat invocations don't stack listeners.
            $ok.off('click.awgConfirm').on('click.awgConfirm', function () {
                closeConfirm();
                if (typeof opts.onConfirm === 'function') { opts.onConfirm(); }
            });
            $cancel.add($modal.find('[data-awg-confirm-close]')).off('click.awgConfirm').on('click.awgConfirm', function () {
                closeConfirm();
                if (typeof opts.onCancel === 'function') { opts.onCancel(); }
            });
            $modal.find('.awg-mem-modal__backdrop').off('click.awgConfirm').on('click.awgConfirm', closeConfirm);

            $modal.addClass('is-open').attr('aria-hidden', 'false');
            // Focus the OK button so Enter confirms and Escape cancels via the global handler below.
            window.setTimeout(function () { $ok.trigger('focus'); }, 10);

            function closeConfirm() {
                $modal.removeClass('is-open').attr('aria-hidden', 'true');
            }
        }
    };
    // Escape key closes any open confirm dialog without firing the action.
    $(document).on('keydown.awgConfirmEsc', function (e) {
        if (e.key === 'Escape' && $('#awg-confirm-modal').hasClass('is-open')) {
            $('#awg-confirm-modal').removeClass('is-open').attr('aria-hidden', 'true');
        }
    });

    /**
     * Move modals to <body> so position:fixed works in every theme.
     * CSS transforms or overflow:hidden on ancestors break fixed positioning —
     * appending to body bypasses all of that.
     */
    function hoistModalsToBody() {
        $('.awg-mem-modal').each(function () {
            if ( $(this).parent().is('body') ) { return; }
            $(this).appendTo('body');
        });
    }

    var modalState = {
        activeModalId: '',
        lastTriggerByModal: {},
        lastActiveElement: null
    };

    function getFocusableElements($modal) {
        return $modal.find('a[href], area[href], input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, [contenteditable], [tabindex]:not([tabindex="-1"])')
            .filter(':visible');
    }

    function trapFocus($modal, event) {
        var $focusable = getFocusableElements($modal);
        if (! $focusable.length) {
            event.preventDefault();
            return;
        }

        var first = $focusable.get(0);
        var last  = $focusable.get($focusable.length - 1);
        var active = document.activeElement;

        if (event.shiftKey) {
            if (active === first || ! $modal[0].contains(active)) {
                event.preventDefault();
                last.focus();
            }
            return;
        }

        if (active === last || ! $modal[0].contains(active)) {
            event.preventDefault();
            first.focus();
        }
    }

    function focusModal($modal) {
        var $focusable = getFocusableElements($modal);
        if ($focusable.length) {
            $focusable.get(0).focus();
            return;
        }

        var $box = $modal.find('.awg-mem-modal__box').first();
        if ($box.length) {
            if (! $box.attr('tabindex')) {
                $box.attr('tabindex', '-1');
            }
            $box.get(0).focus();
        }
    }

    function getTopOpenModal() {
        return $('.awg-mem-modal.is-open').last();
    }

    function openModal($modal, options) {
        options = options || {};
        var modalId = $modal.attr('id') || '';
        var trigger = options.trigger || document.activeElement;

        if (modalId) {
            modalState.lastTriggerByModal[modalId] = trigger;
            modalState.activeModalId = modalId;
        }
        modalState.lastActiveElement = trigger;

        $modal.attr('aria-hidden', 'false').addClass('is-open');
        $('body').addClass('awg-modal-open');
        $modal.trigger('awg:modalopened');
        focusModal($modal);
    }

    function closeModal($modal, options) {
        options = options || {};
        var modalId = $modal.attr('id') || '';
        var restoreFocus = options.restoreFocus !== false;
        var fallbackFocus = modalId ? modalState.lastTriggerByModal[modalId] : null;

        $modal.attr('aria-hidden', 'true').removeClass('is-open');

        if ( ! $('.awg-mem-modal.is-open').length ) {
            $('body').removeClass('awg-modal-open');
            modalState.activeModalId = '';
        } else {
            modalState.activeModalId = getTopOpenModal().attr('id') || '';
            focusModal(getTopOpenModal());
        }

        $modal.trigger('awg:modalclosed');

        if (restoreFocus && fallbackFocus && typeof fallbackFocus.focus === 'function') {
            window.setTimeout(function () {
                fallbackFocus.focus();
            }, 0);
        }
    }

    // Note: escHtml() is defined further down (line ~1358) — null-safe and
    // also escapes single quotes. Function-declaration hoisting means that
    // version is what every call site resolves to, so we don't keep a second
    // weaker copy here.

    function injectSpinStyle() {
        if ( document.getElementById('awg-spin-style') ) { return; }
        var el = document.createElement('style');
        el.id  = 'awg-spin-style';
        el.textContent = '@keyframes awg-spin{to{transform:rotate(360deg)}}';
        document.head.appendChild(el);
    }


    function initModalA11y() {
        $('.awg-mem-modal').each(function () {
            var $modal = $(this);
            var $box = $modal.find('.awg-mem-modal__box').first();
            var $title = $modal.find('.awg-mem-modal__title').first();
            var titleId = $title.attr('id');

            $modal.attr('aria-hidden', $modal.hasClass('is-open') ? 'false' : 'true');
            if (! $box.attr('role')) {
                $box.attr('role', 'dialog');
            }
            $box.attr('aria-modal', 'true');
            if ($title.length) {
                if (! titleId) {
                    titleId = ($modal.attr('id') || 'awg-modal') + '-title';
                    $title.attr('id', titleId);
                }
                $box.attr('aria-labelledby', titleId);
            }
            if (! $box.attr('tabindex')) {
                $box.attr('tabindex', '-1');
            }
        });

        $(document).off('keydown.awg-modal-a11y').on('keydown.awg-modal-a11y', function (e) {
            var $openModal = getTopOpenModal();
            if (! $openModal.length) {
                return;
            }

            if (e.key === 'Escape') {
                e.preventDefault();
                closeModal($openModal);
                return;
            }

            if (e.key === 'Tab') {
                trapFocus($openModal, e);
            }
        });
    }

    // ── Tab switching ────────────────────────────────────────
    function initTabs() {
        var $tabs   = $('.awg-mem-tab');
        var $panels = $('.awg-mem-panel');
        var $mobileTabs = $('.awg-mem-mobile-tab');

        // Legacy IA redirect: quote-requests no longer has its own tab —
        // its content now lives at the top of the Services tab.
        function resolveTab(tab) {
            if (tab === 'quote-requests') {
                return 'services';
            }
            return tab;
        }

        function activateTab(tab, options) {
            options = options || {};
            tab = resolveTab(tab);
            $tabs.removeClass('awg-mem-tab--active').attr('aria-selected', 'false').attr('tabindex', '-1');
            $panels.removeClass('awg-mem-panel--active').attr('hidden', true);
            $mobileTabs.removeClass('awg-mem-mobile-tab--active');

            var $activeTab = $tabs.filter('[data-tab="' + tab + '"]');
            var $activePanel = $panels.filter('[data-panel="' + tab + '"]');
            $activeTab.addClass('awg-mem-tab--active').attr('aria-selected', 'true').attr('tabindex', '0');
            $activePanel.addClass('awg-mem-panel--active').removeAttr('hidden');
            $mobileTabs.filter('[data-tab="' + tab + '"]').addClass('awg-mem-mobile-tab--active');

            if (options.focusTab) {
                $activeTab.trigger('focus');
            }
            if (history.replaceState) {
                history.replaceState(null, '', '#' + tab);
            }
            $(document).trigger('awg:tabchange', [tab]);
        }

        $tabs.on('click', function () { activateTab($(this).data('tab')); });
        $tabs.on('keydown', function (e) {
            var index = $tabs.index(this);
            var nextIndex = index;
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                nextIndex = (index + 1) % $tabs.length;
            } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                nextIndex = (index - 1 + $tabs.length) % $tabs.length;
            } else if (e.key === 'Home') {
                nextIndex = 0;
            } else if (e.key === 'End') {
                nextIndex = $tabs.length - 1;
            } else {
                return;
            }
            e.preventDefault();
            activateTab($tabs.eq(nextIndex).data('tab'), { focusTab: true });
        });

        $(document).on('click', '.awg-mem-tab-link', function (e) {
            e.preventDefault();
            activateTab($(this).data('tab'));
        });

        var hash = window.location.hash.replace('#', '');
        if (hash) {
            var resolvedHash = resolveTab(hash);
            if ($('.awg-mem-tab[data-tab="' + resolvedHash + '"]').length) {
                activateTab(resolvedHash);
            }
        }
        var params = new URLSearchParams(window.location.search);
        var tabParam = params.get('tab');
        if (tabParam) {
            var resolvedParam = resolveTab(tabParam);
            if ($('.awg-mem-tab[data-tab="' + resolvedParam + '"]').length) {
                activateTab(resolvedParam);
            }
        }
        if (params.get('upgrade') || params.get('payment') || params.get('cancelled') || params.get('awg_notice')) {
            activateTab('account');
        }
    }


    function initHistoryLoadMore() {
        function setHistorySummary(visible, total) {
            var $summary = $('#awg-mem-history-summary');
            if (!$summary.length || !total) {
                return;
            }
            $summary.attr('data-visible', visible).attr('data-total', total).text('Showing ' + visible + ' of ' + total + ' submissions');
        }

        $(document).on('click', '#awg-mem-history-load-more', function () {
            var $btn = $(this);
            var $label = $btn.find('.awg-mem-btn__label');
            var nextPage = parseInt($btn.attr('data-page') || '1', 10) + 1;
            $btn.prop('disabled', true).addClass('is-loading');
            if ($label.length) {
                $label.text('Loading…');
            }

            $.post(ajax, {
                action: 'awg_mem_get_history',
                nonce: nonce,
                page: nextPage
            })
            .done(function (res) {
                if (!res.success || !res.data) {
                    $btn.prop('disabled', false).removeClass('is-loading');
                    if ($label.length) {
                        $label.text('Load More');
                    }
                    return;
                }

                var $items = $(res.data.html).find('.awg-mem-history-item');
                $('#awg-mem-history-wrap .awg-mem-history-list').append($items);
                $btn.attr('data-page', res.data.page);

                var visible = $('#awg-mem-history-wrap .awg-mem-history-item').length;
                setHistorySummary(visible, parseInt(res.data.total || visible, 10));

                if (res.data.has_more) {
                    $btn.prop('disabled', false).removeClass('is-loading');
                    if ($label.length) {
                        $label.text('Load More');
                    }
                } else {
                    $btn.remove();
                }
            })
            .fail(function () {
                $btn.prop('disabled', false).removeClass('is-loading');
                if ($label.length) {
                    $label.text('Load More');
                }
            });
        });
    }

    // ── Tool modal ───────────────────────────────────────────
    function initToolModal() {
        var $modal   = $('#awg-tool-modal');
        var $content = $('#awg-tool-modal-content');
        var $title   = $modal.find('.awg-mem-modal__title');
        var pendingRequest = null;
        var pendingTimeout = 0;
        var currentTemplateId = 0;
        var currentTrigger = null;

        function resetToolButton($btn) {
            if (! $btn || ! $btn.length) {
                return;
            }
            var originalText = $btn.data('original-text') || 'Use Tool';
            $btn.prop('disabled', false).removeAttr('aria-busy').text(originalText);
        }

        function setToolButtonBusy($btn) {
            if (! $btn || ! $btn.length) {
                return;
            }
            if (! $btn.data('original-text')) {
                $btn.data('original-text', $.trim($btn.text()) || 'Use Tool');
            }
            $btn.prop('disabled', true).attr('aria-busy', 'true').text(s.tool_loading || 'Loading tool…');
        }

        function clearToolRequestState() {
            if (pendingTimeout) {
                window.clearTimeout(pendingTimeout);
                pendingTimeout = 0;
            }
            if (pendingRequest && typeof pendingRequest.abort === 'function') {
                pendingRequest.abort();
            }
            pendingRequest = null;
        }

        function buildRetryMarkup(message, includeShortcode) {
            var retryLabel = escHtml(s.try_again || 'Try Again');
            var html =
                '<div class="awg-mem-tool-error" style="padding:28px 24px;">' +
                '<p style="color:#991b1b;font-size:14px;margin:0 0 12px;">' + escHtml(message) + '</p>' +
                '<p style="margin:0;"><a href="#" class="awg-mem-tool-retry">' + retryLabel + '</a></p>';

            if (includeShortcode && currentTemplateId > 0) {
                html += '<p style="font-size:13px;color:#6b7280;margin:14px 0 0;">You can also add this tool to any page with the shortcode:<br>' +
                    '<code style="background:#f3f4f6;padding:3px 7px;border-radius:4px;font-size:12px;">[awg_generator id="' + parseInt(currentTemplateId, 10) + '"]</code></p>';
            }

            html += '</div>';
            return html;
        }

        function renderToolError(message, extraHtml) {
            var html = buildRetryMarkup(message, true);
            if (extraHtml) {
                html = html.replace('</div>', extraHtml + '</div>');
            }
            $content.html(html);
            resetToolButton(currentTrigger);
        }

        function resetToolModal(options) {
            options = options || {};
            clearToolRequestState();
            $content.html('');
            $title.text('');
            if (options.resetButton !== false) {
                resetToolButton(currentTrigger);
            }
        }

        function requestToolHtml(templateId, $trigger) {
            currentTemplateId = parseInt(templateId, 10) || 0;
            currentTrigger = $trigger && $trigger.length ? $trigger : currentTrigger;
            if (! currentTemplateId) {
                return;
            }

            clearToolRequestState();
            setToolButtonBusy(currentTrigger);

            $content.html(
                '<div class="awg-mem-skeleton-card" role="status" aria-live="polite" aria-label="' + escHtml(s.tool_loading || 'Loading tool…') + '">' +
                  '<span class="awg-mem-skeleton awg-mem-skeleton--title"></span>' +
                  '<span class="awg-mem-skeleton awg-mem-skeleton--label"></span>' +
                  '<span class="awg-mem-skeleton awg-mem-skeleton--input"></span>' +
                  '<span class="awg-mem-skeleton awg-mem-skeleton--label"></span>' +
                  '<span class="awg-mem-skeleton awg-mem-skeleton--input" style="height:96px;"></span>' +
                  '<span class="awg-mem-skeleton awg-mem-skeleton--button"></span>' +
                '</div>'
            );
            openModal($modal, { trigger: currentTrigger && currentTrigger.length ? currentTrigger.get(0) : document.activeElement });

            pendingRequest = $.post(ajax, {
                action: 'awg_mem_get_tool_html',
                nonce: nonce,
                template_id: currentTemplateId
            })
            .done(function (res) {
                clearToolRequestState();

                if (res.success && res.data && res.data.html) {
                    $title.text(res.data.title || '');
                    $content.html(res.data.html);
                    $(document).trigger('awg_aig_modal_loaded', [$content]);
                    focusModal($modal);
                    resetToolButton(currentTrigger);
                    return;
                }

                var msg = (res.data && res.data.message) || (s.tool_error || 'Could not load tool. Please try again.');
                var upgrade = res.data && res.data.upgrade_url
                    ? '<p style="margin:14px 0 0;"><a href="' + escHtml(res.data.upgrade_url) + '" class="awg-mem-btn awg-mem-btn--primary">' + escHtml((res.data.upgrade_label || 'View plans')) + '</a></p>'
                    : '';
                renderToolError(msg, upgrade);
            })
            .fail(function (xhr, status) {
                clearToolRequestState();
                if (status === 'abort') {
                    return;
                }
                renderToolError(s.tool_error || 'Could not load tool. Please try again.');
            });

            pendingTimeout = window.setTimeout(function () {
                clearToolRequestState();
                renderToolError(s.tool_timeout || 'This tool is taking longer than expected. Please try again.');
            }, parseInt(s.tool_timeout_ms || '15000', 10));
        }

        $(document).on('click', '.awg-mem-open-tool', function () {
            var templateId = $(this).data('template-id');
            if (! templateId) {
                return;
            }
            requestToolHtml(templateId, $(this));
        });

        $(document).on('click', '.awg-mem-tool-retry', function (e) {
            e.preventDefault();
            if (! currentTemplateId) {
                return;
            }
            requestToolHtml(currentTemplateId, currentTrigger);
        });

        $modal.on('awg:modalclosed', function () {
            resetToolModal();
        });

        $(document).on('click', '#awg-tool-modal-close', function () {
            closeModal($modal);
        });
        $(document).on('click', '#awg-tool-modal .awg-mem-modal__backdrop', function () {
            closeModal($modal);
        });
    }

    // ── Service order modal ──────────────────────────────────
    function initServiceModal() {
        var $modal        = $('#awg-service-modal');
        var $detailsModal = $('#awg-service-details-modal');
        var currentSlug   = '';
        var currentName   = '';

        function escapeHtml(text) {
            return $('<div>').text(text || '').html();
        }

        function fillDetailsModal($trigger) {
            var name = $trigger.data('name') || '';
            var category = $trigger.data('category') || (s.service_details || 'Service Details');
            var description = $trigger.data('description') || '';
            var fullDescription = $trigger.data('full-description') || '';
            var price = $trigger.data('price') || '';
            var turnaround = $trigger.data('turnaround') || '';
            var buttonLabel = $trigger.data('button-label') || (s.request_quote || 'Request Quote');
            var buttonUrl = $trigger.data('button-url') || '';
            var imageUrl = $trigger.data('image-url') || '';
            var icon = $trigger.data('icon') || 'dashicons-star-filled';
            var slug = $trigger.data('slug') || '';
            var bodyHtml = fullDescription ? fullDescription : ('<p>' + escapeHtml(description) + '</p>');

            $('#awg-service-details-title').text(name || (s.service_details || 'Service Details'));
            $('#awg-service-details-category').text(category);
            $('#awg-service-details-summary').text(description);
            $('#awg-service-details-body').html(bodyHtml);
            $('#awg-service-details-price').text(price);
            $('#awg-service-details-turnaround').text(turnaround);
            $('#awg-service-details-price-wrap').toggle(!!price);
            $('#awg-service-details-turnaround-wrap').toggle(!!turnaround);

            if (imageUrl) {
                $('#awg-service-details-media').html('<img src="' + escapeHtml(imageUrl) + '" alt="' + escapeHtml(name) + '">');
            } else {
                $('#awg-service-details-media').html('<div class="awg-mem-service-details-modal__icon"><span class="dashicons ' + escapeHtml(icon) + '"></span></div>');
            }

            $('#awg-service-details-primary-action')
                .text(buttonLabel)
                .data('slug', slug)
                .data('name', name)
                .data('button-url', buttonUrl);

            if (buttonUrl) {
                $('#awg-service-details-secondary-action').hide();
            } else {
                $('#awg-service-details-secondary-action')
                    .text(s.close || 'Close')
                    .show();
            }
        }

        function safeVal(selector) {
            var $field = $(selector);
            if (!$field.length) {
                return '';
            }
            var value = $field.val();
            return typeof value === 'string' ? value.trim() : '';
        }

        function showServiceMsg(type, text) {
            var $msg = $('#awg-service-modal-msg');
            $msg.removeClass('awg-mem-alert--success awg-mem-alert--error')
                .addClass('awg-mem-alert awg-mem-alert--' + type)
                .attr('role', type === 'error' ? 'alert' : 'status')
                .text(text)
                .show();
        }


        function serviceMinLength() {
            return parseInt(s.service_details_min || '20', 10);
        }

        function updateServiceCounter() {
            var $notes = $('#awg-service-notes');
            var $counter = $('#awg-service-notes-counter');
            if (!$notes.length || !$counter.length) { return; }

            var value = $notes.val() || '';
            var length = $.trim(value).length;
            var minLength = serviceMinLength();
            var isValid = length >= minLength;

            $counter.text(length + ' / ' + minLength + ' min characters')
                .toggleClass('is-valid', isValid)
                .toggleClass('is-invalid', length > 0 && !isValid);

            if (isValid) {
                $notes.removeClass('awg-mem-textarea--invalid');
                var $msg = $('#awg-service-modal-msg');
                if ($msg.hasClass('awg-mem-alert--error')) {
                    $msg.hide().removeClass('awg-mem-alert--error').text('');
                }
            }
        }

        function resetServiceForm() {
            $('#awg-service-modal-msg').hide().removeClass('awg-mem-alert--success awg-mem-alert--error').text('');
            $('#awg-service-form-wrap').show();
            $('#awg-service-notes').val('').removeClass('awg-mem-textarea--invalid');
            // v3.0.1 — wipe any uploaded attachment rows so the next quote
            // submission starts from a blank list. Without this the previous
            // attachments would silently re-submit alongside the next quote.
            $('[data-awg-quote-attach-list]').empty();
            updateServiceCounter();
        }


        $(document).on('click', '.awg-mem-view-service-details', function () {
            fillDetailsModal($(this));
            openModal($detailsModal, { trigger: this });
        });

        $(document).on('click', '#awg-service-details-modal-close, #awg-service-details-secondary-action', function () {
            closeModal($detailsModal);
        });

        $(document).on('click', '#awg-service-details-modal .awg-mem-modal__backdrop', function () {
            closeModal($detailsModal);
        });

        $(document).on('click', '#awg-service-details-primary-action', function () {
            var buttonUrl = $(this).data('button-url') || '';
            var slug = $(this).data('slug') || '';
            var name = $(this).data('name') || '';

            if (buttonUrl) {
                window.location.href = buttonUrl;
                return;
            }

            currentSlug = slug;
            currentName = name;
            closeModal($detailsModal, { restoreFocus: false });
            $('#awg-service-modal-title').text(currentName || (s.request_quote || 'Request Quote'));
            resetServiceForm();
            openModal($modal, { trigger: this });
        });

        $(document).on('click', '.awg-mem-request-service', function () {
            currentSlug = $(this).data('slug') || '';
            currentName = $(this).data('name') || '';
            $('#awg-service-modal-title').text(currentName || (s.request_quote || 'Request Quote'));
            resetServiceForm();
            openModal($modal, { trigger: this });
        });


        $(document).on('input', '#awg-service-notes', function () {
            updateServiceCounter();
        });

        $modal.on('awg:modalclosed', function () {
            resetServiceForm();
        });

        $(document).on('click', '#awg-service-modal-close', function () { closeModal($modal); });
        $(document).on('click', '#awg-service-modal .awg-mem-modal__backdrop', function () { closeModal($modal); });
        $(document).on('click', '#awg-service-submit', function () {
            var notes = safeVal('#awg-service-notes');
            var $notes = $('#awg-service-notes');
            var $btn  = $(this);
            var minLength = serviceMinLength();

            if (!notes || notes.length < minLength) {
                showServiceMsg('error', s.service_details_required || 'Please add a few project details so we can prepare the right quote.');
                $notes.addClass('awg-mem-textarea--invalid').trigger('focus');
                return;
            }

            $notes.removeClass('awg-mem-textarea--invalid');
            $btn.prop('disabled', true).text(s.submitting || 'Submitting…');

            // v3.0.1 — collect any successfully-uploaded attachments from the
            // inline list. Each row stores data-url/data-name after the upload
            // AJAX returns; rows in error/pending state have no data-url and
            // are skipped here so we never submit a half-uploaded reference.
            var attachments = [];
            $('[data-awg-quote-attach-list] li[data-url]').each(function () {
                attachments.push({
                    url:  $(this).attr('data-url'),
                    name: $(this).attr('data-name') || ''
                });
            });

            $.post(ajax, {
                action:       'awg_mem_submit_order',
                nonce:        nonce,
                service_slug: currentSlug,
                service_name: currentName,
                notes:        notes,
                attachments:  attachments
            })
            .done(function (res) {
                $btn.prop('disabled', false).text(s.submit_request || 'Submit Request');
                if (res && res.success) {
                    showServiceMsg('success', (res.data && res.data.message) || 'Your request has been submitted.');
                    $('#awg-service-form-wrap').hide();
                    setTimeout(function () {
                        closeModal($modal);
                        resetServiceForm();
                    }, 1400);
                } else {
                    showServiceMsg('error', (res && res.data && res.data.message) || s.error_generic || 'Something went wrong. Please try again.');
                }
            })
            .fail(function (xhr) {
                $btn.prop('disabled', false).text(s.submit_request || 'Submit Request');
                var message = s.error_generic || 'Something went wrong. Please try again.';
                if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    message = xhr.responseJSON.data.message;
                }
                showServiceMsg('error', message);
            });
        });
    }


    function initAccountPlanModal() {
        var $modal = $('#awg-account-plan-modal');
        if (!$modal.length) { return; }

        $(document).on('click', '.awg-mem-account-open-plan-modal', function () {
            openModal($modal, { trigger: this });
        });

        $(document).on('click', '#awg-account-plan-modal-close', function () {
            closeModal($modal);
        });

        $(document).on('click', '#awg-account-plan-modal .awg-mem-modal__backdrop', function () {
            closeModal($modal);
        });
    }

    // ── Plan upgrade ─────────────────────────────────────────
    function initPlanUpgrade() {
        function pulsePlanCard(planSlug) {
            if (!planSlug) { return; }
            var $card = $('.awg-mem-plan-card').filter(function () {
                var $button = $(this).find('.awg-mem-select-plan[data-plan]');
                if ($button.length && $button.attr('data-plan') === planSlug) {
                    return true;
                }
                return $(this).find('.awg-mem-plan-card__name').text().trim().toLowerCase() === String(planSlug).toLowerCase();
            }).first();

            if (!$card.length) { return; }

            $card[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
            $card.addClass('awg-mem-plan-card--pulse');
            window.setTimeout(function () {
                $card.removeClass('awg-mem-plan-card--pulse');
            }, 1800);
        }

        function openPlanModalAndHighlight(planSlug) {
            var $modal = $('#awg-account-plan-modal');
            if (!$modal.length) { return; }
            openModal($modal);
            window.setTimeout(function () {
                pulsePlanCard(planSlug);
            }, 180);
        }

        // v3.1.6 — compute the real saving from each card's prices rather than
        // asserting a hardcoded "20%" that goes stale when an admin changes
        // pricing. The per-card note shows the actual percent saved.
        function yearlySavingPct(monthly, yearly) {
            var full = monthly * 12;
            if (full <= 0 || yearly <= 0 || yearly >= full) { return 0; }
            return Math.round((1 - (yearly / full)) * 100);
        }

        function applyBillingState(billing) {
            $('[data-billing-toggle]').removeClass('is-active');
            $('[data-billing-toggle="' + billing + '"]').addClass('is-active');
            $('.awg-mem-select-plan').attr('data-billing', billing);
            $('[data-billing-indicator]').text(billing === 'yearly' ? 'Billed yearly' : 'Billed monthly');
            $('.awg-mem-plan-card').each(function () {
                var $card = $(this);
                var monthly = parseFloat($card.attr('data-monthly-price') || '0');
                var yearly = parseFloat($card.attr('data-yearly-price') || '0');
                var sym = $card.attr('data-currency-symbol') || '$';
                var $price = $card.find('[data-plan-price]');
                var $note = $card.find('[data-plan-note]');
                if (!$price.length || monthly === 0 && yearly === 0) { return; }
                if (billing === 'yearly' && yearly > 0) {
                    $price.text(sym + Math.round(yearly) + '/yr');
                    if ($note.length) {
                        var pct = yearlySavingPct(monthly, yearly);
                        $note.text(pct > 0 ? ('Billed yearly, save ' + pct + '%') : 'Billed yearly');
                    }
                } else {
                    $price.text(sym + Math.round(monthly) + '/mo');
                    if ($note.length) { $note.text('Billed monthly'); }
                }
            });
        }

        $(document).on('click', '[data-billing-toggle]', function () {
            applyBillingState($(this).attr('data-billing-toggle'));
        });

        $(document).on('click', '.awg-mem-tab-link[data-highlight-plan]', function () {
            var planSlug = $(this).attr('data-highlight-plan') || '';
            window.setTimeout(function () {
                openPlanModalAndHighlight(planSlug);
            }, 80);
        });

        var initialBilling = $('.awg-mem-plans-grid--account').attr('data-current-billing') || 'monthly';
        applyBillingState(initialBilling);

        var params = new URLSearchParams(window.location.search);
        // v3.1.6 — both `highlight` (from in-app locked-tool buttons) and
        // `upgrade` (from the public pricing page CTA) open the plan modal and
        // pulse the chosen plan. Previously `upgrade` only switched to the
        // Account tab and the user had to find "Change plan" themselves.
        var highlightPlan = params.get('highlight') || params.get('upgrade');
        if (highlightPlan && $('#awg-account-plan-modal').length) {
            window.setTimeout(function () {
                openPlanModalAndHighlight(highlightPlan);
            }, 220);
        }

        $(document).on('click', '.awg-mem-select-plan', function () {
            var $btn     = $(this);
            var plan     = $btn.data('plan');
            var billing  = $btn.attr('data-billing') || 'monthly';
            var planName = $btn.data('plan-name') || 'this plan';
            var isFree   = String($btn.data('is-free')) === '1';
            var origText = $btn.text().trim();

            function runChange() {
                $btn.prop('disabled', true).text(s.upgrading || 'Processing…');

                $.post(ajax, { action: 'awg_mem_upgrade_plan', nonce: nonce, plan: plan, billing: billing })
                .done(function (res) {
                    if (res.success) {
                        if (res.data && res.data.redirect) {
                            window.location.href = res.data.redirect;
                        } else {
                            window.location.reload();
                        }
                    } else {
                        $btn.prop('disabled', false).text(origText);
                        alert((res.data && res.data.message) || (isFree ? 'Could not switch to the free plan.' : 'Could not start checkout for ' + planName + '.'));
                    }
                })
                .fail(function () {
                    $btn.prop('disabled', false).text(origText);
                    alert(s.error_generic || 'Something went wrong.');
                });
            }

            if (isFree) {
                // v3.1.2 — branded confirm; was native confirm().
                window.AwgMemConfirm.show({
                    title: s.confirm_downgrade_title || 'Switch to the Free plan?',
                    message: s.confirm_downgrade || 'You will lose paid features at the end of your current billing period.',
                    okLabel: s.confirm_downgrade_ok || 'Switch to Free',
                    danger: true,
                    onConfirm: runChange
                });
            } else {
                runChange();
            }
        });
    }

    // ── Cancel plan ──────────────────────────────────────────
    // v3.1.2 — was throwing ReferenceError because the failure-path
    //          alert referenced `isFree` and `planName` from the plan
    //          upgrade scope. That swallowed every server-side error
    //          (looked like "nothing happened" to users). Now uses a
    //          cancel-specific fallback and goes through the branded
    //          confirm modal instead of the native browser confirm().
    function initCancelPlan() {
        $(document).on('click', '.awg-mem-cancel-plan', function () {
            var $btn = $(this);

            window.AwgMemConfirm.show({
                title: s.cancel_title || 'Cancel your plan?',
                message: s.confirm_cancel || 'You will keep paid access until your current renewal date, then drop to the Free plan.',
                okLabel: s.cancel_ok || 'Yes, cancel',
                cancelLabel: s.cancel_keep || 'Keep my plan',
                danger: true,
                onConfirm: function () {
                    $btn.prop('disabled', true);
                    $.post(ajax, { action: 'awg_mem_cancel_plan', nonce: nonce })
                    .done(function (res) {
                        if (res.success) {
                            if (res.data && res.data.redirect) {
                                window.location.href = res.data.redirect;
                            } else {
                                window.location.reload();
                            }
                        } else {
                            alert((res.data && res.data.message) || (s.cancel_fail || 'Could not cancel your plan right now. Please try again.'));
                            $btn.prop('disabled', false);
                        }
                    })
                    .fail(function () {
                        $btn.prop('disabled', false);
                        alert(s.error_generic || 'Something went wrong.');
                    });
                }
            });
        });
    }

    // Open the Stripe Billing Portal so the member can update their card,
    // view invoices, or manage the subscription on Stripe-hosted pages.
    function initManageBilling() {
        $(document).on('click', '.awg-mem-manage-billing', function () {
            var $btn = $(this);
            var n = $btn.data('nonce') || nonce;
            $btn.prop('disabled', true);
            $.post(ajax, { action: 'awg_mem_billing_portal', nonce: n })
            .done(function (res) {
                if (res.success && res.data && res.data.redirect) {
                    window.location.href = res.data.redirect;
                } else {
                    alert((res.data && res.data.message) || (s.error_generic || 'Something went wrong.'));
                    $btn.prop('disabled', false);
                }
            })
            .fail(function () {
                $btn.prop('disabled', false);
                alert(s.error_generic || 'Something went wrong.');
            });
        });
    }




    function initDashboardVisuals() {
        $('.awg-mem-usage-donut__progress').each(function () {
            var $circle = $(this);
            var target = $circle.attr('data-target-dasharray');
            if (!target) { return; }
            window.setTimeout(function () {
                $circle.attr('stroke-dasharray', target);
            }, 120);
        });
    }

    // ── Copy to clipboard ────────────────────────────────────
    function initCopyButtons() {
        $(document).on('click', '.awg-mem-copy-btn', function () {
            var text = $(this).data('copy');
            var $btn = $(this);
            var orig = $btn.text();

            function done() {
                $btn.text(s.copied || 'Copied!');
                setTimeout(function () { $btn.text(orig); }, 2000);
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(done).catch(function () {
                    fallbackCopy(text); done();
                });
            } else {
                fallbackCopy(text); done();
            }
        });

        function fallbackCopy(text) {
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.style.cssText = 'position:fixed;top:-9999px;left:-9999px;opacity:0;';
            document.body.appendChild(ta);
            ta.focus(); ta.select();
            try { document.execCommand('copy'); } catch (e) {}
            document.body.removeChild(ta);
        }
    }


    function initProfileModal() {
        // v2.7.1 — Edit Profile modal removed. All profile/email/password
        // editing now happens inline on the Account & Billing page. The
        // legacy element selectors are kept here as no-ops so older
        // cached pages don't error if some user happens to land on a
        // stale 2.7.0 HTML build mid-rollout.
        if ($('#awg-account-profile-modal').length) {
            $('#awg-account-profile-modal').remove();
        }
    }

    // v2.7.1 — Account & Billing inline interactions
    function initAccountV271() {
        var $card = $('[data-awg-profile-card]');
        if ($card.length) {
            initInlineProfile($card);
        }
        initSecurityRows();
        initNotificationToggles();
        initGdprRequests();
    }

    function initInlineProfile($card) {
        var $view = $card.find('[data-awg-profile-view]');
        var $edit = $card.find('[data-awg-profile-edit]');
        var $form = $card.find('[data-awg-profile-form]');
        var $notice = $card.find('[data-awg-profile-notice]');
        var $editBtn = $card.find('[data-awg-profile-toggle="edit"]');

        function setMode(mode) {
            if (mode === 'edit') {
                $view.attr('hidden', true);
                $edit.removeAttr('hidden');
                $editBtn.attr('aria-expanded', 'true').hide();
                showNotice($notice, '', '');
            } else {
                $edit.attr('hidden', true);
                $view.removeAttr('hidden');
                $editBtn.attr('aria-expanded', 'false').show();
            }
        }

        $card.on('click', '[data-awg-profile-toggle="edit"]', function (e) {
            e.preventDefault();
            setMode('edit');
        });
        $card.on('click', '[data-awg-profile-toggle="cancel"]', function (e) {
            e.preventDefault();
            setMode('view');
        });

        $form.on('submit', function (e) {
            e.preventDefault();
            var $btn = $form.find('[data-awg-profile-save]');
            var original = $btn.text();
            showNotice($notice, '', '');
            $btn.prop('disabled', true).text(s.submitting || 'Saving…');

            $.post(ajax, $form.serialize())
                .done(function (res) {
                    if (!res || !res.success) {
                        showNotice($notice, 'error', (res && res.data && res.data.message) || (s.error_generic || 'Something went wrong.'));
                        return;
                    }
                    showNotice($notice, 'success', res.data.message || 'Profile updated.');
                    if (res.data && res.data.user) {
                        $('.awg-mem-topbar__name').text(res.data.user.display_name || '');
                        $card.find('[data-awg-profile-display-name]').text(res.data.user.display_name || '');
                        $card.find('[data-awg-profile-email]').text(res.data.user.user_email || '');
                    }
                    window.setTimeout(function () { setMode('view'); }, 700);
                })
                .fail(function (xhr) {
                    showNotice($notice, 'error', (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || (s.error_generic || 'Something went wrong.'));
                })
                .always(function () {
                    $btn.prop('disabled', false).text(original);
                });
        });
    }

    function initSecurityRows() {
        $(document).on('click', '[data-awg-sec-toggle]', function (e) {
            e.preventDefault();
            var key = $(this).data('awg-sec-toggle');
            var $form = $('[data-awg-sec-form="' + key + '"]');
            var $row  = $('[data-awg-sec-row="' + key + '"]');
            if ($form.attr('hidden')) {
                $form.removeAttr('hidden');
                $row.find('[data-awg-sec-toggle]').attr('aria-expanded', 'true');
            } else {
                $form.attr('hidden', true);
                $row.find('[data-awg-sec-toggle]').attr('aria-expanded', 'false');
                $('[data-awg-sec-notice="' + key + '"]').attr('hidden', true);
            }
        });

        $(document).on('submit', '[data-awg-sec-submit]', function (e) {
            e.preventDefault();
            var $form = $(this);
            var key = $form.closest('[data-awg-sec-form]').data('awg-sec-form');
            var $notice = $('[data-awg-sec-notice="' + key + '"]');
            var $btn = $form.find('button[type="submit"]');
            var original = $btn.text();
            showNotice($notice, '', '');
            $btn.prop('disabled', true).text(s.submitting || 'Saving…');

            $.post(ajax, $form.serialize())
                .done(function (res) {
                    if (!res || !res.success) {
                        showNotice($notice, 'error', (res && res.data && res.data.message) || (s.error_generic || 'Something went wrong.'));
                        return;
                    }
                    showNotice($notice, 'success', res.data.message || 'Updated.');
                    // v3.1.4 — Live-refresh displayed values without a page reload.
                    // 'email' was already supported in 3.1.2; 'name' is new
                    // for the merged Profile card and also refreshes the
                    // top-right header avatar's name.
                    if (res.data && res.data.user) {
                        if (key === 'email') {
                            $('[data-awg-profile-email]').text(res.data.user.user_email || '');
                            $('[data-awg-sec-row="email"] .awg-mem-v271-sec-row__sub').text(res.data.user.user_email || '');
                        }
                        if (key === 'name' && res.data.user.display_name) {
                            $('[data-awg-profile-display-name]').text(res.data.user.display_name);
                            $('.awg-mem-topbar__name').text(res.data.user.display_name);
                        }
                    }
                    $form.find('input[type="password"]').val('');
                    window.setTimeout(function () {
                        $('[data-awg-sec-form="' + key + '"]').attr('hidden', true);
                        $('[data-awg-sec-row="' + key + '"]').find('[data-awg-sec-toggle]').attr('aria-expanded', 'false');
                    }, 900);
                })
                .fail(function (xhr) {
                    showNotice($notice, 'error', (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || (s.error_generic || 'Something went wrong.'));
                })
                .always(function () {
                    $btn.prop('disabled', false).text(original);
                });
        });
    }

    function initNotificationToggles() {
        $(document).on('click', '[data-awg-notif-toggle]', function (e) {
            e.preventDefault();
            var $btn   = $(this);
            var prefKey = $btn.data('pref-key');
            var nonce   = $('[data-awg-notif-nonce]').val();
            var currentOn = $btn.hasClass('awg-mem-v271-toggle--on');
            var nextOn = !currentOn;

            $btn.toggleClass('awg-mem-v271-toggle--on', nextOn)
                .toggleClass('awg-mem-v271-toggle--off', !nextOn)
                .attr('aria-checked', nextOn ? 'true' : 'false');

            var $status = $('[data-awg-notif-status]');
            $status.text(s.saving_pref || 'Saving…');

            $.post(ajax, {
                action: 'awg_mem_save_notif_pref',
                nonce:  nonce,
                pref_key: prefKey,
                value:  nextOn ? 1 : 0
            }).done(function (res) {
                if (res && res.success) {
                    $status.text(s.saved_pref || 'Saved');
                    window.setTimeout(function () { $status.text(''); }, 1500);
                } else {
                    $btn.toggleClass('awg-mem-v271-toggle--on', currentOn)
                        .toggleClass('awg-mem-v271-toggle--off', !currentOn)
                        .attr('aria-checked', currentOn ? 'true' : 'false');
                    $status.text((res && res.data && res.data.message) || 'Failed to save');
                }
            }).fail(function () {
                $btn.toggleClass('awg-mem-v271-toggle--on', currentOn)
                    .toggleClass('awg-mem-v271-toggle--off', !currentOn)
                    .attr('aria-checked', currentOn ? 'true' : 'false');
                $status.text(s.error_generic || 'Failed to save');
            });
        });
    }

    // v3.1.4 — Renamed from initSessionsAndGdpr now that the buggy
    //          Active Sessions feature has been removed. Only GDPR
    //          export and erase requests remain in this initializer.
    function initGdprRequests() {
        $(document).on('click', '[data-awg-gdpr-request]', function (e) {
            e.preventDefault();
            var $btn = $(this);
            var kind = $btn.data('awg-gdpr-request');
            var nonceVal = $btn.data('nonce');
            // v3.1.2 — branded confirm; was native confirm(). Erase is now
            //          labelled as "request deletion" since it only files
                       // a wp_create_user_request, not an immediate erasure.
            var isErase = kind === 'erase';
            window.AwgMemConfirm.show({
                title: isErase
                    ? (s.confirm_delete_title || 'Request account deletion?')
                    : (s.confirm_export_title || 'Export your data?'),
                message: isErase
                    ? (s.confirm_delete_account || 'A team member will review your request, cancel any active plan, and confirm by email. This cannot be undone after the review window closes.')
                    : (s.confirm_export || 'We will compile every generation, quote request, and profile field tied to your account into a downloadable archive.'),
                okLabel: isErase
                    ? (s.confirm_delete_ok || 'Request deletion')
                    : (s.confirm_export_ok || 'Request export'),
                danger: isErase,
                onConfirm: function () {
                    $btn.prop('disabled', true);
                    $.post(ajax, { action: 'awg_mem_gdpr_request', nonce: nonceVal, kind: kind })
                        .done(function (res) {
                            if (res && res.success) {
                                window.alert(res.data.message || 'Request received.');
                            } else {
                                window.alert((res && res.data && res.data.message) || (s.error_generic || 'Failed.'));
                            }
                        })
                        .fail(function (xhr) {
                            window.alert((xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || (s.error_generic || 'Failed.'));
                        })
                        .always(function () {
                            $btn.prop('disabled', false);
                        });
                }
            });
        });
    }

    function showNotice($notice, type, message) {
        if (!$notice || !$notice.length) { return; }
        $notice.removeClass('is-error is-success');
        if (type === 'success') { $notice.addClass('is-success'); }
        if (type === 'error')   { $notice.addClass('is-error'); }
        $notice.text(message || '').prop('hidden', !message);
    }

    // v2.8.0 — Help & Support tab interactions
    function initHelpPanel() {
        var $root = $('[data-awg-help-root]');
        if (!$root.length) { return; }
        initTicketForm($root);
    }

    function initTicketForm($root) {
        var $form   = $root.find('[data-awg-ticket-form]');
        var $notice = $root.find('[data-awg-ticket-notice]');
        if (!$form.length) { return; }

        $form.on('submit', function (e) {
            e.preventDefault();
            var $btn = $form.find('button[type="submit"]');
            var original = $btn.text();
            showNotice($notice, '', '');
            $btn.prop('disabled', true).text(s.submitting || 'Sending…');

            $.post(ajax, $form.serialize())
                .done(function (res) {
                    if (!res || !res.success) {
                        showNotice($notice, 'error', (res && res.data && res.data.message) || (s.error_generic || 'Something went wrong.'));
                        return;
                    }
                    showNotice($notice, 'success', res.data.message || 'Sent.');
                    $form.find('input[type="text"], textarea').val('');
                    // Reload the tickets list section without a full page reload
                    // (could be replaced with an AJAX list call later).
                    window.setTimeout(function () { window.location.hash = '#help'; }, 500);
                })
                .fail(function (xhr) {
                    showNotice($notice, 'error', (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || (s.error_generic || 'Something went wrong.'));
                })
                .always(function () {
                    $btn.prop('disabled', false).text(original);
                });
        });
    }

    function escHtml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
    function escAttr(s) { return escHtml(s); }

    // ── v3.0.0 — AI Tools controls (filter chips + search + favorite) ──
    function initToolsControls() {
        var $controls = $('[data-awg-tools-controls]');
        if (!$controls.length) { return; }

        var currentFilter = 'all';
        var currentQuery  = '';

        function applyFilters() {
            $('.awg-mem-tool-card').each(function () {
                var $card = $(this);
                var cat   = ($card.data('tool-category') || '').toString();
                var name  = ($card.data('tool-name') || '').toString();
                var isFav = $card.find('[data-awg-fav-toggle]').hasClass('is-fav');

                var passesFilter = currentFilter === 'all'
                    || (currentFilter === 'favorites' && isFav)
                    || (cat === currentFilter);
                var passesSearch = currentQuery === '' || name.indexOf(currentQuery) !== -1;
                $card.toggle(passesFilter && passesSearch);
            });
            // Hide section headers whose cards are all hidden.
            $('.awg-mem-tools-section').each(function () {
                var $section = $(this);
                var anyVisible = $section.find('.awg-mem-tool-card:visible').length > 0;
                $section.toggle(anyVisible);
            });
        }

        $controls.on('click', '[data-awg-tools-filter]', function (e) {
            e.preventDefault();
            $controls.find('[data-awg-tools-filter]').removeClass('awg-mem-tools-chip--on');
            $(this).addClass('awg-mem-tools-chip--on');
            currentFilter = $(this).data('awg-tools-filter');
            applyFilters();
        });

        $controls.on('input', '[data-awg-tools-search]', function () {
            currentQuery = String($(this).val() || '').toLowerCase().trim();
            applyFilters();
        });

        // Favorite toggle
        $(document).on('click', '[data-awg-fav-toggle]', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var $btn = $(this);
            var templateId = $btn.data('template-id');
            var nonce = $btn.data('nonce');
            var wasFav = $btn.hasClass('is-fav');
            $btn.toggleClass('is-fav', !wasFav).attr('aria-pressed', !wasFav ? 'true' : 'false');

            $.post(ajax, { action: 'awg_mem_toggle_favorite_tool', nonce: nonce, template_id: templateId })
                .done(function (res) {
                    if (!res || !res.success) {
                        $btn.toggleClass('is-fav', wasFav).attr('aria-pressed', wasFav ? 'true' : 'false');
                        return;
                    }
                    // v3.0.2 — keep the Favorites filter chip in sync with
                    // the live count returned by the server. The chip is
                    // server-rendered hidden when count is zero; we show it
                    // when count > 0 and hide it back when count returns
                    // to zero. The count badge updates on every toggle.
                    var count = (res.data && typeof res.data.count === 'number') ? res.data.count : null;
                    if (count !== null) {
                        var $chip = $('[data-awg-favorites-chip]');
                        if ($chip.length) {
                            $chip.find('[data-awg-favorites-count]').text(count);
                            if (count > 0) {
                                $chip.removeAttr('hidden');
                            } else {
                                $chip.attr('hidden', true);
                                // If the user was filtering on Favorites and
                                // just unfavorited the last one, fall back to
                                // the All filter so the grid isn't empty.
                                if ($chip.hasClass('awg-mem-tools-chip--on')) {
                                    $chip.removeClass('awg-mem-tools-chip--on');
                                    $('[data-awg-tools-filter="all"]').addClass('awg-mem-tools-chip--on').trigger('click');
                                }
                            }
                        }
                        // Re-apply filters in case the user is currently on
                        // the Favorites view and just changed its membership.
                        applyFilters();
                    }
                })
                .fail(function () {
                    $btn.toggleClass('is-fav', wasFav).attr('aria-pressed', wasFav ? 'true' : 'false');
                });
        });
    }

    // ── v3.0.0 — Quote attachments ─────────────────────────────────
    function initQuoteAttachments() {
        $(document).on('change', '[data-awg-quote-attach-input]', function () {
            var input = this;
            var file = input.files && input.files[0];
            if (!file) { return; }
            var nonce = $(input).data('nonce');
            var $list = $('[data-awg-quote-attach-list]');
            var rowId = 'aw-att-' + Date.now();
            $list.append(
                '<li id="' + rowId + '" class="awg-mem-quote-attach__item">' +
                  '<span class="awg-mem-quote-attach__item-name">' + escHtml(file.name) + '</span>' +
                  '<span class="awg-mem-quote-attach__item-status">' + escHtml(s.uploading || 'Uploading…') + '</span>' +
                '</li>'
            );
            var formData = new FormData();
            formData.append('action', 'awg_mem_upload_quote_attachment');
            formData.append('nonce', nonce);
            formData.append('file', file);

            $.ajax({
                url: ajax,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false
            }).done(function (res) {
                if (!res || !res.success) {
                    $('#' + rowId).find('.awg-mem-quote-attach__item-status').text((res && res.data && res.data.message) || (s.error_generic || 'Failed'));
                    return;
                }
                var att = res.data;
                $('#' + rowId).attr('data-url', att.url).attr('data-name', att.name);
                $('#' + rowId).find('.awg-mem-quote-attach__item-status').html(
                    '<span class="awg-mem-quote-attach__item-ok">' + escHtml(s.attached || 'Attached') + '</span>'
                );
            }).fail(function (xhr) {
                $('#' + rowId).find('.awg-mem-quote-attach__item-status').text(
                    (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) || (s.error_generic || 'Failed')
                );
            });
            input.value = '';
        });
    }


    // ── Sidebar drawer (v2.6.0) ──────────────────────────────
    function initSidebar() {
        var $dash = $('.awg-mem-dashboard--sidebar');
        if ( ! $dash.length ) { return; }

        var $sidebar  = $('#awg-mem-sidebar');
        var $backdrop = $('[data-awg-sidebar-backdrop]');
        var $toggle   = $('[data-awg-sidebar-toggle]');
        var $close    = $('[data-awg-sidebar-close]');
        var i18n      = (cfg.i18n || {});

        function openSidebar() {
            $sidebar.addClass('is-open');
            $backdrop.attr('hidden', false).addClass('is-open');
            $toggle.attr('aria-expanded', 'true').attr('aria-label', i18n.closeMenu || 'Close menu');
            if ( window.matchMedia('(max-width: 767px)').matches ) {
                $('body').css('overflow', 'hidden');
            }
        }
        function closeSidebar() {
            $sidebar.removeClass('is-open');
            $backdrop.removeClass('is-open').attr('hidden', true);
            $toggle.attr('aria-expanded', 'false').attr('aria-label', i18n.openMenu || 'Open menu');
            $('body').css('overflow', '');
        }

        $toggle.on('click', function (e) {
            e.preventDefault();
            if ( $sidebar.hasClass('is-open') ) { closeSidebar(); } else { openSidebar(); }
        });
        $close.on('click', function (e) { e.preventDefault(); closeSidebar(); });
        $backdrop.on('click', closeSidebar);

        // Mobile only: close drawer when any nav item or upgrade link inside is clicked
        $sidebar.on('click', '.awg-mem-sidenav__item, .awg-mem-sidebar__upgrade', function () {
            if ( window.matchMedia('(max-width: 767px)').matches ) {
                closeSidebar();
            }
        });

        $(document).on('keydown.awgsidebar', function (e) {
            if ( e.key === 'Escape' && $sidebar.hasClass('is-open') && window.matchMedia('(max-width: 1023px)').matches ) {
                closeSidebar();
                $toggle.trigger('focus');
            }
        });

        // Reset to closed when crossing into desktop viewport (sidebar becomes static)
        var mq = window.matchMedia('(min-width: 1024px)');
        function syncForViewport(e) {
            if ( (e && e.matches) || mq.matches ) { closeSidebar(); }
        }
        if ( mq.addEventListener ) { mq.addEventListener('change', syncForViewport); }
        else if ( mq.addListener ) { mq.addListener(syncForViewport); }
    }

    // Sync the breadcrumb section title with the active tab.
    // Hooks into the awg:tabchange event triggered by activateTab() in initTabs().
    function initSectionTitleSync() {
        var $title = $('[data-awg-section-title]');
        if ( ! $title.length ) { return; }
        var map = {
            home:     'Home',
            tools:    'AI Tools',
            services: 'Services',
            books:    'My books',
            history:  'History',
            account:  'Account',
            help:     'Help & support'
        };
        function update(tab) {
            if ( tab && map[ tab ] ) { $title.text( map[ tab ] ); }
        }
        $(document).on('awg:tabchange', function (e, tab) {
            update(tab);
        });
        // Initial sync: read the active tab right now (initTabs() may have
        // already fired awg:tabchange by the time we register the listener,
        // so we also pull the current state directly).
        var hash = (window.location.hash || '').replace(/^#/, '');
        var $active = $('.awg-mem-tab--active[data-tab]').first();
        var initialTab = hash || ( $active.length ? $active.data('tab') : 'home' );
        update(initialTab);
    }


    // ── Init ─────────────────────────────────────────────────
    $(function () {
        if ( ! $('.awg-mem-dashboard').length ) { return; }

        hoistModalsToBody(); // Must run first
        injectSpinStyle();
        initModalA11y();
        initTabs();
        initToolModal();
        initServiceModal();
        initHistoryLoadMore();
        initDashboardVisuals();
        initAccountPlanModal();
        initProfileModal();
        initAccountV271();
        initHelpPanel();
        initToolsControls();
        initQuoteAttachments();
        initPlanUpgrade();
        initCancelPlan();
        initManageBilling();
        initCopyButtons();
        initSidebar();
        initSectionTitleSync();
    });

}(jQuery));
