<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Memberships {

    private const STRIPE_API_BASE = 'https://api.stripe.com/v1';

    /**
     * User-meta key mirroring a Stripe-scheduled future plan change (e.g. a
     * paid→paid downgrade the Billing Portal queued for period end). Stores
     * [ plan_id, plan_name, billing, effective ]. See sync_pending_change_from_stripe().
     */
    private const PENDING_CHANGE_META = '_awg_mem_pending_change';

    public function get_current_user_membership(): ?array {
        return $this->get_effective_membership( get_current_user_id() );
    }

    public function get_current_user_plan_slug(): string {
        return $this->get_user_plan_slug( get_current_user_id() );
    }

    public function get_member_status( int $user_id ): string {
        $mem = $this->get_effective_membership( $user_id );
        return sanitize_key( (string) ( $mem['status'] ?? 'inactive' ) );
    }

    public function get_stripe_customer_id( int $user_id ): string {
        $mem = $this->get_latest_membership( $user_id );
        return sanitize_text_field( (string) ( $mem['stripe_customer_id'] ?? '' ) );
    }

    public function log_membership_action( string $event, array $context = [] ): void {
        Logger::log( $event, $context );
    }

    public function get_user_membership( int $user_id ): ?array {
        global $wpdb;
        $table = Database::mems_table();
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT m.*, p.name as plan_name, p.slug as plan_slug, p.limits, p.features, p.price_monthly, p.price_yearly, p.currency, p.is_free
                 FROM {$table} m
                 LEFT JOIN {$wpdb->prefix}awg_mem_plans p ON p.id = m.plan_id
                 WHERE m.user_id = %d AND m.status IN ('active','trialing')
                 ORDER BY m.id DESC LIMIT 1",
                $user_id
            ),
            ARRAY_A
        );
    }

    public function get_latest_membership( int $user_id ): ?array {
        global $wpdb;
        $table = Database::mems_table();
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT m.*, p.name as plan_name, p.slug as plan_slug, p.limits, p.features, p.price_monthly, p.price_yearly, p.currency, p.is_free
                 FROM {$table} m
                 LEFT JOIN {$wpdb->prefix}awg_mem_plans p ON p.id = m.plan_id
                 WHERE m.user_id = %d
                 ORDER BY m.id DESC LIMIT 1",
                $user_id
            ),
            ARRAY_A
        );
    }

    public function get_effective_membership( int $user_id ): ?array {
        $owner_id = $this->get_workspace_owner_id( $user_id );
        return $this->get_user_membership( $owner_id );
    }

    public function get_user_limits( int $user_id ): array {
        $mem = $this->get_effective_membership( $user_id );
        if ( ! $mem ) {
            // No membership row: treat as the free tier. Prefer the real Free plan's
            // configured limits; only fall back to a conservative floor when the
            // plans table is unavailable, so a DB hiccup can't hand out a generous
            // allowance (fail closed, not open).
            $free_limits = $this->get_free_plan_limits();
            if ( ! empty( $free_limits ) ) {
                return $free_limits;
            }
            return [
                'ai_generations_per_month' => 3,
                'tools_access'             => 'free',
            ];
        }
        return json_decode( $mem['limits'] ?? '{}', true ) ?: [];
    }

    /** Limits array of the active Free plan, or [] if none / table unavailable. */
    private function get_free_plan_limits(): array {
        static $cache = null;
        if ( $cache !== null ) {
            return $cache;
        }
        global $wpdb;
        $ptable = Database::plans_table();
        $limits = $wpdb->get_var(
            "SELECT limits FROM {$ptable} WHERE is_free = 1 AND is_active = 1 ORDER BY id ASC LIMIT 1"
        );
        $decoded = ( is_string( $limits ) && $limits !== '' ) ? json_decode( $limits, true ) : null;
        $cache   = is_array( $decoded ) ? $decoded : [];
        return $cache;
    }

    public function get_user_plan_slug( int $user_id ): string {
        $mem = $this->get_effective_membership( $user_id );
        return $mem['plan_slug'] ?? 'free';
    }

    // The team/workspace (Publisher seats) system has been removed. These
    // accessors are kept as trivial pass-throughs because the rest of the
    // plugin still calls them; every user now simply owns their own membership
    // and usage, with no workspace indirection.
    public function get_workspace_owner_id( int $user_id ): int {
        return $user_id;
    }

    public function is_team_member( int $user_id ): bool {
        return false;
    }

    public function user_can( int $user_id, string $capability ): bool {
        $user_id = max( 0, $user_id );
        if ( $user_id <= 0 ) {
            return false;
        }

        return user_can( $user_id, $capability );
    }

    public function get_usage_owner_id( int $user_id ): int {
        return $user_id;
    }

    public function set_user_plan( int $user_id, int $plan_id, string $billing = 'monthly', string $stripe_sub_id = '', string $stripe_cust_id = '', int $period_end = 0 ): bool {
        global $wpdb;
        $table = Database::mems_table();
        $now   = current_time( 'mysql' );

        $current_membership = $this->get_user_membership( $user_id );
        if (
            $current_membership
            && (int) $current_membership['plan_id'] === $plan_id
            && sanitize_key( (string) $current_membership['billing_cycle'] ) === sanitize_key( $billing )
            && sanitize_text_field( (string) ( $current_membership['stripe_subscription_id'] ?? '' ) ) === sanitize_text_field( $stripe_sub_id )
            && sanitize_text_field( (string) ( $current_membership['stripe_customer_id'] ?? '' ) ) === sanitize_text_field( $stripe_cust_id )
        ) {
            return true;
        }

        if ( $billing === 'free' ) {
            $end_date = null;
        } elseif ( $period_end > 0 ) {
            // Prefer Stripe's authoritative current_period_end (a Unix timestamp) so
            // the local renewal date matches Stripe exactly and the daily expiry
            // sweep can't downgrade a paid member a day or two early.
            $end_date = gmdate( 'Y-m-d H:i:s', $period_end );
        } elseif ( $billing === 'yearly' ) {
            $end_date = gmdate( 'Y-m-d H:i:s', strtotime( '+1 year' ) );
        } else {
            $end_date = gmdate( 'Y-m-d H:i:s', strtotime( '+1 month' ) );
        }

        // Wrap the cancel-then-insert in a transaction so a failed INSERT
        // cannot leave the user with zero active memberships. Transactions
        // only work on InnoDB; if the table is on a non-transactional engine
        // (legacy MyISAM hosts) we fall back to the previous unguarded path
        // rather than silently doing nothing.
        $use_tx = $this->table_supports_transactions( $table );

        if ( $use_tx ) {
            $wpdb->query( 'START TRANSACTION' );
        }

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table} SET status = 'cancelled', updated_at = %s WHERE user_id = %d AND status IN ('active','trialing')",
                $now,
                $user_id
            )
        );

        $inserted = $wpdb->insert( $table, [
            'user_id'                => $user_id,
            'plan_id'                => $plan_id,
            'status'                 => 'active',
            'billing_cycle'          => $billing,
            'start_date'             => $now,
            'end_date'               => $end_date,
            'stripe_subscription_id' => $stripe_sub_id,
            'stripe_customer_id'     => $stripe_cust_id,
            'created_at'             => $now,
            'updated_at'             => $now,
        ] );

        if ( ! $inserted ) {
            if ( $use_tx ) {
                $wpdb->query( 'ROLLBACK' );
            }
            Logger::log( 'set_user_plan_insert_failed', [
                'user_id' => (string) $user_id,
                'plan_id' => (string) $plan_id,
                'billing' => $billing,
                'db_error' => (string) $wpdb->last_error,
            ] );
            return false;
        }

        if ( $use_tx ) {
            $wpdb->query( 'COMMIT' );
        }

        // Side effects after the transaction commits — these touch wp_users
        // and other tables and should not block / be rolled back with the
        // membership write.
        $ptable = Database::plans_table();
        $plan   = $wpdb->get_row(
            $wpdb->prepare( "SELECT slug FROM {$ptable} WHERE id = %d", $plan_id ),
            ARRAY_A
        );
        if ( $plan ) {
            Roles::set_user_role( $user_id, Roles::slug_to_role( (string) $plan['slug'] ) );
        }
        do_action( 'awg_mem_plan_changed', $user_id, $plan_id );

        return true;
    }

    /**
     * Cached check: does the given table use a transactional engine (InnoDB)?
     * Result is memoised per-request to avoid repeated SHOW TABLE STATUS calls.
     */
    private function table_supports_transactions( string $table ): bool {
        static $cache = [];
        if ( array_key_exists( $table, $cache ) ) {
            return $cache[ $table ];
        }
        global $wpdb;
        $engine = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s LIMIT 1",
                DB_NAME,
                $table
            )
        );
        $cache[ $table ] = is_string( $engine ) && strtolower( $engine ) === 'innodb';
        return $cache[ $table ];
    }

    public function cancel_user_membership( int $user_id, string $status = 'cancelled' ): bool {
        global $wpdb;
        $table = Database::mems_table();
        $now   = current_time( 'mysql' );

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table} SET status = %s, updated_at = %s WHERE user_id = %d AND status IN ('active','trialing')",
                $status,
                $now,
                $user_id
            )
        );

        if ( $updated ) {
            // A cancellation supersedes any queued plan switch.
            $this->clear_pending_change( $user_id );
            Roles::clear_awg_roles( $user_id );
            if ( $status === 'cancelled' ) {
                do_action( 'awg_mem_cancelled', $user_id );
            } elseif ( $status === 'payment_failed' ) {
                do_action( 'awg_mem_payment_failed', $user_id );
            }
        }

        return (bool) $updated;
    }

    public function on_register( int $user_id ): void {
        global $wpdb;
        $ptable  = Database::plans_table();
        $free_plan = $wpdb->get_row(
            "SELECT id FROM {$ptable} WHERE is_free = 1 AND is_active = 1 LIMIT 1",
            ARRAY_A
        );
        if ( $free_plan ) {
            $this->set_user_plan( $user_id, (int) $free_plan['id'], 'free' );
        } else {
            Roles::clear_awg_roles( $user_id );
        }
    }

    public function check_expiries(): void {
        global $wpdb;
        $table = Database::mems_table();
        // end_date is stored in GMT (set_user_plan uses gmdate), so compare against
        // a GMT cutoff — not site-local current_time('mysql'), which would be off by
        // the timezone offset. 2-day grace: only expire memberships whose end_date
        // is comfortably past, so a delayed Stripe renewal webhook can't downgrade a
        // paying member in the window between period end and the renewal event.
        $cutoff = gmdate( 'Y-m-d H:i:s', time() - 2 * DAY_IN_SECONDS );

        $expired = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT user_id FROM {$table}
                 WHERE status = %s AND end_date IS NOT NULL AND end_date < %s",
                'active',
                $cutoff
            ),
            ARRAY_A
        );

        foreach ( (array) $expired as $row ) {
            $this->cancel_user_membership( (int) $row['user_id'], 'expired' );
            do_action( 'awg_mem_expired', (int) $row['user_id'] );
        }
    }

    private function get_settings(): array {
        return URLs::get_settings();
    }

    private function get_account_url(): string {
        // Prefer the dedicated [awg_account] page (lean build). URLs::account()
        // resolves through the "dashboard" page, which lean points at pricing —
        // so without this, portal/checkout returns (and the account-page status
        // banners) would land on the pricing page instead of My Account.
        if ( function_exists( 'awg_aig_mem_account_url' ) ) {
            $url = awg_aig_mem_account_url();
            if ( $url !== '' ) {
                return $url;
            }
        }
        return URLs::account();
    }

    private function get_tools_url(): string {
        if ( function_exists( 'awg_aig_mem_tools_url' ) ) {
            $url = awg_aig_mem_tools_url();
            if ( $url !== '' ) {
                return $url;
            }
        }
        return $this->get_account_url();
    }

    private function get_pricing_url(): string {
        if ( function_exists( 'awg_aig_mem_pricing_url' ) ) {
            $url = awg_aig_mem_pricing_url();
            if ( $url !== '' ) {
                return $url;
            }
        }
        return URLs::pricing();
    }

    private function create_stripe_checkout_session( array $plan, string $billing, int $user_id ) {
        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_secret_key'] ?? '' ) );
        if ( $secret === '' ) {
            return new \WP_Error( 'awg_mem_stripe_missing_secret', __( 'Stripe secret key is missing. Add it in Membership Settings.', 'authorwings-ai-tools' ) );
        }

        $price_key = $billing === 'yearly' ? 'stripe_yearly_price_id' : 'stripe_monthly_price_id';
        $price_id  = trim( (string) ( $plan[ $price_key ] ?? '' ) );
        if ( $price_id === '' ) {
            return new \WP_Error( 'awg_mem_stripe_missing_price', __( 'This plan is not connected to a Stripe price yet. Please contact support.', 'authorwings-ai-tools' ) );
        }

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new \WP_Error( 'awg_mem_user_not_found', __( 'User account not found.', 'authorwings-ai-tools' ) );
        }

        // After a successful first subscription, drop the member straight into
        // the AI Tools hub so they can use what they bought. awg_portal_return=1
        // triggers a resync-from-Stripe on arrival; the hub also shows an
        // "activating…" state with a one-shot refresh to cover webhook lag.
        $tools_url   = $this->get_tools_url();
        $success_url = add_query_arg(
            [
                'payment'           => 'success',
                'awg_portal_return' => '1',
                'session_id'        => '{CHECKOUT_SESSION_ID}',
            ],
            remove_query_arg( [ 'payment', 'session_id', 'cancelled', 'awg_portal_return' ], $tools_url )
        );
        // Abandoned checkout returns to pricing so they can reconsider plans.
        $cancel_url  = add_query_arg(
            [ 'cancelled' => '1' ],
            remove_query_arg( [ 'payment', 'session_id', 'cancelled' ], $this->get_pricing_url() )
        );

        $body = [
            'mode'                         => 'subscription',
            'success_url'                  => $success_url,
            'cancel_url'                   => $cancel_url,
            'client_reference_id'          => (string) $user_id,
            // Let members redeem Stripe promotion codes at checkout.
            'allow_promotion_codes'        => 'true',
            'line_items[0][price]'         => $price_id,
            'line_items[0][quantity]'      => 1,
            'metadata[user_id]'            => (string) $user_id,
            'metadata[plan_id]'            => (string) (int) $plan['id'],
            'metadata[plan_slug]'          => (string) $plan['slug'],
            'metadata[billing]'            => $billing,
            'subscription_data[metadata][user_id]'   => (string) $user_id,
            'subscription_data[metadata][plan_id]'   => (string) (int) $plan['id'],
            'subscription_data[metadata][plan_slug]' => (string) $plan['slug'],
            'subscription_data[metadata][billing]'   => $billing,
        ];

        // Attach to the existing Stripe customer when we already have one (e.g.
        // a member who previously subscribed, cancelled, and is re-subscribing).
        // Stripe rejects passing both `customer` and `customer_email`, so it's
        // one or the other. Reusing the customer keeps a single billing profile
        // and prevents duplicate Customer records per WordPress user.
        $existing_customer = $this->get_stripe_customer_id( $user_id );
        if ( $existing_customer !== '' ) {
            $body['customer'] = $existing_customer;
        } else {
            $body['customer_email'] = (string) $user->user_email;
        }

        // Optional free-trial window, configured per plan via its limits JSON
        // (`trial_days`). Only applied on the user's first paid subscription so
        // a cancel-and-resubscribe can't farm repeat trials.
        $plan_limits = json_decode( (string) ( $plan['limits'] ?? '{}' ), true );
        $trial_days  = is_array( $plan_limits ) ? max( 0, (int) ( $plan_limits['trial_days'] ?? 0 ) ) : 0;
        if ( $trial_days > 0 && ! $this->user_has_had_paid_subscription( $user_id ) ) {
            $body['subscription_data[trial_period_days]'] = $trial_days;
        }

        $response = wp_remote_post(
            self::STRIPE_API_BASE . '/checkout/sessions',
            [
                'timeout' => 30,
                'headers' => [
                    'Authorization'  => 'Bearer ' . $secret,
                    // Pin the API version so account-level default rollovers
                    // never silently change response shape. Bump explicitly
                    // when you intentionally migrate to a newer API surface.
                    'Stripe-Version' => '2023-10-16',
                ],
                'body'    => $body,
            ]
        );

        if ( is_wp_error( $response ) ) {
            $this->log_membership_action( 'stripe_request_failed', [ 'message' => $response->get_error_message(), 'user_id' => (string) $user_id, 'billing' => $billing ] );
            return new \WP_Error( 'awg_mem_stripe_request_failed', $response->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $json = json_decode( (string) wp_remote_retrieve_body( $response ), true );

        if ( $code < 200 || $code >= 300 || ! is_array( $json ) ) {
            $message = __( 'Unable to start checkout right now. Please try again.', 'authorwings-ai-tools' );
            if ( is_array( $json ) && ! empty( $json['error']['message'] ) ) {
                $message = sanitize_text_field( (string) $json['error']['message'] );
            }
            $this->log_membership_action( 'stripe_checkout_failed', [ 'message' => $message, 'user_id' => (string) $user_id, 'billing' => $billing, 'plan_id' => (string) (int) $plan['id'] ] );
            return new \WP_Error( 'awg_mem_stripe_checkout_failed', $message, [ 'raw' => $json ] );
        }

        if ( empty( $json['url'] ) ) {
            return new \WP_Error( 'awg_mem_stripe_missing_url', __( 'Stripe checkout URL was not returned.', 'authorwings-ai-tools' ) );
        }

        return esc_url_raw( (string) $json['url'] );
    }

    /**
     * Has this user ever held a paid Stripe subscription? Used to gate
     * first-time-only free trials.
     */
    private function user_has_had_paid_subscription( int $user_id ): bool {
        global $wpdb;
        $table = Database::mems_table();
        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND stripe_subscription_id <> ''",
                $user_id
            )
        );
        return (int) $count > 0;
    }

    /**
     * Create a Stripe Billing Portal session so the member can update their
     * card, view invoices, and manage their subscription on Stripe-hosted
     * pages. Returns a redirect URL or WP_Error.
     *
     * When $update_subscription_id is supplied, the session is deep-linked to
     * the portal's `subscription_update` flow for that subscription, so a
     * member who clicked a different plan lands directly on the plan-switch
     * screen. Stripe then performs the swap on the EXISTING subscription with
     * proration — never a second subscription. Requires the Customer Portal to
     * be configured (Stripe Dashboard → Settings → Billing → Customer portal)
     * to allow switching plans and to list the relevant products/prices.
     */
    private function create_billing_portal_session( int $user_id, string $update_subscription_id = '', string $cancel_subscription_id = '' ) {
        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_secret_key'] ?? '' ) );
        if ( $secret === '' ) {
            return new \WP_Error( 'awg_mem_stripe_missing_secret', __( 'Billing is not configured yet. Please contact support.', 'authorwings-ai-tools' ) );
        }

        $customer_id = $this->get_stripe_customer_id( $user_id );
        if ( $customer_id === '' ) {
            return new \WP_Error( 'awg_mem_no_customer', __( 'No billing profile was found for your account yet. Start a paid plan first.', 'authorwings-ai-tools' ) );
        }

        // awg_portal_return=1 triggers a front-end resync-from-Stripe on
        // return (see awg_aig_mem_confirm_portal_return). Added to the BASE
        // return URL so a plan switch made from the generic "Manage billing"
        // portal is caught too, not only the deep-linked subscription_update
        // flow below. The resync is throttled and no-ops when already in sync.
        $return_url = add_query_arg(
            [ 'tab' => 'account', 'awg_portal_return' => '1' ],
            remove_query_arg( [ 'payment', 'session_id', 'cancelled' ], $this->get_account_url() )
        );

        $portal_body = [
            'customer'   => $customer_id,
            'return_url' => $return_url,
        ];

        $update_subscription_id = sanitize_text_field( $update_subscription_id );
        $cancel_subscription_id = sanitize_text_field( $cancel_subscription_id );
        if ( $update_subscription_id !== '' ) {
            $portal_body['flow_data[type]']                                = 'subscription_update';
            $portal_body['flow_data[subscription_update][subscription]']   = $update_subscription_id;
            // After the member confirms the change in the portal, send them
            // back to their account page rather than the generic portal home.
            // awg_portal_return=1 lets the front end re-sync the plan straight
            // from Stripe on arrival, so the switch reflects immediately even
            // if the customer.subscription.updated webhook is slow or missing.
            $portal_body['flow_data[after_completion][type]']              = 'redirect';
            $portal_body['flow_data[after_completion][redirect][return_url]'] = add_query_arg(
                [ 'awg_notice' => 'plan-updated', 'awg_portal_return' => '1' ],
                $return_url
            );
        } elseif ( $cancel_subscription_id !== '' ) {
            // Deep-link straight to the portal's cancellation screen for this
            // subscription. Stripe handles the confirmation (and any retention
            // offers / "cancel at period end vs immediately" behaviour you set
            // in Stripe Dashboard → Settings → Billing → Customer portal). On
            // return, awg_portal_return=1 re-syncs from Stripe so the account
            // page reflects the new state even before the webhook lands.
            $portal_body['flow_data[type]']                                = 'subscription_cancel';
            $portal_body['flow_data[subscription_cancel][subscription]']   = $cancel_subscription_id;
            $portal_body['flow_data[after_completion][type]']              = 'redirect';
            $portal_body['flow_data[after_completion][redirect][return_url]'] = add_query_arg(
                [ 'awg_notice' => 'cancel-scheduled', 'awg_portal_return' => '1' ],
                $return_url
            );
        }

        $response = wp_remote_post(
            self::STRIPE_API_BASE . '/billing_portal/sessions',
            [
                'timeout' => 30,
                'headers' => [
                    'Authorization'  => 'Bearer ' . $secret,
                    'Stripe-Version' => '2023-10-16',
                ],
                'body'    => $portal_body,
            ]
        );

        if ( is_wp_error( $response ) ) {
            $this->log_membership_action( 'stripe_portal_request_failed', [ 'message' => $response->get_error_message(), 'user_id' => (string) $user_id ] );
            return new \WP_Error( 'awg_mem_portal_request_failed', $response->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $json = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 || ! is_array( $json ) || empty( $json['url'] ) ) {
            $message = is_array( $json ) && ! empty( $json['error']['message'] )
                ? sanitize_text_field( (string) $json['error']['message'] )
                : __( 'Unable to open the billing portal right now. Please try again.', 'authorwings-ai-tools' );
            $this->log_membership_action( 'stripe_portal_failed', [ 'message' => $message, 'user_id' => (string) $user_id, 'http_code' => (string) $code ] );
            return new \WP_Error( 'awg_mem_portal_failed', $message );
        }

        return esc_url_raw( (string) $json['url'] );
    }

    /**
     * Run read-only Stripe configuration / connectivity diagnostics for the
     * admin Release Tests page. Returns a flat list of rows:
     *   [ 'name' => string, 'status' => 'pass'|'fail'|'warn'|'info', 'message' => string ]
     *
     * Safe to run before any real transaction: it makes at most a couple of
     * lightweight read-only GET calls to Stripe (account + price lookups) and
     * never creates or mutates anything on Stripe or in the database.
     */
    public function run_stripe_diagnostics(): array {
        $checks   = [];
        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_secret_key'] ?? '' ) );
        $webhook  = trim( (string) ( $settings['stripe_webhook_secret'] ?? '' ) );
        $public   = trim( (string) ( $settings['stripe_public_key'] ?? '' ) );

        // 1) Secret key presence + mode (test vs live, read from the prefix).
        if ( $secret === '' ) {
            $checks[] = [ 'name' => __( 'Stripe secret key', 'authorwings-ai-tools' ), 'status' => 'fail', 'message' => __( 'Not set. Add it under Settings before testing payments.', 'authorwings-ai-tools' ) ];
        } else {
            $mode = strpos( $secret, 'sk_live_' ) === 0 ? __( 'LIVE', 'authorwings-ai-tools' )
                  : ( strpos( $secret, 'sk_test_' ) === 0 ? __( 'TEST', 'authorwings-ai-tools' ) : __( 'unknown format', 'authorwings-ai-tools' ) );
            $checks[] = [ 'name' => __( 'Stripe secret key', 'authorwings-ai-tools' ), 'status' => 'pass', 'message' => sprintf( /* translators: %s: key mode */ __( 'Set (%s mode).', 'authorwings-ai-tools' ), $mode ) ];
        }

        // 2) Webhook signing secret presence.
        $checks[] = $webhook === ''
            ? [ 'name' => __( 'Webhook signing secret', 'authorwings-ai-tools' ), 'status' => 'fail', 'message' => __( 'Not set. The endpoint will reject every event until this matches the signing secret Stripe shows for your webhook.', 'authorwings-ai-tools' ) ]
            : [ 'name' => __( 'Webhook signing secret', 'authorwings-ai-tools' ), 'status' => 'pass', 'message' => __( 'Set.', 'authorwings-ai-tools' ) ];

        // 3) Publishable key (informational — only needed for Stripe.js; the
        //    hosted Checkout flow this plugin uses works without it).
        $checks[] = [ 'name' => __( 'Publishable key', 'authorwings-ai-tools' ), 'status' => 'info', 'message' => $public === '' ? __( 'Not set (optional for hosted Checkout).', 'authorwings-ai-tools' ) : __( 'Set.', 'authorwings-ai-tools' ) ];

        // 4) Webhook endpoint URL to register in the Stripe Dashboard.
        $checks[] = [ 'name' => __( 'Webhook endpoint URL', 'authorwings-ai-tools' ), 'status' => 'info', 'message' => esc_url_raw( rest_url( 'authorwings-membership/v1/stripe/webhook' ) ) ];

        // 5) Live API connectivity (only attempted when a secret is present).
        $api_ok = false;
        if ( $secret !== '' ) {
            $resp = wp_remote_get(
                self::STRIPE_API_BASE . '/account',
                [
                    'timeout' => 20,
                    'headers' => [
                        'Authorization'  => 'Bearer ' . $secret,
                        'Stripe-Version' => '2023-10-16',
                    ],
                ]
            );
            if ( is_wp_error( $resp ) ) {
                $checks[] = [ 'name' => __( 'Stripe API connection', 'authorwings-ai-tools' ), 'status' => 'fail', 'message' => $resp->get_error_message() ];
            } else {
                $code = (int) wp_remote_retrieve_response_code( $resp );
                $json = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
                if ( $code >= 200 && $code < 300 && is_array( $json ) && ! empty( $json['id'] ) ) {
                    $api_ok   = true;
                    $acct     = sanitize_text_field( (string) $json['id'] );
                    $name     = sanitize_text_field( (string) ( $json['settings']['dashboard']['display_name'] ?? ( $json['business_profile']['name'] ?? '' ) ) );
                    $checks[] = [ 'name' => __( 'Stripe API connection', 'authorwings-ai-tools' ), 'status' => 'pass', 'message' => trim( sprintf( /* translators: 1: account id 2: optional business name */ __( 'Connected to account %1$s %2$s', 'authorwings-ai-tools' ), $acct, $name !== '' ? '(' . $name . ')' : '' ) ) ];
                } else {
                    $msg      = is_array( $json ) && ! empty( $json['error']['message'] ) ? sanitize_text_field( (string) $json['error']['message'] ) : sprintf( /* translators: %d: HTTP status */ __( 'Stripe returned HTTP %d.', 'authorwings-ai-tools' ), $code );
                    $checks[] = [ 'name' => __( 'Stripe API connection', 'authorwings-ai-tools' ), 'status' => 'fail', 'message' => $msg ];
                }
            }
        }

        // 6) Per-plan price-ID configuration (and live validation if connected).
        global $wpdb;
        $ptable = Database::plans_table();
        $plans  = $wpdb->get_results( "SELECT id, name, slug, currency, is_free, is_active, stripe_monthly_price_id, stripe_yearly_price_id FROM {$ptable} WHERE is_active = 1 ORDER BY sort_order ASC, id ASC", ARRAY_A );

        $paid_plans = array_filter( (array) $plans, static function ( $p ) {
            return empty( $p['is_free'] );
        } );

        if ( empty( $paid_plans ) ) {
            $checks[] = [ 'name' => __( 'Paid plans', 'authorwings-ai-tools' ), 'status' => 'warn', 'message' => __( 'No active paid plans found. Create at least one paid plan with a Stripe price ID to test checkout.', 'authorwings-ai-tools' ) ];
        }

        foreach ( $paid_plans as $p ) {
            $label   = sprintf( /* translators: %s: plan name */ __( 'Plan: %s', 'authorwings-ai-tools' ), (string) $p['name'] );
            $monthly = trim( (string) $p['stripe_monthly_price_id'] );
            $yearly  = trim( (string) $p['stripe_yearly_price_id'] );

            if ( $monthly === '' && $yearly === '' ) {
                $checks[] = [ 'name' => $label, 'status' => 'fail', 'message' => __( 'No Stripe price IDs set (monthly or yearly). Checkout for this plan will fail.', 'authorwings-ai-tools' ) ];
                continue;
            }

            $parts       = [];
            $has_problem = false;
            foreach ( [ 'month' => $monthly, 'year' => $yearly ] as $interval => $price_id ) {
                if ( $price_id === '' ) {
                    continue;
                }
                if ( ! $api_ok ) {
                    $parts[] = sprintf( /* translators: 1: Monthly/Yearly 2: price id */ __( '%1$s price set (%2$s) — not validated (no API connection).', 'authorwings-ai-tools' ), ucfirst( $interval ), $price_id );
                    continue;
                }
                $pr = wp_remote_get(
                    self::STRIPE_API_BASE . '/prices/' . rawurlencode( $price_id ),
                    [
                        'timeout' => 20,
                        'headers' => [ 'Authorization' => 'Bearer ' . $secret, 'Stripe-Version' => '2023-10-16' ],
                    ]
                );
                if ( is_wp_error( $pr ) ) {
                    $has_problem = true;
                    $parts[]     = sprintf( __( '%1$s price %2$s could not be checked: %3$s', 'authorwings-ai-tools' ), ucfirst( $interval ), $price_id, $pr->get_error_message() );
                    continue;
                }
                $pcode = (int) wp_remote_retrieve_response_code( $pr );
                $pjson = json_decode( (string) wp_remote_retrieve_body( $pr ), true );
                if ( $pcode < 200 || $pcode >= 300 || ! is_array( $pjson ) || empty( $pjson['id'] ) ) {
                    $has_problem = true;
                    $parts[]     = sprintf( __( '%1$s price %2$s NOT found on Stripe.', 'authorwings-ai-tools' ), ucfirst( $interval ), $price_id );
                    continue;
                }
                $active = ! empty( $pjson['active'] );
                $recur  = isset( $pjson['recurring']['interval'] ) ? (string) $pjson['recurring']['interval'] : '';
                $issues = [];
                if ( ! $active ) {
                    $issues[] = __( 'inactive', 'authorwings-ai-tools' );
                }
                if ( $recur === '' ) {
                    $issues[] = __( 'not recurring', 'authorwings-ai-tools' );
                } elseif ( $recur !== $interval ) {
                    $issues[] = sprintf( __( 'interval is %1$s, expected %2$s', 'authorwings-ai-tools' ), $recur, $interval );
                }
                if ( $issues ) {
                    $has_problem = true;
                    $parts[]     = sprintf( __( '%1$s price %2$s has issues: %3$s.', 'authorwings-ai-tools' ), ucfirst( $interval ), $price_id, implode( ', ', $issues ) );
                } else {
                    $parts[] = sprintf( __( '%1$s price %2$s OK.', 'authorwings-ai-tools' ), ucfirst( $interval ), $price_id );
                }
            }

            $checks[] = [ 'name' => $label, 'status' => $has_problem ? 'fail' : ( $api_ok ? 'pass' : 'warn' ), 'message' => implode( ' ', $parts ) ];
        }

        // 7) AI Tools plugin presence (only affects usage gating, not billing).
        $ai_active = defined( 'AWG_AIG_VERSION' ) || class_exists( '\\AWG_AIG\\Plugin' );
        $checks[]  = [ 'name' => __( 'AuthorWings AI Tools plugin', 'authorwings-ai-tools' ), 'status' => 'info', 'message' => $ai_active ? __( 'Active — AI usage gating is wired.', 'authorwings-ai-tools' ) : __( 'Not detected — billing still works; AI usage gating only applies when it is active.', 'authorwings-ai-tools' ) ];

        return $checks;
    }

    public function ajax_billing_portal(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-ai-tools' ) ], 401 );
        }
        if ( $this->is_team_member( get_current_user_id() ) ) {
            wp_send_json_error( [ 'message' => __( 'Only the workspace owner can manage billing.', 'authorwings-ai-tools' ) ], 403 );
        }

        $url = $this->create_billing_portal_session( get_current_user_id() );
        if ( is_wp_error( $url ) ) {
            wp_send_json_error( [ 'message' => $url->get_error_message() ], 400 );
        }
        wp_send_json_success( [ 'redirect' => $url ] );
    }

    /**
     * "Cancel plan" → Stripe. Opens the Stripe Customer Portal and, when the
     * member has a live subscription, deep-links straight to Stripe's
     * cancel-confirmation screen. Stripe owns the confirmation and any
     * retention offers, which keeps cancellation as easy as signup (the
     * standard regulators and the card networks expect) without us running a
     * bespoke cancel flow. Falls back to the portal home if no subscription id
     * is on file so the member can still self-serve.
     */
    public function ajax_cancel_portal(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-ai-tools' ) ], 401 );
        }
        if ( $this->is_team_member( get_current_user_id() ) ) {
            wp_send_json_error( [ 'message' => __( 'Team members cannot cancel workspace billing. Please contact the workspace owner.', 'authorwings-ai-tools' ) ], 403 );
        }

        $uid    = get_current_user_id();
        $latest = $this->get_latest_membership( $uid );
        $sub_id = sanitize_text_field( (string) ( $latest['stripe_subscription_id'] ?? '' ) );

        $url = $sub_id !== ''
            ? $this->create_billing_portal_session( $uid, '', $sub_id )
            : $this->create_billing_portal_session( $uid );

        if ( is_wp_error( $url ) ) {
            wp_send_json_error( [ 'message' => $url->get_error_message() ], 400 );
        }
        wp_send_json_success( [ 'redirect' => $url ] );
    }

    /**
     * Best-effort summary of the member's default card (brand + last 4 +
     * expiry) for display on the account page. Read-only and cached: a hit is
     * cached 12h, a miss 1h, so a warm page never calls Stripe. The cache is
     * cleared when the member returns from the Billing Portal (where the card
     * can change). Returns [] when billing is unconfigured, there is no
     * customer, or no card is on file. Never throws.
     *
     * @return array{brand:string,last4:string,exp_month:int,exp_year:int}|array{}
     */
    public function get_payment_method_summary( int $user_id ): array {
        $user_id = max( 0, $user_id );
        if ( $user_id <= 0 ) {
            return [];
        }

        $cache_key = 'awg_mem_pm_summary_' . $user_id;
        $cached    = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            // An empty card array is a cached "no card" — honour it.
            return isset( $cached['card'] ) && is_array( $cached['card'] ) ? $cached['card'] : [];
        }

        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_secret_key'] ?? '' ) );
        $customer = $this->get_stripe_customer_id( $user_id );
        if ( $secret === '' || $customer === '' ) {
            return [];
        }

        $card = $this->fetch_default_card_from_stripe( $secret, $customer );
        set_transient( $cache_key, [ 'card' => $card ], $card ? 12 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
        return $card;
    }

    /**
     * Two read-only Stripe lookups: the customer's default payment method
     * first, then the most recently attached card as a fallback.
     */
    private function fetch_default_card_from_stripe( string $secret, string $customer ): array {
        $headers = [ 'Authorization' => 'Bearer ' . $secret, 'Stripe-Version' => '2023-10-16' ];

        $resp = wp_remote_get(
            self::STRIPE_API_BASE . '/customers/' . rawurlencode( $customer ) . '?expand[]=invoice_settings.default_payment_method',
            [ 'timeout' => 15, 'headers' => $headers ]
        );
        $card = $this->card_from_stripe_response( $resp, [ 'invoice_settings', 'default_payment_method' ] );
        if ( $card ) {
            return $card;
        }

        $resp = wp_remote_get(
            self::STRIPE_API_BASE . '/customers/' . rawurlencode( $customer ) . '/payment_methods?type=card&limit=1',
            [ 'timeout' => 15, 'headers' => $headers ]
        );
        return $this->card_from_stripe_response( $resp, [ 'data', 0 ] );
    }

    /**
     * Pull a normalised card array out of a Stripe response by walking $path to
     * the payment-method node and reading its `card` hash. Returns [] on any
     * error, non-2xx, or missing data.
     */
    private function card_from_stripe_response( $resp, array $path ): array {
        if ( is_wp_error( $resp ) ) {
            return [];
        }
        $code = (int) wp_remote_retrieve_response_code( $resp );
        if ( $code < 200 || $code >= 300 ) {
            return [];
        }
        $node = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
        if ( ! is_array( $node ) ) {
            return [];
        }
        foreach ( $path as $key ) {
            if ( is_array( $node ) && isset( $node[ $key ] ) ) {
                $node = $node[ $key ];
            } else {
                return [];
            }
        }
        $card = is_array( $node ) && isset( $node['card'] ) && is_array( $node['card'] ) ? $node['card'] : null;
        if ( ! $card ) {
            return [];
        }
        return [
            'brand'     => sanitize_text_field( (string) ( $card['brand'] ?? '' ) ),
            'last4'     => sanitize_text_field( (string) ( $card['last4'] ?? '' ) ),
            'exp_month' => (int) ( $card['exp_month'] ?? 0 ),
            'exp_year'  => (int) ( $card['exp_year'] ?? 0 ),
        ];
    }

    /**
     * Daily cron: email members whose paid plan renews within the reminder
     * window (default 7 days). Fires once per renewal cycle, tracked by a
     * per-membership marker keyed on the membership row id + end_date so a
     * later renewal that pushes end_date forward re-arms the reminder.
     */
    public function send_renewal_reminders(): void {
        global $wpdb;
        $settings = $this->get_settings();
        $days     = isset( $settings['renewal_reminder_days'] ) ? max( 0, (int) $settings['renewal_reminder_days'] ) : 7;
        if ( $days <= 0 ) {
            return;
        }

        $table  = Database::mems_table();
        $ptable = Database::plans_table();
        $now    = current_time( 'mysql' );
        $window = gmdate( 'Y-m-d H:i:s', strtotime( '+' . $days . ' days' ) );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT m.id, m.user_id, m.end_date, m.billing_cycle, p.name AS plan_name
                 FROM {$table} m
                 LEFT JOIN {$ptable} p ON p.id = m.plan_id
                 WHERE m.status = 'active'
                   AND m.billing_cycle IN ('monthly','yearly')
                   AND m.end_date IS NOT NULL
                   AND m.end_date > %s
                   AND m.end_date <= %s",
                $now,
                $window
            ),
            ARRAY_A
        );

        foreach ( (array) $rows as $row ) {
            $marker = 'awg_mem_renewal_reminded_' . (int) $row['id'] . '_' . md5( (string) $row['end_date'] );
            if ( get_transient( $marker ) ) {
                continue;
            }
            do_action( 'awg_mem_renewal_reminder', (int) $row['user_id'], [
                'end_date'  => (string) $row['end_date'],
                'plan_name' => (string) ( $row['plan_name'] ?? '' ),
            ] );
            set_transient( $marker, 1, 30 * DAY_IN_SECONDS );
        }
    }

    public function verify_stripe_signature( string $payload, string $signature_header, string $secret ): bool {
        if ( $payload === '' || $signature_header === '' || $secret === '' ) {
            return false;
        }

        // A Stripe-Signature header can carry MULTIPLE v1 signatures (one per active
        // secret) during a webhook-secret rotation. Collect them all and accept the
        // event if ANY matches, instead of keeping only the last v1.
        $timestamp  = '';
        $signatures = [];
        foreach ( explode( ',', $signature_header ) as $segment ) {
            $pair = explode( '=', trim( $segment ), 2 );
            if ( count( $pair ) !== 2 ) {
                continue;
            }
            if ( $pair[0] === 't' ) {
                $timestamp = $pair[1];
            } elseif ( $pair[0] === 'v1' ) {
                $signatures[] = $pair[1];
            }
        }

        if ( $timestamp === '' || empty( $signatures ) ) {
            return false;
        }

        if ( abs( time() - (int) $timestamp ) > 300 ) {
            return false;
        }

        $expected = hash_hmac( 'sha256', $timestamp . '.' . $payload, $secret );
        foreach ( $signatures as $sig ) {
            if ( hash_equals( $expected, (string) $sig ) ) {
                return true;
            }
        }
        return false;
    }

    private function find_user_id_by_subscription( string $subscription_id ): int {
        if ( $subscription_id === '' ) {
            return 0;
        }

        global $wpdb;
        $table = Database::mems_table();
        $user_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT user_id FROM {$table} WHERE stripe_subscription_id = %s ORDER BY id DESC LIMIT 1",
                $subscription_id
            )
        );

        return (int) $user_id;
    }

    private function find_user_id_by_customer( string $customer_id ): int {
        if ( $customer_id === '' ) {
            return 0;
        }

        global $wpdb;
        $table = Database::mems_table();
        $user_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT user_id FROM {$table} WHERE stripe_customer_id = %s ORDER BY id DESC LIMIT 1",
                $customer_id
            )
        );

        return (int) $user_id;
    }

    private function cancel_stripe_subscription( string $subscription_id ): bool {
        $subscription_id = sanitize_text_field( $subscription_id );
        if ( $subscription_id === '' ) {
            return true;
        }

        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_secret_key'] ?? '' ) );
        if ( $secret === '' ) {
            return false;
        }

        // A subscription that still has an active subscription_schedule attached
        // (e.g. a paid→paid downgrade the Billing Portal queued for period end)
        // cannot be mutated directly — Stripe rejects cancel_at_period_end with a
        // 400 ("…attached to a subscription schedule…"). That previously surfaced
        // to the member as "We could not change your plan on Stripe right now" and
        // left WordPress out of sync with Stripe. Release the schedule first so the
        // cancellation below applies cleanly.
        $this->release_subscription_schedule_if_attached( $subscription_id, $secret );

        // Cancel at period end rather than immediately: the member keeps the access
        // they already paid for until the current period closes, while Stripe stops
        // all future renewals. Stripe then fires customer.subscription.deleted at the
        // period end, which the webhook turns into the downgrade to free.
        $response = wp_remote_request(
            self::STRIPE_API_BASE . '/subscriptions/' . rawurlencode( $subscription_id ),
            [
                'method'  => 'POST',
                'timeout' => 30,
                'headers' => [
                    'Authorization'  => 'Bearer ' . $secret,
                    'Stripe-Version' => '2023-10-16',
                    'Content-Type'   => 'application/x-www-form-urlencoded',
                ],
                'body'    => [ 'cancel_at_period_end' => 'true' ],
            ]
        );

        if ( is_wp_error( $response ) ) {
            $this->log_membership_action( 'stripe_cancel_request_failed', [
                'subscription_id' => $subscription_id,
                'message'         => $response->get_error_message(),
            ] );
            return false;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $json = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        $ok   = $code >= 200 && $code < 300 && is_array( $json ) && ! empty( $json['id'] );

        if ( ! $ok ) {
            $message = is_array( $json ) && ! empty( $json['error']['message'] )
                ? sanitize_text_field( (string) $json['error']['message'] )
                : 'Stripe cancellation failed';
            $this->log_membership_action( 'stripe_cancel_failed', [
                'subscription_id' => $subscription_id,
                'http_code'       => (string) $code,
                'message'         => $message,
            ] );
            return false;
        }

        $this->log_membership_action( 'stripe_cancel_succeeded', [
            'subscription_id' => $subscription_id,
            'status'          => sanitize_text_field( (string) ( $json['status'] ?? '' ) ),
        ] );

        return true;
    }

    /**
     * Detach any active subscription_schedule from a subscription so the
     * subscription can be updated directly again. Stripe forbids direct mutation
     * (including cancel_at_period_end and price swaps) of a subscription while a
     * schedule is attached, so a queued downgrade would otherwise block a later
     * cancel/switch. Releasing keeps the subscription running unchanged at its
     * current price — it only discards the queued future phase(s).
     *
     * Best-effort and self-contained: it no-ops when there is no schedule and
     * swallows/logs failures (the caller decides what to do next). On a
     * successful release it also clears the local "pending change" marker, which
     * the released schedule made stale.
     */
    private function release_subscription_schedule_if_attached( string $subscription_id, string $secret ): void {
        $subscription_id = sanitize_text_field( $subscription_id );
        if ( $subscription_id === '' || $secret === '' ) {
            return;
        }

        $response = wp_remote_get(
            self::STRIPE_API_BASE . '/subscriptions/' . rawurlencode( $subscription_id ),
            [
                'timeout' => 20,
                'headers' => [
                    'Authorization'  => 'Bearer ' . $secret,
                    'Stripe-Version' => '2023-10-16',
                ],
            ]
        );
        if ( is_wp_error( $response ) ) {
            return;
        }
        $code = (int) wp_remote_retrieve_response_code( $response );
        $sub  = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 || ! is_array( $sub ) ) {
            return;
        }

        $schedule_id = '';
        if ( isset( $sub['schedule'] ) && $sub['schedule'] !== null ) {
            $schedule_id = is_array( $sub['schedule'] )
                ? sanitize_text_field( (string) ( $sub['schedule']['id'] ?? '' ) )
                : sanitize_text_field( (string) $sub['schedule'] );
        }
        if ( $schedule_id === '' ) {
            return;
        }

        $release = wp_remote_post(
            self::STRIPE_API_BASE . '/subscription_schedules/' . rawurlencode( $schedule_id ) . '/release',
            [
                'timeout' => 20,
                'headers' => [
                    'Authorization'  => 'Bearer ' . $secret,
                    'Stripe-Version' => '2023-10-16',
                ],
            ]
        );
        if ( is_wp_error( $release ) ) {
            $this->log_membership_action( 'stripe_schedule_release_failed', [
                'subscription_id' => $subscription_id,
                'schedule_id'     => $schedule_id,
                'message'         => $release->get_error_message(),
            ] );
            return;
        }
        $rcode = (int) wp_remote_retrieve_response_code( $release );
        if ( $rcode < 200 || $rcode >= 300 ) {
            $rjson = json_decode( (string) wp_remote_retrieve_body( $release ), true );
            $this->log_membership_action( 'stripe_schedule_release_failed', [
                'subscription_id' => $subscription_id,
                'schedule_id'     => $schedule_id,
                'http_code'       => (string) $rcode,
                'message'         => is_array( $rjson ) && ! empty( $rjson['error']['message'] )
                    ? sanitize_text_field( (string) $rjson['error']['message'] )
                    : '',
            ] );
            return;
        }

        // The queued change is gone, so the local mirror must not keep
        // advertising it.
        $uid = $this->find_user_id_by_subscription( $subscription_id );
        if ( $uid > 0 ) {
            $this->clear_pending_change( $uid );
        }
        $this->log_membership_action( 'stripe_schedule_released', [
            'subscription_id' => $subscription_id,
            'schedule_id'     => $schedule_id,
        ] );
    }

    /**
     * Resolve which plan (and billing cycle) a Stripe Subscription object is
     * for, by reading the price on its first line item and matching it against
     * the stored stripe_monthly_price_id / stripe_yearly_price_id columns.
     *
     * This is the authoritative source of truth for plan SWITCHES: when a
     * member changes plan in the Stripe Billing Portal, Stripe updates the
     * subscription's price but does NOT rewrite the subscription metadata, so
     * the stale metadata[plan_id] would point at the OLD plan. Reading the live
     * price keeps WordPress in sync with what Stripe is actually billing.
     *
     * @return array{plan_id:int,billing:string} billing is '' when unresolved.
     */
    private function resolve_plan_from_subscription_object( array $object ): array {
        $price_id = '';
        $interval = '';
        if ( isset( $object['items']['data'][0]['price'] ) && is_array( $object['items']['data'][0]['price'] ) ) {
            $price    = $object['items']['data'][0]['price'];
            $price_id = sanitize_text_field( (string) ( $price['id'] ?? '' ) );
            $interval = isset( $price['recurring']['interval'] ) ? sanitize_key( (string) $price['recurring']['interval'] ) : '';
        }

        $resolved = $this->resolve_plan_from_price_id( $price_id );
        if ( $resolved['plan_id'] <= 0 ) {
            return [ 'plan_id' => 0, 'billing' => '' ];
        }

        // When the price wasn't an exact monthly/yearly match (shouldn't happen
        // for a recognised plan) fall back to the recurring interval.
        $billing = $resolved['billing'] !== '' ? $resolved['billing'] : ( $interval === 'year' ? 'yearly' : 'monthly' );

        return [ 'plan_id' => $resolved['plan_id'], 'billing' => $billing ];
    }

    /**
     * Map a Stripe price id to a local plan. Shared by the subscription-object
     * resolver (live current price) and the scheduled-change detector (the
     * price queued on a subscription schedule's upcoming phase).
     *
     * @return array{plan_id:int,plan_name:string,billing:string} billing is
     *         'monthly'|'yearly' when the price matches a stored price id,
     *         '' when the row was found only by the OR fallback.
     */
    private function resolve_plan_from_price_id( string $price_id ): array {
        $price_id = sanitize_text_field( $price_id );
        if ( $price_id === '' ) {
            return [ 'plan_id' => 0, 'plan_name' => '', 'billing' => '' ];
        }

        global $wpdb;
        $ptable = Database::plans_table();
        $row    = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, name, stripe_monthly_price_id, stripe_yearly_price_id
                 FROM {$ptable}
                 WHERE stripe_monthly_price_id = %s OR stripe_yearly_price_id = %s
                 LIMIT 1",
                $price_id,
                $price_id
            ),
            ARRAY_A
        );

        if ( ! $row ) {
            return [ 'plan_id' => 0, 'plan_name' => '', 'billing' => '' ];
        }

        if ( (string) $row['stripe_yearly_price_id'] === $price_id ) {
            $billing = 'yearly';
        } elseif ( (string) $row['stripe_monthly_price_id'] === $price_id ) {
            $billing = 'monthly';
        } else {
            $billing = '';
        }

        return [ 'plan_id' => (int) $row['id'], 'plan_name' => (string) $row['name'], 'billing' => $billing ];
    }

    /**
     * Read the locally-mirrored "pending change" — a future plan switch Stripe
     * has scheduled for period end (typically a paid→paid downgrade made in the
     * Billing Portal, which Stripe queues rather than applying immediately).
     *
     * Returns [] when nothing is scheduled. Resolves through the workspace
     * owner so team members see the workspace's pending change.
     *
     * @return array{plan_id:int,plan_name:string,billing:string,effective:int}|array{}
     */
    public function get_pending_change( int $user_id ): array {
        $owner_id = $this->get_workspace_owner_id( $user_id );
        $raw      = get_user_meta( $owner_id, self::PENDING_CHANGE_META, true );
        if ( ! is_array( $raw ) || (int) ( $raw['plan_id'] ?? 0 ) <= 0 ) {
            return [];
        }

        // Once the effective date is comfortably past, the switch should already
        // have been applied by the webhook; don't keep advertising it.
        $effective = (int) ( $raw['effective'] ?? 0 );
        if ( $effective > 0 && $effective < ( time() - DAY_IN_SECONDS ) ) {
            return [];
        }

        return [
            'plan_id'   => (int) $raw['plan_id'],
            'plan_name' => (string) ( $raw['plan_name'] ?? '' ),
            'billing'   => (string) ( $raw['billing'] ?? 'monthly' ),
            'effective' => $effective,
        ];
    }

    private function clear_pending_change( int $user_id ): void {
        if ( $user_id > 0 ) {
            delete_user_meta( $user_id, self::PENDING_CHANGE_META );
        }
    }

    /**
     * Mirror any Stripe-scheduled future plan change onto the user as a
     * "pending change" marker, so the account page and pricing page can show
     * "your plan switches to X on <date>" — visibility WordPress otherwise
     * lacks, because the live subscription price doesn't change until the
     * schedule fires at period end.
     *
     * Reads the subscription's attached schedule straight from Stripe and
     * resolves the upcoming phase's price to a local plan. Clears the marker
     * whenever there is no active schedule, the queued plan can't be mapped, or
     * the queued plan equals the one already active.
     *
     * @param array $sub Live Stripe subscription object.
     */
    public function sync_pending_change_from_stripe( int $user_id, array $sub ): void {
        if ( $user_id <= 0 ) {
            return;
        }

        $schedule_id = '';
        if ( isset( $sub['schedule'] ) && $sub['schedule'] !== null ) {
            $schedule_id = is_array( $sub['schedule'] )
                ? sanitize_text_field( (string) ( $sub['schedule']['id'] ?? '' ) )
                : sanitize_text_field( (string) $sub['schedule'] );
        }
        if ( $schedule_id === '' ) {
            $this->clear_pending_change( $user_id );
            return;
        }

        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_secret_key'] ?? '' ) );
        if ( $secret === '' ) {
            return;
        }

        $response = wp_remote_get(
            self::STRIPE_API_BASE . '/subscription_schedules/' . rawurlencode( $schedule_id ),
            [
                'timeout' => 20,
                'headers' => [
                    'Authorization'  => 'Bearer ' . $secret,
                    'Stripe-Version' => '2023-10-16',
                ],
            ]
        );
        if ( is_wp_error( $response ) ) {
            $this->log_membership_action( 'stripe_schedule_request_failed', [
                'user_id'     => (string) $user_id,
                'schedule_id' => $schedule_id,
                'message'     => $response->get_error_message(),
            ] );
            return;
        }

        $code  = (int) wp_remote_retrieve_response_code( $response );
        $sched = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 || ! is_array( $sched ) ) {
            return;
        }

        // Only a live schedule represents a queued change; a released/completed
        // /canceled one has already taken effect or been undone.
        $sched_status = sanitize_key( (string) ( $sched['status'] ?? '' ) );
        if ( ! in_array( $sched_status, [ 'active', 'not_started' ], true ) ) {
            $this->clear_pending_change( $user_id );
            return;
        }

        // The upcoming phase is the earliest one that starts in the future.
        $phases   = isset( $sched['phases'] ) && is_array( $sched['phases'] ) ? $sched['phases'] : [];
        $now      = time();
        $upcoming = null;
        $best     = PHP_INT_MAX;
        foreach ( $phases as $phase ) {
            $start = isset( $phase['start_date'] ) ? (int) $phase['start_date'] : 0;
            if ( $start > $now && $start < $best ) {
                $best     = $start;
                $upcoming = $phase;
            }
        }
        if ( ! is_array( $upcoming ) ) {
            $this->clear_pending_change( $user_id );
            return;
        }

        $price_id = '';
        if ( isset( $upcoming['items'][0]['price'] ) ) {
            $p        = $upcoming['items'][0]['price'];
            $price_id = is_array( $p ) ? sanitize_text_field( (string) ( $p['id'] ?? '' ) ) : sanitize_text_field( (string) $p );
        }

        $resolved = $this->resolve_plan_from_price_id( $price_id );
        $plan_id  = (int) $resolved['plan_id'];
        if ( $plan_id <= 0 ) {
            // Scheduled price isn't mapped to any plan — we can't name it, so
            // don't show a misleading marker.
            $this->clear_pending_change( $user_id );
            return;
        }

        $billing = $resolved['billing'] !== '' ? $resolved['billing'] : 'monthly';

        // Already on the queued plan + cycle? Nothing pending to advertise.
        $current = $this->get_user_membership( $user_id );
        if ( $current
            && (int) $current['plan_id'] === $plan_id
            && sanitize_key( (string) ( $current['billing_cycle'] ?? '' ) ) === $billing ) {
            $this->clear_pending_change( $user_id );
            return;
        }

        update_user_meta( $user_id, self::PENDING_CHANGE_META, [
            'plan_id'   => $plan_id,
            'plan_name' => (string) $resolved['plan_name'],
            'billing'   => $billing,
            'effective' => $best !== PHP_INT_MAX ? $best : (int) ( $sub['current_period_end'] ?? 0 ),
        ] );
        $this->log_membership_action( 'stripe_pending_change_synced', [
            'user_id'   => (string) $user_id,
            'plan_id'   => (string) $plan_id,
            'billing'   => $billing,
            'effective' => (string) ( $best !== PHP_INT_MAX ? $best : 0 ),
        ] );
    }

    /**
     * Synchronise a member's local plan with their LIVE Stripe subscription.
     *
     * This is the Billing-Portal counterpart to the Checkout success-return
     * confirmation (awg_aig_mem_confirm_return). When an existing paying member
     * switches plans in the Stripe Billing Portal, Stripe swaps the price on the
     * SAME subscription and fires customer.subscription.updated. That webhook is
     * the primary sync path — but, unlike Checkout, the portal return carries no
     * session id, so there was previously NO synchronous fallback. If the
     * webhook is delayed, mis-configured, or simply can't reach the site, the
     * 2nd/3rd upgrade is charged on Stripe yet never reflected in WordPress.
     *
     * This reads the current subscription straight from the Stripe API (an
     * outbound call, so it works regardless of webhook delivery), resolves the
     * plan from the live price exactly as the webhook does, and applies it via
     * set_user_plan() — which no-ops when already in sync, so it is safe to run
     * alongside a working webhook.
     *
     * @return bool True when a subscription was found and a sync was applied.
     */
    public function sync_plan_from_stripe_subscription( int $user_id ): bool {
        if ( $user_id <= 0 ) {
            return false;
        }

        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_secret_key'] ?? '' ) );
        if ( $secret === '' ) {
            return false;
        }

        // The active membership still points at the same subscription after a
        // portal price-swap (Stripe mutates the existing sub, it does not
        // create a new one), so the stored id is the right thing to re-read.
        $mem             = $this->get_latest_membership( $user_id );
        $subscription_id = $mem ? sanitize_text_field( (string) ( $mem['stripe_subscription_id'] ?? '' ) ) : '';
        $customer_id     = $mem ? sanitize_text_field( (string) ( $mem['stripe_customer_id'] ?? '' ) ) : '';
        if ( $subscription_id === '' ) {
            return false;
        }

        $response = wp_remote_get(
            self::STRIPE_API_BASE . '/subscriptions/' . rawurlencode( $subscription_id ),
            [
                'timeout' => 20,
                'headers' => [
                    'Authorization'  => 'Bearer ' . $secret,
                    'Stripe-Version' => '2023-10-16',
                ],
            ]
        );
        if ( is_wp_error( $response ) ) {
            $this->log_membership_action( 'stripe_portal_resync_request_failed', [
                'user_id'         => (string) $user_id,
                'subscription_id' => $subscription_id,
                'message'         => $response->get_error_message(),
            ] );
            return false;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $sub  = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 || ! is_array( $sub ) ) {
            $this->log_membership_action( 'stripe_portal_resync_failed', [
                'user_id'         => (string) $user_id,
                'subscription_id' => $subscription_id,
                'http_code'       => (string) $code,
            ] );
            return false;
        }

        // Only re-sync plans for subscriptions Stripe is actively billing. A
        // cancelled/incomplete subscription is the cancel path's job, not this.
        $status = sanitize_key( (string) ( $sub['status'] ?? '' ) );
        if ( ! in_array( $status, [ 'active', 'trialing', 'past_due' ], true ) ) {
            return false;
        }

        // Mirror any Stripe-scheduled future plan change (e.g. a downgrade the
        // portal queued for period end) so the account page can surface it.
        // Runs regardless of whether the *current* price resolves below.
        $this->sync_pending_change_from_stripe( $user_id, $sub );

        $resolved = $this->resolve_plan_from_subscription_object( $sub );
        $plan_id  = (int) $resolved['plan_id'];
        $billing  = $resolved['billing'] !== '' ? $resolved['billing'] : 'monthly';
        if ( $plan_id <= 0 ) {
            // The live price isn't mapped to any plan's stripe_monthly_price_id
            // / stripe_yearly_price_id. This is the OTHER common reason a portal
            // switch doesn't reflect locally: the price the portal offered was
            // never saved on a plan. Surface it loudly rather than silently
            // inheriting the old plan.
            $price_id = isset( $sub['items']['data'][0]['price']['id'] )
                ? sanitize_text_field( (string) $sub['items']['data'][0]['price']['id'] )
                : '';
            $this->log_membership_action( 'stripe_portal_resync_unmapped_price', [
                'user_id'         => (string) $user_id,
                'subscription_id' => $subscription_id,
                'price_id'        => $price_id,
            ] );
            return false;
        }

        $cust_id = $customer_id !== '' ? $customer_id : sanitize_text_field( (string) ( $sub['customer'] ?? '' ) );
        $this->set_user_plan( $user_id, $plan_id, $billing, $subscription_id, $cust_id );
        $this->log_membership_action( 'stripe_portal_resync_synced', [
            'user_id'         => (string) $user_id,
            'subscription_id' => $subscription_id,
            'plan_id'         => (string) $plan_id,
            'billing'         => $billing,
        ] );
        return true;
    }

    private function handle_stripe_subscription_event( array $object, string $event_type ): void {
        $metadata        = isset( $object['metadata'] ) && is_array( $object['metadata'] ) ? $object['metadata'] : [];
        $user_id         = isset( $metadata['user_id'] ) ? (int) $metadata['user_id'] : 0;
        $plan_id         = isset( $metadata['plan_id'] ) ? (int) $metadata['plan_id'] : 0;
        $billing         = isset( $metadata['billing'] ) && in_array( $metadata['billing'], [ 'monthly', 'yearly', 'free' ], true ) ? (string) $metadata['billing'] : 'monthly';
        $customer_id     = sanitize_text_field( (string) ( $object['customer'] ?? '' ) );
        $subscription_id = sanitize_text_field( (string) ( $object['id'] ?? $object['subscription'] ?? '' ) );

        if ( $user_id <= 0 && $customer_id !== '' ) {
            $user_id = $this->find_user_id_by_customer( $customer_id );
        }

        if ( $user_id <= 0 && $subscription_id !== '' ) {
            $user_id = $this->find_user_id_by_subscription( $subscription_id );
        }

        // Authoritative: resolve plan + billing from the live price on the
        // subscription. This wins over metadata so a Billing-Portal plan switch
        // (which leaves metadata pointing at the old plan) is reflected
        // correctly. Falls through to metadata / latest-membership below only
        // when the price isn't recognised (e.g. an unmapped price id).
        $by_price = $this->resolve_plan_from_subscription_object( $object );
        if ( $by_price['plan_id'] > 0 ) {
            $plan_id = $by_price['plan_id'];
            if ( $by_price['billing'] !== '' ) {
                $billing = $by_price['billing'];
            }
        }

        if ( $plan_id <= 0 && $user_id > 0 ) {
            $mem     = $this->get_latest_membership( $user_id );
            $plan_id = (int) ( $mem['plan_id'] ?? 0 );
            // Only inherit prior billing_cycle if it's a paid cycle. A Stripe
            // subscription event by definition cannot represent the 'free'
            // billing path — preserving 'free' here would write a row with a
            // null end_date even though the user is being charged.
            if ( $billing === 'monthly' && ! empty( $mem['billing_cycle'] ) && in_array( $mem['billing_cycle'], [ 'monthly', 'yearly' ], true ) ) {
                $billing = (string) $mem['billing_cycle'];
            }
        }

        $log_context = [
            'event_type'       => $event_type,
            'resolved_user_id' => (string) $user_id,
            'customer_id'      => $customer_id,
            'subscription_id'  => $subscription_id,
            'plan_id'          => (string) $plan_id,
            'billing'          => $billing,
        ];

        if ( $user_id <= 0 ) {
            $this->log_membership_action( 'stripe_webhook_unresolved_user', $log_context );
            return;
        }

        if ( $event_type === 'customer.subscription.deleted' ) {
            $this->cancel_user_membership( $user_id, 'cancelled' );
            $this->log_membership_action( 'stripe_webhook_membership_cancelled', $log_context + [ 'action' => 'cancel' ] );
            return;
        }

        if ( $event_type === 'invoice.payment_failed' ) {
            // Do NOT revoke access here. Stripe retries the charge over the
            // next few days (its built-in dunning) and only fires
            // customer.subscription.deleted once retries are exhausted — that
            // event is what triggers the real downgrade below. Until then the
            // member keeps their paid access; we just send a dunning email so
            // they can update their card.
            do_action( 'awg_mem_payment_failed', $user_id );
            $this->log_membership_action( 'stripe_webhook_membership_payment_failed', $log_context + [ 'action' => 'dunning_email' ] );
            return;
        }

        // Status guard: customer.subscription.created/updated fire for many states
        // (incomplete, past_due, unpaid, canceled, incomplete_expired), not just
        // active/trialing. Only (re)grant the plan when Stripe says the subscription
        // is actually live — otherwise a status-only update could resurrect a
        // cancelled or never-paid subscription as an active membership.
        $sub_status = isset( $object['status'] ) ? sanitize_key( (string) $object['status'] ) : '';
        if ( $sub_status !== '' ) {
            if ( in_array( $sub_status, [ 'canceled', 'incomplete_expired' ], true ) ) {
                $this->cancel_user_membership( $user_id, 'cancelled' );
                $this->log_membership_action( 'stripe_webhook_membership_cancelled', $log_context + [ 'action' => 'cancel', 'sub_status' => $sub_status ] );
                return;
            }
            if ( ! in_array( $sub_status, [ 'active', 'trialing' ], true ) ) {
                // past_due / unpaid / incomplete — leave existing access untouched and
                // wait for Stripe to resolve (renewal succeeds, or it fires
                // customer.subscription.deleted after dunning is exhausted).
                $this->log_membership_action( 'stripe_webhook_status_pending', $log_context + [ 'sub_status' => $sub_status ] );
                return;
            }
        }

        if ( $plan_id <= 0 ) {
            $this->log_membership_action( 'stripe_webhook_missing_plan', $log_context );
            return;
        }

        // Carry Stripe's real period end through so the local end_date matches the
        // actual renewal date instead of a PHP-estimated "+1 month/year".
        $period_end = isset( $object['current_period_end'] ) ? (int) $object['current_period_end'] : 0;
        $this->set_user_plan( $user_id, $plan_id, $billing, $subscription_id, $customer_id, $period_end );
        $this->log_membership_action( 'stripe_webhook_membership_synced', $log_context + [ 'action' => 'sync' ] );

        // Keep the "pending change" marker in step: a subscription.updated that
        // attaches a schedule (downgrade queued) stores it; the later update
        // that applies the swap (schedule released) clears it.
        $this->sync_pending_change_from_stripe( $user_id, $object );
    }

    /**
     * Handle Stripe invoice.payment_succeeded — fired both on initial
     * subscription payment AND on each recurring renewal. We only want to
     * notify the user on RENEWAL, not on the initial payment (which is
     * already covered by the checkout.session.completed welcome flow).
     *
     * Stripe gives us `billing_reason` on the invoice object — values include:
     *   - subscription_create   (initial payment, skip — covered elsewhere)
     *   - subscription_cycle    (recurring renewal — this is what we want)
     *   - subscription_update   (mid-cycle change with proration — skip)
     *   - manual                (one-off, skip)
     */
    private function handle_stripe_invoice_paid( array $object ): void {
        $billing_reason = isset( $object['billing_reason'] ) ? sanitize_key( (string) $object['billing_reason'] ) : '';
        if ( $billing_reason !== 'subscription_cycle' ) {
            return;
        }

        $subscription_id = sanitize_text_field( (string) ( $object['subscription'] ?? '' ) );
        $customer_id     = sanitize_text_field( (string) ( $object['customer'] ?? '' ) );

        $user_id = 0;
        if ( $subscription_id !== '' ) {
            $user_id = $this->find_user_id_by_subscription( $subscription_id );
        }
        if ( $user_id <= 0 && $customer_id !== '' ) {
            $user_id = $this->find_user_id_by_customer( $customer_id );
        }
        if ( $user_id <= 0 ) {
            $this->log_membership_action( 'stripe_webhook_renewal_unresolved_user', [
                'subscription_id' => $subscription_id,
                'customer_id'     => $customer_id,
            ] );
            return;
        }

        $amount_paid = isset( $object['amount_paid'] ) ? (int) $object['amount_paid'] : 0;
        $currency    = sanitize_text_field( (string) ( $object['currency'] ?? '' ) );

        $this->log_membership_action( 'stripe_webhook_renewal_paid', [
            'user_id'         => (string) $user_id,
            'subscription_id' => $subscription_id,
            'amount_paid'     => (string) $amount_paid,
            'currency'        => $currency,
        ] );

        // Extend end_date based on current billing cycle. Stripe is the source
        // of truth for the actual next-billing date, but the membership row
        // mirrors it for the dashboard's renewal-date display.
        $mem = $this->get_latest_membership( $user_id );
        if ( $mem && in_array( $mem['billing_cycle'] ?? '', [ 'monthly', 'yearly' ], true ) ) {
            global $wpdb;
            $table = Database::mems_table();
            $cycle = $mem['billing_cycle'];
            $base  = ! empty( $mem['end_date'] ) ? strtotime( (string) $mem['end_date'] ) : time();
            // If the prior end_date is in the past (renewal cycle ran late),
            // extend from now, not from the stale date — otherwise we'd write
            // an end_date that's already expired.
            if ( $base < time() ) {
                $base = time();
            }
            $new_end = gmdate( 'Y-m-d H:i:s', strtotime( $cycle === 'yearly' ? '+1 year' : '+1 month', $base ) );
            $wpdb->update(
                $table,
                [ 'end_date' => $new_end, 'updated_at' => current_time( 'mysql' ) ],
                [ 'id' => (int) $mem['id'] ],
                [ '%s', '%s' ],
                [ '%d' ]
            );
        }

        do_action( 'awg_mem_renewed', $user_id, [
            'amount_paid' => $amount_paid,
            'currency'    => strtoupper( $currency ),
        ] );
    }

    public function rest_webhook( \WP_REST_Request $request ): \WP_REST_Response {
        $payload  = $request->get_body();
        $settings = $this->get_settings();
        $secret   = trim( (string) ( $settings['stripe_webhook_secret'] ?? '' ) );
        $sig      = (string) $request->get_header( 'stripe-signature' );

        if ( ! $this->verify_stripe_signature( $payload, $sig, $secret ) ) {
            return new \WP_REST_Response( [ 'received' => false, 'message' => 'Invalid signature.' ], 400 );
        }

        $event = json_decode( $payload, true );
        if ( ! is_array( $event ) || empty( $event['type'] ) || empty( $event['data']['object'] ) || ! is_array( $event['data']['object'] ) ) {
            return new \WP_REST_Response( [ 'received' => false, 'message' => 'Invalid payload.' ], 400 );
        }

        $type   = sanitize_text_field( (string) $event['type'] );
        $object = $event['data']['object'];

        // Idempotency: Stripe retries delivery on any non-2xx response and may
        // re-send events even on 2xx if the network ack is lost.
        //
        // The previous (single-phase) implementation marked an event as "seen"
        // BEFORE processing. If the handler crashed (DB blip, hook fatal), the
        // dedupe key would stay set for 24h and every Stripe retry would be
        // short-circuited as a duplicate — the event was permanently lost.
        //
        // Two-phase approach below:
        //   1. Reserve a short-TTL "processing" marker before handling. Two
        //      concurrent retries arriving in parallel race here; only one wins.
        //   2. After successful handling, upgrade to a 24h "done" marker.
        //   3. If the handler throws, the short marker expires in ~2 minutes
        //      and Stripe's retry succeeds.
        $event_id   = isset( $event['id'] ) ? sanitize_text_field( (string) $event['id'] ) : '';
        $dedupe_key = $event_id !== '' ? 'awg_mem_stripe_evt_' . md5( $event_id ) : '';

        if ( $dedupe_key !== '' ) {
            $marker = get_transient( $dedupe_key );
            if ( $marker === 'done' ) {
                $this->log_membership_action( 'stripe_webhook_duplicate_skipped', [
                    'event_id'   => $event_id,
                    'event_type' => $type,
                ] );
                return new \WP_REST_Response( [ 'received' => true, 'duplicate' => true ], 200 );
            }
            if ( $marker === 'processing' ) {
                // A concurrent retry is mid-flight. Tell Stripe to back off
                // briefly without committing us to "done" — the in-flight call
                // will finish or fail and the next retry will resolve cleanly.
                $this->log_membership_action( 'stripe_webhook_concurrent_processing', [
                    'event_id'   => $event_id,
                    'event_type' => $type,
                ] );
                return new \WP_REST_Response( [ 'received' => false, 'message' => 'Processing.' ], 409 );
            }
            // Reserve. 2 minutes is long enough for a normal handler to finish
            // and short enough that a true crash doesn't poison long-term.
            set_transient( $dedupe_key, 'processing', 2 * MINUTE_IN_SECONDS );
        }

        $this->log_membership_action( 'stripe_webhook_received', [
            'event_type' => $type,
            'event_id'   => $event_id,
            'object_id'  => sanitize_text_field( (string) ( $object['id'] ?? '' ) ),
        ] );

        switch ( $type ) {
            case 'checkout.session.completed':
                $metadata = isset( $object['metadata'] ) && is_array( $object['metadata'] ) ? $object['metadata'] : [];
                $user_id  = isset( $metadata['user_id'] ) ? (int) $metadata['user_id'] : (int) ( $object['client_reference_id'] ?? 0 );
                $plan_id  = isset( $metadata['plan_id'] ) ? (int) $metadata['plan_id'] : 0;
                $billing  = isset( $metadata['billing'] ) && in_array( $metadata['billing'], [ 'monthly', 'yearly', 'free' ], true ) ? (string) $metadata['billing'] : 'monthly';
                $sub_id   = sanitize_text_field( (string) ( $object['subscription'] ?? '' ) );
                $cust_id  = sanitize_text_field( (string) ( $object['customer'] ?? '' ) );
                if ( $user_id > 0 && $plan_id > 0 ) {
                    $this->set_user_plan( $user_id, $plan_id, $billing, $sub_id, $cust_id );
                    $this->log_membership_action( 'stripe_webhook_checkout_completed', [
                        'event_type'       => $type,
                        'resolved_user_id' => (string) $user_id,
                        'customer_id'      => $cust_id,
                        'subscription_id'  => $sub_id,
                        'plan_id'          => (string) $plan_id,
                        'billing'          => $billing,
                        'action'           => 'activate',
                    ] );
                } else {
                    $this->log_membership_action( 'stripe_webhook_checkout_missing_metadata', [
                        'event_type'       => $type,
                        'resolved_user_id' => (string) $user_id,
                        'customer_id'      => $cust_id,
                        'subscription_id'  => $sub_id,
                        'plan_id'          => (string) $plan_id,
                    ] );
                }
                break;

            case 'customer.subscription.created':
            case 'customer.subscription.updated':
            case 'customer.subscription.deleted':
            case 'invoice.payment_failed':
                $this->handle_stripe_subscription_event( $object, $type );
                break;

            case 'invoice.payment_succeeded':
                $this->handle_stripe_invoice_paid( $object );
                break;
        }

        // Phase 2 of dedupe: handling completed (we only reach here if no
        // exception bubbled up). Upgrade the short "processing" marker to a
        // 24h "done" marker so future retries of the same event_id are
        // recognised and short-circuited.
        if ( $dedupe_key !== '' ) {
            set_transient( $dedupe_key, 'done', DAY_IN_SECONDS );
        }

        return new \WP_REST_Response( [ 'received' => true ], 200 );
    }

    public function ajax_upgrade(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-ai-tools' ) ], 401 );
        }
        $user_id = get_current_user_id();
        if ( $this->is_team_member( $user_id ) ) {
            wp_send_json_error( [ 'message' => __( 'Team members cannot change workspace billing. Please contact the workspace owner.', 'authorwings-ai-tools' ) ], 403 );
        }

        $plan_slug = isset( $_POST['plan'] ) ? sanitize_key( wp_unslash( (string) $_POST['plan'] ) ) : '';
        $billing_raw = isset( $_POST['billing'] ) ? wp_unslash( (string) $_POST['billing'] ) : '';
        $billing   = in_array( $billing_raw, [ 'monthly', 'yearly' ], true )
            ? sanitize_key( $billing_raw )
            : 'monthly';

        global $wpdb;
        $ptable = Database::plans_table();
        $plan   = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$ptable} WHERE slug = %s AND is_active = 1 LIMIT 1", $plan_slug ),
            ARRAY_A
        );

        if ( ! $plan ) {
            wp_send_json_error( [ 'message' => __( 'Plan not found.', 'authorwings-ai-tools' ) ] );
        }

        // Current subscription state. A member with a live Stripe subscription
        // is on a *paid* plan that Stripe is actively billing.
        $current             = $this->get_user_membership( $user_id );
        $current_sub_id      = $current ? sanitize_text_field( (string) ( $current['stripe_subscription_id'] ?? '' ) ) : '';
        $current_is_free     = $current ? ! empty( $current['is_free'] ) : true;
        $current_status      = $current ? sanitize_key( (string) ( $current['status'] ?? '' ) ) : '';
        $has_active_paid_sub = ( $current_sub_id !== '' && ! $current_is_free && in_array( $current_status, [ 'active', 'trialing' ], true ) );

        // --- Replacing an already-scheduled change needs confirmation -------
        // If the member already has a future plan change queued on Stripe (a
        // schedule the Billing Portal created for a paid→paid downgrade) and is
        // now choosing a DIFFERENT plan, proceeding will discard that queued
        // change. Ask first instead of silently stacking conflicting schedules —
        // the exact "mixed signals" the pricing page otherwise shows. Skipped
        // when re-selecting the current plan (handled as a no-op below) and once
        // the member has confirmed via confirm_replace.
        if ( $has_active_paid_sub ) {
            $confirm_replace = isset( $_POST['confirm_replace'] )
                && (string) wp_unslash( $_POST['confirm_replace'] ) === '1';
            $pending = $this->get_pending_change( $user_id );
            if ( ! $confirm_replace
                && ! empty( $pending )
                && (int) ( $pending['plan_id'] ?? 0 ) > 0
                && (int) $pending['plan_id'] !== (int) $plan['id']
                && (int) ( $current['plan_id'] ?? 0 ) !== (int) $plan['id'] ) {
                $pending_name = (string) ( $pending['plan_name'] ?? '' );
                $when         = ! empty( $pending['effective'] )
                    ? date_i18n( get_option( 'date_format' ), (int) $pending['effective'] )
                    : '';
                $message = $when !== ''
                    ? sprintf(
                        /* translators: 1: currently-scheduled plan name, 2: date it takes effect, 3: newly-chosen plan name */
                        __( 'You already have a switch to %1$s scheduled for %2$s. Continuing will replace it with %3$s. Proceed?', 'authorwings-ai-tools' ),
                        $pending_name,
                        $when,
                        (string) $plan['name']
                    )
                    : sprintf(
                        /* translators: 1: currently-scheduled plan name, 2: newly-chosen plan name */
                        __( 'You already have a switch to %1$s scheduled. Continuing will replace it with %2$s. Proceed?', 'authorwings-ai-tools' ),
                        $pending_name,
                        (string) $plan['name']
                    );
                wp_send_json_error( [
                    'message'            => $message,
                    'needs_confirmation' => true,
                ], 409 );
            }
        }

        // --- Target is the FREE plan ---------------------------------------
        if ( (bool) $plan['is_free'] ) {
            // A paying member choosing Free is a downgrade: schedule the Stripe
            // subscription to cancel at period end (which stops future charges —
            // a bare set_user_plan('free') would NOT) and KEEP the paid access
            // until then. Stripe emits customer.subscription.deleted at period end,
            // which the webhook turns into the free membership.
            if ( $has_active_paid_sub ) {
                if ( ! $this->cancel_stripe_subscription( $current_sub_id ) ) {
                    wp_send_json_error( [ 'message' => __( 'We could not change your plan on Stripe right now. Please try again, or use Manage billing.', 'authorwings-ai-tools' ) ], 502 );
                }
                $end_date = (string) ( $current['end_date'] ?? '' );
                $when     = $end_date !== '' ? date_i18n( get_option( 'date_format' ), strtotime( $end_date ) ) : '';
                $message  = $when !== ''
                    ? sprintf(
                        /* translators: %s: date the paid access ends */
                        __( 'Your plan will switch to Free on %s. You keep your current plan until then.', 'authorwings-ai-tools' ),
                        $when
                    )
                    : __( 'Your plan will switch to Free at the end of your current billing period. You keep your current plan until then.', 'authorwings-ai-tools' );
                wp_send_json_success( [
                    'message'  => $message,
                    'redirect' => add_query_arg( [ 'tab' => 'account', 'awg_notice' => 'cancel_scheduled' ], $this->get_account_url() ),
                ] );
                return;
            }

            // Not currently paying: just assign Free locally.
            $this->set_user_plan( $user_id, (int) $plan['id'], 'free' );
            wp_send_json_success( [ 'message' => __( 'Plan updated.', 'authorwings-ai-tools' ), 'redirect' => add_query_arg( [ 'tab' => 'account', 'awg_notice' => 'plan-updated' ], $this->get_account_url() ) ] );
            return;
        }

        // --- Target is a PAID plan -----------------------------------------
        // Existing paying subscriber => this is a plan SWITCH, not a new
        // purchase. Route them to the Stripe Billing Portal's subscription-
        // update flow so Stripe swaps the price on the EXISTING subscription
        // with proration. Starting a fresh Checkout here would create a SECOND
        // subscription and bill the member twice.
        if ( $has_active_paid_sub ) {
            // Already on this exact plan + billing cycle — nothing to switch.
            if ( (int) $current['plan_id'] === (int) $plan['id']
                && sanitize_key( (string) ( $current['billing_cycle'] ?? '' ) ) === $billing ) {
                wp_send_json_success( [
                    'message'  => __( 'You are already on this plan.', 'authorwings-ai-tools' ),
                    'redirect' => add_query_arg( [ 'tab' => 'account' ], $this->get_account_url() ),
                ] );
                return;
            }

            $portal_url = $this->create_billing_portal_session( $user_id, $current_sub_id );
            if ( is_wp_error( $portal_url ) ) {
                wp_send_json_error( [ 'message' => $portal_url->get_error_message() ], 400 );
            }
            wp_send_json_success( [ 'redirect' => $portal_url ] );
            return;
        }

        // New, free, or lapsed member => first paid subscription via Checkout.
        $checkout_url = $this->create_stripe_checkout_session( $plan, $billing, $user_id );
        if ( is_wp_error( $checkout_url ) ) {
            wp_send_json_error( [ 'message' => $checkout_url->get_error_message() ], 400 );
        }

        wp_send_json_success( [ 'redirect' => $checkout_url ] );
    }

    public function ajax_cancel(): void {
        check_ajax_referer( 'awg_mem_nonce', 'nonce' );
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Please log in.', 'authorwings-ai-tools' ) ], 401 );
        }
        if ( $this->is_team_member( get_current_user_id() ) ) {
            wp_send_json_error( [ 'message' => __( 'Team members cannot cancel workspace billing. Please contact the workspace owner.', 'authorwings-ai-tools' ) ], 403 );
        }

        $latest = $this->get_latest_membership( get_current_user_id() );
        $subscription_id = sanitize_text_field( (string) ( $latest['stripe_subscription_id'] ?? '' ) );
        $status          = sanitize_key( (string) ( $latest['status'] ?? '' ) );

        if ( $subscription_id !== '' && in_array( $status, [ 'active', 'trialing', 'payment_failed', 'past_due', 'unpaid' ], true ) ) {
            // Paid subscription: schedule cancellation at period end and KEEP access
            // until then. The downgrade happens later via customer.subscription.deleted
            // (with check_expiries as the fallback), not immediately, so the member
            // isn't stripped of time they already paid for.
            if ( ! $this->cancel_stripe_subscription( $subscription_id ) ) {
                wp_send_json_error( [ 'message' => __( 'We could not schedule your cancellation right now. Please try again or contact support before retrying.', 'authorwings-ai-tools' ) ], 502 );
            }

            $end_date = (string) ( $latest['end_date'] ?? '' );
            $when     = $end_date !== '' ? date_i18n( get_option( 'date_format' ), strtotime( $end_date ) ) : '';
            $message  = $when !== ''
                ? sprintf(
                    /* translators: %s: date the access ends */
                    __( 'Your membership is set to cancel. You keep full access until %s, then move to the free plan.', 'authorwings-ai-tools' ),
                    $when
                )
                : __( 'Your membership is set to cancel at the end of your current billing period. You keep access until then.', 'authorwings-ai-tools' );

            wp_send_json_success( [
                'message'  => $message,
                'redirect' => add_query_arg( [ 'tab' => 'account', 'awg_notice' => 'cancel_scheduled' ], $this->get_account_url() ),
            ] );
            return;
        }

        // No live Stripe subscription (free or manually-assigned): downgrade now.
        $this->cancel_user_membership( get_current_user_id(), 'cancelled' );
        wp_send_json_success( [
            'message'  => __( 'Membership cancelled.', 'authorwings-ai-tools' ),
            'redirect' => add_query_arg( [ 'tab' => 'account', 'awg_notice' => 'cancelled' ], $this->get_account_url() ),
        ] );
    }

}
