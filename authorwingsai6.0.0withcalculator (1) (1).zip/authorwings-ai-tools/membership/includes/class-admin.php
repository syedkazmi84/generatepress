<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Admin {

    /** @var Memberships */
    private $memberships;

    /** @var Plans */
    private $plans;

    /** @var Usage */
    private $usage;

    /** @var Tickets|null */
    private $tickets;

    public function __construct( Memberships $memberships, Plans $plans, Usage $usage, ?Tickets $tickets = null ) {
        $this->memberships = $memberships;
        $this->plans       = $plans;
        $this->usage       = $usage;
        $this->tickets     = $tickets;
    }

    public function menu(): void {
        add_menu_page(
            __( 'AuthorWings Members', 'authorwings-ai-tools' ),
            __( 'AW Members', 'authorwings-ai-tools' ),
            'manage_awg_membership',
            'awg-membership',
            [ $this, 'page_members' ],
            'dashicons-groups',
            57
        );

        add_submenu_page(
            'awg-membership',
            __( 'Members', 'authorwings-ai-tools' ),
            __( 'Members', 'authorwings-ai-tools' ),
            'manage_awg_membership',
            'awg-membership',
            [ $this, 'page_members' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Plans', 'authorwings-ai-tools' ),
            __( 'Plans', 'authorwings-ai-tools' ),
            'manage_awg_membership',
            'awg-membership-plans',
            [ $this, 'page_plans' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Quote Requests', 'authorwings-ai-tools' ),
            __( 'Quote Requests', 'authorwings-ai-tools' ),
            'manage_awg_membership',
            'awg-membership-orders',
            [ $this, 'page_orders' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Services', 'authorwings-ai-tools' ),
            __( 'Services', 'authorwings-ai-tools' ),
            'manage_awg_membership',
            'edit.php?post_type=awg_service'
        );

        add_submenu_page(
            'awg-membership',
            __( 'Dashboard Builder', 'authorwings-ai-tools' ),
            __( 'Dashboard Builder', 'authorwings-ai-tools' ),
            'manage_awg_membership',
            'awg-membership-dashboard-builder',
            [ $this, 'page_dashboard_builder' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Settings', 'authorwings-ai-tools' ),
            __( 'Settings', 'authorwings-ai-tools' ),
            'manage_awg_membership',
            'awg-membership-settings',
            [ $this, 'page_settings' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Release Tests', 'authorwings-ai-tools' ),
            __( 'Release Tests', 'authorwings-ai-tools' ),
            'manage_awg_membership',
            'awg-membership-release-tests',
            [ $this, 'page_release_tests' ]
        );

        add_submenu_page(
            'awg-membership',
            __( 'Demo Data', 'authorwings-ai-tools' ),
            __( 'Demo Data', 'authorwings-ai-tools' ),
            'manage_awg_membership',
            'awg-membership-demo-data',
            [ $this, 'page_demo_data' ]
        );

        // v2.8.0 — Support tickets admin page
        add_submenu_page(
            'awg-membership',
            __( 'Support', 'authorwings-ai-tools' ),
            __( 'Support', 'authorwings-ai-tools' ),
            'manage_awg_membership',
            'awg-membership-support',
            [ $this, 'page_support_tickets' ]
        );

        // Billing / membership error log viewer.
        add_submenu_page(
            'awg-membership',
            __( 'Logs', 'authorwings-ai-tools' ),
            __( 'Logs', 'authorwings-ai-tools' ),
            'manage_awg_membership',
            'awg-membership-logs',
            [ $this, 'page_logs' ]
        );
    }

    /**
     * Read-only viewer for the redacted billing/membership error log captured
     * by Logger. Surfaces the entries the plugin already stores so support can
     * diagnose Stripe/webhook issues without DB access.
     */
    public function page_logs(): void {
        if ( ! current_user_can( 'manage_awg_membership' ) ) {
            wp_die( esc_html__( 'You are not allowed to view this page.', 'authorwings-ai-tools' ), 403 );
        }

        if ( ! empty( $_POST['awg_mem_clear_logs'] ) && check_admin_referer( 'awg_mem_clear_logs' ) ) {
            Logger::clear();
            echo '<div class="notice notice-success"><p>' . esc_html__( 'Logs cleared.', 'authorwings-ai-tools' ) . '</p></div>';
        }

        $settings = get_option( Plugin::OPT, [] );
        $enabled  = ! empty( $settings['enable_error_logging'] );
        $logs     = Logger::get_logs();
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'Membership Logs', 'authorwings-ai-tools' ); ?></h1>
            <?php if ( ! $enabled ) : ?>
                <div class="notice notice-warning inline"><p>
                    <?php
                    printf(
                        /* translators: %s: link to settings */
                        esc_html__( 'Error logging is turned off. Enable it under %s to start capturing billing and membership errors.', 'authorwings-ai-tools' ),
                        '<a href="' . esc_url( admin_url( 'admin.php?page=awg-membership-settings' ) ) . '">' . esc_html__( 'Settings', 'authorwings-ai-tools' ) . '</a>'
                    );
                    ?>
                </p></div>
            <?php endif; ?>

            <?php if ( ! empty( $logs ) ) : ?>
                <form method="post" style="margin:12px 0;">
                    <?php wp_nonce_field( 'awg_mem_clear_logs' ); ?>
                    <button type="submit" name="awg_mem_clear_logs" value="1" class="button"
                        onclick="return confirm('<?php echo esc_js( __( 'Clear all stored logs?', 'authorwings-ai-tools' ) ); ?>');">
                        <?php esc_html_e( 'Clear logs', 'authorwings-ai-tools' ); ?>
                    </button>
                </form>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th style="width:160px;"><?php esc_html_e( 'Time', 'authorwings-ai-tools' ); ?></th>
                            <th style="width:220px;"><?php esc_html_e( 'Event', 'authorwings-ai-tools' ); ?></th>
                            <th><?php esc_html_e( 'Context', 'authorwings-ai-tools' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $logs as $log ) : ?>
                            <tr>
                                <td><?php echo esc_html( (string) ( $log['time'] ?? '' ) ); ?></td>
                                <td><code><?php echo esc_html( (string) ( $log['event'] ?? '' ) ); ?></code></td>
                                <td><?php
                                    $ctx = isset( $log['context'] ) && is_array( $log['context'] ) ? $log['context'] : [];
                                    echo $ctx ? '<code>' . esc_html( wp_json_encode( $ctx ) ) . '</code>' : '&mdash;';
                                ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p><?php esc_html_e( 'No log entries yet.', 'authorwings-ai-tools' ); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * v2.8.0 — Admin support tickets page. Lists tickets; admins can
     * click through to view a ticket and post a reply (which is emailed
     * back to the member and stored in admin_reply).
     */
    public function page_support_tickets(): void {
        if ( ! current_user_can( 'manage_awg_membership' ) ) {
            wp_die( esc_html__( 'You are not allowed to view this page.', 'authorwings-ai-tools' ) );
        }
        if ( ! $this->tickets ) {
            echo '<div class="wrap"><p>' . esc_html__( 'Ticket system not initialised.', 'authorwings-ai-tools' ) . '</p></div>';
            return;
        }

        // Handle status change form
        if ( ! empty( $_POST['awg_ticket_set_status'] ) && check_admin_referer( 'awg_mem_ticket_admin' ) ) {
            $ticket_id = (int) ( $_POST['ticket_id'] ?? 0 );
            $status    = sanitize_key( (string) ( $_POST['status'] ?? '' ) );
            $this->tickets->set_status( $ticket_id, $status );
            echo '<div class="notice notice-success"><p>' . esc_html__( 'Ticket status updated.', 'authorwings-ai-tools' ) . '</p></div>';
        }

        // v3.1.6 — Handle admin reply. Stores admin_reply, sets status to
        // "replied", and emails the member.
        if ( ! empty( $_POST['awg_ticket_reply'] ) && check_admin_referer( 'awg_mem_ticket_admin' ) ) {
            $ticket_id = (int) ( $_POST['ticket_id'] ?? 0 );
            $reply     = (string) ( $_POST['admin_reply'] ?? '' );
            $result    = $this->tickets->add_reply( $ticket_id, $reply );
            if ( is_wp_error( $result ) ) {
                echo '<div class="notice notice-error"><p>' . esc_html( $result->get_error_message() ) . '</p></div>';
            } else {
                echo '<div class="notice notice-success"><p>' . esc_html__( 'Reply sent to the member and saved.', 'authorwings-ai-tools' ) . '</p></div>';
            }
        }

        $filter = sanitize_key( (string) ( $_GET['status'] ?? '' ) );
        $rows = $this->tickets->list_for_admin( 100, $filter );
        $counts = [
            'all'     => count( $this->tickets->list_for_admin( 999 ) ),
            'open'    => count( $this->tickets->list_for_admin( 999, 'open' ) ),
            'replied' => count( $this->tickets->list_for_admin( 999, 'replied' ) ),
            'closed'  => count( $this->tickets->list_for_admin( 999, 'closed' ) ),
        ];
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'Support tickets', 'authorwings-ai-tools' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Member-submitted support tickets, newest first. Reply by emailing the member directly — Reply-To is set when they submit.', 'authorwings-ai-tools' ); ?></p>

            <ul class="subsubsub" style="margin: 12px 0;">
                <li><a href="?page=awg-membership-support"<?php echo $filter === '' ? ' class="current"' : ''; ?>><?php esc_html_e( 'All', 'authorwings-ai-tools' ); ?> <span class="count">(<?php echo (int) $counts['all']; ?>)</span></a> |</li>
                <li><a href="?page=awg-membership-support&status=open"<?php echo $filter === 'open' ? ' class="current"' : ''; ?>><?php esc_html_e( 'Open', 'authorwings-ai-tools' ); ?> <span class="count">(<?php echo (int) $counts['open']; ?>)</span></a> |</li>
                <li><a href="?page=awg-membership-support&status=replied"<?php echo $filter === 'replied' ? ' class="current"' : ''; ?>><?php esc_html_e( 'Replied', 'authorwings-ai-tools' ); ?> <span class="count">(<?php echo (int) $counts['replied']; ?>)</span></a> |</li>
                <li><a href="?page=awg-membership-support&status=closed"<?php echo $filter === 'closed' ? ' class="current"' : ''; ?>><?php esc_html_e( 'Closed', 'authorwings-ai-tools' ); ?></a> <span class="count">(<?php echo (int) $counts['closed']; ?>)</span></li>
            </ul>

            <?php if ( empty( $rows ) ) : ?>
                <div class="awg-card"><p><?php esc_html_e( 'No tickets in this view yet.', 'authorwings-ai-tools' ); ?></p></div>
            <?php else : ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( '#', 'authorwings-ai-tools' ); ?></th>
                            <th><?php esc_html_e( 'Member', 'authorwings-ai-tools' ); ?></th>
                            <th><?php esc_html_e( 'Subject', 'authorwings-ai-tools' ); ?></th>
                            <th><?php esc_html_e( 'Topic', 'authorwings-ai-tools' ); ?></th>
                            <th><?php esc_html_e( 'Priority', 'authorwings-ai-tools' ); ?></th>
                            <th><?php esc_html_e( 'Status', 'authorwings-ai-tools' ); ?></th>
                            <th><?php esc_html_e( 'Submitted', 'authorwings-ai-tools' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $rows as $row ) : ?>
                            <tr>
                                <td><strong>#<?php echo esc_html( str_pad( (string) $row['id'], 4, '0', STR_PAD_LEFT ) ); ?></strong></td>
                                <td>
                                    <?php echo esc_html( $row['display_name'] ?: __( 'Unknown', 'authorwings-ai-tools' ) ); ?><br>
                                    <small><a href="mailto:<?php echo esc_attr( $row['user_email'] ); ?>"><?php echo esc_html( $row['user_email'] ); ?></a></small>
                                </td>
                                <td>
                                    <strong><?php echo esc_html( $row['subject'] ); ?></strong>
                                    <details style="margin-top: 4px;">
                                        <summary style="cursor: pointer; color: #50575e; font-size: 12px;"><?php esc_html_e( 'Show body & reply', 'authorwings-ai-tools' ); ?></summary>
                                        <div style="background: #fbf8f2; border: 1px solid #e8decf; border-radius: 6px; padding: 10px; margin-top: 6px; white-space: pre-wrap; font-size: 12px;"><?php echo esc_html( wp_strip_all_tags( $row['body'] ) ); ?></div>
                                        <?php // v3.1.6 — show the existing reply (if any) and a reply box. ?>
                                        <?php if ( ! empty( $row['admin_reply'] ) ) : ?>
                                            <div style="margin-top:8px;font-size:11px;font-weight:600;color:#50575e;"><?php esc_html_e( 'Your last reply:', 'authorwings-ai-tools' ); ?></div>
                                            <div style="background:#eef3ec;border:1px solid #d7e2d2;border-radius:6px;padding:10px;margin-top:4px;white-space:pre-wrap;font-size:12px;"><?php echo esc_html( wp_strip_all_tags( (string) $row['admin_reply'] ) ); ?></div>
                                        <?php endif; ?>
                                        <form method="post" style="margin-top:8px;">
                                            <?php wp_nonce_field( 'awg_mem_ticket_admin' ); ?>
                                            <input type="hidden" name="ticket_id" value="<?php echo (int) $row['id']; ?>" />
                                            <textarea name="admin_reply" rows="3" class="large-text" placeholder="<?php esc_attr_e( 'Type a reply — it is emailed to the member and saved on the ticket.', 'authorwings-ai-tools' ); ?>"></textarea>
                                            <button type="submit" name="awg_ticket_reply" value="1" class="button button-small button-primary" style="margin-top:4px;"><?php esc_html_e( 'Send reply', 'authorwings-ai-tools' ); ?></button>
                                        </form>
                                    </details>
                                </td>
                                <td><?php echo esc_html( \AWG_MEM\Tickets::topic_label( $row['topic'] ) ); ?></td>
                                <td><span class="awg-plan-pill awg-plan-pill--<?php echo $row['priority'] === 'high' ? 'publisher' : ( $row['priority'] === 'low' ? 'free' : 'basic' ); ?>"><?php echo esc_html( $row['priority'] ); ?></span></td>
                                <td>
                                    <form method="post" style="display:flex; gap:4px;">
                                        <?php wp_nonce_field( 'awg_mem_ticket_admin' ); ?>
                                        <input type="hidden" name="ticket_id" value="<?php echo (int) $row['id']; ?>" />
                                        <select name="status">
                                            <option value="open" <?php selected( $row['status'], 'open' ); ?>><?php esc_html_e( 'Open', 'authorwings-ai-tools' ); ?></option>
                                            <option value="replied" <?php selected( $row['status'], 'replied' ); ?>><?php esc_html_e( 'Replied', 'authorwings-ai-tools' ); ?></option>
                                            <option value="closed" <?php selected( $row['status'], 'closed' ); ?>><?php esc_html_e( 'Closed', 'authorwings-ai-tools' ); ?></option>
                                        </select>
                                        <button type="submit" name="awg_ticket_set_status" value="1" class="button button-small"><?php esc_html_e( 'Set', 'authorwings-ai-tools' ); ?></button>
                                    </form>
                                </td>
                                <td><?php echo esc_html( wp_date( 'd M Y g:i a', strtotime( $row['created_at'] ) ) ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }

    public function page_demo_data(): void {
        if ( ! current_user_can( 'manage_awg_membership' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'authorwings-ai-tools' ), 403 );
        }
        // The demo-data / services seeder is not part of this lean build.
        if ( ! class_exists( '\\AWG_MEM\\Demo_Data' ) || ! class_exists( '\\AWG_MEM\\Services' ) ) {
            echo '<div class="wrap"><h1>' . esc_html__( 'Demo Data', 'authorwings-ai-tools' ) . '</h1><div class="notice notice-warning"><p>'
                . esc_html__( 'This feature is not available in this build.', 'authorwings-ai-tools' )
                . '</p></div></div>';
            return;
        }

        $message = '';
        $error   = '';

        // Reset
        if ( isset( $_POST['awg_mem_reset_demo'] ) && check_admin_referer( 'awg_mem_demo_data_action', 'awg_mem_demo_data_nonce' ) ) {
            delete_option( Demo_Data::OPTION_KEY );
            $message = __( 'Demo-data flag cleared. The next seed will run fresh.', 'authorwings-ai-tools' );
        }

        // Re-seed
        if ( isset( $_POST['awg_mem_run_demo_seed'] ) && check_admin_referer( 'awg_mem_demo_data_action', 'awg_mem_demo_data_nonce' ) ) {
            delete_option( Demo_Data::OPTION_KEY );
            // v3.1.1 — pass force=true so the gate inside maybe_seed()
            // (WP_DEBUG / AWG_MEM_DEMO_DATA / awg_mem_install_demo_data
            // filter) is bypassed. A human clicking this button is
            // explicit intent — on production it should always run.
            Demo_Data::maybe_seed( true );
            $status = get_option( Demo_Data::OPTION_KEY );
            if ( is_array( $status ) ) {
                $services_added = (int) ( $status['services_count'] ?? 0 );
                $orders_added   = (int) ( $status['orders_count']   ?? 0 );
                $usage_added    = (int) ( $status['usage_count']    ?? 0 );
                if ( $services_added + $orders_added + $usage_added === 0 ) {
                    // v3.1.1 — be honest about why nothing was added.
                    // The individual seed_* methods skip when content
                    // already exists (services > 0, orders for this
                    // user > 0, usage logs for this user > 0). The
                    // generic "may be disabled by filter" notice was
                    // misleading because none of those skips have
                    // anything to do with filters.
                    $message = __( 'Seed flag refreshed, but no new content was added — services, quote requests, and AI usage logs already exist for this account. Use the Wipe button below if you want a clean re-seed.', 'authorwings-ai-tools' );
                } else {
                    $message = sprintf(
                        /* translators: 1: services count, 2: orders count, 3: usage logs count */
                        __( 'Seed complete — %1$d services, %2$d quote requests, %3$d usage logs.', 'authorwings-ai-tools' ),
                        $services_added,
                        $orders_added,
                        $usage_added
                    );
                }
            } else {
                // With force=true reaching this branch means the seed
                // genuinely couldn't write (DB error, or
                // awg_mem_install_demo_data filter explicitly returned
                // false via a custom override that ignored $force).
                $error = __( 'Seed did not run. Check that the database tables exist and that no mu-plugin is forcing the awg_mem_install_demo_data filter to false.', 'authorwings-ai-tools' );
            }
        }

        // Wipe (delete all demo content)
        //
        // v3.0.1 — this TRUNCATEs the orders / usage_logs / usage tables and
        // deletes every service post. There is no "demo row" marker, so this
        // wipes real customer data too. Gate behind a typed confirmation so a
        // misclick on a live site can't nuke history.
        if ( isset( $_POST['awg_mem_wipe_demo'] ) && check_admin_referer( 'awg_mem_demo_data_action', 'awg_mem_demo_data_nonce' ) ) {
            $confirmation = isset( $_POST['awg_mem_wipe_confirm'] ) ? strtoupper( trim( (string) wp_unslash( $_POST['awg_mem_wipe_confirm'] ) ) ) : '';
            if ( $confirmation !== 'WIPE' ) {
                $error = __( 'Wipe blocked: please type WIPE in the confirmation field to proceed. This destroys all services, quote requests, and usage logs — including real customer data.', 'authorwings-ai-tools' );
            } else {
                global $wpdb;
                $svc_ids = get_posts( [
                    'post_type'      => Services::CPT,
                    'post_status'    => 'any',
                    'posts_per_page' => -1,
                    'fields'         => 'ids',
                ] );
                foreach ( $svc_ids as $id ) { wp_delete_post( (int) $id, true ); }
                $wpdb->query( "TRUNCATE TABLE " . Database::orders_table() );
                $wpdb->query( "TRUNCATE TABLE " . Database::usage_logs_table() );
                $wpdb->query( "TRUNCATE TABLE " . Database::usage_table() );
                delete_option( Demo_Data::OPTION_KEY );
                $message = __( 'All services, quote requests, and usage logs deleted.', 'authorwings-ai-tools' );
            }
        }

        $status = get_option( Demo_Data::OPTION_KEY );
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'Demo Data', 'authorwings-ai-tools' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Seed the dashboard with realistic sample content (services, quote requests, recent AI activity) for testing and demos. The seed only runs once — use the buttons below to re-run or wipe.', 'authorwings-ai-tools' ); ?></p>

            <?php if ( $message ) : ?>
                <div class="notice notice-success"><p><?php echo esc_html( $message ); ?></p></div>
            <?php endif; ?>
            <?php if ( $error ) : ?>
                <div class="notice notice-warning"><p><?php echo esc_html( $error ); ?></p></div>
            <?php endif; ?>

            <h2><?php esc_html_e( 'Current state', 'authorwings-ai-tools' ); ?></h2>
            <?php if ( $status && is_array( $status ) ) : ?>
                <table class="widefat striped" style="max-width:640px;">
                    <tbody>
                        <tr><th><?php esc_html_e( 'Seeded at', 'authorwings-ai-tools' ); ?></th><td><?php echo esc_html( $status['seeded_at'] ?? '' ); ?></td></tr>
                        <tr><th><?php esc_html_e( 'Plugin version at seed', 'authorwings-ai-tools' ); ?></th><td><?php echo esc_html( $status['version'] ?? '' ); ?></td></tr>
                        <tr><th><?php esc_html_e( 'Services created', 'authorwings-ai-tools' ); ?></th><td><?php echo (int) ( $status['services_count'] ?? 0 ); ?></td></tr>
                        <tr><th><?php esc_html_e( 'Quote requests created', 'authorwings-ai-tools' ); ?></th><td><?php echo (int) ( $status['orders_count'] ?? 0 ); ?></td></tr>
                        <tr><th><?php esc_html_e( 'AI usage logs created', 'authorwings-ai-tools' ); ?></th><td><?php echo (int) ( $status['usage_count'] ?? 0 ); ?></td></tr>
                    </tbody>
                </table>
            <?php else : ?>
                <p><em><?php esc_html_e( 'Demo data has not been seeded yet on this site.', 'authorwings-ai-tools' ); ?></em></p>
            <?php endif; ?>

            <h2 style="margin-top:24px;"><?php esc_html_e( 'Actions', 'authorwings-ai-tools' ); ?></h2>
            <form method="post" style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                <?php wp_nonce_field( 'awg_mem_demo_data_action', 'awg_mem_demo_data_nonce' ); ?>
                <button type="submit" name="awg_mem_run_demo_seed" class="button button-primary"
                        onclick="return confirm('<?php echo esc_js( __( 'Re-seed demo content? Existing services will be kept (the seeder skips if any service already exists). Quote requests and usage logs are only added if this user has none.', 'authorwings-ai-tools' ) ); ?>');">
                    <?php esc_html_e( 'Run / Re-run seed', 'authorwings-ai-tools' ); ?>
                </button>
                <button type="submit" name="awg_mem_reset_demo" class="button">
                    <?php esc_html_e( 'Clear seeded flag only', 'authorwings-ai-tools' ); ?>
                </button>
            </form>

            <h2 style="margin-top:32px;color:#b32d2e;"><?php esc_html_e( 'Danger zone — wipe ALL services, quote requests, and usage logs', 'authorwings-ai-tools' ); ?></h2>
            <p style="max-width:680px;">
                <?php esc_html_e( 'This deletes every service post, every quote/service order, and every AI usage log — INCLUDING real customer data. There is no separate "demo only" tag in storage, so the wipe is total. Type WIPE in the field below and submit to proceed.', 'authorwings-ai-tools' ); ?>
            </p>
            <form method="post" style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                <?php wp_nonce_field( 'awg_mem_demo_data_action', 'awg_mem_demo_data_nonce' ); ?>
                <input type="text" name="awg_mem_wipe_confirm" placeholder="<?php esc_attr_e( 'Type WIPE', 'authorwings-ai-tools' ); ?>" autocomplete="off" style="text-transform:uppercase;" />
                <button type="submit" name="awg_mem_wipe_demo" class="button button-link-delete"
                        onclick="return confirm('<?php echo esc_js( __( 'DELETE every service, quote request, and usage log on this site? This includes real customer data and cannot be undone.', 'authorwings-ai-tools' ) ); ?>');">
                    <?php esc_html_e( 'Wipe everything', 'authorwings-ai-tools' ); ?>
                </button>
            </form>

            <h2 style="margin-top:32px;"><?php esc_html_e( 'Auto-seed defaults (v3.0.1+)', 'authorwings-ai-tools' ); ?></h2>
            <p><?php esc_html_e( 'On production (WP_DEBUG off) the seeder does NOT run on activation — this page is the only way to populate demo content. On dev / staging (WP_DEBUG on) it auto-seeds once per site.', 'authorwings-ai-tools' ); ?></p>
            <p><?php esc_html_e( 'Force ON or OFF regardless of WP_DEBUG by adding to wp-config.php:', 'authorwings-ai-tools' ); ?></p>
            <pre style="background:#f6f7f7; padding:12px; border:1px solid #dcdcde; border-radius:4px;">// Force auto-seed ON:
define( 'AWG_MEM_DEMO_DATA', true );

// Force auto-seed OFF:
define( 'AWG_MEM_DEMO_DATA', false );

// Or via a mu-plugin:
add_filter( 'awg_mem_install_demo_data', '__return_true' );  // or '__return_false'</pre>
        </div>
        <?php
    }


    public function page_release_tests(): void {
        if ( ! current_user_can( 'manage_awg_membership' ) ) { wp_die( esc_html__( 'You do not have permission to access this page.', 'authorwings-ai-tools' ), 403 ); }

        $results = null;
        if ( isset( $_POST['awg_mem_run_selftests'] ) && check_admin_referer( 'awg_mem_run_selftests_action', 'awg_mem_run_selftests_nonce' ) ) {
            // The self-test runner is not part of this lean build (selftest is null
            // on the shim Plugin); guard so the page can't fatal if it is reached.
            $selftest = Plugin::instance()->selftest ?? null;
            if ( is_object( $selftest ) && method_exists( $selftest, 'run_all' ) ) {
                $results = $selftest->run_all( get_current_user_id() );
            }
        }

        $stripe_diag = null;
        if ( isset( $_POST['awg_mem_run_stripe_diag'] ) && check_admin_referer( 'awg_mem_run_stripe_diag_action', 'awg_mem_run_stripe_diag_nonce' ) ) {
            $stripe_diag = Plugin::instance()->memberships->run_stripe_diagnostics();
        }
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'Release Tests', 'authorwings-ai-tools' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Run automated plugin self-tests before packaging or deploying updates. Then complete the manual release checklist included in the plugin package.', 'authorwings-ai-tools' ); ?></p>
            <form method="post" class="awg-plan-form">
                <?php wp_nonce_field( 'awg_mem_run_selftests_action', 'awg_mem_run_selftests_nonce' ); ?>
                <p><button type="submit" name="awg_mem_run_selftests" class="button button-primary awg-btn-primary"><?php esc_html_e( 'Run Self-Tests', 'authorwings-ai-tools' ); ?></button></p>
            </form>
            <?php if ( is_array( $results ) ) : ?>
                <?php $all_passed = ! empty( $results['passed'] ); ?>
                <div class="notice <?php echo $all_passed ? 'notice-success' : 'notice-error'; ?>"><p><?php echo esc_html( $all_passed ? __( 'All automated self-tests passed.', 'authorwings-ai-tools' ) : __( 'One or more self-tests failed. Review the results below before release.', 'authorwings-ai-tools' ) ); ?></p></div>
                <table class="widefat striped awg-table-compact">
                    <thead><tr><th><?php esc_html_e( 'Test', 'authorwings-ai-tools' ); ?></th><th><?php esc_html_e( 'Status', 'authorwings-ai-tools' ); ?></th><th><?php esc_html_e( 'Details', 'authorwings-ai-tools' ); ?></th></tr></thead>
                    <tbody>
                    <?php foreach ( (array) $results['tests'] as $test ) : ?>
                        <tr>
                            <td><strong><?php echo esc_html( $test['name'] ); ?></strong></td>
                            <td><?php echo esc_html( ! empty( $test['passed'] ) ? __( 'Passed', 'authorwings-ai-tools' ) : __( 'Failed', 'authorwings-ai-tools' ) ); ?></td>
                            <td><?php echo esc_html( $test['message'] ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <hr style="margin:28px 0;">

            <h2><?php esc_html_e( 'Stripe connection &amp; billing readiness', 'authorwings-ai-tools' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Verify your Stripe keys, webhook, and per-plan price IDs before taking a real or test payment. This runs read-only checks against Stripe and never creates or changes anything.', 'authorwings-ai-tools' ); ?></p>
            <form method="post" class="awg-plan-form">
                <?php wp_nonce_field( 'awg_mem_run_stripe_diag_action', 'awg_mem_run_stripe_diag_nonce' ); ?>
                <p><button type="submit" name="awg_mem_run_stripe_diag" class="button button-primary awg-btn-primary"><?php esc_html_e( 'Test Stripe Connection', 'authorwings-ai-tools' ); ?></button></p>
            </form>
            <?php if ( is_array( $stripe_diag ) ) : ?>
                <?php
                $has_fail = false;
                foreach ( $stripe_diag as $row ) {
                    if ( ( $row['status'] ?? '' ) === 'fail' ) { $has_fail = true; break; }
                }
                ?>
                <div class="notice <?php echo $has_fail ? 'notice-error' : 'notice-success'; ?>"><p><?php echo esc_html( $has_fail ? __( 'One or more Stripe checks failed. Fix the items marked “Fail” before testing payments.', 'authorwings-ai-tools' ) : __( 'Stripe configuration looks ready. You can run a test checkout.', 'authorwings-ai-tools' ) ); ?></p></div>
                <table class="widefat striped awg-table-compact">
                    <thead><tr><th><?php esc_html_e( 'Check', 'authorwings-ai-tools' ); ?></th><th><?php esc_html_e( 'Status', 'authorwings-ai-tools' ); ?></th><th><?php esc_html_e( 'Details', 'authorwings-ai-tools' ); ?></th></tr></thead>
                    <tbody>
                    <?php
                    $labels = [
                        'pass' => __( 'Pass', 'authorwings-ai-tools' ),
                        'fail' => __( 'Fail', 'authorwings-ai-tools' ),
                        'warn' => __( 'Warning', 'authorwings-ai-tools' ),
                        'info' => __( 'Info', 'authorwings-ai-tools' ),
                    ];
                    foreach ( (array) $stripe_diag as $row ) :
                        $st = (string) ( $row['status'] ?? 'info' );
                        ?>
                        <tr>
                            <td><strong><?php echo esc_html( (string) ( $row['name'] ?? '' ) ); ?></strong></td>
                            <td><?php echo esc_html( $labels[ $st ] ?? ucfirst( $st ) ); ?></td>
                            <td><?php echo esc_html( (string) ( $row['message'] ?? '' ) ); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }

    public function register_settings(): void {
        register_setting( 'awg_mem_settings_group', Plugin::OPT, [
            'type'              => 'array',
            'sanitize_callback' => [ $this, 'sanitize_settings' ],
        ] );
    }

    public function sanitize_settings( $input ): array {
        $input = is_array( $input ) ? wp_unslash( $input ) : [];
        $out = [];
        $existing = get_option( Plugin::OPT, [] );
        $existing = is_array( $existing ) ? $existing : [];
        $out['notify_admin_email'] = sanitize_email( $input['notify_admin_email'] ?? get_option( 'admin_email' ) );
        // Keep the saved secret/webhook value when the field is submitted blank, so
        // the credentials can't be wiped on a normal save. The form never re-renders
        // the stored secret (it is not echoed back into the page), so a blank field
        // means "unchanged", and a non-blank field means "replace".
        $secret_in = sanitize_text_field( $input['stripe_secret_key'] ?? '' );
        $out['stripe_secret_key']  = $secret_in !== '' ? $secret_in : (string) ( $existing['stripe_secret_key'] ?? '' );
        $out['stripe_public_key']  = sanitize_text_field( $input['stripe_public_key']  ?? '' );
        $whsec_in = sanitize_text_field( $input['stripe_webhook_secret'] ?? '' );
        $out['stripe_webhook_secret'] = $whsec_in !== '' ? $whsec_in : (string) ( $existing['stripe_webhook_secret'] ?? '' );
        $out['dashboard_page_id']  = (int) ( $input['dashboard_page_id'] ?? 0 );
        $out['pricing_page_id']    = (int) ( $input['pricing_page_id'] ?? 0 );
        // Days before renewal to email a reminder; 0 disables the reminder.
        $out['renewal_reminder_days'] = max( 0, min( 30, (int) ( $input['renewal_reminder_days'] ?? 7 ) ) );
        $out['enable_error_logging'] = isset( $input['enable_error_logging'] ) ? 1 : 0;
        $out['log_retention_days'] = max( 0, (int) ( $input['log_retention_days'] ?? 30 ) );
        $out['usage_retention_days'] = max( 0, (int) ( $input['usage_retention_days'] ?? 0 ) );
        $out['order_retention_days'] = max( 0, (int) ( $input['order_retention_days'] ?? 0 ) );
        $out['membership_retention_days'] = max( 0, (int) ( $input['membership_retention_days'] ?? 0 ) );
        $out['dashboard_primary_color'] = sanitize_hex_color( $input['dashboard_primary_color'] ?? '#10243c' ) ?: '#10243c';
        $out['dashboard_bg_color']      = sanitize_hex_color( $input['dashboard_bg_color'] ?? '#fbf8f2' ) ?: '#fbf8f2';
        $out['dashboard_card_bg']       = sanitize_hex_color( $input['dashboard_card_bg'] ?? '#ffffff' ) ?: '#ffffff';
        $out['dashboard_text_color']    = sanitize_hex_color( $input['dashboard_text_color'] ?? '#10243c' ) ?: '#10243c';
        $out['dashboard_border_color']  = sanitize_hex_color( $input['dashboard_border_color'] ?? '#e8decf' ) ?: '#e8decf';

        $out['dashboard_font_family']   = sanitize_text_field( $input['dashboard_font_family'] ?? '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' );
        $out['dashboard_heading_font']  = sanitize_text_field( $input['dashboard_heading_font'] ?? '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' );
        $out['dashboard_font_size']     = max( 12, (int) ( $input['dashboard_font_size'] ?? 16 ) );

        $out['dashboard_button_bg']     = sanitize_hex_color( $input['dashboard_button_bg'] ?? '#10243c' ) ?: '#10243c';
        $out['dashboard_button_text']   = sanitize_hex_color( $input['dashboard_button_text'] ?? '#ffffff' ) ?: '#ffffff';
        $out['dashboard_button_hover']  = sanitize_hex_color( $input['dashboard_button_hover'] ?? '#7e9374' ) ?: '#7e9374';
        $out['dashboard_button_radius'] = max( 0, (int) ( $input['dashboard_button_radius'] ?? 12 ) );

        $out['dashboard_card_padding']      = max( 0, (int) ( $input['dashboard_card_padding'] ?? 20 ) );
        $out['dashboard_card_shadow']       = sanitize_text_field( $input['dashboard_card_shadow'] ?? '0 10px 28px rgba(16,36,60,.04)' );
        $out['dashboard_card_hover_shadow'] = sanitize_text_field( $input['dashboard_card_hover_shadow'] ?? '0 12px 30px rgba(16,36,60,.12)' );
        $out['dashboard_card_border_width'] = max( 0, (float) ( $input['dashboard_card_border_width'] ?? 1 ) );

        $out['dashboard_radius']            = max( 0, (int) ( $input['dashboard_radius'] ?? 12 ) );
        $out['dashboard_max_width']         = max( 320, (int) ( $input['dashboard_max_width'] ?? 960 ) );
        $out['dashboard_container_padding'] = max( 0, (int) ( $input['dashboard_container_padding'] ?? 0 ) );
        $out['dashboard_grid_gap']          = max( 0, (int) ( $input['dashboard_grid_gap'] ?? 16 ) );
        $out['dashboard_section_spacing']   = max( 0, (int) ( $input['dashboard_section_spacing'] ?? 28 ) );

        $custom_css = trim( (string) ( $input['dashboard_custom_css'] ?? '' ) );
        $custom_css = str_replace( [ '<', '>' ], '', $custom_css );
        // Strip CSS vectors that can fetch external resources or break context.
        $custom_css = (string) preg_replace( '/@import\b/i', '', $custom_css );
        $custom_css = (string) preg_replace( '/expression\s*\(/i', '', $custom_css );
        $custom_css = (string) preg_replace( '/(?:javascript|vbscript)\s*:/i', '', $custom_css );
        $out['dashboard_custom_css'] = $custom_css;
        return $out;
    }


    private function get_status_badge_markup( string $status ): string {
        $status = sanitize_key( $status );
        if ( 'in_progress' === $status ) {
            $status = 'responded';
        } elseif ( 'completed' === $status ) {
            $status = 'closed';
        }
        $map = [
            'active'    => [ 'label' => __( 'Active', 'authorwings-ai-tools' ), 'bg' => '#dcfce7', 'color' => '#166534' ],
            'cancelled' => [ 'label' => __( 'Cancelled', 'authorwings-ai-tools' ), 'bg' => '#e5e7eb', 'color' => '#374151' ],
            'pending'   => [ 'label' => __( 'Pending', 'authorwings-ai-tools' ), 'bg' => '#fef3c7', 'color' => '#92400e' ],
            'trialing'  => [ 'label' => __( 'Trialing', 'authorwings-ai-tools' ), 'bg' => '#dbeafe', 'color' => '#1d4ed8' ],
            'expired'   => [ 'label' => __( 'Expired', 'authorwings-ai-tools' ), 'bg' => '#fee2e2', 'color' => '#991b1b' ],
            'payment_failed' => [ 'label' => __( 'Payment Failed', 'authorwings-ai-tools' ), 'bg' => '#fee2e2', 'color' => '#991b1b' ],
            'responded' => [ 'label' => __( 'Responded', 'authorwings-ai-tools' ), 'bg' => '#dbeafe', 'color' => '#1d4ed8' ],
            'closed' => [ 'label' => __( 'Closed', 'authorwings-ai-tools' ), 'bg' => '#e5e7eb', 'color' => '#374151' ],
            
        ];

        $badge = $map[ $status ] ?? [
            'label' => ucwords( str_replace( '_', ' ', $status ?: 'unknown' ) ),
            'bg'    => '#f3f4f6',
            'color' => '#374151',
        ];

        return sprintf(
            '<span style="display:inline-block;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600;background:%1$s;color:%2$s;">%3$s</span>',
            esc_attr( $badge['bg'] ),
            esc_attr( $badge['color'] ),
            esc_html( $badge['label'] )
        );
    }

    private function get_member_usage_display( int $user_id, array $limits ): string {
        $used  = $this->usage->get_total_for_user( $user_id );
        $limit = isset( $limits['ai_generations_per_month'] ) ? (int) $limits['ai_generations_per_month'] : 0;

        if ( $limit < 0 ) {
            return sprintf( __( '%1$d / Unlimited', 'authorwings-ai-tools' ), $used );
        }

        return sprintf( __( '%1$d / %2$d', 'authorwings-ai-tools' ), $used, max( 0, $limit ) );
    }

    public function page_members(): void {
        if ( ! current_user_can( 'manage_awg_membership' ) ) { wp_die( esc_html__( 'You do not have permission to access this page.', 'authorwings-ai-tools' ), 403 ); }

        global $wpdb;
        $mems_table  = Database::mems_table();
        $plans_table = Database::plans_table();

        if ( isset( $_POST['awg_assign_plan_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST['awg_assign_plan_nonce'] ) ), 'awg_assign_plan' ) ) {
            $uid     = isset( $_POST['awg_uid'] ) ? (int) wp_unslash( (string) $_POST['awg_uid'] ) : 0;
            $plan_id = isset( $_POST['awg_plan_id'] ) ? (int) wp_unslash( (string) $_POST['awg_plan_id'] ) : 0;
            $billing_raw = isset( $_POST['awg_billing'] ) ? wp_unslash( (string) $_POST['awg_billing'] ) : '';
            $billing = in_array( $billing_raw, [ 'monthly', 'yearly', 'free' ], true )
                       ? sanitize_key( $billing_raw )
                       : 'monthly';
            if ( $uid && $plan_id ) {
                $this->memberships->set_user_plan( $uid, $plan_id, $billing );
                echo '<div class="notice notice-success"><p>' . esc_html__( 'Plan updated.', 'authorwings-ai-tools' ) . '</p></div>';
            }
        }

        $search_term   = isset( $_GET['member_search'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['member_search'] ) ) : '';
        $status_filter = isset( $_GET['member_status'] ) ? sanitize_key( wp_unslash( (string) $_GET['member_status'] ) ) : '';
        $plan_filter   = isset( $_GET['member_plan'] ) ? (int) wp_unslash( (string) $_GET['member_plan'] ) : 0;
        $edit_user_id  = isset( $_GET['edit_member'] ) ? (int) wp_unslash( (string) $_GET['edit_member'] ) : 0;

        // v3.1.1 — replace the correlated subquery on the WHERE clause
        // (one MAX(m2.id) lookup per outer row) with a join against a
        // derived "latest membership per user" table. Same result, but
        // the inner SELECT is evaluated once instead of N times.
        $latest_join = "JOIN (SELECT user_id, MAX(id) AS max_id FROM {$mems_table} GROUP BY user_id) latest ON latest.max_id = m.id";
        $where = [];
        $query_args = [];

        if ( $status_filter && in_array( $status_filter, [ 'active', 'cancelled', 'trialing', 'expired', 'payment_failed' ], true ) ) {
            $where[] = 'm.status = %s';
            $query_args[] = $status_filter;
        } else {
            $where[] = "m.status IN ('active','cancelled','trialing','expired','payment_failed')";
        }

        if ( $plan_filter > 0 ) {
            $where[] = 'm.plan_id = %d';
            $query_args[] = $plan_filter;
        }

        if ( $search_term !== '' ) {
            $like = '%' . $wpdb->esc_like( $search_term ) . '%';
            $where[] = '(u.display_name LIKE %s OR u.user_email LIKE %s)';
            $query_args[] = $like;
            $query_args[] = $like;
        }

        $sql = "SELECT m.*, p.name as plan_name, p.slug as plan_slug, p.limits, u.display_name, u.user_email
             FROM {$mems_table} m
             {$latest_join}
             LEFT JOIN {$plans_table} p ON p.id = m.plan_id
             LEFT JOIN {$wpdb->users} u ON u.ID = m.user_id"
             . ( ! empty( $where ) ? "\n             WHERE " . implode( ' AND ', $where ) : '' ) . "
             ORDER BY m.id DESC
             LIMIT 100";

        if ( ! empty( $query_args ) ) {
            $members = $wpdb->get_results( $wpdb->prepare( $sql, $query_args ), ARRAY_A );
        } else {
            $members = $wpdb->get_results( $sql, ARRAY_A );
        }

        $all_plans = $this->plans->get_all_for_admin();
        $activity_summary = $this->usage->get_member_activity_summary( 15 );
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'AuthorWings Members', 'authorwings-ai-tools' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Overview of active members, plan distribution, and estimated monthly recurring revenue.', 'authorwings-ai-tools' ); ?></p>
            <?php
            $total_active  = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$mems_table} WHERE status = 'active'" );
            $total_paid    = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT m.user_id) FROM {$mems_table} m LEFT JOIN {$plans_table} p ON p.id = m.plan_id WHERE m.status = 'active' AND p.is_free = 0" );
            $total_free    = max( 0, $total_active - $total_paid );

            // v2.7.0 — plan distribution + estimated MRR (USD-equivalent, best-effort)
            //
            // v3.1.1 — column name fix: schema defines `billing_cycle`, the
            // query used `billing` which silently returned an empty result
            // set and zeroed out the MRR donut. See class-database.php.
            //
            // v3.1.1 — replace the correlated subquery
            //   m.id = (SELECT MAX(m2.id) FROM ... WHERE m2.user_id = m.user_id)
            // with a derived-table join on the per-user MAX(id). The
            // correlated form executes the subquery once per outer row —
            // O(n²) on the membership table — while the derived table is
            // evaluated once and joined.
            $awg27_plan_rows = $wpdb->get_results(
                "SELECT p.id, p.slug, p.name, p.is_free, p.price_monthly, p.price_yearly, p.currency,
                        SUM(CASE WHEN m.status='active' AND m.billing_cycle='yearly'  THEN 1 ELSE 0 END) AS yearly_count,
                        SUM(CASE WHEN m.status='active' AND m.billing_cycle='monthly' THEN 1 ELSE 0 END) AS monthly_count,
                        SUM(CASE WHEN m.status='active' THEN 1 ELSE 0 END) AS active_count
                   FROM {$plans_table} p
                   LEFT JOIN (
                       SELECT m1.*
                         FROM {$mems_table} m1
                         JOIN (SELECT user_id, MAX(id) AS max_id FROM {$mems_table} GROUP BY user_id) latest
                           ON latest.max_id = m1.id
                   ) m ON m.plan_id = p.id
                  GROUP BY p.id
                  ORDER BY p.is_free ASC, p.price_monthly ASC",
                ARRAY_A
            ) ?: [];

            $awg27_mrr        = 0.0;
            $awg27_plan_mix   = []; // [ slug => count ]
            $awg27_plan_color = [
                'free'      => '#d9cdbb',
                'basic'     => '#7e9374',
                'pro'       => '#10243c',
                'publisher' => '#c97a5e',
            ];
            foreach ( $awg27_plan_rows as $pr ) {
                $cnt = (int) $pr['active_count'];
                $awg27_plan_mix[ $pr['slug'] ] = [
                    'name'  => $pr['name'],
                    'count' => $cnt,
                ];
                if ( (int) $pr['is_free'] === 1 ) {
                    continue;
                }
                $monthly_price = (float) $pr['price_monthly'];
                $yearly_price  = (float) $pr['price_yearly'];
                $awg27_mrr += $monthly_price * (int) $pr['monthly_count'];
                $awg27_mrr += ( $yearly_price / 12.0 ) * (int) $pr['yearly_count'];
            }
            $awg27_mrr = round( $awg27_mrr, 2 );

            // Donut math — 30/30 viewBox, r=12 → circumference ≈ 75.4
            $awg27_donut_total = array_sum( wp_list_pluck( $awg27_plan_mix, 'count' ) );
            $awg27_donut_total = $awg27_donut_total > 0 ? $awg27_donut_total : 1;
            ?>

            <div class="awg-overview-row">
                <div>
                    <div class="awg-kpi-grid">
                        <div class="awg-kpi">
                            <div class="awg-kpi__label"><?php esc_html_e( 'Active members', 'authorwings-ai-tools' ); ?></div>
                            <div class="awg-kpi__value"><?php echo esc_html( number_format_i18n( $total_active ) ); ?></div>
                            <div class="awg-kpi__delta awg-kpi__delta--muted">
                                <?php
                                printf(
                                    /* translators: 1: paid count, 2: free count */
                                    esc_html__( '%1$s paid · %2$s free', 'authorwings-ai-tools' ),
                                    esc_html( number_format_i18n( $total_paid ) ),
                                    esc_html( number_format_i18n( $total_free ) )
                                );
                                ?>
                            </div>
                        </div>
                        <div class="awg-kpi">
                            <div class="awg-kpi__label"><?php esc_html_e( 'Estimated MRR', 'authorwings-ai-tools' ); ?></div>
                            <div class="awg-kpi__value"><?php
                                /* translators: %s: dollar amount (best-effort MRR estimate) */
                                printf( '%s%s', '$', esc_html( number_format_i18n( $awg27_mrr, 2 ) ) );
                            ?></div>
                            <div class="awg-kpi__delta awg-kpi__delta--muted"><?php esc_html_e( 'Monthly + yearly ÷ 12', 'authorwings-ai-tools' ); ?></div>
                            <svg class="awg-kpi__spark" viewBox="0 0 64 24" preserveAspectRatio="none" aria-hidden="true">
                                <polyline fill="none" stroke="#7e9374" stroke-width="1.4" points="0,18 8,16 16,17 24,13 32,14 40,10 48,11 56,7 64,5"/>
                            </svg>
                        </div>
                        <div class="awg-kpi">
                            <div class="awg-kpi__label"><?php esc_html_e( 'Paid conversion', 'authorwings-ai-tools' ); ?></div>
                            <?php $awg27_conv_pct = $total_active > 0 ? round( $total_paid / $total_active * 100 ) : 0; ?>
                            <div class="awg-kpi__value"><?php echo esc_html( $awg27_conv_pct ); ?>%</div>
                            <div class="awg-kpi__delta awg-kpi__delta--muted">
                                <?php
                                printf(
                                    /* translators: 1: paid, 2: active */
                                    esc_html__( '%1$s of %2$s active', 'authorwings-ai-tools' ),
                                    esc_html( number_format_i18n( $total_paid ) ),
                                    esc_html( number_format_i18n( $total_active ) )
                                );
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="awg-planmix">
                    <div class="awg-planmix__head"><?php esc_html_e( 'Plan mix', 'authorwings-ai-tools' ); ?></div>
                    <div class="awg-planmix__body">
                        <svg viewBox="0 0 30 30" width="100" height="100" aria-hidden="true">
                            <circle cx="15" cy="15" r="12" fill="none" stroke="#f0e6d4" stroke-width="5"/>
                            <?php
                            $awg27_offset = 0.0;
                            $awg27_circ   = 75.4; // 2 * π * 12
                            foreach ( $awg27_plan_mix as $slug => $info ) {
                                $cnt = (int) $info['count'];
                                if ( $cnt <= 0 ) continue;
                                $len = ( $cnt / $awg27_donut_total ) * $awg27_circ;
                                $color = $awg27_plan_color[ $slug ] ?? '#8b7e6f';
                                printf(
                                    '<circle cx="15" cy="15" r="12" fill="none" stroke="%s" stroke-width="5" stroke-dasharray="%s,%s" stroke-dashoffset="%s" transform="rotate(-90 15 15)"/>',
                                    esc_attr( $color ),
                                    esc_attr( round( $len, 2 ) ),
                                    esc_attr( round( $awg27_circ, 2 ) ),
                                    esc_attr( round( -$awg27_offset, 2 ) )
                                );
                                $awg27_offset += $len;
                            }
                            ?>
                            <text x="15" y="14" text-anchor="middle" font-size="6" fill="#10243c" font-weight="500" font-family="-apple-system,system-ui,sans-serif"><?php echo esc_html( $total_active ); ?></text>
                            <text x="15" y="20" text-anchor="middle" font-size="3" fill="#8b7e6f" font-family="-apple-system,system-ui,sans-serif"><?php esc_html_e( 'members', 'authorwings-ai-tools' ); ?></text>
                        </svg>
                        <div class="awg-planmix__legend">
                            <?php foreach ( $awg27_plan_mix as $slug => $info ) : ?>
                                <?php $color = $awg27_plan_color[ $slug ] ?? '#8b7e6f'; ?>
                                <div>
                                    <span class="awg-planmix__legend-dot" style="background:<?php echo esc_attr( $color ); ?>"></span>
                                    <?php echo esc_html( $info['name'] ); ?> · <?php echo esc_html( $info['count'] ); ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <?php /* Legacy stat row preserved for backward-compat (hidden by default, easy to restore via CSS if needed) */ ?>
            <div class="awg-stat-row" style="display:none;">
                <div class="awg-stat-card">
                    <div class="awg-stat-card__value"><?php echo esc_html( $total_active ); ?></div>
                    <div class="awg-stat-card__label"><?php esc_html_e( 'Active Members', 'authorwings-ai-tools' ); ?></div>
                </div>
                <div class="awg-stat-card">
                    <div class="awg-stat-card__value awg-stat-card__value--paid"><?php echo esc_html( $total_paid ); ?></div>
                    <div class="awg-stat-card__label"><?php esc_html_e( 'Paid Members', 'authorwings-ai-tools' ); ?></div>
                </div>
                <div class="awg-stat-card">
                    <div class="awg-stat-card__value awg-stat-card__value--free"><?php echo esc_html( $total_free ); ?></div>
                    <div class="awg-stat-card__label"><?php esc_html_e( 'Free Members', 'authorwings-ai-tools' ); ?></div>
                </div>
            </div>

            <div class="awg-card">
                <h2 style="margin-top:0;"><?php esc_html_e( 'Member Activity Summary', 'authorwings-ai-tools' ); ?></h2>
                <p class="description"><?php esc_html_e( 'Shows one row per member with current-month total usage and latest recorded AI activity.', 'authorwings-ai-tools' ); ?></p>
                <table class="widefat striped awg-table-compact">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Member', 'authorwings-ai-tools' ); ?></th>
                            <th><?php esc_html_e( 'Plan', 'authorwings-ai-tools' ); ?></th>
                            <th><?php esc_html_e( 'Total Usage', 'authorwings-ai-tools' ); ?></th>
                            <th><?php esc_html_e( 'Last Activity', 'authorwings-ai-tools' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ( empty( $activity_summary ) ) : ?>
                            <tr><td colspan="4"><?php esc_html_e( 'No member activity recorded yet.', 'authorwings-ai-tools' ); ?></td></tr>
                        <?php else : ?>
                            <?php foreach ( $activity_summary as $row ) : ?>
                                <?php
                                // v2.7.0 — derive avatar initials, plan slug for pill, and avatar color rotation.
                                $awg27_name     = (string) ( $row['display_name'] ?? '' );
                                $awg27_initials = strtoupper( substr( trim( $awg27_name ), 0, 1 ) ) . strtoupper( substr( strrchr( ' ' . trim( $awg27_name ), ' ' ), 1, 1 ) );
                                $awg27_initials = $awg27_initials !== '' ? $awg27_initials : '?';
                                $awg27_plan_slug = strtolower( (string) ( $row['plan_slug'] ?? '' ) );
                                $awg27_av_class = 'awg-member-avatar';
                                $awg27_av_pick  = ( ord( substr( $awg27_name . 'x', 0, 1 ) ) % 4 );
                                $awg27_av_class .= [ '', ' awg-member-avatar--coral', ' awg-member-avatar--navy', ' awg-member-avatar--muted' ][ $awg27_av_pick ];
                                $awg27_pill_class = 'awg-plan-pill';
                                if ( in_array( $awg27_plan_slug, [ 'free', 'basic', 'pro', 'publisher' ], true ) ) {
                                    $awg27_pill_class .= ' awg-plan-pill--' . $awg27_plan_slug;
                                }
                                ?>
                                <tr>
                                    <td>
                                        <span class="awg-member-user">
                                            <span class="<?php echo esc_attr( $awg27_av_class ); ?>" aria-hidden="true"><?php echo esc_html( $awg27_initials ); ?></span>
                                            <span>
                                                <strong><?php echo esc_html( $awg27_name ); ?></strong><br>
                                                <small><?php echo esc_html( $row['user_email'] ); ?></small>
                                            </span>
                                        </span>
                                    </td>
                                    <td><span class="<?php echo esc_attr( $awg27_pill_class ); ?>"><?php echo esc_html( $row['plan_name'] ); ?></span></td>
                                    <td><?php echo esc_html( (string) $row['month_used'] ); ?></td>
                                    <td><?php echo ! empty( $row['last_activity'] ) ? esc_html( wp_date( 'd M Y g:i a', strtotime( $row['last_activity'] ) ) ) : '—'; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="awg-card">
                <form method="get" class="awg-filter-form">
                    <input type="hidden" name="page" value="awg-membership">
                    <div>
                        <label for="awg-member-search" class="awg-form-field-block"><?php esc_html_e( 'Search', 'authorwings-ai-tools' ); ?></label>
                        <input id="awg-member-search" type="search" name="member_search" value="<?php echo esc_attr( $search_term ); ?>" placeholder="<?php esc_attr_e( 'Name or email', 'authorwings-ai-tools' ); ?>" class="regular-text">
                    </div>
                    <div>
                        <label for="awg-member-plan" class="awg-form-field-block"><?php esc_html_e( 'Plan', 'authorwings-ai-tools' ); ?></label>
                        <select id="awg-member-plan" name="member_plan">
                            <option value="0"><?php esc_html_e( 'All plans', 'authorwings-ai-tools' ); ?></option>
                            <?php foreach ( $all_plans as $plan ) : ?>
                                <option value="<?php echo esc_attr( $plan['id'] ); ?>" <?php selected( $plan_filter, (int) $plan['id'] ); ?>><?php echo esc_html( $plan['name'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="awg-member-status" class="awg-form-field-block"><?php esc_html_e( 'Status', 'authorwings-ai-tools' ); ?></label>
                        <select id="awg-member-status" name="member_status">
                            <option value=""><?php esc_html_e( 'All statuses', 'authorwings-ai-tools' ); ?></option>
                            <option value="active" <?php selected( $status_filter, 'active' ); ?>><?php esc_html_e( 'Active', 'authorwings-ai-tools' ); ?></option>
                            <option value="cancelled" <?php selected( $status_filter, 'cancelled' ); ?>><?php esc_html_e( 'Cancelled', 'authorwings-ai-tools' ); ?></option>
                            <option value="trialing" <?php selected( $status_filter, 'trialing' ); ?>><?php esc_html_e( 'Trialing', 'authorwings-ai-tools' ); ?></option>
                            <option value="expired" <?php selected( $status_filter, 'expired' ); ?>><?php esc_html_e( 'Expired', 'authorwings-ai-tools' ); ?></option>
                            <option value="payment_failed" <?php selected( $status_filter, 'payment_failed' ); ?>><?php esc_html_e( 'Payment Failed', 'authorwings-ai-tools' ); ?></option>
                        </select>
                    </div>
                    <div class="awg-actions-inline">
                        <button class="button button-primary awg-btn-primary" type="submit"><?php esc_html_e( 'Filter', 'authorwings-ai-tools' ); ?></button>
                        <a class="button awg-btn-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership' ) ); ?>"><?php esc_html_e( 'Reset', 'authorwings-ai-tools' ); ?></a>
                    </div>
                </form>
            </div>

            <table class="widefat striped awg-table-compact">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'User ID', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Member', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Plan', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Billing', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Usage', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Ends', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Action', 'authorwings-ai-tools' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $members ) ) : ?>
                        <tr><td colspan="8"><?php esc_html_e( 'No memberships found for the current filters.', 'authorwings-ai-tools' ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $members as $m ) : ?>
                            <?php $limits = json_decode( $m['limits'] ?? '{}', true ) ?: []; ?>
                            <tr>
                                <td>
                                    <?php echo esc_html( $m['user_id'] ); ?>
                                    <br><small style="color:#666;"><?php echo esc_html( sprintf( __( 'Record #%d', 'authorwings-ai-tools' ), (int) $m['id'] ) ); ?></small>
                                </td>
                                <td><strong><?php echo esc_html( $m['display_name'] ); ?></strong><br><small><?php echo esc_html( $m['user_email'] ); ?></small></td>
                                <td><?php echo esc_html( $m['plan_name'] ?: '—' ); ?></td>
                                <td><?php echo esc_html( ucfirst( $m['billing_cycle'] ) ); ?></td>
                                <td><?php echo esc_html( $this->get_member_usage_display( (int) $m['user_id'], $limits ) ); ?></td>
                                <td><?php echo wp_kses_post( $this->get_status_badge_markup( (string) $m['status'] ) ); ?></td>
                                <td><?php echo ! empty( $m['end_date'] ) ? esc_html( wp_date( 'd M Y', strtotime( $m['end_date'] ) ) ) : '—'; ?></td>
                                <td>
                                    <?php if ( $edit_user_id === (int) $m['user_id'] ) : ?>
                                        <form method="post" class="awg-actions-inline">
                                            <?php wp_nonce_field( 'awg_assign_plan', 'awg_assign_plan_nonce' ); ?>
                                            <input type="hidden" name="awg_uid" value="<?php echo esc_attr( $m['user_id'] ); ?>">
                                            <select name="awg_plan_id">
                                                <?php foreach ( $all_plans as $plan ) : ?>
                                                    <option value="<?php echo esc_attr( $plan['id'] ); ?>" <?php selected( (int) $plan['id'], (int) $m['plan_id'] ); ?>><?php echo esc_html( $plan['name'] ); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <select name="awg_billing">
                                                <option value="monthly" <?php selected( $m['billing_cycle'], 'monthly' ); ?>><?php esc_html_e( 'Monthly', 'authorwings-ai-tools' ); ?></option>
                                                <option value="yearly" <?php selected( $m['billing_cycle'], 'yearly' ); ?>><?php esc_html_e( 'Yearly', 'authorwings-ai-tools' ); ?></option>
                                                <option value="free" <?php selected( $m['billing_cycle'], 'free' ); ?>><?php esc_html_e( 'Free', 'authorwings-ai-tools' ); ?></option>
                                            </select>
                                            <button class="button button-primary button-small awg-btn-save" type="submit"><?php esc_html_e( 'Save', 'authorwings-ai-tools' ); ?></button>
                                            <a class="button button-small awg-btn-edit" href="<?php echo esc_url( remove_query_arg( 'edit_member' ) ); ?>"><?php esc_html_e( 'Cancel', 'authorwings-ai-tools' ); ?></a>
                                        </form>
                                    <?php else : ?>
                                        <a class="button button-small awg-btn-edit" href="<?php echo esc_url( add_query_arg( 'edit_member', (int) $m['user_id'] ) ); ?>"><?php esc_html_e( 'Edit', 'authorwings-ai-tools' ); ?></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function page_plans(): void {
        if ( ! current_user_can( 'manage_awg_membership' ) ) { wp_die( esc_html__( 'You do not have permission to access this page.', 'authorwings-ai-tools' ), 403 ); }

        $notice = '';
        $editing_plan = null;

        if ( isset( $_GET['plan_action'], $_GET['plan_id'], $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'awg_plan_action' ) ) {
            $plan_action = sanitize_key( wp_unslash( $_GET['plan_action'] ) );
            $plan_id     = (int) $_GET['plan_id'];
            $plan        = $this->plans->get( $plan_id );

            if ( $plan ) {
                if ( 'delete' === $plan_action ) {
                    $assigned_count = $this->plans->count_members_assigned( $plan_id );
                    if ( $assigned_count > 0 ) {
                        $notice = '<div class="notice notice-error"><p>' . sprintf( esc_html__( 'Plan cannot be deleted because %d members are assigned to it.', 'authorwings-ai-tools' ), $assigned_count ) . '</p></div>';
                    } elseif ( $this->plans->delete_plan( $plan_id ) ) {
                        $notice = '<div class="notice notice-success"><p>' . esc_html__( 'Plan deleted.', 'authorwings-ai-tools' ) . '</p></div>';
                    } else {
                        $notice = '<div class="notice notice-error"><p>' . esc_html__( 'Plan could not be deleted.', 'authorwings-ai-tools' ) . '</p></div>';
                    }
                } elseif ( in_array( $plan_action, [ 'activate', 'deactivate' ], true ) ) {
                    $plan['is_active'] = 'activate' === $plan_action ? 1 : 0;
                    $this->plans->save_plan( $plan );
                    $notice = '<div class="notice notice-success"><p>' . ( 'activate' === $plan_action ? esc_html__( 'Plan activated.', 'authorwings-ai-tools' ) : esc_html__( 'Plan deactivated.', 'authorwings-ai-tools' ) ) . '</p></div>';
                }
            }
        }

        if ( isset( $_POST['awg_plan_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['awg_plan_nonce'] ) ), 'awg_save_plan' ) ) {
            $plan_id         = (int) ( $_POST['plan_id'] ?? 0 );
            $is_unlimited    = ! empty( $_POST['limit_ai_unlimited'] );
            $raw_limit_value = isset( $_POST['limit_ai_generations'] ) ? wp_unslash( (string) $_POST['limit_ai_generations'] ) : '0';
            $usage_limit     = $is_unlimited ? -1 : max( 0, (int) $raw_limit_value );

            // v3.1.6 — split on any newline style (Windows \r\n, old-Mac \r,
            // Unix \n). The previous pattern was three identical \n branches,
            // so \r-only input never split (the whole textarea became one
            // feature) and \r\n left stray carriage returns.
            $feature_lines = preg_split( '/\r\n|\r|\n/', (string) wp_unslash( $_POST['features'] ?? '' ) ) ?: [];
            $plan_payload = [
                'id'                      => $plan_id,
                'name'                    => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
                'slug'                    => sanitize_title( wp_unslash( $_POST['slug'] ?? '' ) ),
                'description'             => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
                'price_monthly'           => (float) ( $_POST['price_monthly'] ?? 0 ),
                'price_yearly'            => (float) ( $_POST['price_yearly'] ?? 0 ),
                'currency'                => sanitize_text_field( wp_unslash( $_POST['currency'] ?? 'USD' ) ),
                'sort_order'              => (int) ( $_POST['sort_order'] ?? 0 ),
                'stripe_monthly_price_id' => sanitize_text_field( wp_unslash( $_POST['stripe_monthly_price_id'] ?? '' ) ),
                'stripe_yearly_price_id'  => sanitize_text_field( wp_unslash( $_POST['stripe_yearly_price_id'] ?? '' ) ),
                'features'                => array_values( array_filter( array_map( 'sanitize_text_field', $feature_lines ), static function ( $feature ) {
                    return '' !== trim( (string) $feature );
                } ) ),
                'is_active'               => ! empty( $_POST['is_active'] ) ? 1 : 0,
                'is_free'                 => ! empty( $_POST['is_free'] ) ? 1 : 0,
                'is_popular'              => ! empty( $_POST['is_popular'] ) ? 1 : 0,
                'limits'                  => [
                    'ai_generations_per_month' => $usage_limit,
                    'tools_access'             => sanitize_key( $_POST['limit_tools_access'] ?? 'free' ),
                    'trial_days'               => max( 0, (int) ( $_POST['limit_trial_days'] ?? 0 ) ),
                ],
            ];

            $validation = $this->plans->validate_plan_input( $plan_payload );
            if ( $validation['valid'] ) {
                $saved_id = $this->plans->save_plan( $validation['data'] );
                $editing_plan = $this->plans->get( $saved_id );
                $notice = '<div class="notice notice-success"><p>' . esc_html__( 'Plan saved.', 'authorwings-ai-tools' ) . '</p></div>';
            } else {
                $editing_plan = array_merge( [ 'limits' => [] ], $plan_payload );
                $error_lines = '';
                foreach ( (array) $validation['errors'] as $error ) {
                    $error_lines .= '<li>' . esc_html( $error ) . '</li>';
                }
                $notice = '<div class="notice notice-error"><p>' . esc_html__( 'Plan could not be saved.', 'authorwings-ai-tools' ) . '</p><ul class="awg-validation-list">' . $error_lines . '</ul></div>';
            }
        }

        if ( ! $editing_plan && isset( $_GET['edit_plan'] ) ) {
            $editing_plan = $this->plans->get( (int) $_GET['edit_plan'] );
        }

        if ( ! $editing_plan ) {
            $editing_plan = [
                'id'            => 0,
                'name'          => '',
                'slug'          => '',
                'price_monthly' => '0.00',
                'price_yearly'  => '0.00',
                'is_free'       => 0,
                'description'   => '',
                'currency'      => 'USD',
                'is_active'     => 1,
                'is_popular'    => 0,
                'sort_order'    => 0,
                'features'      => [],
                'limits'        => [
                    'ai_generations_per_month' => 0,
                    'tools_access'             => 'free',
                ],
                'stripe_monthly_price_id' => '',
                'stripe_yearly_price_id'  => '',
            ];
        }

        $plans = $this->plans->get_all_for_admin();
        $current_limit = (int) ( $editing_plan['limits']['ai_generations_per_month'] ?? 0 );
        $is_unlimited  = $current_limit < 0;
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'Membership Plans', 'authorwings-ai-tools' ); ?></h1>
            <?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

            <div class="awg-plan-edit-grid">
                <div class="awg-plan-edit-card">
                    <h2><?php echo $editing_plan['id'] ? esc_html__( 'Edit Plan', 'authorwings-ai-tools' ) : esc_html__( 'Add Plan', 'authorwings-ai-tools' ); ?></h2>
                    <p class="description"><?php esc_html_e( 'Edit plan pricing, limits, front-end description, and feature list from one place.', 'authorwings-ai-tools' ); ?></p>
                    <form method="post" class="awg-plan-form">
                        <?php wp_nonce_field( 'awg_save_plan', 'awg_plan_nonce' ); ?>
                        <input type="hidden" name="plan_id" value="<?php echo esc_attr( $editing_plan['id'] ); ?>">
                        <table class="form-table awg-plan-form-table" role="presentation">
                            <tr><th><label for="awg-plan-name"><?php esc_html_e( 'Plan Name', 'authorwings-ai-tools' ); ?></label></th><td><input id="awg-plan-name" class="regular-text" type="text" name="name" value="<?php echo esc_attr( $editing_plan['name'] ); ?>" required></td></tr>
                            <tr><th><label for="awg-plan-slug"><?php esc_html_e( 'Slug', 'authorwings-ai-tools' ); ?></label></th><td><input id="awg-plan-slug" class="regular-text" type="text" name="slug" value="<?php echo esc_attr( $editing_plan['slug'] ); ?>" required><p class="description"><?php esc_html_e( 'Used internally for access checks and links.', 'authorwings-ai-tools' ); ?></p></td></tr>
                            <tr><th><?php esc_html_e( 'Monthly Price', 'authorwings-ai-tools' ); ?></th><td><input type="number" step="0.01" min="0" name="price_monthly" value="<?php echo esc_attr( $editing_plan['price_monthly'] ); ?>"></td></tr>
                            <tr><th><?php esc_html_e( 'Yearly Price', 'authorwings-ai-tools' ); ?></th><td><input type="number" step="0.01" min="0" name="price_yearly" value="<?php echo esc_attr( $editing_plan['price_yearly'] ); ?>"></td></tr>
                            <tr><th><label for="awg-plan-description"><?php esc_html_e( 'Description', 'authorwings-ai-tools' ); ?></label></th><td><textarea id="awg-plan-description" class="large-text" rows="3" name="description"><?php echo esc_textarea( $editing_plan['description'] ?? '' ); ?></textarea><p class="description"><?php esc_html_e( 'Shown on pricing and membership screens.', 'authorwings-ai-tools' ); ?></p></td></tr>
                            <tr><th><label for="awg-plan-features"><?php esc_html_e( 'Plan Features', 'authorwings-ai-tools' ); ?></label></th><td><textarea id="awg-plan-features" class="large-text" rows="8" name="features"><?php echo esc_textarea( implode( "
", (array) ( $editing_plan['features'] ?? [] ) ) ); ?></textarea><p class="description"><?php esc_html_e( 'One feature per line. These are the items shown on the member dashboard cards.', 'authorwings-ai-tools' ); ?></p></td></tr>
                            <tr>
                                <th><?php esc_html_e( 'Usage Limit', 'authorwings-ai-tools' ); ?></th>
                                <td>
                                    <label style="display:inline-flex;align-items:center;gap:6px;margin-bottom:8px;">
                                        <input type="checkbox" name="limit_ai_unlimited" value="1" <?php checked( $is_unlimited ); ?>>
                                        <?php esc_html_e( 'Unlimited', 'authorwings-ai-tools' ); ?>
                                    </label><br>
                                    <input type="number" min="0" name="limit_ai_generations" value="<?php echo esc_attr( $is_unlimited ? 0 : $current_limit ); ?>" <?php disabled( $is_unlimited ); ?>>
                                    <p class="description"><?php esc_html_e( 'Monthly AI generations for this plan.', 'authorwings-ai-tools' ); ?></p>
                                </td>
                            </tr>
                            <tr><th><?php esc_html_e( 'Access Level', 'authorwings-ai-tools' ); ?></th><td><select class="regular-text" name="limit_tools_access"><option value="free" <?php selected( $editing_plan['limits']['tools_access'] ?? 'free', 'free' ); ?>>Free</option><option value="basic" <?php selected( $editing_plan['limits']['tools_access'] ?? '', 'basic' ); ?>>Basic</option><option value="pro" <?php selected( $editing_plan['limits']['tools_access'] ?? '', 'pro' ); ?>>Pro</option><option value="publisher" <?php selected( $editing_plan['limits']['tools_access'] ?? '', 'publisher' ); ?>>Publisher</option></select></td></tr>
                            <tr><th><label for="awg-plan-trial-days"><?php esc_html_e( 'Free Trial (days)', 'authorwings-ai-tools' ); ?></label></th><td><input id="awg-plan-trial-days" type="number" min="0" max="365" name="limit_trial_days" value="<?php echo esc_attr( (int) ( $editing_plan['limits']['trial_days'] ?? 0 ) ); ?>"><p class="description"><?php esc_html_e( 'Days of free trial offered at Stripe checkout for first-time subscribers. 0 = no trial.', 'authorwings-ai-tools' ); ?></p></td></tr>
                            <tr><th><label for="awg-plan-sort-order"><?php esc_html_e( 'Sort Order', 'authorwings-ai-tools' ); ?></label></th><td><input id="awg-plan-sort-order" type="number" min="0" name="sort_order" value="<?php echo esc_attr( (int) ( $editing_plan['sort_order'] ?? 0 ) ); ?>"><p class="description"><?php esc_html_e( 'Controls plan order in admin and front view.', 'authorwings-ai-tools' ); ?></p></td></tr>
                            <tr><th><label for="awg-plan-currency"><?php esc_html_e( 'Currency', 'authorwings-ai-tools' ); ?></label></th><td><input id="awg-plan-currency" class="regular-text" type="text" name="currency" value="<?php echo esc_attr( $editing_plan['currency'] ?? 'USD' ); ?>"><p class="description"><?php esc_html_e( 'Usually USD.', 'authorwings-ai-tools' ); ?></p></td></tr>
                            <tr><th><label for="awg-plan-stripe-monthly"><?php esc_html_e( 'Stripe Monthly Price ID', 'authorwings-ai-tools' ); ?></label></th><td><input id="awg-plan-stripe-monthly" class="regular-text" type="text" name="stripe_monthly_price_id" value="<?php echo esc_attr( $editing_plan['stripe_monthly_price_id'] ?? '' ); ?>"></td></tr>
                            <tr><th><label for="awg-plan-stripe-yearly"><?php esc_html_e( 'Stripe Yearly Price ID', 'authorwings-ai-tools' ); ?></label></th><td><input id="awg-plan-stripe-yearly" class="regular-text" type="text" name="stripe_yearly_price_id" value="<?php echo esc_attr( $editing_plan['stripe_yearly_price_id'] ?? '' ); ?>"></td></tr>
                            <tr><th><?php esc_html_e( 'Status', 'authorwings-ai-tools' ); ?></th><td><label><input type="checkbox" name="is_active" value="1" <?php checked( ! empty( $editing_plan['is_active'] ) ); ?>> <?php esc_html_e( 'Active', 'authorwings-ai-tools' ); ?></label><br><label><input type="checkbox" name="is_free" value="1" <?php checked( ! empty( $editing_plan['is_free'] ) ); ?>> <?php esc_html_e( 'Free plan', 'authorwings-ai-tools' ); ?></label><br><label><input type="checkbox" name="is_popular" value="1" <?php checked( ! empty( $editing_plan['is_popular'] ) ); ?>> <?php esc_html_e( 'Show "Most Popular" badge on this plan', 'authorwings-ai-tools' ); ?></label></td></tr>
                        </table>
                        <p>
                            <button type="submit" class="button button-primary awg-btn-primary"><?php esc_html_e( 'Save Plan', 'authorwings-ai-tools' ); ?></button>
                            <a class="button awg-btn-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-plans' ) ); ?>"><?php esc_html_e( 'Add New', 'authorwings-ai-tools' ); ?></a>
                        </p>
                    </form>
                    <script>
                    document.addEventListener('DOMContentLoaded', function () {
                        var checkbox = document.querySelector('input[name="limit_ai_unlimited"]');
                        var input = document.querySelector('input[name="limit_ai_generations"]');
                        var nameInput = document.getElementById('awg-plan-name');
                        var slugInput = document.getElementById('awg-plan-slug');
                        if (checkbox && input) {
                            var syncState = function () {
                                input.disabled = checkbox.checked;
                            };
                            checkbox.addEventListener('change', syncState);
                            syncState();
                        }
                        if (nameInput && slugInput) {
                            var slugTouched = slugInput.value.trim() !== '';
                            slugInput.addEventListener('input', function () {
                                slugTouched = slugInput.value.trim() !== '';
                            });
                            nameInput.addEventListener('input', function () {
                                if (slugTouched) { return; }
                                slugInput.value = nameInput.value
                                    .toLowerCase()
                                    .trim()
                                    .replace(/[^a-z0-9\s-]/g, '')
                                    .replace(/\s+/g, '-')
                                    .replace(/-+/g, '-');
                            });
                        }
                    });
                    </script>
                </div>

                <div class="awg-plan-edit-card">
                    <h2><?php esc_html_e( 'All Plans', 'authorwings-ai-tools' ); ?></h2>
                    <table class="widefat striped awg-table-compact">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th><?php esc_html_e( 'Plan', 'authorwings-ai-tools' ); ?></th>
                                <th><?php esc_html_e( 'Prices', 'authorwings-ai-tools' ); ?></th>
                                <th><?php esc_html_e( 'Usage Limit', 'authorwings-ai-tools' ); ?></th>
                                <th><?php esc_html_e( 'Access Level', 'authorwings-ai-tools' ); ?></th>
                                <th><?php esc_html_e( 'Status', 'authorwings-ai-tools' ); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ( empty( $plans ) ) : ?>
                                <tr><td colspan="6"><?php esc_html_e( 'No plans found.', 'authorwings-ai-tools' ); ?></td></tr>
                            <?php else : ?>
                                <?php foreach ( $plans as $plan ) : ?>
                                    <?php $limit = (int) ( $plan['limits']['ai_generations_per_month'] ?? 0 ); ?>
                                    <tr>
                                        <?php $assigned_count = $this->plans->count_members_assigned( (int) $plan['id'] ); ?>
                                        <?php $toggle_action = ! empty( $plan['is_active'] ) ? 'deactivate' : 'activate'; ?>
                                        <?php $toggle_label  = ! empty( $plan['is_active'] ) ? __( 'Deactivate', 'authorwings-ai-tools' ) : __( 'Activate', 'authorwings-ai-tools' ); ?>
                                        <?php $edit_url = admin_url( 'admin.php?page=awg-membership-plans&edit_plan=' . (int) $plan['id'] ); ?>
                                        <?php $toggle_url = wp_nonce_url( admin_url( 'admin.php?page=awg-membership-plans&plan_action=' . $toggle_action . '&plan_id=' . (int) $plan['id'] ), 'awg_plan_action' ); ?>
                                        <?php $delete_url = wp_nonce_url( admin_url( 'admin.php?page=awg-membership-plans&plan_action=delete&plan_id=' . (int) $plan['id'] ), 'awg_plan_action' ); ?>
                                        <td><?php echo esc_html( $plan['id'] ); ?></td>
                                        <td>
                                            <strong><a href="<?php echo esc_url( $edit_url ); ?>"><?php echo esc_html( $plan['name'] ); ?></a></strong>
                                            <div class="row-actions visible">
                                                <span class="edit"><a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'authorwings-ai-tools' ); ?></a></span> | 
                                                <span class="toggle"><a href="<?php echo esc_url( $toggle_url ); ?>"><?php echo esc_html( $toggle_label ); ?></a></span> | 
                                                <?php if ( $assigned_count > 0 ) : ?>
                                                    <span class="trash"><span class="submitdelete" style="cursor:not-allowed;opacity:.7;"><?php esc_html_e( 'Delete', 'authorwings-ai-tools' ); ?></span></span>
                                                <?php else : ?>
                                                    <span class="trash"><a class="submitdelete" href="<?php echo esc_url( $delete_url ); ?>" onclick="return confirm('<?php echo esc_js( __( 'Delete this plan?', 'authorwings-ai-tools' ) ); ?>');"><?php esc_html_e( 'Delete', 'authorwings-ai-tools' ); ?></a></span>
                                                <?php endif; ?>
                                            </div>
                                            <p class="description awg-plan-assigned"><?php echo esc_html( sprintf( _n( '%d member assigned', '%d members assigned', $assigned_count, 'authorwings-ai-tools' ), $assigned_count ) ); ?></p>
                                        </td>
                                        <td>
                                            <?php if ( ! empty( $plan['is_free'] ) ) : ?>
                                                <?php esc_html_e( 'Free', 'authorwings-ai-tools' ); ?>
                                            <?php else : ?>
                                                $<?php echo esc_html( number_format( (float) $plan['price_monthly'], 2 ) ); ?> / <?php esc_html_e( 'month', 'authorwings-ai-tools' ); ?><br>
                                                $<?php echo esc_html( number_format( (float) $plan['price_yearly'], 2 ) ); ?> / <?php esc_html_e( 'year', 'authorwings-ai-tools' ); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo esc_html( $limit < 0 ? __( 'Unlimited', 'authorwings-ai-tools' ) : $limit . '/month' ); ?></td>
                                        <td><?php echo esc_html( ucfirst( (string) ( $plan['limits']['tools_access'] ?? 'free' ) ) ); ?></td>
                                        <td><?php echo ! empty( $plan['is_active'] ) ? esc_html__( 'Active', 'authorwings-ai-tools' ) : esc_html__( 'Inactive', 'authorwings-ai-tools' ); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    public function page_orders(): void {
        if ( ! current_user_can( 'manage_awg_membership' ) ) { wp_die( esc_html__( 'You do not have permission to access this page.', 'authorwings-ai-tools' ), 403 ); }
        global $wpdb;
        $table = Database::orders_table();

        if ( isset( $_POST['awg_order_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST['awg_order_nonce'] ) ), 'awg_update_order' ) ) {
            $order_id = isset( $_POST['awg_order_id'] ) ? (int) wp_unslash( (string) $_POST['awg_order_id'] ) : 0;
            $status   = isset( $_POST['awg_order_status'] ) ? sanitize_key( wp_unslash( (string) $_POST['awg_order_status'] ) ) : 'pending';
            $notes    = isset( $_POST['awg_order_notes'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['awg_order_notes'] ) ) : '';

            if ( 'in_progress' === $status ) {
                $status = 'responded';
            } elseif ( 'completed' === $status ) {
                $status = 'closed';
            }

            if ( ! in_array( $status, [ 'pending', 'responded', 'closed' ], true ) ) {
                $status = 'pending';
            }

            if ( $order_id > 0 ) {
                $updated = $wpdb->update(
                    $table,
                    [
                        'status'      => $status,
                        'admin_notes' => $notes,
                        'updated_at'  => current_time( 'mysql' ),
                    ],
                    [ 'id' => $order_id ],
                    [ '%s', '%s', '%s' ],
                    [ '%d' ]
                );

                if ( false !== $updated ) {
                    echo '<div class="notice notice-success"><p>' . esc_html__( 'Quote request updated.', 'authorwings-ai-tools' ) . '</p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>' . esc_html__( 'Could not update this quote request.', 'authorwings-ai-tools' ) . '</p></div>';
                }
            }
        }

        $edit_order_id   = isset( $_GET['edit_order'] ) ? (int) wp_unslash( (string) $_GET['edit_order'] ) : 0;
        $view_order_id   = isset( $_GET['view_order'] ) ? (int) wp_unslash( (string) $_GET['view_order'] ) : 0;
        $search_query    = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['s'] ) ) : '';
        $status_filter   = isset( $_GET['request_status'] ) ? sanitize_key( wp_unslash( (string) $_GET['request_status'] ) ) : '';
        if ( 'in_progress' === $status_filter ) {
            $status_filter = 'responded';
        } elseif ( 'completed' === $status_filter ) {
            $status_filter = 'closed';
        }
        if ( ! in_array( $status_filter, [ '', 'pending', 'responded', 'closed' ], true ) ) {
            $status_filter = '';
        }

        $where = [];
        $args  = [];

        if ( '' !== $status_filter ) {
            $where[] = 'o.status = %s';
            $args[]  = $status_filter;
        }

        if ( '' !== $search_query ) {
            $like = '%' . $wpdb->esc_like( $search_query ) . '%';
            $where[] = '(o.service_name LIKE %s OR o.service_slug LIKE %s OR o.notes LIKE %s OR o.admin_notes LIKE %s OR u.display_name LIKE %s OR u.user_email LIKE %s)';
            array_push( $args, $like, $like, $like, $like, $like, $like );
        }

        $sql = "SELECT o.*, u.display_name, u.user_email FROM {$table} o LEFT JOIN {$wpdb->users} u ON u.ID = o.user_id";
        if ( ! empty( $where ) ) {
            $sql .= ' WHERE ' . implode( ' AND ', $where );
        }
        $sql .= ' ORDER BY o.id DESC LIMIT 100';

        if ( ! empty( $args ) ) {
            $orders = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
        } else {
            $orders = $wpdb->get_results( $sql, ARRAY_A );
        }

        $count_total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        $count_pending = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'pending'" );
        $count_responded = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status IN ('responded','in_progress')" );
        $count_closed = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status IN ('closed','completed')" );
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'Quote Requests', 'authorwings-ai-tools' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Basic workflow only: Pending, Responded, Closed.', 'authorwings-ai-tools' ); ?></p>

            <div class="awg-stat-grid">
                <div class="awg-stat-tile"><div class="awg-stat-tile__label"><?php esc_html_e( 'Total Requests', 'authorwings-ai-tools' ); ?></div><div class="awg-stat-tile__value"><?php echo esc_html( $count_total ); ?></div></div>
                <div class="awg-stat-tile"><div class="awg-stat-tile__label"><?php esc_html_e( 'Pending', 'authorwings-ai-tools' ); ?></div><div class="awg-stat-tile__value"><?php echo esc_html( $count_pending ); ?></div></div>
                <div class="awg-stat-tile"><div class="awg-stat-tile__label"><?php esc_html_e( 'Responded', 'authorwings-ai-tools' ); ?></div><div class="awg-stat-tile__value"><?php echo esc_html( $count_responded ); ?></div></div>
                <div class="awg-stat-tile"><div class="awg-stat-tile__label"><?php esc_html_e( 'Closed', 'authorwings-ai-tools' ); ?></div><div class="awg-stat-tile__value"><?php echo esc_html( $count_closed ); ?></div></div>
            </div>

            <form method="get" class="awg-filter-form">
                <input type="hidden" name="page" value="awg-membership-orders">
                <div>
                    <label for="awg-quote-search" class="awg-form-field-block"><?php esc_html_e( 'Search', 'authorwings-ai-tools' ); ?></label>
                    <input type="search" id="awg-quote-search" name="s" value="<?php echo esc_attr( $search_query ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'Service, user, email, notes', 'authorwings-ai-tools' ); ?>">
                </div>
                <div>
                    <label for="awg-request-status" class="awg-form-field-block"><?php esc_html_e( 'Status', 'authorwings-ai-tools' ); ?></label>
                    <select id="awg-request-status" name="request_status">
                        <option value=""><?php esc_html_e( 'All statuses', 'authorwings-ai-tools' ); ?></option>
                        <option value="pending" <?php selected( $status_filter, 'pending' ); ?>><?php esc_html_e( 'Pending', 'authorwings-ai-tools' ); ?></option>
                        <option value="responded" <?php selected( $status_filter, 'responded' ); ?>><?php esc_html_e( 'Responded', 'authorwings-ai-tools' ); ?></option>
                        <option value="closed" <?php selected( $status_filter, 'closed' ); ?>><?php esc_html_e( 'Closed', 'authorwings-ai-tools' ); ?></option>
                    </select>
                </div>
                <div class="awg-actions-inline">
                    <button type="submit" class="button button-primary awg-btn-primary"><?php esc_html_e( 'Filter', 'authorwings-ai-tools' ); ?></button>
                    <a class="button awg-btn-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-orders' ) ); ?>"><?php esc_html_e( 'Reset', 'authorwings-ai-tools' ); ?></a>
                </div>
            </form>

            <table class="widefat striped awg-table-compact">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th><?php esc_html_e( 'Service', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'User', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Request Details', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Admin Notes', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Date', 'authorwings-ai-tools' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'authorwings-ai-tools' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $orders ) ) : ?>
                        <tr><td colspan="8"><?php esc_html_e( 'No quote requests found.', 'authorwings-ai-tools' ); ?></td></tr>
                    <?php else : ?>
                        <?php foreach ( $orders as $o ) : ?>
                            <?php
                            $row_status = sanitize_key( (string) ( $o['status'] ?? 'pending' ) );
                            if ( 'in_progress' === $row_status ) {
                                $row_status = 'responded';
                            } elseif ( 'completed' === $row_status ) {
                                $row_status = 'closed';
                            }
                            if ( ! in_array( $row_status, [ 'pending', 'responded', 'closed' ], true ) ) {
                                $row_status = 'pending';
                            }
                            ?>
                            <tr>
                                <td><?php echo esc_html( (int) $o['id'] ); ?></td>
                                <td><strong><?php echo esc_html( (string) $o['service_name'] ); ?></strong></td>
                                <td><?php echo esc_html( (string) $o['display_name'] ); ?><br><small><?php echo esc_html( (string) $o['user_email'] ); ?></small></td>
                                <td><?php echo wp_kses_post( $this->get_status_badge_markup( $row_status ) ); ?></td>
                                <td><?php echo esc_html( wp_trim_words( (string) $o['notes'], 18 ) ); ?></td>
                                <td><?php echo esc_html( wp_trim_words( (string) $o['admin_notes'], 18 ) ?: '—' ); ?></td>
                                <td><?php echo esc_html( wp_date( 'd M Y', strtotime( (string) $o['created_at'] ) ) ); ?></td>
                                <td>
                                    <a class="button button-small awg-btn-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-orders&view_order=' . (int) $o['id'] ) ); ?>"><?php esc_html_e( 'View', 'authorwings-ai-tools' ); ?></a>
                                    <a class="button button-small awg-btn-edit" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-orders&edit_order=' . (int) $o['id'] ) ); ?>"><?php esc_html_e( 'Edit', 'authorwings-ai-tools' ); ?></a>
                                    <?php
                                    // Book-project portal: offer to start (or open) a project for
                                    // this order when the dashboard sub-module is active and the
                                    // current user can manage projects.
                                    if ( class_exists( '\\AWG_DASH\\Projects' ) && current_user_can( 'awg_manage_projects' ) ) :
                                        $awg_existing_project = ( new \AWG_DASH\Projects() )->find_by_order( (int) $o['id'] );
                                        if ( $awg_existing_project ) : ?>
                                            <a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-dash-projects&project=' . (int) $awg_existing_project['id'] ) ); ?>"><?php esc_html_e( 'View project', 'authorwings-ai-tools' ); ?></a>
                                        <?php else : ?>
                                            <a class="button button-small button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-dash-projects&from_order=' . (int) $o['id'] ) ); ?>"><?php esc_html_e( 'Start project', 'authorwings-ai-tools' ); ?></a>
                                        <?php endif;
                                    endif;
                                    ?>
                                </td>
                            </tr>
                            <?php if ( $view_order_id === (int) $o['id'] ) : ?>
                                <?php
                                // v3.0.1 — decode the meta JSON once so the
                                // detail row can show any uploaded attachments
                                // beneath the request body.
                                $o_meta = [];
                                if ( ! empty( $o['meta'] ) ) {
                                    $decoded = json_decode( (string) $o['meta'], true );
                                    if ( is_array( $decoded ) ) { $o_meta = $decoded; }
                                }
                                $o_attachments = isset( $o_meta['attachments'] ) && is_array( $o_meta['attachments'] ) ? $o_meta['attachments'] : [];
                                ?>
                                <tr>
                                    <td colspan="8" class="awg-order-detail-row">
                                        <div class="awg-order-detail-stack">
                                            <div><strong><?php esc_html_e( 'Full Request Details', 'authorwings-ai-tools' ); ?></strong><div class="awg-order-detail-pre"><?php echo esc_html( (string) $o['notes'] ); ?></div></div>
                                            <?php if ( ! empty( $o_attachments ) ) : ?>
                                                <div>
                                                    <strong><?php esc_html_e( 'Attachments', 'authorwings-ai-tools' ); ?></strong>
                                                    <ul style="margin:6px 0 0 18px;padding:0;">
                                                        <?php foreach ( $o_attachments as $att ) : ?>
                                                            <?php
                                                            $a_url  = isset( $att['url'] )  ? esc_url( (string) $att['url'] )  : '';
                                                            $a_name = isset( $att['name'] ) ? esc_html( (string) $att['name'] ) : '';
                                                            if ( $a_url === '' ) { continue; }
                                                            ?>
                                                            <li><a href="<?php echo $a_url; ?>" target="_blank" rel="noopener noreferrer"><?php echo $a_name ?: esc_html__( 'Download attachment', 'authorwings-ai-tools' ); ?></a></li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                            <div><strong><?php esc_html_e( 'Admin Notes', 'authorwings-ai-tools' ); ?></strong><div class="awg-order-detail-pre"><?php echo esc_html( (string) ( $o['admin_notes'] ?: '—' ) ); ?></div></div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            <?php if ( $edit_order_id === (int) $o['id'] ) : ?>
                                <tr>
                                    <td colspan="8" class="awg-order-detail-row">
                                        <form method="post" class="awg-order-detail-stack awg-order-detail-stack--form">
                                            <?php wp_nonce_field( 'awg_update_order', 'awg_order_nonce' ); ?>
                                            <input type="hidden" name="awg_order_id" value="<?php echo esc_attr( $o['id'] ); ?>">
                                            <div>
                                                <label for="awg-order-status-<?php echo esc_attr( $o['id'] ); ?>" class="awg-form-field-block"><?php esc_html_e( 'Request Status', 'authorwings-ai-tools' ); ?></label>
                                                <select id="awg-order-status-<?php echo esc_attr( $o['id'] ); ?>" name="awg_order_status">
                                                    <option value="pending" <?php selected( $row_status, 'pending' ); ?>><?php esc_html_e( 'Pending', 'authorwings-ai-tools' ); ?></option>
                                                    <option value="responded" <?php selected( $row_status, 'responded' ); ?>><?php esc_html_e( 'Responded', 'authorwings-ai-tools' ); ?></option>
                                                    <option value="closed" <?php selected( $row_status, 'closed' ); ?>><?php esc_html_e( 'Closed', 'authorwings-ai-tools' ); ?></option>
                                                </select>
                                            </div>
                                            <div>
                                                <label for="awg-order-notes-<?php echo esc_attr( $o['id'] ); ?>" class="awg-form-field-block"><?php esc_html_e( 'Admin Notes', 'authorwings-ai-tools' ); ?></label>
                                                <textarea id="awg-order-notes-<?php echo esc_attr( $o['id'] ); ?>" name="awg_order_notes" rows="5" class="large-text"><?php echo esc_textarea( (string) $o['admin_notes'] ); ?></textarea>
                                            </div>
                                            <div class="awg-actions-inline">
                                                <button type="submit" class="button button-primary awg-btn-primary"><?php esc_html_e( 'Save', 'authorwings-ai-tools' ); ?></button>
                                                <a class="button awg-btn-secondary" href="<?php echo esc_url( admin_url( 'admin.php?page=awg-membership-orders' ) ); ?>"><?php esc_html_e( 'Cancel', 'authorwings-ai-tools' ); ?></a>
                                            </div>
                                        </form>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * v3.1.7 — Dashboard Builder. Lets admins reorder / show-hide / re-title
     * every member-dashboard section per tab, edit per-widget options, and
     * insert custom content blocks. Saved to the awg_mem_dashboard_layout
     * option; an empty option means the dashboard renders its stock layout.
     */
    public function page_dashboard_builder(): void {
        if ( ! current_user_can( 'manage_awg_membership' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'authorwings-ai-tools' ), 403 );
        }

        // The Dashboard Builder depends on the DashboardSections class, which is
        // not shipped in the lean build. This page is not registered by the lean
        // loader, but guard anyway so a future re-hook of the full admin menu
        // degrades gracefully instead of fataling on an undefined class.
        if ( ! class_exists( '\\AWG_MEM\\DashboardSections' ) ) {
            echo '<div class="wrap"><h1>' . esc_html__( 'Dashboard Builder', 'authorwings-ai-tools' ) . '</h1>';
            echo '<div class="notice notice-warning"><p>' . esc_html__( 'The Dashboard Builder is unavailable in this build.', 'authorwings-ai-tools' ) . '</p></div></div>';
            return;
        }

        $notice = '';

        if ( isset( $_POST['awg_reset_dashboard_layout'] ) && check_admin_referer( 'awg_mem_dashboard_builder' ) ) {
            delete_option( DashboardSections::OPTION );
            $notice = '<div class="notice notice-success"><p>' . esc_html__( 'Dashboard layout reset to defaults.', 'authorwings-ai-tools' ) . '</p></div>';
        }

        if ( isset( $_POST['awg_save_dashboard_layout'] ) && check_admin_referer( 'awg_mem_dashboard_builder' ) ) {
            $raw   = isset( $_POST['awg_dashboard_layout_json'] ) && is_array( $_POST['awg_dashboard_layout_json'] ) ? wp_unslash( $_POST['awg_dashboard_layout_json'] ) : [];
            $input = [];
            foreach ( $raw as $tab => $json ) {
                $decoded = json_decode( (string) $json, true );
                if ( is_array( $decoded ) ) {
                    $input[ sanitize_key( $tab ) ] = $decoded;
                }
            }
            update_option( DashboardSections::OPTION, DashboardSections::sanitize( $input ) );
            $notice = '<div class="notice notice-success"><p>' . esc_html__( 'Dashboard layout saved.', 'authorwings-ai-tools' ) . '</p></div>';
        }

        $registry = DashboardSections::registry();
        $tabs     = DashboardSections::tabs();
        ?>
        <div class="wrap awg-mem-admin-wrap awg-builder-wrap">
            <h1><?php esc_html_e( 'Dashboard Builder', 'authorwings-ai-tools' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Drag to reorder, toggle visibility, edit each widget’s options, and add custom content blocks for every member-dashboard tab. Leave everything as-is to keep the default layout.', 'authorwings-ai-tools' ); ?></p>
            <?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

            <form method="post" class="awg-builder-form">
                <?php wp_nonce_field( 'awg_mem_dashboard_builder' ); ?>

                <div class="awg-builder-tabs-nav">
                    <?php $first = true; foreach ( $tabs as $tab_key => $tab_label ) : ?>
                        <button type="button" class="button awg-builder-tab-btn<?php echo $first ? ' button-primary' : ''; ?>" data-builder-tab="<?php echo esc_attr( $tab_key ); ?>"><?php echo esc_html( $tab_label ); ?></button>
                    <?php $first = false; endforeach; ?>
                </div>

                <?php $first = true; foreach ( $tabs as $tab_key => $tab_label ) : ?>
                    <input type="hidden" name="awg_dashboard_layout_json[<?php echo esc_attr( $tab_key ); ?>]" data-builder-json="<?php echo esc_attr( $tab_key ); ?>" value="" />
                    <div class="awg-builder-panel" data-builder-panel="<?php echo esc_attr( $tab_key ); ?>"<?php echo $first ? '' : ' style="display:none;"'; ?>>
                        <div class="awg-builder-panel__head">
                            <h2><?php echo esc_html( $tab_label ); ?></h2>
                            <button type="button" class="button awg-builder-add-block" data-builder-add="<?php echo esc_attr( $tab_key ); ?>"><?php esc_html_e( '+ Add content block', 'authorwings-ai-tools' ); ?></button>
                        </div>
                        <ul class="awg-builder-list" data-builder-list="<?php echo esc_attr( $tab_key ); ?>">
                            <?php
                            foreach ( DashboardSections::resolve( $tab_key ) as $row ) {
                                $is_content = ( $row['type'] === 'content' );
                                $meta       = $is_content ? null : ( $registry[ $tab_key ][ $row['id'] ] ?? null );
                                if ( ! $is_content && ! $meta ) { continue; }
                                $label  = $is_content ? __( 'Custom content block', 'authorwings-ai-tools' ) : (string) $meta['label'];
                                $fields = $is_content ? [] : (array) $meta['fields'];
                                $this->render_builder_row( $row, $label, $fields, $is_content );
                            }
                            ?>
                        </ul>
                    </div>
                <?php $first = false; endforeach; ?>

                <?php // Hidden template used by JS to clone new content blocks. ?>
                <script type="text/html" data-builder-content-template>
                    <?php $this->render_builder_row( [ 'id' => '__NEW__', 'type' => 'content', 'visible' => true, 'title' => '', 'html' => '', 'attrs' => [] ], __( 'Custom content block', 'authorwings-ai-tools' ), [], true ); ?>
                </script>

                <p class="awg-builder-actions">
                    <button type="submit" name="awg_save_dashboard_layout" value="1" class="button button-primary"><?php esc_html_e( 'Save layout', 'authorwings-ai-tools' ); ?></button>
                    <button type="submit" name="awg_reset_dashboard_layout" value="1" class="button" onclick="return confirm('<?php echo esc_js( __( 'Reset every tab to the default layout? Your customizations will be lost.', 'authorwings-ai-tools' ) ); ?>');"><?php esc_html_e( 'Reset to defaults', 'authorwings-ai-tools' ); ?></button>
                </p>
            </form>
        </div>
        <?php
    }

    /**
     * Render one builder row (a section or a custom content block).
     */
    private function render_builder_row( array $row, string $label, array $fields, bool $is_content ): void {
        $visible = ! isset( $row['visible'] ) || ! empty( $row['visible'] );
        ?>
        <li class="awg-builder-row<?php echo $is_content ? ' awg-builder-row--content' : ''; ?>" data-row-id="<?php echo esc_attr( (string) $row['id'] ); ?>" data-row-type="<?php echo $is_content ? 'content' : 'dynamic'; ?>">
            <div class="awg-builder-row__head">
                <span class="awg-builder-row__handle" title="<?php esc_attr_e( 'Drag to reorder', 'authorwings-ai-tools' ); ?>">&#9776;</span>
                <label class="awg-builder-row__vis"><input type="checkbox" class="awg-builder-visible" <?php checked( $visible ); ?> /> <?php esc_html_e( 'Visible', 'authorwings-ai-tools' ); ?></label>
                <strong class="awg-builder-row__label"><?php echo esc_html( $label ); ?></strong>
                <?php if ( $is_content ) : ?>
                    <button type="button" class="button-link awg-builder-remove" title="<?php esc_attr_e( 'Remove', 'authorwings-ai-tools' ); ?>"><?php esc_html_e( 'Remove', 'authorwings-ai-tools' ); ?></button>
                <?php endif; ?>
            </div>

            <?php if ( $is_content ) :
                $content_html = (string) ( $row['html'] ?? '' );
                // Start in block-editor mode when the saved markup already looks
                // like blocks; otherwise show the raw HTML/shortcode textarea.
                $starts_blocks = ( strpos( $content_html, '<!-- wp:' ) !== false );
                ?>
                <div class="awg-builder-row__body awg-builder-content" data-awg-content-editor data-mode="<?php echo $starts_blocks ? 'blocks' : 'html'; ?>">
                    <input type="text" class="regular-text awg-builder-title" placeholder="<?php esc_attr_e( 'Optional heading', 'authorwings-ai-tools' ); ?>" value="<?php echo esc_attr( (string) ( $row['title'] ?? '' ) ); ?>" />

                    <div class="awg-builder-content__modes">
                        <button type="button" class="button awg-builder-mode" data-set-mode="blocks"><?php esc_html_e( 'Edit with blocks', 'authorwings-ai-tools' ); ?></button>
                        <button type="button" class="button awg-builder-mode" data-set-mode="html"><?php esc_html_e( 'Edit as HTML / shortcode', 'authorwings-ai-tools' ); ?></button>
                    </div>

                    <?php // Block-editor mount point. The editor reads/writes the textarea below, which stays the single source of truth on save. ?>
                    <div class="awg-builder-blockeditor" data-awg-blockeditor data-placeholder="<?php esc_attr_e( 'Click here to design this block in the editor…', 'authorwings-ai-tools' ); ?>"></div>

                    <textarea class="large-text awg-builder-html" rows="4" placeholder="<?php esc_attr_e( 'HTML or shortcodes — e.g. [awg_usage_meter] or [awg_ai_tools]', 'authorwings-ai-tools' ); ?>"><?php echo esc_textarea( $content_html ); ?></textarea>
                </div>
            <?php elseif ( ! empty( $fields ) ) : ?>
                <div class="awg-builder-row__body awg-builder-row__fields">
                    <?php foreach ( $fields as $key => $field ) :
                        $val = $row['attrs'][ $key ] ?? ( $field['default'] ?? '' );
                        $fid = 'awgf_' . esc_attr( (string) $row['id'] ) . '_' . esc_attr( $key );
                        ?>
                        <div class="awg-builder-field" data-attr-key="<?php echo esc_attr( $key ); ?>">
                            <?php if ( $field['type'] === 'toggle' ) : ?>
                                <label><input type="checkbox" class="awg-builder-attr" data-attr-type="toggle" <?php checked( ! empty( $val ) ); ?> /> <?php echo esc_html( $field['label'] ); ?></label>
                            <?php elseif ( $field['type'] === 'number' ) : ?>
                                <label><?php echo esc_html( $field['label'] ); ?>
                                    <input type="number" class="small-text awg-builder-attr" data-attr-type="number" value="<?php echo esc_attr( (string) $val ); ?>" <?php echo isset( $field['min'] ) ? 'min="' . (int) $field['min'] . '"' : ''; ?> <?php echo isset( $field['max'] ) ? 'max="' . (int) $field['max'] . '"' : ''; ?> />
                                </label>
                            <?php elseif ( $field['type'] === 'select' ) : ?>
                                <label><?php echo esc_html( $field['label'] ); ?>
                                    <select class="awg-builder-attr" data-attr-type="select">
                                        <?php foreach ( (array) ( $field['choices'] ?? [] ) as $choice ) : ?>
                                            <option value="<?php echo esc_attr( $choice ); ?>" <?php selected( (string) $val, (string) $choice ); ?>><?php echo esc_html( $choice ); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                            <?php elseif ( $field['type'] === 'textarea' ) : ?>
                                <label class="awg-builder-field--full"><?php echo esc_html( $field['label'] ); ?>
                                    <textarea class="large-text awg-builder-attr" data-attr-type="text" rows="2"><?php echo esc_textarea( (string) $val ); ?></textarea>
                                </label>
                            <?php else : ?>
                                <label class="awg-builder-field--full"><?php echo esc_html( $field['label'] ); ?>
                                    <input type="text" class="regular-text awg-builder-attr" data-attr-type="text" value="<?php echo esc_attr( (string) $val ); ?>" />
                                </label>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </li>
        <?php
    }

    public function page_settings(): void {
        if ( ! current_user_can( 'manage_awg_membership' ) ) { wp_die( esc_html__( 'You do not have permission to access this page.', 'authorwings-ai-tools' ), 403 ); }
        $s = get_option( Plugin::OPT, [] );
        ?>
        <div class="wrap awg-mem-admin-wrap">
            <h1><?php esc_html_e( 'AuthorWings Membership Settings', 'authorwings-ai-tools' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'awg_mem_settings_group' ); ?>

                <h2><?php esc_html_e( 'General Settings', 'authorwings-ai-tools' ); ?></h2>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e( 'Admin Notification Email', 'authorwings-ai-tools' ); ?></th>
                        <td>
                            <input type="email" name="<?php echo esc_attr( Plugin::OPT ); ?>[notify_admin_email]"
                                   value="<?php echo esc_attr( $s['notify_admin_email'] ?? get_option( 'admin_email' ) ); ?>"
                                   class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Secret Key', 'authorwings-ai-tools' ); ?></th>
                        <td>
                            <input type="password" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_secret_key]"
                                   value="" placeholder="<?php echo ! empty( $s['stripe_secret_key'] ) ? esc_attr__( 'Saved — leave blank to keep the current key', 'authorwings-ai-tools' ) : ''; ?>"
                                   class="regular-text" autocomplete="off">
                            <p class="description"><?php esc_html_e( 'Your Stripe secret key (sk_live_... or sk_test_...). For security the saved key is never shown again; leave this blank to keep it, or paste a new key to replace it.', 'authorwings-ai-tools' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Publishable Key', 'authorwings-ai-tools' ); ?></th>
                        <td>
                            <input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_public_key]"
                                   value="<?php echo esc_attr( $s['stripe_public_key'] ?? '' ); ?>"
                                   class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Stripe Webhook Secret', 'authorwings-ai-tools' ); ?></th>
                        <td>
                            <input type="password" name="<?php echo esc_attr( Plugin::OPT ); ?>[stripe_webhook_secret]"
                                   value="" placeholder="<?php echo ! empty( $s['stripe_webhook_secret'] ) ? esc_attr__( 'Saved — leave blank to keep the current secret', 'authorwings-ai-tools' ) : ''; ?>"
                                   class="regular-text" autocomplete="off">
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Dashboard Page', 'authorwings-ai-tools' ); ?></th>
                        <td>
                            <?php
                            wp_dropdown_pages( [
                                'name'             => esc_attr( Plugin::OPT ) . '[dashboard_page_id]',
                                'selected'         => (int) ( $s['dashboard_page_id'] ?? 0 ),
                                'show_option_none' => '— ' . __( 'Auto (member-dashboard)', 'authorwings-ai-tools' ) . ' —',
                            ] );
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Pricing Page', 'authorwings-ai-tools' ); ?></th>
                        <td>
                            <?php
                            wp_dropdown_pages( [
                                'name'             => esc_attr( Plugin::OPT ) . '[pricing_page_id]',
                                'selected'         => (int) ( $s['pricing_page_id'] ?? 0 ),
                                'show_option_none' => '— ' . __( 'Auto (pricing)', 'authorwings-ai-tools' ) . ' —',
                            ] );
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Renewal reminder (days before)', 'authorwings-ai-tools' ); ?></th>
                        <td><input type="number" min="0" max="30" name="<?php echo esc_attr( Plugin::OPT ); ?>[renewal_reminder_days]" value="<?php echo esc_attr( $s['renewal_reminder_days'] ?? 7 ); ?>" class="small-text"><p class="description"><?php esc_html_e( 'Email paid members this many days before their plan renews. 0 disables the reminder.', 'authorwings-ai-tools' ); ?></p></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Enable sanitized error logging', 'authorwings-ai-tools' ); ?></th>
                        <td><label><input type="checkbox" name="<?php echo esc_attr( Plugin::OPT ); ?>[enable_error_logging]" value="1" <?php checked( ! empty( $s['enable_error_logging'] ) ); ?>> <?php esc_html_e( 'Keep billing and membership errors in an internal log without exposing secrets.', 'authorwings-ai-tools' ); ?></label></td>
                    </tr>
                    <tr><th><?php esc_html_e( 'Error log retention (days)', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[log_retention_days]" value="<?php echo esc_attr( $s['log_retention_days'] ?? 30 ); ?>" class="small-text"><p class="description"><?php esc_html_e( '0 keeps logs until manually cleared. Positive values remove older logs during daily cleanup.', 'authorwings-ai-tools' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Usage retention (days)', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[usage_retention_days]" value="<?php echo esc_attr( $s['usage_retention_days'] ?? 0 ); ?>" class="small-text"><p class="description"><?php esc_html_e( '0 keeps usage records indefinitely.', 'authorwings-ai-tools' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Quote request retention (days)', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[order_retention_days]" value="<?php echo esc_attr( $s['order_retention_days'] ?? 0 ); ?>" class="small-text"><p class="description"><?php esc_html_e( '0 keeps quote request records indefinitely.', 'authorwings-ai-tools' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Cancelled membership retention (days)', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[membership_retention_days]" value="<?php echo esc_attr( $s['membership_retention_days'] ?? 0 ); ?>" class="small-text"><p class="description"><?php esc_html_e( 'Only cancelled, expired, or erased membership rows are auto-removed. 0 disables automatic deletion.', 'authorwings-ai-tools' ); ?></p></td></tr>
                </table>

                <h2><?php esc_html_e( 'Dashboard Design Settings', 'authorwings-ai-tools' ); ?></h2>

                <h3><?php esc_html_e( 'Colors', 'authorwings-ai-tools' ); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e( 'Primary', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_primary_color]" value="<?php echo esc_attr( $s['dashboard_primary_color'] ?? '#10243c' ); ?>" class="regular-text awg-color-field" data-default-color="#10243c"></td></tr>
                    <tr><th><?php esc_html_e( 'Background', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_bg_color]" value="<?php echo esc_attr( $s['dashboard_bg_color'] ?? '#fbf8f2' ); ?>" class="regular-text awg-color-field" data-default-color="#fbf8f2"></td></tr>
                    <tr><th><?php esc_html_e( 'Card Background', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_card_bg]" value="<?php echo esc_attr( $s['dashboard_card_bg'] ?? '#ffffff' ); ?>" class="regular-text awg-color-field" data-default-color="#ffffff"></td></tr>
                    <tr><th><?php esc_html_e( 'Text', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_text_color]" value="<?php echo esc_attr( $s['dashboard_text_color'] ?? '#10243c' ); ?>" class="regular-text awg-color-field" data-default-color="#10243c"></td></tr>
                    <tr><th><?php esc_html_e( 'Border', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_border_color]" value="<?php echo esc_attr( $s['dashboard_border_color'] ?? '#e8decf' ); ?>" class="regular-text awg-color-field" data-default-color="#e8decf"></td></tr>
                </table>

                <h3><?php esc_html_e( 'Typography', 'authorwings-ai-tools' ); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e( 'Font Family', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_font_family]" value="<?php echo esc_attr( $s['dashboard_font_family'] ?? '-apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, sans-serif' ); ?>" class="regular-text"><p class="description"><?php esc_html_e( 'Example: Roboto, Arial, sans-serif', 'authorwings-ai-tools' ); ?></p></td></tr>
                    <tr><th><?php esc_html_e( 'Heading Font', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_heading_font]" value="<?php echo esc_attr( $s['dashboard_heading_font'] ?? '-apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Roboto, sans-serif' ); ?>" class="regular-text"></td></tr>
                    <tr><th><?php esc_html_e( 'Base Size', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="12" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_font_size]" value="<?php echo esc_attr( $s['dashboard_font_size'] ?? 16 ); ?>" class="small-text"> px</td></tr>
                </table>

                <h3><?php esc_html_e( 'Buttons', 'authorwings-ai-tools' ); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e( 'Background', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_button_bg]" value="<?php echo esc_attr( $s['dashboard_button_bg'] ?? '#10243c' ); ?>" class="regular-text awg-color-field" data-default-color="#10243c"></td></tr>
                    <tr><th><?php esc_html_e( 'Text', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_button_text]" value="<?php echo esc_attr( $s['dashboard_button_text'] ?? '#ffffff' ); ?>" class="regular-text awg-color-field" data-default-color="#ffffff"></td></tr>
                    <tr><th><?php esc_html_e( 'Hover', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_button_hover]" value="<?php echo esc_attr( $s['dashboard_button_hover'] ?? '#7e9374' ); ?>" class="regular-text awg-color-field" data-default-color="#7e9374"></td></tr>
                    <tr><th><?php esc_html_e( 'Radius', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_button_radius]" value="<?php echo esc_attr( $s['dashboard_button_radius'] ?? 12 ); ?>" class="small-text"> px</td></tr>
                </table>

                <h3><?php esc_html_e( 'Cards', 'authorwings-ai-tools' ); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e( 'Padding', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_card_padding]" value="<?php echo esc_attr( $s['dashboard_card_padding'] ?? 20 ); ?>" class="small-text"> px</td></tr>
                    <tr><th><?php esc_html_e( 'Shadow', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_card_shadow]" value="<?php echo esc_attr( $s['dashboard_card_shadow'] ?? '0 10px 28px rgba(3,12,23,.04)' ); ?>" class="regular-text"></td></tr>
                    <tr><th><?php esc_html_e( 'Hover Shadow', 'authorwings-ai-tools' ); ?></th><td><input type="text" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_card_hover_shadow]" value="<?php echo esc_attr( $s['dashboard_card_hover_shadow'] ?? '0 12px 30px rgba(26,115,232,.12)' ); ?>" class="regular-text"></td></tr>
                    <tr><th><?php esc_html_e( 'Border Width', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="0" step="0.5" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_card_border_width]" value="<?php echo esc_attr( $s['dashboard_card_border_width'] ?? 1 ); ?>" class="small-text"> px</td></tr>
                </table>

                <h3><?php esc_html_e( 'Layout', 'authorwings-ai-tools' ); ?></h3>
                <table class="form-table">
                    <tr><th><?php esc_html_e( 'Max Width', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="320" step="10" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_max_width]" value="<?php echo esc_attr( $s['dashboard_max_width'] ?? 960 ); ?>" class="small-text"> px</td></tr>
                    <tr><th><?php esc_html_e( 'Container Padding', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_container_padding]" value="<?php echo esc_attr( $s['dashboard_container_padding'] ?? 0 ); ?>" class="small-text"> px</td></tr>
                    <tr><th><?php esc_html_e( 'Grid Gap', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_grid_gap]" value="<?php echo esc_attr( $s['dashboard_grid_gap'] ?? 16 ); ?>" class="small-text"> px</td></tr>
                    <tr><th><?php esc_html_e( 'Section Spacing', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_section_spacing]" value="<?php echo esc_attr( $s['dashboard_section_spacing'] ?? 28 ); ?>" class="small-text"> px</td></tr>
                    <tr><th><?php esc_html_e( 'Global Radius', 'authorwings-ai-tools' ); ?></th><td><input type="number" min="0" name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_radius]" value="<?php echo esc_attr( $s['dashboard_radius'] ?? 12 ); ?>" class="small-text"> px</td></tr>
                </table>

                <h3><?php esc_html_e( 'Advanced', 'authorwings-ai-tools' ); ?></h3>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e( 'Custom CSS', 'authorwings-ai-tools' ); ?></th>
                        <td>
                            <textarea name="<?php echo esc_attr( Plugin::OPT ); ?>[dashboard_custom_css]" rows="12" class="large-text code"><?php echo esc_textarea( $s['dashboard_custom_css'] ?? '' ); ?></textarea>
                            <p class="description"><?php esc_html_e( 'Target selectors like .awg-mem-dashboard, .awg-mem-tools-hero, .awg-mem-quick-card, .awg-mem-usage-card, and .awg-mem-tab.', 'authorwings-ai-tools' ); ?></p>
                        </td>
                    </tr>
                    <tr><th><?php esc_html_e( 'Stored data summary', 'authorwings-ai-tools' ); ?></th><td><p class="description"><?php esc_html_e( 'This plugin stores membership plan records, Stripe customer and subscription identifiers, usage counts, and quote request notes.', 'authorwings-ai-tools' ); ?></p></td></tr>
                </table>

                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}
