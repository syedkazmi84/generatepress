<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Database {

    public static function create_tables(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Plans table
        dbDelta( "CREATE TABLE {$wpdb->prefix}awg_mem_plans (
            id            BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            name          VARCHAR(100) NOT NULL DEFAULT '',
            slug          VARCHAR(100) NOT NULL DEFAULT '',
            description   TEXT         NULL,
            price_monthly DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            price_yearly  DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            currency      VARCHAR(10)  NOT NULL DEFAULT 'USD',
            is_free       TINYINT(1)   NOT NULL DEFAULT 0,
            is_active     TINYINT(1)   NOT NULL DEFAULT 1,
            is_popular    TINYINT(1)   NOT NULL DEFAULT 0,
            sort_order    INT(11)      NOT NULL DEFAULT 0,
            features      LONGTEXT     NULL,
            limits        LONGTEXT     NULL,
            stripe_monthly_price_id VARCHAR(100) NOT NULL DEFAULT '',
            stripe_yearly_price_id  VARCHAR(100) NOT NULL DEFAULT '',
            created_at    DATETIME     NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug)
        ) $charset;" );

        // Memberships table
        dbDelta( "CREATE TABLE {$wpdb->prefix}awg_mem_memberships (
            id                    BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id               BIGINT(20) UNSIGNED NOT NULL,
            plan_id               BIGINT(20) UNSIGNED NOT NULL,
            status                VARCHAR(20)  NOT NULL DEFAULT 'active',
            billing_cycle         VARCHAR(10)  NOT NULL DEFAULT 'monthly',
            start_date            DATETIME     NOT NULL,
            end_date              DATETIME              DEFAULT NULL,
            stripe_subscription_id VARCHAR(100) NOT NULL DEFAULT '',
            stripe_customer_id     VARCHAR(100) NOT NULL DEFAULT '',
            created_at            DATETIME     NOT NULL,
            updated_at            DATETIME     NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY plan_id (plan_id),
            KEY status  (status)
        ) $charset;" );

        // Usage tracking table
        dbDelta( "CREATE TABLE {$wpdb->prefix}awg_mem_usage (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id      BIGINT(20) UNSIGNED NOT NULL,
            service_slug VARCHAR(100) NOT NULL DEFAULT '',
            period       VARCHAR(7)   NOT NULL DEFAULT '',
            used         INT(11)      NOT NULL DEFAULT 0,
            updated_at   DATETIME     NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY user_service_period (user_id, service_slug, period)
        ) $charset;" );

        // Detailed usage log table
        dbDelta( "CREATE TABLE {$wpdb->prefix}awg_mem_usage_logs (
            id             BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            actor_user_id  BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            owner_user_id  BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            service_slug   VARCHAR(100) NOT NULL DEFAULT '',
            tool_name      VARCHAR(200) NOT NULL DEFAULT '',
            template_id    BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
            usage_count    INT(11)      NOT NULL DEFAULT 1,
            usage_date     DATE         NOT NULL,
            period         VARCHAR(7)   NOT NULL DEFAULT '',
            created_at     DATETIME     NOT NULL,
            PRIMARY KEY (id),
            KEY owner_user_id (owner_user_id),
            KEY actor_user_id (actor_user_id),
            KEY service_slug (service_slug),
            KEY usage_date (usage_date),
            KEY period (period)
        ) $charset;" );

        // Service orders table
        dbDelta( "CREATE TABLE {$wpdb->prefix}awg_mem_service_orders (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id      BIGINT(20) UNSIGNED NOT NULL,
            service_slug VARCHAR(100) NOT NULL DEFAULT '',
            service_name VARCHAR(200) NOT NULL DEFAULT '',
            status       VARCHAR(30)  NOT NULL DEFAULT 'pending',
            price        DECIMAL(10,2)         DEFAULT NULL,
            notes        TEXT         NULL,
            admin_notes  TEXT         NULL,
            meta         LONGTEXT     NULL,
            created_at   DATETIME     NOT NULL,
            updated_at   DATETIME     NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY status  (status)
        ) $charset;" );

        // v2.8.0 — support tickets table
        dbDelta( "CREATE TABLE {$wpdb->prefix}awg_mem_tickets (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id      BIGINT(20) UNSIGNED NOT NULL,
            user_email   VARCHAR(190) NOT NULL DEFAULT '',
            topic        VARCHAR(40)  NOT NULL DEFAULT 'other',
            priority     VARCHAR(20)  NOT NULL DEFAULT 'normal',
            subject      VARCHAR(255) NOT NULL DEFAULT '',
            body         LONGTEXT     NOT NULL,
            status       VARCHAR(20)  NOT NULL DEFAULT 'open',
            admin_reply  LONGTEXT     NULL,
            created_at   DATETIME     NOT NULL,
            updated_at   DATETIME     NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset;" );

        update_option( 'awg_mem_db_version', AWG_MEM_VERSION );
    }

    public static function tickets_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'awg_mem_tickets';
    }

    public static function plans_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'awg_mem_plans';
    }

    public static function mems_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'awg_mem_memberships';
    }

    public static function usage_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'awg_mem_usage';
    }

    public static function usage_logs_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'awg_mem_usage_logs';
    }

    public static function orders_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'awg_mem_service_orders';
    }
}
