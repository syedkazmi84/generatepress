<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Assets {

    public function frontend(): void {
        global $post;
        $has_dashboard = is_a( $post, 'WP_Post' ) && (
            has_shortcode( $post->post_content, 'awg_dashboard' ) ||
            has_shortcode( $post->post_content, 'awg_pricing' )
        );

        // v3.1.7 — also load on pages that embed a single dashboard widget via
        // its [awg_*] shortcode, so the widget gets its CSS/JS.
        if ( ! $has_dashboard && is_a( $post, 'WP_Post' ) && class_exists( '\\AWG_MEM\\DashboardSections' ) ) {
            foreach ( array_keys( \AWG_MEM\DashboardSections::shortcode_map() ) as $sc ) {
                if ( has_shortcode( $post->post_content, $sc ) ) {
                    $has_dashboard = true;
                    break;
                }
            }
        }

        // v3.4.0 — also load when the page uses an AuthorWings editor block,
        // which is stored as a block comment, not a shortcode.
        if ( ! $has_dashboard && is_a( $post, 'WP_Post' ) && class_exists( '\\AWG_MEM\\Blocks' ) ) {
            foreach ( \AWG_MEM\Blocks::names() as $block_name ) {
                if ( has_block( $block_name, $post ) ) {
                    $has_dashboard = true;
                    break;
                }
            }
        }

        if ( ! $has_dashboard ) { return; }

        // ── Membership plugin assets ────────────────────────
        wp_enqueue_style(
            'awg-mem-front',
            AWG_MEM_URL . 'assets/css/dashboard.css',
            [ 'dashicons' ],
            AWG_MEM_VERSION
        );

        $settings         = get_option( Plugin::OPT, [] );
        $primary          = sanitize_hex_color( $settings['dashboard_primary_color'] ?? '#10243c' ) ?: '#10243c';
        $bg               = sanitize_hex_color( $settings['dashboard_bg_color'] ?? '#fbf8f2' ) ?: '#fbf8f2';
        $card_bg          = sanitize_hex_color( $settings['dashboard_card_bg'] ?? '#ffffff' ) ?: '#ffffff';
        $text             = sanitize_hex_color( $settings['dashboard_text_color'] ?? '#10243c' ) ?: '#10243c';
        $border           = sanitize_hex_color( $settings['dashboard_border_color'] ?? '#e8decf' ) ?: '#e8decf';
        $font_family      = sanitize_text_field( $settings['dashboard_font_family'] ?? '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' );
        $heading_font     = sanitize_text_field( $settings['dashboard_heading_font'] ?? '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' );
        $font_size        = isset( $settings['dashboard_font_size'] ) ? max( 12, (int) $settings['dashboard_font_size'] ) : 16;
        $button_bg        = sanitize_hex_color( $settings['dashboard_button_bg'] ?? '#10243c' ) ?: '#10243c';
        $button_text      = sanitize_hex_color( $settings['dashboard_button_text'] ?? '#ffffff' ) ?: '#ffffff';
        $button_hover     = sanitize_hex_color( $settings['dashboard_button_hover'] ?? '#7e9374' ) ?: '#7e9374';
        $button_radius    = isset( $settings['dashboard_button_radius'] ) ? max( 0, (int) $settings['dashboard_button_radius'] ) : 12;
        $card_padding     = isset( $settings['dashboard_card_padding'] ) ? max( 0, (int) $settings['dashboard_card_padding'] ) : 20;
        $card_shadow      = sanitize_text_field( $settings['dashboard_card_shadow'] ?? '0 10px 28px rgba(16,36,60,.04)' );
        $card_hover_shadow= sanitize_text_field( $settings['dashboard_card_hover_shadow'] ?? '0 12px 30px rgba(16,36,60,.12)' );
        $card_border_width= isset( $settings['dashboard_card_border_width'] ) ? max( 0, (float) $settings['dashboard_card_border_width'] ) : 1;
        $radius           = isset( $settings['dashboard_radius'] ) ? max( 0, (int) $settings['dashboard_radius'] ) : 12;
        $max_width        = isset( $settings['dashboard_max_width'] ) ? max( 320, (int) $settings['dashboard_max_width'] ) : 960;
        $container_padding= isset( $settings['dashboard_container_padding'] ) ? max( 0, (int) $settings['dashboard_container_padding'] ) : 0;
        $grid_gap         = isset( $settings['dashboard_grid_gap'] ) ? max( 0, (int) $settings['dashboard_grid_gap'] ) : 16;
        $section_spacing  = isset( $settings['dashboard_section_spacing'] ) ? max( 0, (int) $settings['dashboard_section_spacing'] ) : 28;
        $custom_css       = trim( str_replace( [ '<', '>' ], '', (string) ( $settings['dashboard_custom_css'] ?? '' ) ) );

        $inline_css = ":root {
"
            . "    --awg-primary: {$primary};
"
            . "    --awg-bg: {$bg};
"
            . "    --awg-card-bg: {$card_bg};
"
            . "    --awg-text: {$text};
"
            . "    --awg-border: {$border};
"
            . "    --awg-font: {$font_family};
"
            . "    --awg-heading-font: {$heading_font};
"
            . "    --awg-base-font-size: {$font_size}px;
"
            . "    --awg-button-bg: {$button_bg};
"
            . "    --awg-button-text: {$button_text};
"
            . "    --awg-button-hover: {$button_hover};
"
            . "    --awg-button-radius: {$button_radius}px;
"
            . "    --awg-card-padding: {$card_padding}px;
"
            . "    --awg-card-shadow: {$card_shadow};
"
            . "    --awg-card-hover-shadow: {$card_hover_shadow};
"
            . "    --awg-card-border-width: {$card_border_width}px;
"
            . "    --awg-radius: {$radius}px;
"
            . "    --awg-grid-gap: {$grid_gap}px;
"
            . "    --awg-section-spacing: {$section_spacing}px;
"
            . "}
"
            . ".awg-mem-dashboard { max-width: {$max_width}px; padding: 0 {$container_padding}px 48px; font-size: var(--awg-base-font-size); }
"
            . ".awg-mem-dashboard h1, .awg-mem-dashboard h2, .awg-mem-dashboard h3, .awg-mem-dashboard h4, .awg-mem-dashboard h5, .awg-mem-dashboard h6 { font-family: var(--awg-heading-font); }
"
            . ".awg-mem-usage-grid, .awg-mem-quick-grid { gap: var(--awg-grid-gap); }
"
            . ".awg-mem-tools-grid, .awg-mem-plans-grid, .awg-mem-history-list { gap: var(--awg-grid-gap); }
"
            . ".awg-mem-section-title { margin-top: var(--awg-section-spacing); }
"
            . ".awg-mem-usage-card, .awg-mem-quick-card, .awg-mem-tools-hero, .awg-mem-tools-banner, .awg-mem-plan-card, .awg-mem-history-item, .awg-mem-service-card { border-width: var(--awg-card-border-width); box-shadow: var(--awg-card-shadow); }
"
            . ".awg-mem-usage-card, .awg-mem-quick-card, .awg-mem-plan-card, .awg-mem-history-item, .awg-mem-service-card { padding: var(--awg-card-padding); }
"
            . ".awg-mem-quick-card:hover, .awg-mem-plan-card:hover, .awg-mem-service-card:hover { box-shadow: var(--awg-card-hover-shadow); }
"
            . ".awg-mem-dashboard .button, .awg-mem-dashboard button:not(.awg-mem-tab):not(.awg-mem-tab-link):not(.awg-mem-quick-card):not(.components-button), .awg-mem-dashboard input[type=submit], .awg-mem-dashboard input[type=button] { background: var(--awg-button-bg); color: var(--awg-button-text); border-radius: var(--awg-button-radius); border-color: var(--awg-button-bg); }
"
            . ".awg-mem-dashboard .button:hover, .awg-mem-dashboard button:not(.awg-mem-tab):not(.awg-mem-tab-link):not(.awg-mem-quick-card):not(.components-button):hover, .awg-mem-dashboard input[type=submit]:hover, .awg-mem-dashboard input[type=button]:hover { background: var(--awg-button-hover); border-color: var(--awg-button-hover); color: var(--awg-button-text); }
"
            . ".awg-mem-dashboard .awg-mem-quick-card { background: var(--awg-card-bg); color: var(--awg-text); border-radius: var(--awg-radius); }
"
            . ".awg-mem-dashboard .awg-mem-quick-card:hover { background: var(--awg-card-bg); color: var(--awg-text); }
";

        if ( '' !== $custom_css ) {
            $inline_css .= "
" . $custom_css;
        }

        wp_add_inline_style( 'awg-mem-front', $inline_css );

        wp_enqueue_script(
            'awg-mem-front',
            AWG_MEM_URL . 'assets/js/dashboard.js',
            [ 'jquery' ],
            AWG_MEM_VERSION,
            true
        );

        wp_localize_script( 'awg-mem-front', 'AWG_MEM', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'awg_mem_nonce' ),
            'strings'  => [
                'confirm_cancel'  => __( 'Are you sure you want to cancel your paid membership and move back to the free plan?', 'authorwings-ai-tools' ),
                'confirm_downgrade' => __( 'Are you sure you want to switch to the free plan right now?', 'authorwings-ai-tools' ),
                'upgrading'       => __( 'Processing…', 'authorwings-ai-tools' ),
                'copied'          => __( 'Copied!', 'authorwings-ai-tools' ),
                'submitting'      => __( 'Submitting…', 'authorwings-ai-tools' ),
                'error_generic'   => __( 'Something went wrong. Please try again.', 'authorwings-ai-tools' ),
                'tool_loading'    => __( 'Loading tool…', 'authorwings-ai-tools' ),
                'tool_error'      => __( 'Could not load tool. Please try again.', 'authorwings-ai-tools' ),
                'tool_timeout'    => __( 'This tool is taking longer than expected. Please try again.', 'authorwings-ai-tools' ),
                'tool_timeout_ms' => '15000',
                'try_again'       => __( 'Try Again', 'authorwings-ai-tools' ),
                'service_details_required' => __( 'Please add a few project details so we can prepare the right quote.', 'authorwings-ai-tools' ),
                'submit_request'  => __( 'Submit Request', 'authorwings-ai-tools' ),
                'request_sent'    => __( 'Request sent', 'authorwings-ai-tools' ),
                'request_quote'   => __( 'Request Quote', 'authorwings-ai-tools' ),
                'service_details_min' => '20',
                'service_details' => __( 'Service Details', 'authorwings-ai-tools' ),
                'close'           => __( 'Close', 'authorwings-ai-tools' ),

                // v3.0.2 — keys that were previously falling through to JS
                // hardcoded fallbacks. Translators see English regardless
                // of locale otherwise. Group them by feature for clarity.
                // Generic.
                'success'         => __( 'Done.', 'authorwings-ai-tools' ),
                'error'           => __( 'Something went wrong.', 'authorwings-ai-tools' ),
                'add'             => __( 'Add', 'authorwings-ai-tools' ),
                'remove'          => __( 'Remove', 'authorwings-ai-tools' ),
                'reset'           => __( 'Reset', 'authorwings-ai-tools' ),
                'restore'         => __( 'Restore', 'authorwings-ai-tools' ),
                'message'         => __( 'Message', 'authorwings-ai-tools' ),
                // Account & security (v2.7.1+).
                'confirm_delete_account'   => __( 'Permanently delete your account? You will be sent a confirmation email.', 'authorwings-ai-tools' ),
                'confirm_export'           => __( 'Request a copy of your AuthorWings data? We will email you when it is ready.', 'authorwings-ai-tools' ),
                'confirm_signout_others'   => __( 'Sign out of every other session you have open on AuthorWings?', 'authorwings-ai-tools' ),
                'devices_word'             => __( 'devices', 'authorwings-ai-tools' ),
                'one_device'               => __( '1 device', 'authorwings-ai-tools' ),
                'saved_pref'               => __( 'Preference saved.', 'authorwings-ai-tools' ),
                'saving_pref'              => __( 'Saving…', 'authorwings-ai-tools' ),
                // Quote attachments (v3.0.0+).
                'uploading'       => __( 'Uploading…', 'authorwings-ai-tools' ),
                'attached'        => __( 'Attached', 'authorwings-ai-tools' ),
            ],
            'i18n' => [
                'openMenu'  => __( 'Open menu', 'authorwings-ai-tools' ),
                'closeMenu' => __( 'Close menu', 'authorwings-ai-tools' ),
            ],
        ] );

        // ── Force-load AI plugin front assets on dashboard ──
        // The AI plugin's Assets::maybe_enqueue_front_assets() only loads
        // when it detects [awg_generator] in page content. The dashboard
        // uses [awg_dashboard], so we must signal the AI plugin manually.
        // The filter 'awg_aig_enqueue_assets' is checked by class-assets.php
        // in the AI plugin — returning true forces its front.js + front.css.
        add_filter( 'awg_aig_enqueue_assets', '__return_true' );

        // Fallback: if the AI plugin version doesn't have the filter yet,
        // enqueue its assets directly by calling its enqueue method.
        add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_ai_assets' ], 20 );
    }

    /**
     * Fallback: directly call the AI plugin's asset enqueue method
     * if the filter approach didn't work (older AI plugin version).
     * Runs at priority 20 — after the AI plugin's own priority-10 hook.
     */
    public function maybe_enqueue_ai_assets(): void {
        // Already enqueued via filter — nothing to do
        if ( wp_script_is( 'awg-aig-front', 'enqueued' ) ) {
            return;
        }

        // AI plugin is active — call its enqueue directly
        if ( class_exists( '\\AWG_AIG\\Assets' ) ) {
            $ai_assets = new \AWG_AIG\Assets();
            $ai_assets->enqueue_front_assets();
            return;
        }

        // Last resort: enqueue by known paths if AI plugin is active
        if ( defined( 'AWG_AIG_URL' ) && defined( 'AWG_AIG_VERSION' ) ) {
            wp_enqueue_style( 'dashicons' );
            wp_enqueue_style(
                'awg-aig-front',
                AWG_AIG_URL . 'assets/front.css',
                [],
                AWG_AIG_VERSION
            );
            wp_enqueue_script(
                'awg-aig-front',
                AWG_AIG_URL . 'assets/front.js',
                [ 'jquery' ],
                AWG_AIG_VERSION,
                true
            );
            wp_localize_script( 'awg-aig-front', 'AWG_AIG', [
                'ajaxurl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'awg_aig_nonce_front' ),
            ] );
        }
    }

    public function admin( string $hook ): void {
        if ( strpos( $hook, 'awg-membership' ) === false ) { return; }

        wp_enqueue_style(
            'awg-mem-admin',
            AWG_MEM_URL . 'assets/css/admin.css',
            [],
            AWG_MEM_VERSION
        );

        wp_enqueue_style( 'wp-color-picker' );
        wp_enqueue_script( 'wp-color-picker' );
        wp_add_inline_script(
            'wp-color-picker',
            "jQuery(function($){ $('.awg-color-field').wpColorPicker(); });"
        );

        // v3.1.7 — Dashboard Builder needs jQuery UI sortable + its own script.
        if ( strpos( $hook, 'dashboard-builder' ) !== false ) {
            wp_enqueue_script( 'jquery-ui-sortable' );
            wp_enqueue_script(
                'awg-mem-admin-builder',
                AWG_MEM_URL . 'assets/js/admin-builder.js',
                [ 'jquery', 'jquery-ui-sortable' ],
                AWG_MEM_VERSION,
                true
            );

            $this->enqueue_builder_block_editor();
        }
    }

    /**
     * v3.5.0 — Load a self-contained block editor for the Dashboard Builder's
     * custom content blocks, so admins can design them with blocks + a
     * block-settings sidebar instead of typing HTML/shortcodes.
     *
     * To make every block available — not just WordPress core blocks but also
     * GenerateBlocks, GeneratePress, the AuthorWings widget blocks, and any
     * other plugin's blocks — we fire `enqueue_block_editor_assets` (exactly as
     * the post editor does) so each plugin registers its editor blocks, and we
     * hand the editor the real block categories + editor settings.
     */
    private function enqueue_builder_block_editor(): void {
        // Needs the block-editor JS packages and core blocks to be available.
        if ( ! function_exists( 'register_block_type' ) || ! wp_script_is( 'wp-block-editor', 'registered' ) ) {
            return;
        }

        // Media library (for the Image/Gallery blocks) and core block styles.
        if ( function_exists( 'wp_enqueue_media' ) ) {
            wp_enqueue_media();
        }
        foreach ( [ 'wp-edit-blocks', 'wp-block-library', 'wp-block-library-theme', 'wp-block-editor', 'wp-components', 'wp-format-library' ] as $style ) {
            if ( wp_style_is( $style, 'registered' ) ) {
                wp_enqueue_style( $style );
            }
        }

        // Ensure core editor script packages are present for third-party block
        // scripts that depend on them.
        foreach ( [ 'wp-block-library', 'wp-format-library', 'wp-editor' ] as $script ) {
            if ( wp_script_is( $script, 'registered' ) ) {
                wp_enqueue_script( $script );
            }
        }

        // Some plugins only enqueue their blocks when the current screen reports
        // as a block editor, so flag it before firing the hook.
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        if ( $screen && method_exists( $screen, 'is_block_editor' ) ) {
            $screen->is_block_editor( true );
        }

        // Let every plugin (GenerateBlocks, GeneratePress, AuthorWings, …)
        // enqueue and register its editor blocks, just like on the post editor,
        // so they all appear in the Dashboard Builder's block inserter.
        do_action( 'enqueue_block_editor_assets' );

        // Real block categories + editor settings so third-party blocks (which
        // live in their own categories) actually show up and behave.
        $categories = [];
        $settings   = [];
        if ( class_exists( '\WP_Block_Editor_Context' ) ) {
            $context    = new \WP_Block_Editor_Context( [ 'name' => 'core/edit-post' ] );
            $categories = get_block_categories( $context );
            if ( function_exists( 'get_block_editor_settings' ) ) {
                $settings = get_block_editor_settings( [], $context );
            }
        }
        if ( is_array( $settings ) ) {
            $settings['hasFixedToolbar'] = false;
        }

        wp_enqueue_script(
            'awg-mem-builder-editor',
            AWG_MEM_URL . 'assets/js/admin-blockeditor.js',
            [
                'jquery',
                'wp-blocks',
                'wp-block-editor',
                'wp-block-library',
                'wp-components',
                'wp-element',
                'wp-data',
                'wp-format-library',
                'wp-keyboard-shortcuts',
                'wp-i18n',
                'wp-editor',
            ],
            AWG_MEM_VERSION,
            true
        );

        wp_add_inline_script(
            'awg-mem-builder-editor',
            'window.AWG_MEM_BUILDER_EDITOR = ' . wp_json_encode( [
                'settings'   => $settings,
                'categories' => $categories,
            ] ) . ';',
            'before'
        );
    }
}
