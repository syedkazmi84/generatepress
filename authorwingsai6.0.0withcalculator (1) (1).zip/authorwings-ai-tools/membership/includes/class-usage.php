<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Usage {

    /**
     * Current monthly period key (YYYY-MM) in the site's timezone.
     *
     * History note: this used to return gmdate('Y-m'), but log_usage() writes
     * usage_date with current_time() (site-local). Near month boundaries those
     * two clocks would disagree by one day for non-UTC sites, leaving the
     * usage_date and period fields on the same row pointing at different
     * months. The rebuild cron groups on period; the monthly breakdown chart
     * groups by usage_date — so the row would land in the wrong bucket on
     * one side. Standardising on current_time matches what the dashboard
     * shows the user and keeps both columns in lockstep.
     */
    public static function current_period(): string {
        return (string) current_time( 'Y-m' );
    }

    private function resolve_user_id( int $user_id ): int {
        $mapped = (int) apply_filters( 'awg_mem_usage_owner_user_id', $user_id, $user_id );
        return $mapped > 0 ? $mapped : $user_id;
    }

    private function resolve_actor_and_owner_ids( int $user_id ): array {
        $owner_id = $this->resolve_user_id( $user_id );
        return [
            'actor_user_id' => $user_id,
            'owner_user_id' => $owner_id,
        ];
    }

    public function get( int $user_id, string $service_slug ): int {
        global $wpdb;
        $user_id = $this->resolve_user_id( $user_id );
        $table  = Database::usage_table();
        $period = self::current_period();
        $count  = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT used FROM {$table} WHERE user_id = %d AND service_slug = %s AND period = %s",
                $user_id, $service_slug, $period
            )
        );
        return (int) $count;
    }

    public function log_usage( int $user_id, string $service_slug, string $tool_name = '', int $template_id = 0, int $usage_count = 1 ): void {
        global $wpdb;

        $usage_count = max( 1, $usage_count );
        $ids         = $this->resolve_actor_and_owner_ids( $user_id );
        $owner_id    = $ids['owner_user_id'];
        $logs_table  = Database::usage_logs_table();
        $now         = current_time( 'mysql' );
        $period      = self::current_period();
        $usage_date  = current_time( 'Y-m-d' );

        $wpdb->insert(
            $logs_table,
            [
                'actor_user_id' => $ids['actor_user_id'],
                'owner_user_id' => $owner_id,
                'service_slug'  => $service_slug,
                'tool_name'     => sanitize_text_field( $tool_name ),
                'template_id'   => max( 0, $template_id ),
                'usage_count'   => $usage_count,
                'usage_date'    => $usage_date,
                'period'        => $period,
                'created_at'    => $now,
            ],
            [ '%d', '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s' ]
        );
    }

    public function increment( int $user_id, string $service_slug, string $tool_name = '', int $template_id = 0 ): void {
        global $wpdb;
        $ids     = $this->resolve_actor_and_owner_ids( $user_id );
        $user_id = $ids['owner_user_id'];
        $table   = Database::usage_table();
        $period  = self::current_period();
        $now     = current_time( 'mysql' );

        $this->log_usage( $ids['actor_user_id'], $service_slug, $tool_name, $template_id, 1 );

        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO {$table} (user_id, service_slug, period, used, updated_at)
                 VALUES (%d, %s, %s, 1, %s)
                 ON DUPLICATE KEY UPDATE used = used + 1, updated_at = %s",
                $user_id, $service_slug, $period, $now, $now
            )
        );

        if ( $ids['actor_user_id'] > 0 && $ids['actor_user_id'] !== $ids['owner_user_id'] ) {
            Logger::log( 'workspace_usage_incremented', [
                'actor_user_id' => (string) $ids['actor_user_id'],
                'owner_user_id' => (string) $ids['owner_user_id'],
                'service_slug'  => $service_slug,
                'tool_name'     => $tool_name,
                'period'        => $period,
            ] );
        }
    }

    public function maybe_rebuild_current_period_totals( int $user_id, string $service_slug = 'ai_generation' ): void {
        global $wpdb;

        $user_id    = $this->resolve_user_id( $user_id );
        $logs_table = Database::usage_logs_table();
        $usage_table = Database::usage_table();
        $period     = self::current_period();
        $now        = current_time( 'mysql' );

        $logged_total = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COALESCE(SUM(usage_count), 0) FROM {$logs_table} WHERE owner_user_id = %d AND service_slug = %s AND period = %s",
                $user_id,
                $service_slug,
                $period
            )
        );

        if ( $logged_total > 0 ) {
            $wpdb->query(
                $wpdb->prepare(
                    "INSERT INTO {$usage_table} (user_id, service_slug, period, used, updated_at)
                     VALUES (%d, %s, %s, %d, %s)
                     ON DUPLICATE KEY UPDATE used = VALUES(used), updated_at = VALUES(updated_at)",
                    $user_id,
                    $service_slug,
                    $period,
                    $logged_total,
                    $now
                )
            );
        }
    }

    public function get_all_for_user( int $user_id ): array {
        global $wpdb;
        $user_id = $this->resolve_user_id( $user_id );
        $table  = Database::usage_table();
        $period = self::current_period();
        $rows   = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT service_slug, used FROM {$table} WHERE user_id = %d AND period = %s",
                $user_id, $period
            ),
            ARRAY_A
        );
        $out = [];
        foreach ( (array) $rows as $row ) {
            $out[ $row['service_slug'] ] = (int) $row['used'];
        }
        return $out;
    }

    public function get_monthly_breakdown( int $user_id, int $months = 6 ): array {
        global $wpdb;
        $user_id = $this->resolve_user_id( $user_id );
        $months  = max( 1, min( 24, $months ) );
        $table   = Database::usage_table();
        $start   = gmdate( 'Y-m', strtotime( '-' . ( $months - 1 ) . ' months', strtotime( gmdate( 'Y-m-01' ) ) ) );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT period, SUM(used) AS total_used FROM {$table} WHERE user_id = %d AND period >= %s GROUP BY period ORDER BY period ASC",
                $user_id,
                $start
            ),
            ARRAY_A
        );

        $map = [];
        foreach ( (array) $rows as $row ) {
            $map[ $row['period'] ] = (int) $row['total_used'];
        }

        $out = [];
        for ( $i = $months - 1; $i >= 0; $i-- ) {
            $period = gmdate( 'Y-m', strtotime( '-' . $i . ' months', strtotime( gmdate( 'Y-m-01' ) ) ) );
            $out[] = [
                'period' => $period,
                'label'  => wp_date( 'M Y', strtotime( $period . '-01 00:00:00' ) ),
                'used'   => $map[ $period ] ?? 0,
            ];
        }

        return $out;
    }

    public function get_recent_tools_used( int $user_id, int $limit = 5 ): array {
        global $wpdb;
        $user_id = $this->resolve_user_id( $user_id );
        $limit   = max( 1, min( 20, $limit ) );
        $logs_table = Database::usage_logs_table();

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT tool_name, SUM(usage_count) AS run_count, MAX(created_at) AS last_used
                 FROM {$logs_table}
                 WHERE owner_user_id = %d AND tool_name <> ''
                 GROUP BY tool_name
                 ORDER BY last_used DESC
                 LIMIT %d",
                $user_id,
                $limit
            ),
            ARRAY_A
        );

        return array_map( static function( $row ) {
            return [
                'tool'      => (string) $row['tool_name'],
                'run_count' => (int) $row['run_count'],
                'last_used' => (string) $row['last_used'],
            ];
        }, (array) $rows );
    }

    /**
     * v2.7.1 — Lifetime AI tool run count for a single user.
     * Used by the Account "Activity overview" card. Single aggregate
     * query against usage_logs; no per-tool breakdown.
     *
     * @since 2.7.1
     */
    public function get_lifetime_run_count( int $user_id ): int {
        global $wpdb;
        $user_id = $this->resolve_user_id( $user_id );
        if ( $user_id <= 0 ) {
            return 0;
        }
        $logs_table = Database::usage_logs_table();
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COALESCE(SUM(usage_count), 0) FROM {$logs_table} WHERE owner_user_id = %d",
                $user_id
            )
        );
    }

    public function get_member_activity_summary( int $limit = 20 ): array {
        global $wpdb;
        $limit = max( 1, min( 100, $limit ) );
        $period = self::current_period();
        $usage_table = Database::usage_table();
        $mems_table  = Database::mems_table();
        $plans_table = Database::plans_table();
        $logs_table  = Database::usage_logs_table();

        // Rewritten in 2.5.2: previous version had a correlated subquery in the
        // SELECT clause that ran once per user — fine at 1k users, painful at
        // 100k. Now joins a single derived table that pre-aggregates monthly
        // totals per user. EXPLAIN should show a hash-join / index scan rather
        // than the per-row dependent subquery.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    u.ID AS user_id,
                    u.display_name,
                    u.user_email,
                    COALESCE( MAX( p.name ), 'Free' ) AS plan_name,
                    COALESCE( MAX( p.slug ), 'free' ) AS plan_slug,
                    COALESCE( MAX( usum.month_used ), 0 ) AS month_used,
                    MAX( logs.created_at ) AS last_activity
                 FROM {$wpdb->users} u
                 LEFT JOIN {$mems_table} m ON m.user_id = u.ID AND m.id = (
                    SELECT MAX(m2.id) FROM {$mems_table} m2 WHERE m2.user_id = u.ID
                 )
                 LEFT JOIN {$plans_table} p ON p.id = m.plan_id
                 LEFT JOIN (
                    SELECT user_id, SUM(used) AS month_used
                    FROM {$usage_table}
                    WHERE period = %s
                    GROUP BY user_id
                 ) usum ON usum.user_id = u.ID
                 LEFT JOIN {$logs_table} logs ON logs.owner_user_id = u.ID
                 GROUP BY u.ID, u.display_name, u.user_email
                 HAVING month_used > 0 OR last_activity IS NOT NULL
                 ORDER BY last_activity DESC, month_used DESC
                 LIMIT %d",
                $period,
                $limit
            ),
            ARRAY_A
        );

        return array_map( static function( $row ) {
            return [
                'user_id'       => (int) $row['user_id'],
                'display_name'  => (string) $row['display_name'],
                'user_email'    => (string) $row['user_email'],
                'plan_name'     => (string) $row['plan_name'],
                'plan_slug'     => (string) ( $row['plan_slug'] ?? 'free' ),
                'month_used'    => (int) $row['month_used'],
                'last_activity' => (string) $row['last_activity'],
            ];
        }, (array) $rows );
    }

    public function get_total_for_user( int $user_id ): int {
        global $wpdb;
        $user_id = $this->resolve_user_id( $user_id );
        $table   = Database::usage_table();
        $period  = self::current_period();

        $total = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COALESCE(SUM(used), 0) FROM {$table} WHERE user_id = %d AND period = %s",
                $user_id,
                $period
            )
        );

        return (int) $total;
    }

    public function can_use( int $user_id, string $service_slug, int $limit ): bool {
        if ( $limit < 0 ) {
            return true;
        }

        // The counter is kept in sync atomically by increment(), so the gate
        // check no longer needs to rebuild from the logs table on every call.
        // A daily cron (awg_mem_daily_rebuild_usage) reconciles the cached
        // total against the source-of-truth logs to repair any drift.
        return $this->get( $user_id, $service_slug ) < $limit;
    }

    /**
     * Cron-only: rebuild the cached usage totals for the current period from
     * the authoritative usage_logs table. Runs once per day so a corrupted
     * counter (e.g. from a partial upgrade or a manual DB edit) self-heals
     * within 24 hours instead of being papered over on every gate check.
     */
    public function rebuild_all_current_period_totals(): void {
        global $wpdb;

        $logs_table  = Database::usage_logs_table();
        $usage_table = Database::usage_table();
        $period      = self::current_period();
        $now         = current_time( 'mysql' );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT owner_user_id, service_slug, COALESCE(SUM(usage_count), 0) AS total
                 FROM {$logs_table}
                 WHERE period = %s
                 GROUP BY owner_user_id, service_slug",
                $period
            ),
            ARRAY_A
        );

        foreach ( (array) $rows as $row ) {
            $owner_id = (int) $row['owner_user_id'];
            $slug     = (string) $row['service_slug'];
            $total    = (int) $row['total'];
            if ( $owner_id <= 0 || $slug === '' ) {
                continue;
            }
            $wpdb->query(
                $wpdb->prepare(
                    "INSERT INTO {$usage_table} (user_id, service_slug, period, used, updated_at)
                     VALUES (%d, %s, %s, %d, %s)
                     ON DUPLICATE KEY UPDATE used = VALUES(used), updated_at = VALUES(updated_at)",
                    $owner_id,
                    $slug,
                    $period,
                    $total,
                    $now
                )
            );
        }
    }
}
