<?php
/**
 * Lightweight stand-in for the standalone plugin's AWG_MEM\Plugin class.
 *
 * The lean class set only ever reads Plugin::OPT (the settings option key) and,
 * in two admin code paths we do not register, Plugin::instance()->memberships /
 * ->selftest. This shim supplies the option key, the table-name constants, and
 * an instance() that the lean bootstrap populates with the live module objects.
 *
 * It is loaded ONLY when the standalone membership plugin is absent, so it can
 * never collide with that plugin's real (final) Plugin class.
 */

namespace AWG_MEM;

defined( 'ABSPATH' ) || exit;

class Plugin {

	public const OPT          = 'awg_mem_settings';
	public const TABLE_PLANS  = 'awg_mem_plans';
	public const TABLE_MEMS   = 'awg_mem_memberships';
	public const TABLE_USAGE  = 'awg_mem_usage';
	public const TABLE_ORDERS = 'awg_mem_service_orders';

	private static $instance = null;

	/** @var Memberships|null */
	public $memberships = null;
	/** @var Usage|null */
	public $usage = null;
	/** @var Plans|null */
	public $plans = null;
	/** @var Admin|null */
	public $admin = null;
	/** @var Assets|null */
	public $assets = null;
	/** Unused in the lean build; present so optional code paths don't fatal. */
	public $selftest = null;

	public static function instance(): self {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
}
