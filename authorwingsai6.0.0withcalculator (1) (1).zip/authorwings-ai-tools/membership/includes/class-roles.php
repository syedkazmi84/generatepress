<?php
namespace AWG_MEM;

if ( ! defined( 'ABSPATH' ) ) { exit; }

class Roles {

    // Role slugs
    public const FREE      = 'awg_free_member';
    public const BASIC     = 'awg_basic_member';
    public const PRO       = 'awg_pro_member';
    public const PUBLISHER = 'awg_publisher';

    // Ordered hierarchy (index = level, higher = more access)
    public const HIERARCHY = [
        self::FREE,
        self::BASIC,
        self::PRO,
        self::PUBLISHER,
    ];

    /**
     * Canonical role label + capability map. Single source of truth used by
     * both register() (first install) and sync_caps() (upgrades).
     */
    private static function role_definitions(): array {
        // Base subscriber caps
        $subscriber_caps = [ 'read' => true ];

        return [
            self::FREE => [
                'label' => 'AuthorWings Free Member',
                'caps'  => array_merge( $subscriber_caps, [
                    'awg_use_free_tools'     => true,
                ] ),
            ],
            self::BASIC => [
                'label' => 'AuthorWings Basic Member',
                'caps'  => array_merge( $subscriber_caps, [
                    'awg_use_free_tools'     => true,
                    'awg_use_basic_tools'    => true,
                    'awg_download_outputs'   => true,
                    'awg_view_history'       => true,
                ] ),
            ],
            self::PRO => [
                'label' => 'AuthorWings Pro Member',
                'caps'  => array_merge( $subscriber_caps, [
                    'awg_use_free_tools'     => true,
                    'awg_use_basic_tools'    => true,
                    'awg_use_pro_tools'      => true,
                    'awg_download_outputs'   => true,
                    'awg_view_history'       => true,
                    'awg_priority_queue'     => true,
                    'awg_service_discounts'  => true,
                ] ),
            ],
            self::PUBLISHER => [
                'label' => 'AuthorWings Publisher',
                'caps'  => array_merge( $subscriber_caps, [
                    'awg_use_free_tools'     => true,
                    'awg_use_basic_tools'    => true,
                    'awg_use_pro_tools'      => true,
                    'awg_use_publisher_tools'=> true,
                    'awg_download_outputs'   => true,
                    'awg_view_history'       => true,
                    'awg_priority_queue'     => true,
                    'awg_service_discounts'  => true,
                    'awg_bulk_tools'         => true,
                ] ),
            ],
        ];
    }

    public static function register(): void {
        foreach ( self::role_definitions() as $slug => $def ) {
            // Only add if not already registered
            if ( ! get_role( $slug ) ) {
                add_role( $slug, $def['label'], $def['caps'] );
            }
        }

        // Ensure Administrator has the membership-management capability.
        // This lets us swap the brittle `manage_options` check across every
        // admin page for a granular cap that can be granted to a future
        // "Membership Manager" role without giving them full WP admin.
        $admin = get_role( 'administrator' );
        if ( $admin && ! $admin->has_cap( 'manage_awg_membership' ) ) {
            $admin->add_cap( 'manage_awg_membership' );
        }
    }

    /**
     * Re-apply the canonical capability map to existing roles. Unlike
     * register() (which skips roles that already exist), this adds any caps a
     * newer plugin version introduced to roles created by an older version, so
     * upgrades don't leave members missing newly-added tool access. Runs on the
     * version-bump path. Only adds caps; never removes, so a site that granted
     * extra caps to these roles keeps them.
     */
    public static function sync_caps(): void {
        foreach ( self::role_definitions() as $slug => $def ) {
            $role = get_role( $slug );
            if ( ! $role ) {
                add_role( $slug, $def['label'], $def['caps'] );
                continue;
            }
            foreach ( $def['caps'] as $cap => $grant ) {
                if ( $grant && ! $role->has_cap( $cap ) ) {
                    $role->add_cap( $cap );
                }
            }
        }

        $admin = get_role( 'administrator' );
        if ( $admin && ! $admin->has_cap( 'manage_awg_membership' ) ) {
            $admin->add_cap( 'manage_awg_membership' );
        }
    }


    /**
     * Remove only AuthorWings membership roles from a user without touching
     * their normal WordPress roles like administrator or editor.
     */
    public static function clear_awg_roles( int $user_id ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) {
            return;
        }
        foreach ( self::HIERARCHY as $r ) {
            $user->remove_role( $r );
        }
    }

    /**
     * Return the virtual membership capabilities for a plan slug.
     * This lets workspace seats inherit tool access without inheriting the
     * full WordPress membership role.
     */
    public static function caps_for_plan_slug( string $slug ): array {
        $map = [
            'free'      => [ 'awg_use_free_tools' ],
            'basic'     => [ 'awg_use_free_tools', 'awg_use_basic_tools', 'awg_download_outputs', 'awg_view_history' ],
            'pro'       => [ 'awg_use_free_tools', 'awg_use_basic_tools', 'awg_use_pro_tools', 'awg_download_outputs', 'awg_view_history', 'awg_priority_queue', 'awg_service_discounts' ],
            'publisher' => [ 'awg_use_free_tools', 'awg_use_basic_tools', 'awg_use_pro_tools', 'awg_use_publisher_tools', 'awg_download_outputs', 'awg_view_history', 'awg_priority_queue', 'awg_service_discounts', 'awg_bulk_tools' ],
        ];

        return $map[ $slug ] ?? $map['free'];
    }

    /**
     * Return the AWG role slug for a user (or FREE if none found).
     */
    public static function get_user_awg_role( int $user_id ): string {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) {
            return self::FREE;
        }
        foreach ( array_reverse( self::HIERARCHY ) as $role ) {
            if ( in_array( $role, (array) $user->roles, true ) ) {
                return $role;
            }
        }
        return self::FREE;
    }

    /**
     * Assign an AWG role to a user, removing any previous AWG role first.
     */
    public static function set_user_role( int $user_id, string $role ): void {
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) {
            return;
        }
        // Strip existing AWG roles
        foreach ( self::HIERARCHY as $r ) {
            $user->remove_role( $r );
        }
        $user->add_role( $role );
    }

    /**
     * Return human-readable label for a role slug.
     */
    public static function label( string $slug ): string {
        $labels = [
            self::FREE      => __( 'Free',      'authorwings-ai-tools' ),
            self::BASIC     => __( 'Basic',     'authorwings-ai-tools' ),
            self::PRO       => __( 'Pro',       'authorwings-ai-tools' ),
            self::PUBLISHER => __( 'Publisher', 'authorwings-ai-tools' ),
        ];
        return $labels[ $slug ] ?? $slug;
    }


    /**
     * Map a membership plan slug to the corresponding AWG role slug.
     */
    public static function slug_to_role( string $slug ): string {
        $map = [
            'free'      => self::FREE,
            'basic'     => self::BASIC,
            'pro'       => self::PRO,
            'publisher' => self::PUBLISHER,
        ];

        return $map[ $slug ] ?? self::FREE;
    }

    /**
     * Return numeric level for a role (higher = more access).
     */
    public static function level( string $slug ): int {
        $idx = array_search( $slug, self::HIERARCHY, true );
        return $idx === false ? 0 : (int) $idx;
    }
}
