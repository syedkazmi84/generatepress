<?php
/**
 * Header account / authentication links for Blank Base.
 *
 * Renders the Log in / Sign up (logged-out) or account / Log out (logged-in)
 * controls in the header actions row, next to the primary navigation.
 *
 * When the AuthorWings AI membership engine is active its richer
 * [awg_account_menu] widget (avatar dropdown with plan, usage and billing) is
 * used automatically. Without that plugin the theme falls back to its own
 * lightweight, correctly-redirecting Log in / Sign up / Log out links so the
 * header is never left without an authentication control.
 *
 * The whole feature is gated behind the "Show account links in header"
 * Customizer toggle (Primary Navigation section), which defaults to on.
 *
 * @package Blank_Base
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'blank_base_header_account_enabled' ) ) :
	/**
	 * Whether the header account links should be shown.
	 *
	 * @return bool
	 */
	function blank_base_header_account_enabled() {
		return (bool) get_theme_mod( 'blank_base_header_show_account', true );
	}
endif;

if ( ! function_exists( 'blank_base_account_redirect_url' ) ) :
	/**
	 * The URL a visitor should return to after logging in.
	 *
	 * Prefers the AuthorWings account page when the membership engine exposes
	 * one, then the page currently being viewed, and finally the site home.
	 *
	 * @return string
	 */
	function blank_base_account_redirect_url() {
		if ( function_exists( 'awg_mem_get_account_url' ) ) {
			$account = awg_mem_get_account_url();
			if ( is_string( $account ) && '' !== $account ) {
				return $account;
			}
		}

		if ( ! is_admin() ) {
			$current = home_url( add_query_arg( array() ) );
			if ( is_string( $current ) && '' !== $current ) {
				return $current;
			}
		}

		return home_url( '/' );
	}
endif;

if ( ! function_exists( 'blank_base_account_menu' ) ) :
	/**
	 * Output the header account controls.
	 *
	 * @param bool $echo Whether to echo (true) or return (false) the markup.
	 * @return string Markup when $echo is false, empty string otherwise.
	 */
	function blank_base_account_menu( $echo = true ) {
		if ( ! blank_base_header_account_enabled() ) {
			return '';
		}

		// Prefer the plugin's full account widget when it is available.
		if ( shortcode_exists( 'awg_account_menu' ) ) {
			$markup = do_shortcode( '[awg_account_menu]' );
			if ( is_string( $markup ) && '' !== trim( $markup ) ) {
				$out = '<div class="blank-base-account blank-base-account--plugin">' . $markup . '</div>';
				if ( $echo ) {
					echo $out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plugin markup, already escaped.
					return '';
				}
				return $out;
			}
		}

		// Native fallback — no membership plugin, or it produced nothing.
		$redirect = blank_base_account_redirect_url();

		ob_start();
		?>
		<div class="blank-base-account blank-base-account--native">
			<?php if ( is_user_logged_in() ) : ?>
				<?php
				$current = wp_get_current_user();
				$name    = ( $current && $current->exists() ) ? ( $current->display_name ? $current->display_name : $current->user_login ) : '';
				if ( '' !== $name ) :
					?>
					<span class="blank-base-account__hello">
						<?php
						/* translators: %s: logged-in user's display name. */
						printf( esc_html__( 'Hi, %s', 'blank-base' ), esc_html( $name ) );
						?>
					</span>
				<?php endif; ?>
				<a class="blank-base-account__link" href="<?php echo esc_url( admin_url( 'profile.php' ) ); ?>">
					<?php esc_html_e( 'My account', 'blank-base' ); ?>
				</a>
				<a class="blank-base-account__btn" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">
					<?php esc_html_e( 'Log out', 'blank-base' ); ?>
				</a>
			<?php else : ?>
				<a class="blank-base-account__link" href="<?php echo esc_url( wp_login_url( $redirect ) ); ?>">
					<?php esc_html_e( 'Log in', 'blank-base' ); ?>
				</a>
				<?php if ( get_option( 'users_can_register' ) ) : ?>
					<?php
					$register = wp_registration_url();
					$register = $register ? add_query_arg( 'redirect_to', rawurlencode( $redirect ), $register ) : '';
					if ( $register ) :
						?>
						<a class="blank-base-account__btn" href="<?php echo esc_url( $register ); ?>">
							<?php esc_html_e( 'Sign up', 'blank-base' ); ?>
						</a>
					<?php endif; ?>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<?php
		$out = (string) ob_get_clean();

		if ( $echo ) {
			echo $out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts above.
			return '';
		}

		return $out;
	}
endif;
