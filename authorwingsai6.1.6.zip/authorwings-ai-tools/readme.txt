=== AuthorWings AI ===
Contributors: Syed Kazmi
Tags: ai, openai, generator, shortcode, gutenberg
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 6.1.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create customizable AI generator templates and render them via shortcode or Gutenberg block.

By Syed Haider Kazmi — https://www.linkedin.com/in/syed-haider-kazmi/

== Description ==

AuthorWings AI lets you build AI-powered tools (title generators, blurb writers, character idea generators, etc.) as reusable templates and drop them into any page or post via shortcode or a Gutenberg block.

Each template defines its own input fields, prompt, model, output format, and limits. The plugin handles the OpenAI API call, validates user input, applies per-IP rate limiting to control costs, and renders the result with copy / download / clear / regenerate actions.

Defaults follow the AuthorWings.com brand palette; every color is configurable from **AuthorWings AI → Settings** with a full color picker.

Published by AuthorWings (https://authorwings.com). The plugin code is free software licensed under GPLv2 or later; the "AuthorWings" name and associated branding are trademarks of their owner and are not granted by that license.

== External services ==

This plugin connects to third-party services. By using the relevant features you agree to those services' terms; please review their policies before enabling them.

**OpenAI**
Used by the AI generator tools. When a visitor runs a generator, the input they submit (the template's form fields) together with the template's prompt is sent to the OpenAI API (api.openai.com) to produce the generated text, which is returned and displayed. Requests are only made when a generator is run, and only if you have entered an OpenAI API key in **AuthorWings AI → Settings** and the tool uses an OpenAI model. No data is sent to OpenAI until you configure a key and a visitor runs a tool.
- Terms of Use: https://openai.com/policies/terms-of-use
- Privacy Policy: https://openai.com/policies/privacy-policy

**Anthropic (Claude)**
Optional alternative provider for the AI generator tools. If a tool's model id begins with "claude", the visitor's submitted input and the template's prompt are sent to the Anthropic API (api.anthropic.com) to produce the generated text. Requests are only made when a generator using a Claude model is run, and only if you have entered an Anthropic API key in **AuthorWings AI → Settings**.
- Consumer Terms: https://www.anthropic.com/legal/consumer-terms
- Privacy Policy: https://www.anthropic.com/legal/privacy

**DeepSeek**
Optional alternative provider for the AI generator tools. If a tool's model id begins with "deepseek", the visitor's submitted input and the template's prompt are sent to the DeepSeek API (api.deepseek.com) to produce the generated text. Requests are only made when a generator using a DeepSeek model is run, and only if you have entered a DeepSeek API key in **AuthorWings AI → Settings**.
- Terms of Use: https://platform.deepseek.com/downloads/DeepSeek%20Open%20Platform%20Terms%20of%20Service.html
- Privacy Policy: https://cdn.deepseek.com/policies/en-US/deepseek-privacy-policy.html

**Stripe**
Used by the built-in membership/subscription engine for billing. When a user subscribes to a paid plan or opens the billing portal, billing data (such as the user's email address and a plan identifier) is sent to the Stripe API (api.stripe.com) to create the checkout/portal session and process the subscription, and Stripe sends payment events back to the site via a signed webhook. Requests are only made when you have configured Stripe API keys and a user initiates a checkout or billing action. No data is sent to Stripe until you configure keys and a user starts a billing flow.
- Services Agreement: https://stripe.com/legal/ssa
- Privacy Policy: https://stripe.com/privacy

== Installation ==

1. Upload the `authorwings-ai-tools` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Go to **AuthorWings AI → Settings** and enter your OpenAI API key.
4. Go to **AuthorWings AI Templates → Add New** to create a generator template.
5. Place the template on any page or post using the shortcode or the Gutenberg block (see Usage).

== Usage ==

**Shortcode:**

`[awg_generator id="123"]`

Replace `123` with the ID of the template you created.

**Gutenberg block:**

In the block editor, add the block named **AuthorWings AI** and pick a template from the dropdown.

== Frequently Asked Questions ==

= Where do I add my OpenAI API key? =

Go to **AuthorWings AI → Settings** and paste the key into the API Key field. Use the **Test API Key** button to confirm it works before saving.

= How do I control how often visitors can run a generator? =

Two layers of rate limiting are available:

* **Global Rate Limit (per minute per IP)** — set in **AuthorWings AI → Settings**. Default is `10`. Applies to every template that doesn't override it.
* **Template Rate Limit (per minute per IP)** — set per template in the template editor. Default is `0`, which means "inherit the global limit." If you set it to a non-zero value, the tighter (smaller) of the template and global limits applies.

Blocked requests never reach OpenAI, so they don't consume any tokens.

A third, optional layer sits on top of both:

* **Site-Wide Daily Cap (all visitors)** — set in **AuthorWings AI → Settings**. This is the maximum number of successful generations *across every visitor combined* in a single day (resets at midnight in your site's timezone). It exists as a backstop against distributed abuse — a flood of requests from many different IP addresses that each stay under the per-IP limit but together still run up your OpenAI bill. Default is `0`, which means no daily cap. Only requests that actually reach OpenAI count toward it.

= Can guests (non-logged-in visitors) use the generators? =

Yes, if **Allow Guests** is on. The global default can be set in **Settings**, and each template can override it (Allow Guests / Login Required / Inherit Global).

= Does the plugin store submissions? =

Only if you turn on **Store Submissions** in Settings. When on, you can optionally also store the visitor's IP and set a retention period in days. By default, nothing is stored.

= My site is behind a reverse proxy or CDN (Cloudflare, etc.). Does rate limiting still work? =

Per-IP rate limiting and one-vote-per-visitor ratings identify visitors by their connecting IP address (`REMOTE_ADDR`). This is deliberate: it's the one value a visitor cannot forge. The trade-off is that when your site sits behind a proxy or CDN, WordPress often sees the *proxy's* IP rather than the visitor's — so every visitor can look like the same address, and the per-IP limits may apply to all of them at once.

If your edge (Cloudflare, a load balancer, etc.) passes the real client IP in a header **and** strips any client-supplied copy of that header, you can tell the plugin to use it with the `awg_aig_client_ip` filter, for example in a small site-specific plugin or your theme's functions.php:

`add_filter('awg_aig_client_ip', function ($ip) { return isset($_SERVER['HTTP_CF_CONNECTING_IP']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_CF_CONNECTING_IP'])) : $ip; });`

Only do this if you trust that header on your infrastructure — a forwarded header that visitors can set themselves is spoofable and would let them bypass per-IP limits. When in doubt, leave the default in place and rely on the Site-Wide Daily Cap as your safety net.

One more note: per-minute limits are stored as transients. On hosts using a non-persistent object cache, transients may be evicted early, which can loosen the per-minute limit. The Site-Wide Daily Cap is stored as a regular option (not a transient) specifically so it stays reliable in that situation.

= How do I uninstall the plugin? =

Deactivate and delete it from the **Plugins** screen. Existing settings and template posts are left in place unless you remove them manually — the plugin does not auto-delete data on removal.

== Screenshots ==

1. Settings page — API key, defaults, brand colors.
2. Template editor — fields, prompt, model, limits.
3. Front-end generator with result panel and actions.
4. Admin template preview — view and test any tool from the dashboard without placing a shortcode.

== Changelog ==

= 6.1.6 =
* Added: **Consistent logout landing.** Logging out now returns members to the site home instead of the bare "You are now logged out" WordPress screen. Site managers (admins/editors) keep the default WordPress behaviour, and any log-out link that already specifies its own destination is still honoured. Completes the login (members land on their account page) / sign-up (free plan assigned, WordPress e-mail confirmation) / logout redirect trio for the account menu.

= 6.1.5 =
* Fixed: **Category pages no longer 404 right after installing/updating.** The `/tool-category/<slug>/` archive URLs now resolve immediately — the plugin flushes rewrite rules on activation (and self-heals once after an update), so you no longer have to open Settings → Permalinks and click Save to make category pages open.

= 6.1.4 =
* Added: **Custom content per category.** Each Tool Category now has its own **Intro content** (shown above the tools) and **Extra content** (shown below the tools — handy for an FAQ or SEO copy) on its Add/Edit screen. Every category can be filled in differently, and the fields appear automatically for every category — including new ones — with no page-building required. The intro/extra fields use the full visual editor on the category Edit screen.

= 6.1.3 =
* Changed: **AI Tools now works as a simple category system.** Tool categories are real, public pages at `/tool-category/<slug>/` that list the tools inside; each tool links to the ordinary WordPress page holding its `[awg_generator id="N"]` shortcode.
* Changed: **The tool → page link is now automatic.** The old manual "Tool page" picker in the template editor was removed. The plugin detects which published page hosts each tool's `[awg_generator]` shortcode and links to it, refreshing whenever a page is saved or deleted. A tool whose shortcode isn't on a published page yet is hidden from its category page, so there are never dead links.
* Removed: the old membership-hub deep-link URLs — the category listing (`?awg_cat=<slug>`) and the in-place single-tool view (`?tool=<ID>`).
* Removed: the login-gated `[awg_tools]` hub. The `[awg_tools]` shortcode now renders a simple, public grid of category cards that link to each category's archive page. Access is still enforced server-side at generation time on the tool page itself.

= 6.0.0 =
* Release: **first public 6.0 release.** Rolls up the recent Book Cost Calculator refinements — a plain, small "Important notes" block, shorter default form copy, past-date blocking on the "Preferred call date" picker, per-service helper lines on every "Not included" skip card, and auto-advance to the next section when a package is picked — plus packaging cleanup (trimmed readme, Plugin URI, and author profile link). No breaking changes; saved settings and templates are preserved.

= 5.9.46 =
* Improved: **The calculator now auto-advances after a package is picked.** Selecting an option smoothly scrolls to the next section in the step (e.g. Cover Design → Interior Formatting → Illustration), or to the Next button when it was the last/only section. Add-on checkboxes are unaffected.

= 5.9.45 =
* Fixed: **The calculator "Not included" helper line now shows for every service.** Cover, formatting, illustration, publishing, marketing and coaching load their tiers from the saved price catalogue, so the new line only appeared for writing/editing; a built-in per-service fallback now shows it everywhere.

= 5.9.44 =
* Improved: **Each calculator "Not included" (skip) card now shows a short helper line** explaining what choosing it means — e.g. "No marketing" reads "I'll handle my own promotion" and "No cover" reads "I already have a cover" — so skipping a service reads as a deliberate choice.

= 5.9.43 =
* Improved: **The calculator's "Preferred call date" no longer accepts past dates.** The date picker's earliest selectable day is today, set both server-side and in the browser so cached pages stay correct.

= 5.9.42 =
* Improved: **Shorter default calculator copy.** The default "Important notes" and post-submit confirmation message were tightened (the four-step numbered list became one short paragraph). Defaults only — saved custom wording is untouched.

= 5.9.41 =
* Improved: **The calculator's "Important notes" now render as a plain, small note** instead of a bordered, italic, bulleted block, so it reads as a simple note under the form.

= 5.9.40 =
* Improved: **The calculator's "None" option cards now show a clear "Not included" state.** Instead of an empty body, each "None" card (ghostwriting, editing, etc.) now displays a muted circle-slash icon with a centered "None" title and "Not included" label, so it reads as a deliberate choice rather than a blank card. No prices or behaviour changed.
* Fixed: **The calculator's "Number of illustrations" quantity label now shows on the navy "Most Popular" illustration card.** It was dark text on the navy card and disappeared when that tier was selected; it now renders in white.
* Improved: **The calculator's visitor confirmation email now names the exact call slot the visitor picked** (e.g. "We have your preferred call time as 2026-07-14 12:20 (GMT-05:00)…"), via a new `{preferred}` email placeholder. The date/time form fields were also relabelled "Preferred call date/time" with a short helper line.
* Improved: **Lightened the calculator's estimate email and PDF download.** The deep-green header stays, but the "Estimated total" is now a soft sage tint (not a solid dark-green bar) and the email button is a white outline chip with a sage border, so the green no longer feels heavy. Applies to both emails and the PDF.
* Improved: **The calculator's quote / consultation form no longer opens on an empty ($0) estimate.** The quote CTA stays disabled until at least one service is selected, so the form only appears once there is something to quote.
* Improved: **Rewrote the calculator form's default copy to be more professional and consultation-led.** Button labels, the intro heading/text, the "Good to know" notes and the post-submit confirmation now guide visitors toward booking a call to discuss their book, with clear next steps. The visitor confirmation email default copy was updated to match. Defaults only — saved custom wording is untouched.


== License ==

GPLv2 or later — see https://www.gnu.org/licenses/gpl-2.0.html. The plugin code is free software under the GPL: you may use, modify, and redistribute it under those terms. The "AuthorWings" name, logos, and associated branding are trademarks of AuthorWings (authorwings.com) and remain the property of their owner; trademark rights are not granted by the GPL.
