<?php
/**
 * AuthorWings AI — embedded membership engine (LEAN bundle).
 *
 * This folder bundles the plan / pricing / Stripe / usage subset of the
 * standalone "AuthorWings Membership" plugin so the AI-tools plugin can gate
 * paid tools on its own, with no second plugin required.
 *
 * What it boots (lean): Plans, the [awg_pricing] page, Stripe checkout +
 * billing portal + webhook, per-month usage metering, the plan-based tool gate,
 * and the Plans / Settings / Members / Logs admin screens.
 *
 * What it deliberately does NOT boot: the member dashboard, services / quote
 * requests, the projects-and-deliverables portal, support tickets, e-mail
 * notifications, demo data, and the block/dashboard builders.
 *
 * Coexistence: if the original standalone membership plugin is still active,
 * this engine stays completely dormant and lets that plugin own everything —
 * so you can install this build first and deactivate the old plugin afterwards
 * without any "class already declared" crash. Once the standalone plugin is
 * gone, this engine takes over using the SAME database tables and the SAME
 * Stripe webhook URL, so existing plans, members, and subscriptions keep
 * working untouched.
 *
 * @package AuthorWings AI
 */

defined( 'ABSPATH' ) || exit;

/**
 * The standalone membership plugin (namespace AWG_MEM) declares this class.
 * If it is present, it is active — so we must not load our bundled copies.
 */
if ( ! function_exists( 'awg_aig_mem_should_load' ) ) {
	function awg_aig_mem_should_load(): bool {
		return ! class_exists( '\\AWG_MEM\\Memberships', false );
	}
}

/**
 * Master on/off switch for the whole membership engine.
 *
 * Stored in its own option (awg_mem_enabled) so it can be read cheaply at boot
 * (plugins_loaded) before any membership class is loaded. Defaults to ON when
 * never saved, so existing installs — Stripe members, plan/usage tool gating,
 * the pricing/account pages — keep working untouched until an admin turns it
 * off from AuthorWings AI → Settings. When OFF the engine stays completely
 * dormant: no admin pages, no shortcodes, no Stripe/webhook routes, no tool
 * gate, no cron, no member-role wp-admin block — exactly as if the membership
 * folder were absent. AI tools then run for whoever the core plugin allows.
 */
if ( ! function_exists( 'awg_aig_mem_is_enabled' ) ) {
	function awg_aig_mem_is_enabled(): bool {
		// get_option returns the stored value (a string) or the default when
		// unset. Only an explicit "0" disables; unset / "1" / 1 mean enabled.
		return '0' !== (string) get_option( 'awg_mem_enabled', '1' );
	}
}

/**
 * Idempotently define the AWG_MEM constants, the lightweight Plugin shim, and
 * require the lean class set. Safe to call more than once. Only ever runs when
 * the standalone plugin is absent, so it can never clash with that plugin's
 * own constants / classes.
 */
if ( ! function_exists( 'awg_aig_mem_load_engine' ) ) {
	function awg_aig_mem_load_engine(): void {
		if ( ! awg_aig_mem_should_load() ) {
			return;
		}

		if ( ! defined( 'AWG_MEM_VERSION' ) ) {
			define( 'AWG_MEM_VERSION', '3.7.11-bundled' );
			define( 'AWG_MEM_FILE', __FILE__ );
			define( 'AWG_MEM_PATH', plugin_dir_path( __FILE__ ) );
			define( 'AWG_MEM_URL', plugin_dir_url( __FILE__ ) );
		}

		// Minimal Plugin shim — supplies the constants the lean classes read
		// (Plugin::OPT and the TABLE_* names) plus an instance() that exposes
		// ->memberships / ->usage / ->plans for the rare code paths that ask.
		if ( ! class_exists( '\\AWG_MEM\\Plugin', false ) ) {
			require_once AWG_MEM_PATH . 'includes/class-shim-plugin.php';
		}

		$dir = AWG_MEM_PATH . 'includes/';
		$classes = [
			'\\AWG_MEM\\Database'    => 'class-database.php',
			'\\AWG_MEM\\Logger'      => 'class-logger.php',
			'\\AWG_MEM\\Roles'       => 'class-roles.php',
			'\\AWG_MEM\\URLs'        => 'class-urls.php',
			'\\AWG_MEM\\Plans'       => 'class-plans.php',
			'\\AWG_MEM\\Usage'       => 'class-usage.php',
			'\\AWG_MEM\\Memberships' => 'class-memberships.php',
			'\\AWG_MEM\\AI_Gate'     => 'class-ai-gate.php',
			'\\AWG_MEM\\Assets'      => 'class-assets.php',
			'\\AWG_MEM\\Admin'       => 'class-admin.php',
		];
		foreach ( $classes as $class => $file ) {
			if ( ! class_exists( $class, false ) ) {
				require_once $dir . $file;
			}
		}
	}
}

/**
 * Boot the lean engine on plugins_loaded (priority 20, i.e. after the
 * standalone plugin's own boot at the default priority 10, so the dormancy
 * check above sees its classes if it is active).
 */
if ( ! function_exists( 'awg_aig_mem_boot' ) ) {
	function awg_aig_mem_boot(): void {
		if ( ! awg_aig_mem_should_load() ) {
			return; // Standalone membership plugin owns everything.
		}

		// Master switch UI/option is registered even when membership is OFF, so
		// the admin can always re-enable it from AuthorWings AI → Settings. (The
		// toggle is rendered into the always-visible "AI Settings" tab — never the
		// Membership tab, which disappears when the engine is off.)
		add_action( 'admin_init', 'awg_aig_mem_register_master_setting' );

		if ( ! awg_aig_mem_is_enabled() ) {
			return; // Engine kept fully dormant by the admin's master switch.
		}

		awg_aig_mem_load_engine();

		// One-time / upgrade self-heal: make sure tables + role caps exist.
		if ( get_option( 'awg_mem_db_version' ) !== AWG_MEM_VERSION ) {
			\AWG_MEM\Database::create_tables();
			\AWG_MEM\Roles::sync_caps();
			update_option( 'awg_mem_db_version', AWG_MEM_VERSION );
		}

		// One-time lean setup self-heal. Runs even if the plugin was updated by
		// overwriting files (which does not always re-fire the activation hook).
		// DETECTS (never creates) a pricing page and points the membership
		// "dashboard"/return URL at it, so Stripe's post-checkout redirect lands
		// there. Admins create the page themselves with the [awg_pricing]
		// shortcode (see the Pages settings hint). Idempotent; only writes when
		// something actually changes.
		if ( ! get_option( 'awg_mem_lean_setup_done' ) ) {
			$pricing = get_page_by_path( 'pricing' );
			$pricing_id = ( $pricing instanceof \WP_Post )
				? (int) $pricing->ID
				: awg_aig_mem_find_page_id_by_shortcode( 'awg_pricing' );

			if ( $pricing_id > 0 ) {
				$opt = get_option( 'awg_mem_settings', [] );
				if ( ! is_array( $opt ) ) {
					$opt = [];
				}
				$changed = false;
				if ( (int) ( $opt['pricing_page_id'] ?? 0 ) !== $pricing_id ) {
					$opt['pricing_page_id'] = $pricing_id;
					$changed = true;
				}
				// Lean has no member dashboard, so the "dashboard" page (used to
				// build Stripe return URLs) should be the pricing page.
				if ( (int) ( $opt['dashboard_page_id'] ?? 0 ) !== $pricing_id ) {
					$opt['dashboard_page_id'] = $pricing_id;
					$changed = true;
				}
				if ( $changed ) {
					update_option( 'awg_mem_settings', $opt );
				}
			}
			update_option( 'awg_mem_lean_setup_done', 1 );
		}

		// One-time: DETECT (never create) a member account page ([awg_account]).
		// If the admin has built one, assign it; otherwise leave it unset and let
		// the Pages settings hint prompt them to create it.
		if ( ! get_option( 'awg_mem_lean_account_done' ) ) {
			$opt = get_option( 'awg_mem_settings', [] );
			if ( ! is_array( $opt ) ) {
				$opt = [];
			}
			$acct_id = (int) ( $opt['account_page_id'] ?? 0 );
			$valid   = $acct_id > 0 && get_post_status( $acct_id ) === 'publish';
			if ( ! $valid ) {
				$found = awg_aig_mem_find_page_id_by_shortcode( 'awg_account' );
				if ( $found > 0 ) {
					$opt['account_page_id'] = $found;
					update_option( 'awg_mem_settings', $opt );
				}
			}
			update_option( 'awg_mem_lean_account_done', 1 );
		}

		// Auto-assign (never create) the AI Tools hub page ([awg_tools]) when the
		// admin has built one. Runs on admin_init; not gated on a one-time flag so
		// a newly created hub page gets picked up on the next admin load.
		add_action( 'admin_init', 'awg_aig_mem_ensure_tools_page' );

		$plugin              = \AWG_MEM\Plugin::instance();
		$plugin->plans       = new \AWG_MEM\Plans();
		$plugin->memberships = new \AWG_MEM\Memberships();
		$plugin->usage       = new \AWG_MEM\Usage();
		$plugin->assets      = new \AWG_MEM\Assets();
		$ai_gate             = new \AWG_MEM\AI_Gate( $plugin->memberships, $plugin->usage );
		$plugin->admin       = new \AWG_MEM\Admin( $plugin->memberships, $plugin->plans, $plugin->usage, null );

		// Idempotent role re-seed (mirrors the standalone plugin's safety net).
		add_action( 'admin_init', static function () {
			$last = (int) get_option( 'awg_mem_roles_last_check', 0 );
			if ( $last && ( time() - $last ) < DAY_IN_SECONDS ) {
				return;
			}
			$missing = false;
			foreach ( \AWG_MEM\Roles::HIERARCHY as $slug ) {
				if ( ! get_role( $slug ) ) { $missing = true; break; }
			}
			if ( $missing ) {
				\AWG_MEM\Roles::register();
			}
			update_option( 'awg_mem_roles_last_check', time(), false );
		}, 5 );

		// Pricing page shortcode.
		add_shortcode( 'awg_pricing', [ $plugin->plans, 'render_pricing_page' ] );

		// Member account / billing self-service page.
		add_shortcode( 'awg_account', 'awg_aig_mem_render_account_page' );

		// AI Tools landing: a public grid of category cards linking to each
		// category's /tool-category/<slug>/ archive.
		add_shortcode( 'awg_tools', 'awg_aig_mem_render_tools_page' );

		// Keep the detected-hub-page cache fresh as pages are edited/removed.
		add_action( 'save_post', 'awg_aig_mem_flush_tools_page_cache' );
		add_action( 'deleted_post', 'awg_aig_mem_flush_tools_page_cache' );

		// The hub embeds [awg_generator] only after a tool is opened, so force
		// the generator's front-end assets to load on the hub page (they are
		// otherwise gated to pages whose content literally contains that
		// shortcode, which would leave an opened tool's form non-functional).
		add_filter( 'awg_aig_enqueue_assets', static function ( $should ) {
			if ( $should ) { return $should; }
			$post = get_post();
			if ( $post instanceof \WP_Post && has_shortcode( (string) $post->post_content, 'awg_tools' ) ) {
				return true;
			}
			return $should;
		} );

		// Header account menu (Log in / Sign up for visitors; avatar dropdown for
		// members). The site owner places it via the [awg_account_menu] shortcode
		// or the matching block; see awg_aig_mem_render_account_menu().
		add_shortcode( 'awg_account_menu', 'awg_aig_mem_render_account_menu' );

		// Assets for the header menu. It typically lives in the theme header,
		// which renders AFTER wp_head(), so a late (in-shortcode) style enqueue
		// would flash unstyled markup. Enqueue globally on the front end instead;
		// both files are tiny (~3KB combined).
		add_action( 'wp_enqueue_scripts', static function () {
			if ( is_admin() ) {
				return;
			}
			wp_enqueue_style( 'awg-mem-account-menu', AWG_MEM_URL . 'assets/css/account-menu.css', [], AWG_MEM_VERSION );
			wp_register_script( 'awg-mem-account-menu', AWG_MEM_URL . 'assets/js/account-menu.js', [], AWG_MEM_VERSION, true );
			wp_localize_script( 'awg-mem-account-menu', 'AWG_MEM_AM', [
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'awg_mem_nonce' ),
			] );
			wp_enqueue_script( 'awg-mem-account-menu' );
		}, 20 );

		// Optional editor block (same server-rendered markup) so block / FSE
		// themes can drop the menu into a header template part.
		add_action( 'init', static function () {
			if ( ! function_exists( 'register_block_type' ) ) {
				return;
			}
			wp_register_script(
				'awg-mem-account-menu-block',
				AWG_MEM_URL . 'assets/js/account-menu-block.js',
				[ 'wp-blocks', 'wp-element', 'wp-i18n' ],
				AWG_MEM_VERSION,
				true
			);
			register_block_type( 'authorwings/account-menu', [
				'editor_script'   => 'awg-mem-account-menu-block',
				'render_callback' => static function ( $attrs ) {
					return awg_aig_mem_render_account_menu( is_array( $attrs ) ? $attrs : [] );
				},
				'supports'        => [ 'html' => false ],
			] );
		} );

		// Stripe webhook — SAME route as the standalone plugin, so the endpoint
		// URL already registered in your Stripe dashboard keeps working.
		add_action( 'rest_api_init', static function () use ( $plugin ) {
			register_rest_route( 'authorwings-membership/v1', '/stripe/webhook', [
				'methods'             => 'POST',
				'callback'            => [ $plugin->memberships, 'rest_webhook' ],
				'permission_callback' => '__return_true',
			] );
		} );

		// Plan-change / billing AJAX (same action names the pricing JS calls).
		add_action( 'wp_ajax_awg_mem_upgrade_plan',   [ $plugin->memberships, 'ajax_upgrade' ] );
		add_action( 'wp_ajax_awg_mem_cancel_plan',    [ $plugin->memberships, 'ajax_cancel' ] );
		add_action( 'wp_ajax_awg_mem_cancel_portal',  [ $plugin->memberships, 'ajax_cancel_portal' ] );
		add_action( 'wp_ajax_awg_mem_billing_portal', [ $plugin->memberships, 'ajax_billing_portal' ] );

		// Auto-assign the Free plan when a user registers.
		add_action( 'user_register', [ $plugin->memberships, 'on_register' ] );

		// Front + admin assets (pricing page CSS/JS; admin Plans/Settings UI).
		add_action( 'wp_enqueue_scripts',    [ $plugin->assets, 'frontend' ] );
		add_action( 'admin_enqueue_scripts', [ $plugin->assets, 'admin' ] );

		// Lean pricing behaviour: the shared pricing CTA links into the member
		// dashboard's upgrade flow, which the lean build does not ship. This
		// small script makes the CTA start Stripe checkout directly (via the
		// awg_mem_upgrade_plan AJAX) for logged-in visitors.
		add_action( 'wp_enqueue_scripts', static function () {
			if ( ! is_singular() ) {
				return;
			}
			$post = get_post();
			if ( ! ( $post instanceof \WP_Post ) || ! has_shortcode( (string) $post->post_content, 'awg_pricing' ) ) {
				return;
			}
			wp_enqueue_script(
				'awg-mem-lean-pricing',
				AWG_MEM_URL . 'assets/js/lean-pricing.js',
				[],
				AWG_MEM_VERSION,
				true
			);
			wp_localize_script( 'awg-mem-lean-pricing', 'AWG_MEM_LEAN', [
				'ajax_url'  => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( 'awg_mem_nonce' ),
				'logged_in' => is_user_logged_in() ? 1 : 0,
			] );
		}, 20 );

		// Account page assets (Manage billing / Cancel buttons).
		add_action( 'wp_enqueue_scripts', static function () {
			if ( ! is_singular() || ! is_user_logged_in() ) {
				return;
			}
			$post = get_post();
			if ( ! ( $post instanceof \WP_Post ) || ! has_shortcode( (string) $post->post_content, 'awg_account' ) ) {
				return;
			}
			wp_enqueue_script(
				'awg-mem-lean-account',
				AWG_MEM_URL . 'assets/js/lean-account.js',
				[],
				AWG_MEM_VERSION,
				true
			);
			wp_localize_script( 'awg-mem-lean-account', 'AWG_MEM_ACCT', [
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'awg_mem_nonce' ),
			] );
		}, 20 );

		// Activate the plan when the buyer returns from Stripe Checkout, by
		// verifying the session directly with Stripe. This is what actually
		// grants access in the lean build: the webhook is the primary path in
		// production, but it can't reach a local/dev site, and the dropped
		// member dashboard previously handled the return. Safe alongside the
		// webhook (set_user_plan no-ops if the membership already matches).
		add_action( 'template_redirect', 'awg_aig_mem_confirm_return' );

		// Billing-Portal counterpart to the Checkout confirm above. When a
		// member returns from a Stripe Billing-Portal plan switch (2nd/3rd
		// upgrade), re-read the live subscription and sync the plan straight
		// away — so the switch no longer depends solely on the
		// customer.subscription.updated webhook, which (unlike Checkout) the
		// portal return cannot fall back on. Safe alongside the webhook:
		// set_user_plan() no-ops when the membership already matches.
		add_action( 'template_redirect', 'awg_aig_mem_confirm_portal_return' );

		// Keep members out of wp-admin after logging in: send non-privileged
		// users to a front-end page (pricing) instead of the bare dashboard.
		add_filter( 'login_redirect', 'awg_aig_mem_login_redirect', 10, 3 );

		// Counterpart for logout: when a member logs out without an explicit
		// destination (e.g. a bare wp-login.php?action=logout link), land them
		// on the site home instead of the stark wp-login.php?loggedout=true
		// screen. The account-menu Log-out link already carries a redirect, so
		// this only fills the gap for logouts triggered elsewhere.
		add_filter( 'logout_redirect', 'awg_aig_mem_logout_redirect', 10, 3 );

		// Hide the WordPress dashboard entirely for AuthorWings member roles:
		// no admin bar on the front end, and any wp-admin request is bounced to
		// their account page (AJAX and the Stripe webhook are unaffected).
		add_filter( 'show_admin_bar', 'awg_aig_mem_admin_bar' );
		add_action( 'admin_init', 'awg_aig_mem_block_admin', 1 );

		// Membership admin pages live UNDER the existing "AuthorWings AI" menu
		// (parent slug edit.php?post_type=awg_ai_template) rather than a separate
		// top-level menu, so everything is in one place. Priority 11 ensures the
		// AuthorWings AI parent menu is registered first.
		add_action( 'admin_menu', static function () use ( $plugin ) {
			$parent = 'edit.php?post_type=awg_ai_template';
			add_submenu_page( $parent, __( 'Members', 'authorwings-ai-tools' ), __( 'Members', 'authorwings-ai-tools' ), 'manage_awg_membership', 'awg-membership', [ $plugin->admin, 'page_members' ], 50 );
			add_submenu_page( $parent, __( 'Plans', 'authorwings-ai-tools' ), __( 'Plans', 'authorwings-ai-tools' ), 'manage_awg_membership', 'awg-membership-plans', [ $plugin->admin, 'page_plans' ], 60 );
			add_submenu_page( $parent, __( 'Membership Logs', 'authorwings-ai-tools' ), __( 'Membership Logs', 'authorwings-ai-tools' ), 'manage_awg_membership', 'awg-membership-logs', [ $plugin->admin, 'page_logs' ], 70 );
			// v5.4.28: "Membership Settings" is no longer a separate submenu item.
			// Its form now renders as the "Membership" tab inside the main
			// AuthorWings AI → Settings screen (see class-settings.php::page()).
			// The option group is still registered via awg_aig_mem_register_settings()
			// on admin_init, so saving from that tab works unchanged.
		}, 11 );
		// Register the trimmed (lean) settings option/sanitizer.
		add_action( 'admin_init', 'awg_aig_mem_register_settings' );

		// Daily maintenance: expire ended subscriptions + self-heal usage totals.
		// (Renewal-reminder e-mails are intentionally omitted in the lean build;
		// Stripe still sends its own billing e-mails when configured.)
		add_action( 'awg_mem_daily_cron', [ $plugin->memberships, 'check_expiries' ] );
		if ( ! wp_next_scheduled( 'awg_mem_daily_cron' ) ) {
			wp_schedule_event( time(), 'daily', 'awg_mem_daily_cron' );
		}
		add_action( 'awg_mem_daily_rebuild_usage', [ $plugin->usage, 'rebuild_all_current_period_totals' ] );
		if ( ! wp_next_scheduled( 'awg_mem_daily_rebuild_usage' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'awg_mem_daily_rebuild_usage' );
		}

		// Wire the gate into the AI-tools plugin (the filters/actions it fires).
		$ai_gate->register_hooks();
	}
}
add_action( 'plugins_loaded', 'awg_aig_mem_boot', 20 );

/**
 * Verify a returning Stripe Checkout session and grant the plan.
 *
 * Runs on front-end page loads. When Stripe redirects the buyer back with
 * ?payment=success&session_id=cs_..., this retrieves that session from the
 * Stripe API (an outbound call from the server, so it works even on a local
 * site Stripe can't call back), confirms it belongs to the current user and was
 * actually paid, then activates the plan via Memberships::set_user_plan().
 *
 * In production the Stripe webhook is still the primary activation path; this
 * is a safe, immediate fallback (set_user_plan() no-ops if the membership is
 * already current, so the two can't double-apply).
 */
if ( ! function_exists( 'awg_aig_mem_confirm_return' ) ) {
	function awg_aig_mem_confirm_return(): void {
		if ( is_admin() || ! is_user_logged_in() ) {
			return;
		}
		$payment    = isset( $_GET['payment'] ) ? sanitize_key( wp_unslash( $_GET['payment'] ) ) : '';
		$session_id = isset( $_GET['session_id'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['session_id'] ) ) : '';
		if ( $payment !== 'success' || strpos( $session_id, 'cs_' ) !== 0 ) {
			return;
		}
		if ( ! class_exists( '\\AWG_MEM\\Memberships', false ) ) {
			return;
		}

		// Avoid re-hitting the Stripe API on every refresh of the same session.
		// Key the throttle on session + current user so one user's processed return
		// can't short-circuit another user's (ownership is also re-checked below).
		$guard = 'awg_mem_sess_' . md5( $session_id . '|' . get_current_user_id() );
		if ( get_transient( $guard ) === 'done' ) {
			return;
		}

		$settings = get_option( 'awg_mem_settings', [] );
		$secret   = is_array( $settings ) ? trim( (string) ( $settings['stripe_secret_key'] ?? '' ) ) : '';
		if ( $secret === '' ) {
			return;
		}

		$resp = wp_remote_get(
			'https://api.stripe.com/v1/checkout/sessions/' . rawurlencode( $session_id ),
			[
				'timeout' => 20,
				'headers' => [
					'Authorization'  => 'Bearer ' . $secret,
					'Stripe-Version' => '2023-10-16',
				],
			]
		);
		if ( is_wp_error( $resp ) ) {
			return;
		}
		$code = (int) wp_remote_retrieve_response_code( $resp );
		$body = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
		if ( $code < 200 || $code >= 300 || ! is_array( $body ) ) {
			return;
		}

		// The session must belong to the logged-in user (defends against
		// activating someone else's plan by replaying a session id).
		$meta        = isset( $body['metadata'] ) && is_array( $body['metadata'] ) ? $body['metadata'] : [];
		$session_uid = isset( $meta['user_id'] ) ? (int) $meta['user_id'] : (int) ( $body['client_reference_id'] ?? 0 );
		$current_uid = get_current_user_id();
		if ( $session_uid <= 0 || $session_uid !== $current_uid ) {
			return;
		}

		// The checkout must actually be complete / paid.
		$status         = isset( $body['status'] ) ? (string) $body['status'] : '';
		$payment_status = isset( $body['payment_status'] ) ? (string) $body['payment_status'] : '';
		$paid_ok        = ( $status === 'complete' ) || in_array( $payment_status, [ 'paid', 'no_payment_required' ], true );
		if ( ! $paid_ok ) {
			return;
		}

		$plan_id = isset( $meta['plan_id'] ) ? (int) $meta['plan_id'] : 0;
		$billing = ( isset( $meta['billing'] ) && in_array( $meta['billing'], [ 'monthly', 'yearly', 'free' ], true ) ) ? (string) $meta['billing'] : 'monthly';
		$sub_id  = isset( $body['subscription'] ) ? sanitize_text_field( (string) $body['subscription'] ) : '';
		$cust_id = isset( $body['customer'] ) ? sanitize_text_field( (string) $body['customer'] ) : '';
		if ( $plan_id <= 0 ) {
			return;
		}

		\AWG_MEM\Plugin::instance()->memberships->set_user_plan( $current_uid, $plan_id, $billing, $sub_id, $cust_id );
		set_transient( $guard, 'done', 10 * MINUTE_IN_SECONDS );

		// Prefer sending the buyer to their account page (shows the now-active
		// plan + billing controls); otherwise stay on the current page minus the
		// session id, keeping payment=success so the confirmation still shows.
		$account = awg_aig_mem_account_url();
		if ( $account ) {
			$redirect = add_query_arg( 'awg_notice', 'plan-updated', $account );
		} else {
			$redirect = remove_query_arg( [ 'session_id' ] );
		}
		if ( $redirect ) {
			wp_safe_redirect( $redirect );
			exit;
		}
	}
}

/**
 * Re-sync a member's plan when they return from a Stripe Billing-Portal switch.
 *
 * The 2nd/3rd upgrade routes existing paying members through the Billing Portal
 * (Stripe swaps the price on the SAME subscription, with proration). Stripe
 * announces that change via the customer.subscription.updated webhook — but the
 * portal return URL has no session id, so unlike Checkout there was no
 * synchronous fallback. If the webhook is delayed, mis-configured, or can't
 * reach the site, the upgrade is billed on Stripe yet never reflected here.
 *
 * On return we tag the URL with awg_portal_return=1; this reads the live
 * subscription straight from Stripe and applies the plan immediately. Safe
 * alongside the webhook (set_user_plan no-ops when already in sync).
 */
if ( ! function_exists( 'awg_aig_mem_confirm_portal_return' ) ) {
	function awg_aig_mem_confirm_portal_return(): void {
		if ( is_admin() || ! is_user_logged_in() ) {
			return;
		}
		$is_return = isset( $_GET['awg_portal_return'] )
			&& (string) wp_unslash( $_GET['awg_portal_return'] ) === '1';
		if ( ! $is_return ) {
			return;
		}
		if ( ! class_exists( '\\AWG_MEM\\Plugin', false ) ) {
			return;
		}

		$user_id = get_current_user_id();

		// Throttle: the trigger arg can survive a manual refresh, and we don't
		// want to hit the Stripe API on every reload. One resync per ~30s per
		// user is ample to catch a just-completed portal switch.
		$guard = 'awg_mem_portal_resync_' . $user_id;
		if ( get_transient( $guard ) !== 'done' ) {
			set_transient( $guard, 'done', 30 );
			\AWG_MEM\Plugin::instance()->memberships->sync_plan_from_stripe_subscription( $user_id );
		}

		// The member may have updated their card in the portal — drop the
		// cached card summary so the account page re-reads it from Stripe.
		delete_transient( 'awg_mem_pm_summary_' . $user_id );

		// Strip the trigger arg so a refresh / back-button doesn't keep firing,
		// but keep awg_notice=plan-updated so the success notice still shows.
		// Dropping the arg also makes this a one-shot (no redirect loop: the
		// next load no longer matches awg_portal_return=1).
		$clean = remove_query_arg( [ 'awg_portal_return' ] );
		if ( $clean ) {
			wp_safe_redirect( $clean );
			exit;
		}
	}
}

/**
 * Send members to a front-end page after login instead of wp-admin.
 *
 * Admins and anyone who can edit content (editors/authors) are left alone so
 * their normal wp-admin login still works. An explicit front-end destination
 * (e.g. the pricing/upgrade URL from a "Get Started" button) is also respected;
 * only an empty or wp-admin destination is redirected to the pricing page.
 */
if ( ! function_exists( 'awg_aig_mem_login_redirect' ) ) {
	function awg_aig_mem_login_redirect( $redirect_to, $requested_redirect_to, $user ) {
		if ( ! ( $user instanceof \WP_User ) ) {
			return $redirect_to;
		}
		if ( user_can( $user, 'manage_options' ) || user_can( $user, 'edit_posts' ) ) {
			return $redirect_to;
		}
		$admin  = admin_url();
		$target = $redirect_to !== '' ? $redirect_to : (string) $requested_redirect_to;
		$is_admin_dest = ( $target === '' ) || ( strpos( (string) $target, $admin ) === 0 );
		if ( ! $is_admin_dest ) {
			return $redirect_to; // a specific front-end URL was requested; keep it
		}
		$account = awg_aig_mem_account_url();
		if ( $account ) {
			return $account;
		}
		$opt = get_option( 'awg_mem_settings', [] );
		$pid = is_array( $opt ) ? (int) ( $opt['pricing_page_id'] ?? 0 ) : 0;
		$url = $pid ? get_permalink( $pid ) : '';
		return $url ?: home_url( '/' );
	}
}


/**
 * Logout redirect. Honours an explicit destination when one was requested
 * (e.g. the account-menu Log-out link, which passes the site home); otherwise
 * sends the user to the site home rather than the default wp-login.php
 * "You are now logged out" screen. Privileged users who requested nothing keep
 * the WordPress default so admin logout still behaves as expected.
 */
if ( ! function_exists( 'awg_aig_mem_logout_redirect' ) ) {
	function awg_aig_mem_logout_redirect( $redirect_to, $requested_redirect_to, $user ) {
		$requested = (string) $requested_redirect_to;
		if ( $requested !== '' ) {
			return $redirect_to; // a specific destination was requested; keep it
		}
		if ( $user instanceof \WP_User && ( user_can( $user, 'manage_options' ) || user_can( $user, 'edit_posts' ) ) ) {
			return $redirect_to; // leave the WordPress default for site managers
		}
		return home_url( '/' );
	}
}


/**
 * Activation — create tables, register roles, seed default plans (idempotent;
 * skips if your plans already exist), ensure a /pricing/ page exists, and point
 * the membership "dashboard"/return URL at that pricing page (the lean build
 * has no separate member dashboard, so post-checkout redirects land on pricing).
 *
 * Called from the AI-tools main plugin file's activation hook.
 */
if ( ! function_exists( 'awg_aig_mem_activate' ) ) {
	function awg_aig_mem_activate(): void {
		// Ensure the engine classes are available (whether from this bundle or,
		// during the transition, from the still-active standalone plugin).
		if ( awg_aig_mem_should_load() ) {
			awg_aig_mem_load_engine();
		}
		// Seed the master switch ON by default (add_option no-ops if it already
		// exists, so an admin who turned membership off stays off across updates).
		add_option( 'awg_mem_enabled', '1' );

		if ( ! class_exists( '\\AWG_MEM\\Database', false ) ) {
			return; // Nothing we can safely do.
		}

		\AWG_MEM\Database::create_tables();
		\AWG_MEM\Roles::register();
		if ( method_exists( '\\AWG_MEM\\Plans', 'seed_defaults' ) ) {
			\AWG_MEM\Plans::seed_defaults();
		}

		// Pages are NOT auto-created. If the admin already has pricing/account
		// pages (existing install, or built by hand with the documented
		// shortcodes), detect and assign them; otherwise leave them unset and let
		// the Pages settings hint guide the admin to create them.
		$pricing    = get_page_by_path( 'pricing' );
		$pricing_id = ( $pricing instanceof \WP_Post )
			? (int) $pricing->ID
			: awg_aig_mem_find_page_id_by_shortcode( 'awg_pricing' );

		$opt_now = get_option( 'awg_mem_settings', [] );
		$opt_now = is_array( $opt_now ) ? $opt_now : [];
		$acct_id = (int) ( $opt_now['account_page_id'] ?? 0 );
		if ( ! ( $acct_id > 0 && get_post_status( $acct_id ) === 'publish' ) ) {
			$acct_id = awg_aig_mem_find_page_id_by_shortcode( 'awg_account' );
		}

		// Repoint return URLs at the pricing page (no dashboard in lean build),
		// only when one was actually found.
		if ( $pricing_id > 0 ) {
			$opt = get_option( 'awg_mem_settings', [] );
			if ( ! is_array( $opt ) ) {
				$opt = [];
			}
			$opt['pricing_page_id']   = (int) $pricing_id;
			$opt['dashboard_page_id'] = (int) $pricing_id;
			if ( $acct_id > 0 ) {
				$opt['account_page_id'] = (int) $acct_id;
			}
			update_option( 'awg_mem_settings', $opt );
		}

		if ( defined( 'AWG_MEM_VERSION' ) ) {
			update_option( 'awg_mem_db_version', AWG_MEM_VERSION );
		}
		flush_rewrite_rules();
	}
}

/**
 * Register the master on/off option (awg_mem_enabled) and its sanitizer.
 *
 * Lives in its own settings group so the toggle posts to options.php on its
 * own, independent of the AI and Membership settings forms. Registered even
 * when membership is OFF (see awg_aig_mem_boot) so it can be turned back on.
 */
if ( ! function_exists( 'awg_aig_mem_register_master_setting' ) ) {
	function awg_aig_mem_register_master_setting(): void {
		register_setting( 'awg_aig_mem_master_group', 'awg_mem_enabled', [
			'type'              => 'string',
			'sanitize_callback' => static function ( $v ) {
				return ! empty( $v ) ? '1' : '0';
			},
			'default'           => '1',
		] );
	}
}

/**
 * Render the master Membership on/off toggle.
 *
 * Called from the AuthorWings AI → Settings "AI Settings" tab (always visible),
 * so it stays reachable whether membership is currently on or off. A hidden
 * field guarantees a "0" is submitted when the box is unchecked.
 */
if ( ! function_exists( 'awg_aig_mem_render_master_toggle' ) ) {
	function awg_aig_mem_render_master_toggle(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$enabled = awg_aig_mem_is_enabled();
		?>
		<div class="awg-section" style="border:1px solid #dcdcde;border-radius:6px;padding:12px 16px;margin:0 0 16px;background:#fff;">
			<form method="post" action="options.php" style="margin:0;">
				<?php settings_fields( 'awg_aig_mem_master_group' ); ?>
				<h2 style="margin:0 0 6px;font-size:14px;"><?php esc_html_e( 'Membership', 'authorwings-ai-tools' ); ?></h2>
				<input type="hidden" name="awg_mem_enabled" value="0" />
				<label style="display:inline-flex;align-items:center;gap:8px;">
					<input type="checkbox" name="awg_mem_enabled" value="1" <?php checked( $enabled ); ?> />
					<strong><?php esc_html_e( 'Enable membership', 'authorwings-ai-tools' ); ?></strong>
				</label>
				<p class="description" style="margin:8px 0 12px;max-width:760px;">
					<?php esc_html_e( 'When enabled, all membership features turn on: the Members, Plans and Membership Logs admin screens, the Membership settings tab, the pricing/account/account-menu shortcodes, Stripe checkout & billing, and per-plan tool access with monthly usage limits. When disabled, every membership feature is hidden and all AI tools run for whoever your core access settings already allow (guests / rate limits) — no plan or usage gate.', 'authorwings-ai-tools' ); ?>
				</p>
				<?php submit_button( __( 'Save Membership Status', 'authorwings-ai-tools' ), 'primary', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}
}

/**
 * Register the LEAN settings option + sanitizer. The lean build only surfaces
 * the Stripe credentials and the pricing page; the sanitizer below merges onto
 * the existing option so any other stored keys (from the standalone plugin) are
 * preserved untouched rather than wiped.
 */
if ( ! function_exists( 'awg_aig_mem_register_settings' ) ) {
	function awg_aig_mem_register_settings(): void {
		register_setting( 'awg_aig_mem_settings_group', 'awg_mem_settings', [
			'type'              => 'array',
			'sanitize_callback' => 'awg_aig_mem_sanitize_settings',
		] );
	}
}

if ( ! function_exists( 'awg_aig_mem_sanitize_settings' ) ) {
	function awg_aig_mem_sanitize_settings( $input ): array {
		$input    = is_array( $input ) ? wp_unslash( $input ) : [];
		$existing = get_option( 'awg_mem_settings', [] );
		if ( ! is_array( $existing ) ) {
			$existing = [];
		}
		$out = $existing; // preserve everything we don't manage in the lean UI

		// Admin notification email.
		$email = sanitize_email( (string) ( $input['notify_admin_email'] ?? '' ) );
		$out['notify_admin_email'] = $email !== '' ? $email : ( $existing['notify_admin_email'] ?? get_option( 'admin_email' ) );

		// Stripe credentials. Keep the existing value if a field is submitted
		// blank, so the keys can't be wiped by accident on a normal save.
		$secret = sanitize_text_field( (string) ( $input['stripe_secret_key'] ?? '' ) );
		$out['stripe_secret_key'] = $secret !== '' ? $secret : ( $existing['stripe_secret_key'] ?? '' );

		$pub = sanitize_text_field( (string) ( $input['stripe_public_key'] ?? '' ) );
		$out['stripe_public_key'] = $pub !== '' ? $pub : ( $existing['stripe_public_key'] ?? '' );

		$whsec = sanitize_text_field( (string) ( $input['stripe_webhook_secret'] ?? '' ) );
		$out['stripe_webhook_secret'] = $whsec !== '' ? $whsec : ( $existing['stripe_webhook_secret'] ?? '' );

		// Pricing page. The lean build has no separate member dashboard, so the
		// "dashboard" page (used to build Stripe return URLs) tracks the pricing
		// page automatically.
		$pid = (int) ( $input['pricing_page_id'] ?? ( $existing['pricing_page_id'] ?? 0 ) );
		$out['pricing_page_id']   = $pid;
		$out['dashboard_page_id'] = $pid;

		// Member account page.
		$out['account_page_id'] = (int) ( $input['account_page_id'] ?? ( $existing['account_page_id'] ?? 0 ) );

		// AI Tools hub page.
		$out['tools_page_id'] = (int) ( $input['tools_page_id'] ?? ( $existing['tools_page_id'] ?? 0 ) );

		// Keep billing/webhook diagnostics available in the Logs page.
		if ( ! isset( $out['enable_error_logging'] ) ) {
			$out['enable_error_logging'] = 1;
		}

		return $out;
	}
}

/**
 * Trimmed Membership Settings page: only the fields the lean build uses
 * (Stripe credentials + pricing page), plus the webhook URL for reference.
 */
if ( ! function_exists( 'awg_aig_mem_render_settings_page' ) ) {
	function awg_aig_mem_render_settings_page( bool $bare = false ): void {
		if ( ! current_user_can( 'manage_awg_membership' ) && ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'authorwings-ai-tools' ), 403 );
		}

		$opt    = get_option( 'awg_mem_settings', [] );
		$opt    = is_array( $opt ) ? $opt : [];
		$email  = (string) ( $opt['notify_admin_email'] ?? get_option( 'admin_email' ) );
		$secret = (string) ( $opt['stripe_secret_key'] ?? '' );
		$pub    = (string) ( $opt['stripe_public_key'] ?? '' );
		$whsec  = (string) ( $opt['stripe_webhook_secret'] ?? '' );
		$pid     = (int) ( $opt['pricing_page_id'] ?? 0 );
		$acctid  = (int) ( $opt['account_page_id'] ?? 0 );
		$toolsid = (int) ( $opt['tools_page_id'] ?? 0 );
		$webhook_url = rest_url( 'authorwings-membership/v1/stripe/webhook' );
		?>
		<?php if ( ! $bare ) : ?><div class="wrap"><h1><?php esc_html_e( 'Membership Settings', 'authorwings-ai-tools' ); ?></h1><?php endif; ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'awg_aig_mem_settings_group' ); ?>

				<h2 class="title"><?php esc_html_e( 'General', 'authorwings-ai-tools' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="awg_mem_notify_admin_email"><?php esc_html_e( 'Admin Notification Email', 'authorwings-ai-tools' ); ?></label></th>
						<td><input type="email" class="regular-text" id="awg_mem_notify_admin_email" name="awg_mem_settings[notify_admin_email]" value="<?php echo esc_attr( $email ); ?>"></td>
					</tr>
				</table>

				<h2 class="title"><?php esc_html_e( 'Stripe', 'authorwings-ai-tools' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="awg_mem_stripe_secret_key"><?php esc_html_e( 'Stripe Secret Key', 'authorwings-ai-tools' ); ?></label></th>
						<td>
							<input type="password" class="regular-text" id="awg_mem_stripe_secret_key" name="awg_mem_settings[stripe_secret_key]" value="" placeholder="<?php echo $secret !== '' ? esc_attr__( 'Saved — leave blank to keep the current key', 'authorwings-ai-tools' ) : ''; ?>" autocomplete="off">
							<p class="description"><?php esc_html_e( 'Your Stripe secret key (sk_live_… or sk_test_…). For security the saved key is never shown again; leave this blank to keep it, or paste a new key to replace it.', 'authorwings-ai-tools' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="awg_mem_stripe_public_key"><?php esc_html_e( 'Stripe Publishable Key', 'authorwings-ai-tools' ); ?></label></th>
						<td><input type="text" class="regular-text" id="awg_mem_stripe_public_key" name="awg_mem_settings[stripe_public_key]" value="<?php echo esc_attr( $pub ); ?>" autocomplete="off"></td>
					</tr>
					<tr>
						<th scope="row"><label for="awg_mem_stripe_webhook_secret"><?php esc_html_e( 'Stripe Webhook Secret', 'authorwings-ai-tools' ); ?></label></th>
						<td>
							<input type="password" class="regular-text" id="awg_mem_stripe_webhook_secret" name="awg_mem_settings[stripe_webhook_secret]" value="" placeholder="<?php echo $whsec !== '' ? esc_attr__( 'Saved — leave blank to keep the current secret', 'authorwings-ai-tools' ) : ''; ?>" autocomplete="off">
							<p class="description">
								<?php esc_html_e( 'Webhook signing secret (whsec_…). In your Stripe dashboard, point the webhook endpoint at:', 'authorwings-ai-tools' ); ?><br>
								<code><?php echo esc_html( $webhook_url ); ?></code>
							</p>
						</td>
					</tr>
				</table>

				<h2 class="title"><?php esc_html_e( 'Pages', 'authorwings-ai-tools' ); ?></h2>
				<?php awg_aig_mem_render_pages_hint(); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="awg_mem_pricing_page_id"><?php esc_html_e( 'Pricing Page', 'authorwings-ai-tools' ); ?></label></th>
						<td>
							<?php
							wp_dropdown_pages( [
								'name'              => 'awg_mem_settings[pricing_page_id]',
								'id'                => 'awg_mem_pricing_page_id',
								'selected'          => $pid,
								'show_option_none'  => esc_html__( '— Select —', 'authorwings-ai-tools' ),
								'option_none_value' => 0,
							] );
							?>
							<p class="description"><?php
								/* translators: %s: shortcode */
								printf( esc_html__( 'Select the page that contains the %s shortcode. Stripe returns buyers here after checkout.', 'authorwings-ai-tools' ), '<code>[awg_pricing]</code>' );
							?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="awg_mem_account_page_id"><?php esc_html_e( 'Account Page', 'authorwings-ai-tools' ); ?></label></th>
						<td>
							<?php
							wp_dropdown_pages( [
								'name'              => 'awg_mem_settings[account_page_id]',
								'id'                => 'awg_mem_account_page_id',
								'selected'          => $acctid,
								'show_option_none'  => esc_html__( '— Select —', 'authorwings-ai-tools' ),
								'option_none_value' => 0,
							] );
							?>
							<p class="description"><?php
								/* translators: %s: shortcode */
								printf( esc_html__( 'Select the page that contains the %s shortcode (members see their plan, usage, and billing controls). Members are sent here after logging in.', 'authorwings-ai-tools' ), '<code>[awg_account]</code>' );
							?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="awg_mem_tools_page_id"><?php esc_html_e( 'AI Tools Hub Page', 'authorwings-ai-tools' ); ?></label></th>
						<td>
							<?php
							wp_dropdown_pages( [
								'name'              => 'awg_mem_settings[tools_page_id]',
								'id'                => 'awg_mem_tools_page_id',
								'selected'          => $toolsid,
								'show_option_none'  => esc_html__( '— Select —', 'authorwings-ai-tools' ),
								'option_none_value' => 0,
							] );
							?>
							<p class="description"><?php
								/* translators: %s: shortcode */
								printf( esc_html__( 'Select the page that contains the %s shortcode (the grid of your AI tools).', 'authorwings-ai-tools' ), '<code>[awg_tools]</code>' );
							?></p>
						</td>
					</tr>
				</table>

				<?php submit_button(); ?>
			</form>
		<?php if ( ! $bare ) : ?></div><?php endif; ?>
		<?php
	}
}

/** Permalink of the configured pricing page (fallback: site home). */
if ( ! function_exists( 'awg_aig_mem_pricing_url' ) ) {
	function awg_aig_mem_pricing_url(): string {
		$opt = get_option( 'awg_mem_settings', [] );
		$pid = is_array( $opt ) ? (int) ( $opt['pricing_page_id'] ?? 0 ) : 0;
		$url = $pid ? get_permalink( $pid ) : '';
		return $url ?: home_url( '/' );
	}
}

/** Permalink of the configured member account page ('' if none). */
if ( ! function_exists( 'awg_aig_mem_account_url' ) ) {
	function awg_aig_mem_account_url(): string {
		$opt = get_option( 'awg_mem_settings', [] );
		$pid = is_array( $opt ) ? (int) ( $opt['account_page_id'] ?? 0 ) : 0;
		$url = $pid ? get_permalink( $pid ) : '';
		return $url ?: '';
	}
}

/**
 * Permalink of the AI Tools hub page ('' if none yet).
 *
 * Standard, no-auto-create resolution: an explicitly assigned tools_page_id
 * setting wins; otherwise the published page that contains the [awg_tools]
 * shortcode is detected (cached, refreshed whenever a page is saved/deleted).
 * The site owner simply creates one page with [awg_tools]; the plugin never
 * inserts a page itself.
 */
if ( ! function_exists( 'awg_aig_mem_tools_url' ) ) {
	function awg_aig_mem_tools_url(): string {
		$opt = get_option( 'awg_mem_settings', [] );
		$pid = is_array( $opt ) ? (int) ( $opt['tools_page_id'] ?? 0 ) : 0;
		if ( $pid > 0 && get_post_status( $pid ) === 'publish' ) {
			$url = get_permalink( $pid );
			if ( $url ) {
				return $url;
			}
		}

		$detected = get_transient( 'awg_mem_tools_page_id' );
		if ( false === $detected ) {
			global $wpdb;
			$detected = (int) $wpdb->get_var(
				"SELECT ID FROM {$wpdb->posts}
				 WHERE post_type = 'page' AND post_status = 'publish'
				   AND post_content LIKE '%[awg_tools%'
				 ORDER BY ID ASC LIMIT 1"
			);
			set_transient( 'awg_mem_tools_page_id', $detected, DAY_IN_SECONDS );
		}
		$detected = (int) $detected;
		if ( $detected > 0 && get_post_status( $detected ) === 'publish' ) {
			$url = get_permalink( $detected );
			if ( $url ) {
				return $url;
			}
		}
		return '';
	}
}

/** Forget the detected [awg_tools] page whenever any page is saved or removed. */
if ( ! function_exists( 'awg_aig_mem_flush_tools_page_cache' ) ) {
	function awg_aig_mem_flush_tools_page_cache(): void {
		delete_transient( 'awg_mem_tools_page_id' );
	}
}

/**
 * Find the first published page whose content contains the given shortcode.
 *
 * Used to auto-ASSIGN (never create) the pricing / account / tools pages once an
 * admin has built them by hand with the documented shortcode. Returns 0 when no
 * such page exists — the plugin then shows an admin hint instead of creating one.
 */
if ( ! function_exists( 'awg_aig_mem_find_page_id_by_shortcode' ) ) {
	function awg_aig_mem_find_page_id_by_shortcode( string $shortcode ): int {
		global $wpdb;
		$like = '%' . $wpdb->esc_like( '[' . $shortcode ) . '%';
		$id   = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT ID FROM {$wpdb->posts}
			 WHERE post_type = 'page' AND post_status = 'publish'
			   AND post_content LIKE %s
			 ORDER BY ID ASC LIMIT 1",
			$like
		) );
		return $id > 0 ? $id : 0;
	}
}

/**
 * The membership pages and the shortcode each one must contain. Single source of
 * truth for the settings hint, the admin notice, and page auto-detection.
 */
if ( ! function_exists( 'awg_aig_mem_page_shortcodes' ) ) {
	function awg_aig_mem_page_shortcodes(): array {
		return [
			'pricing_page_id' => [
				'label'     => __( 'Pricing page', 'authorwings-ai-tools' ),
				'shortcode' => 'awg_pricing',
				'desc'      => __( 'Plans and Stripe checkout. Stripe returns buyers here after payment.', 'authorwings-ai-tools' ),
			],
			'account_page_id' => [
				'label'     => __( 'Account page', 'authorwings-ai-tools' ),
				'shortcode' => 'awg_account',
				'desc'      => __( "Members see their plan, usage, and billing controls. Members land here after logging in.", 'authorwings-ai-tools' ),
			],
			'tools_page_id'   => [
				'label'     => __( 'AI Tools hub page', 'authorwings-ai-tools' ),
				'shortcode' => 'awg_tools',
				'desc'      => __( 'A grid of your AI tools; each tool opens in place.', 'authorwings-ai-tools' ),
			],
		];
	}
}

/**
 * Resolve, for each membership page, whether it's set up: an assigned & published
 * page, or any published page that already contains the shortcode. Returns the
 * page_shortcodes() map enriched with 'page_id' (resolved, 0 if none) and 'exists'.
 */
if ( ! function_exists( 'awg_aig_mem_pages_status' ) ) {
	function awg_aig_mem_pages_status(): array {
		$opt = get_option( 'awg_mem_settings', [] );
		$opt = is_array( $opt ) ? $opt : [];
		$out = [];
		foreach ( awg_aig_mem_page_shortcodes() as $key => $meta ) {
			$pid = (int) ( $opt[ $key ] ?? 0 );
			if ( ! ( $pid > 0 && get_post_status( $pid ) === 'publish' ) ) {
				$pid = awg_aig_mem_find_page_id_by_shortcode( $meta['shortcode'] );
			}
			$meta['page_id'] = $pid;
			$meta['exists']  = $pid > 0;
			$out[ $key ]     = $meta;
		}
		return $out;
	}
}

/**
 * Inline hint (used on the Membership → Pages settings) listing each page, its
 * required shortcode, and whether it's been found yet. No page is auto-created;
 * this tells the admin exactly what to build.
 */
if ( ! function_exists( 'awg_aig_mem_render_pages_hint' ) ) {
	function awg_aig_mem_render_pages_hint(): void {
		$status = awg_aig_mem_pages_status();
		?>
		<div class="notice notice-info inline" style="margin:0 0 14px;padding:10px 14px;">
			<p style="margin:0 0 8px;">
				<strong><?php esc_html_e( 'These pages are not created automatically.', 'authorwings-ai-tools' ); ?></strong>
				<?php esc_html_e( 'Create a normal WordPress page for each one, paste in its shortcode, publish it, then select it below. The plugin auto-detects a page once it contains the shortcode.', 'authorwings-ai-tools' ); ?>
			</p>
			<ul style="margin:0;list-style:disc;padding-left:20px;">
				<?php foreach ( $status as $meta ) : ?>
					<li style="margin:2px 0;">
						<code>[<?php echo esc_html( $meta['shortcode'] ); ?>]</code>
						— <?php echo esc_html( $meta['label'] ); ?>
						<?php if ( $meta['exists'] ) : ?>
							<span style="color:#1a8038;font-weight:600;">
								<?php
								/* translators: %s: page edit link */
								printf( esc_html__( '✓ found (%s)', 'authorwings-ai-tools' ), esc_html( get_the_title( $meta['page_id'] ) ) );
								?>
							</span>
						<?php else : ?>
							<span style="color:#b32d2e;font-weight:600;"><?php esc_html_e( '✗ not set up yet', 'authorwings-ai-tools' ); ?></span>
						<?php endif; ?>
						<br><span class="description"><?php echo esc_html( $meta['desc'] ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
	}
}

/**
 * Admin notice on the plugin's own screens prompting the admin to set up any
 * missing membership pages with their shortcodes. Only shows when membership is
 * enabled and at least one page is missing, and links to the Pages settings.
 */
if ( ! function_exists( 'awg_aig_mem_pages_admin_notice' ) ) {
	function awg_aig_mem_pages_admin_notice(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( get_option( 'awg_mem_enabled', '1' ) !== '1' ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		// Limit to AuthorWings AI admin screens to avoid nagging site-wide.
		if ( ! $screen || strpos( (string) $screen->id, 'awg' ) === false ) {
			return;
		}

		$missing = [];
		foreach ( awg_aig_mem_pages_status() as $meta ) {
			if ( empty( $meta['exists'] ) ) {
				$missing[] = $meta;
			}
		}
		if ( empty( $missing ) ) {
			return;
		}

		$cpt          = class_exists( '\\AWG_AIG\\Plugin' ) ? \AWG_AIG\Plugin::CPT : 'awg_ai_template';
		$settings_url = admin_url( 'edit.php?post_type=' . $cpt . '&page=awg-aig-settings&tab=membership' );
		$codes = [];
		foreach ( $missing as $meta ) {
			$codes[] = '<code>[' . esc_html( $meta['shortcode'] ) . ']</code>';
		}
		?>
		<div class="notice notice-warning">
			<p>
				<strong><?php esc_html_e( 'AuthorWings AI membership:', 'authorwings-ai-tools' ); ?></strong>
				<?php
				/* translators: %s: list of shortcodes */
				printf(
					wp_kses( __( 'Some membership pages are not set up. Create a page for each and add its shortcode: %s.', 'authorwings-ai-tools' ), [ 'code' => [] ] ),
					implode( ', ', $codes )
				);
				?>
				<a href="<?php echo esc_url( $settings_url ); ?>"><?php esc_html_e( 'Open Pages settings', 'authorwings-ai-tools' ); ?></a>
			</p>
		</div>
		<?php
	}
}
add_action( 'admin_notices', 'awg_aig_mem_pages_admin_notice' );

/**
 * Auto-ASSIGN (never create) the AI Tools hub page ([awg_tools]). Runs on
 * admin_init. Returns immediately when a valid hub page is already assigned;
 * otherwise, if the admin has a published [awg_tools] page, assigns it. It does
 * NOT create a page — when none exists the admin is prompted via the Pages
 * settings hint to make one with the [awg_tools] shortcode.
 */
if ( ! function_exists( 'awg_aig_mem_ensure_tools_page' ) ) {
	function awg_aig_mem_ensure_tools_page(): void {
		$opt = get_option( 'awg_mem_settings', [] );
		if ( ! is_array( $opt ) ) {
			$opt = [];
		}

		// Cheap path: a valid hub page is already assigned — nothing to do.
		$pid = (int) ( $opt['tools_page_id'] ?? 0 );
		if ( $pid > 0 && get_post_status( $pid ) === 'publish' ) {
			return;
		}

		// Assign an existing [awg_tools] page if the admin has built one.
		$existing = awg_aig_mem_find_page_id_by_shortcode( 'awg_tools' );
		if ( $existing > 0 ) {
			$opt['tools_page_id'] = $existing;
			update_option( 'awg_mem_settings', $opt );
			delete_transient( 'awg_mem_tools_page_id' );
		}
	}
}

/** Scoped styles for the account page, printed once per request. */
if ( ! function_exists( 'awg_aig_mem_account_styles' ) ) {
	function awg_aig_mem_account_styles(): string {
		static $done = false;
		if ( $done ) {
			return '';
		}
		$done = true;
		return '<style>'
			. '.awg-acct{max-width:680px;margin:0 auto;font:16px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#10243c}'
			. '.awg-acct-card{background:#fff;border:1px solid #e8decf;border-radius:16px;padding:28px;box-shadow:0 10px 28px rgba(16,36,60,.04)}'
			. '.awg-acct h2{margin:0 0 4px;font-size:22px}'
			. '.awg-acct__sub{color:#5b6b7c;margin:0 0 20px}'
			. '.awg-acct-row{display:flex;justify-content:space-between;align-items:baseline;gap:12px;padding:12px 0;border-top:1px solid #f0e9dd}'
			. '.awg-acct-row:first-of-type{border-top:0}'
			. '.awg-acct-row__label{color:#5b6b7c}'
			. '.awg-acct-row__value{font-weight:600;text-align:right}'
			. '.awg-acct-badge{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600;background:#dcfce7;color:#166534}'
			. '.awg-acct-badge--muted{background:#e5e7eb;color:#374151}'
			. '.awg-acct-meter{height:10px;border-radius:999px;background:#eef1f4;overflow:hidden;margin-top:6px}'
			. '.awg-acct-meter__fill{height:100%;background:#10243c;transition:width .3s}'
			. '.awg-acct-meter__fill.is-warn{background:#e0922f}'
			. '.awg-acct-meter__fill.is-full{background:#d2502f}'
			. '.awg-acct__unltd{display:inline-block;padding:1px 9px;border-radius:999px;background:#e7f6ec;color:#0f7a43;font-size:12px;font-weight:700;vertical-align:1px}'
			. '.awg-acct-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:24px}'
			. '.awg-acct-btn{display:inline-block;padding:11px 18px;border-radius:12px;border:1px solid #10243c;background:#fff;color:#10243c;font-weight:600;text-decoration:none;cursor:pointer}'
			. '.awg-acct-btn--primary{background:#10243c;color:#fff}'
			. '.awg-acct-btn--danger{border-color:#b91c1c;color:#b91c1c;background:#fff}'
			. '.awg-acct__sub a{color:#10243c;text-decoration:underline}'
			. '.awg-acct__sep{color:#c7cfd8;margin:0 2px}'
			. '.awg-acct-reset{display:block;color:#5b6b7c;font-size:13px;margin-top:6px}'
			. '.awg-acct-link{background:none;border:0;padding:0;font:inherit;color:#10243c;font-weight:600;text-decoration:underline;cursor:pointer}'
			. '.awg-acct__hint{color:#5b6b7c;font-size:13px;margin:12px 0 0}'
			. '.awg-acct__hint .awg-acct-link{font-size:13px}'
			. '.awg-acct-nudge{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-top:20px;padding:12px 16px;border-radius:12px;background:#f6f1e7;border:1px solid #ecd9b8;color:#7a5b16;font-size:14px}'
			. '.awg-acct-nudge__cta{color:#10243c;font-weight:600;text-decoration:underline;white-space:nowrap}'
			. '</style>';
	}
}

/**
 * [awg_account] — purpose-built lean member area.
 *
 * Logged-out: a log in / create account prompt.
 * Logged-in: current plan + status, this month's usage, and self-service
 * buttons — Change plan (to the pricing page), Manage billing (Stripe customer
 * portal) and Cancel plan for paid members.
 */
if ( ! function_exists( 'awg_aig_mem_render_account_page' ) ) {
	function awg_aig_mem_render_account_page(): string {
		$styles = awg_aig_mem_account_styles();

		if ( ! is_user_logged_in() ) {
			$login = wp_login_url( awg_aig_mem_account_url() ?: home_url( '/' ) );
			$reg   = wp_registration_url();
			ob_start();
			echo $styles; // phpcs:ignore WordPress.Security.EscapeOutput
			?>
			<div class="awg-acct">
				<div class="awg-acct-card">
					<h2><?php esc_html_e( 'Your membership', 'authorwings-ai-tools' ); ?></h2>
					<p class="awg-acct__sub"><?php esc_html_e( 'Log in to view and manage your plan.', 'authorwings-ai-tools' ); ?></p>
					<div class="awg-acct-actions">
						<a class="awg-acct-btn awg-acct-btn--primary" href="<?php echo esc_url( $login ); ?>"><?php esc_html_e( 'Log in', 'authorwings-ai-tools' ); ?></a>
						<a class="awg-acct-btn" href="<?php echo esc_url( $reg ); ?>"><?php esc_html_e( 'Create an account', 'authorwings-ai-tools' ); ?></a>
					</div>
				</div>
			</div>
			<?php
			return (string) ob_get_clean();
		}

		if ( ! class_exists( '\\AWG_MEM\\Memberships', false ) ) {
			return '';
		}
		$plugin = \AWG_MEM\Plugin::instance();
		$uid    = get_current_user_id();
		$mem    = $plugin->memberships ? $plugin->memberships->get_effective_membership( $uid ) : null;
		$limits = $plugin->memberships ? $plugin->memberships->get_user_limits( $uid ) : [];
		$used   = $plugin->usage ? $plugin->usage->get_total_for_user( $uid ) : 0;
		$user   = wp_get_current_user();

		$plan_name = (string) ( $mem['plan_name'] ?? __( 'Free', 'authorwings-ai-tools' ) );
		$plan_slug = (string) ( $mem['plan_slug'] ?? 'free' );
		$status    = (string) ( $mem['status'] ?? 'active' );
		$billing   = (string) ( $mem['billing_cycle'] ?? '' );
		$end_date  = (string) ( $mem['end_date'] ?? '' );
		$is_free   = ! empty( $mem['is_free'] ) || $plan_slug === 'free';
		$has_cust  = ! empty( $mem['stripe_customer_id'] );
		$sub_id    = (string) ( $mem['stripe_subscription_id'] ?? '' );
		$active_paid = ! $is_free && in_array( $status, [ 'active', 'trialing' ], true );

		// Stripe-scheduled future plan change (e.g. a paid→paid downgrade queued
		// for period end). The live plan above is unchanged until it fires, so
		// without this the member sees no sign their downgrade registered.
		$pending      = $plugin->memberships ? $plugin->memberships->get_pending_change( $uid ) : [];
		$pending_name = is_array( $pending ) && ! empty( $pending['plan_name'] ) ? (string) $pending['plan_name'] : '';
		$pending_date = ( is_array( $pending ) && ! empty( $pending['effective'] ) )
			? date_i18n( (string) get_option( 'date_format' ), (int) $pending['effective'] )
			: '';

		$limit     = isset( $limits['ai_generations_per_month'] ) ? (int) $limits['ai_generations_per_month'] : 0;
		$unlimited = $limit < 0;
		$pct       = ( $unlimited || $limit <= 0 ) ? 0 : (int) min( 100, round( ( $used / $limit ) * 100 ) );
		$has_meter  = ( ! $unlimited && $limit > 0 );
		$at_limit   = ( $has_meter && $used >= $limit );
		$near_limit = ( $has_meter && $pct >= 80 );

		// Notices.
		$awg_notice = isset( $_GET['awg_notice'] ) ? sanitize_key( wp_unslash( $_GET['awg_notice'] ) ) : '';
		$payment    = isset( $_GET['payment'] ) ? sanitize_key( wp_unslash( $_GET['payment'] ) ) : '';
		$banner     = '';
		if ( $pending_name !== '' ) {
			// A queued change takes priority over the generic "plan is now
			// active" success notice, which would otherwise mislead a member who
			// just scheduled a downgrade into thinking it applied immediately.
			$banner = [ 'info', $pending_date !== ''
				? sprintf(
					/* translators: 1: plan name being switched to, 2: date it takes effect */
					__( 'Your plan will switch to %1$s on %2$s. You keep your current plan until then.', 'authorwings-ai-tools' ),
					$pending_name,
					$pending_date
				)
				: sprintf(
					/* translators: %s: plan name being switched to */
					__( 'Your plan will switch to %s at the end of your current billing period. You keep your current plan until then.', 'authorwings-ai-tools' ),
					$pending_name
				),
			];
		} elseif ( $payment === 'success' || $awg_notice === 'plan-updated' ) {
			$banner = [ 'success', __( 'Your plan is now active.', 'authorwings-ai-tools' ) ];
		} elseif ( $awg_notice === 'cancelled' ) {
			$banner = [ 'info', __( "Your plan was cancelled — you're now on the Free plan.", 'authorwings-ai-tools' ) ];
		} elseif ( $awg_notice === 'cancel-scheduled' ) {
			$banner = [ 'info', __( 'Your cancellation request was sent to Stripe. If you confirmed it, your plan stays active until your renewal date and then moves to the Free plan.', 'authorwings-ai-tools' ) ];
		}

		// Payment-problem alert. The effective membership above only reflects
		// active/trialing rows, so read the latest row to surface a failed
		// payment (which needs a card update) even when the plan no longer
		// counts as active.
		$payment_alert = false;
		$latest        = $plugin->memberships ? $plugin->memberships->get_latest_membership( $uid ) : null;
		$latest_status = is_array( $latest ) ? (string) ( $latest['status'] ?? '' ) : '';
		$latest_sub    = is_array( $latest ) ? (string) ( $latest['stripe_subscription_id'] ?? '' ) : '';
		if ( $latest_sub !== '' && in_array( $latest_status, [ 'payment_failed', 'past_due', 'unpaid' ], true ) ) {
			$payment_alert = true;
		}

		$status_labels = [
			'active'         => __( 'Active', 'authorwings-ai-tools' ),
			'trialing'       => __( 'Trial', 'authorwings-ai-tools' ),
			'cancelled'      => __( 'Cancelled', 'authorwings-ai-tools' ),
			'expired'        => __( 'Expired', 'authorwings-ai-tools' ),
			'payment_failed' => __( 'Payment failed', 'authorwings-ai-tools' ),
		];
		$status_label = $status_labels[ $status ] ?? ucfirst( $status );

		// --- Derived display data -------------------------------------------
		$currency  = (string) ( $mem['currency'] ?? 'USD' );
		$sym       = \AWG_MEM\Plans::currency_symbol( $currency );
		$price_val = $billing === 'yearly' ? (float) ( $mem['price_yearly'] ?? 0 ) : (float) ( $mem['price_monthly'] ?? 0 );
		$price_str = ( $active_paid && $price_val > 0 )
			? $sym . \AWG_MEM\Plans::format_amount( $price_val ) . ' / ' . ( $billing === 'yearly' ? __( 'year', 'authorwings-ai-tools' ) : __( 'month', 'authorwings-ai-tools' ) )
			: '';

		// Default card on file (cached; only attempted when a customer exists).
		$card     = ( $has_cust && $plugin->memberships ) ? $plugin->memberships->get_payment_method_summary( $uid ) : [];
		$card_str = '';
		if ( ! empty( $card['last4'] ) ) {
			$brand    = ! empty( $card['brand'] ) ? ucfirst( (string) $card['brand'] ) : __( 'Card', 'authorwings-ai-tools' );
			$card_str = $brand . ' •••• ' . $card['last4'];
			if ( ! empty( $card['exp_month'] ) && ! empty( $card['exp_year'] ) ) {
				$card_str .= ' · ' . sprintf( /* translators: 1: month 2: 2-digit year */ __( 'exp %1$02d/%2$02d', 'authorwings-ai-tools' ), (int) $card['exp_month'], (int) $card['exp_year'] % 100 );
			}
		}

		// Monthly AI usage resets on the 1st of next calendar month (usage is
		// bucketed by Y-m in site-local time — see Usage::current_period()).
		$reset_ts  = strtotime( 'first day of next month 00:00:00', current_time( 'timestamp' ) );
		$reset_str = $reset_ts ? date_i18n( (string) get_option( 'date_format' ), $reset_ts ) : '';

		// Profile.
		$profile_email = (string) $user->user_email;
		$change_pw_url = wp_lostpassword_url( awg_aig_mem_account_url() ?: home_url( '/' ) );

		// One contextual nudge: yearly savings for monthly payers, otherwise a
		// gentle "running low" prompt when the usage meter is nearly full.
		$nudge       = '';
		$nudge_cta   = '';
		$nudge_url   = awg_aig_mem_pricing_url();
		$monthly_val = (float) ( $mem['price_monthly'] ?? 0 );
		$yearly_val  = (float) ( $mem['price_yearly'] ?? 0 );
		if ( $active_paid && $billing === 'monthly' && $yearly_val > 0 && $monthly_val > 0 && $yearly_val < $monthly_val * 12 ) {
			$save_pct = (int) round( ( 1 - ( $yearly_val / ( $monthly_val * 12 ) ) ) * 100 );
			if ( $save_pct > 0 ) {
				$nudge     = sprintf( /* translators: %d: percent saved */ __( 'Save %d%% by switching to yearly billing.', 'authorwings-ai-tools' ), $save_pct );
				$nudge_cta = __( 'See yearly pricing', 'authorwings-ai-tools' );
			}
		}
		if ( $nudge === '' && ! $unlimited && $limit > 0 && $pct >= 80 ) {
			$nudge     = sprintf( /* translators: %d: percent of monthly allowance used */ __( "You've used %d%% of this month's AI generations.", 'authorwings-ai-tools' ), $pct );
			$nudge_cta = $is_free ? __( 'Upgrade for more', 'authorwings-ai-tools' ) : __( 'See plans', 'authorwings-ai-tools' );
		}

		ob_start();
		echo $styles; // phpcs:ignore WordPress.Security.EscapeOutput
		?>
		<div class="awg-acct">
			<?php if ( $payment_alert ) : ?>
				<div class="awg-acct-notice" role="alert" style="margin:0 0 16px;padding:12px 16px;border-radius:10px;background:#fdecec;color:#991b1b;border:1px solid #f5b5b5;">
					<?php esc_html_e( 'We could not process your last payment. Please update your card to keep your plan active.', 'authorwings-ai-tools' ); ?>
					<button type="button" class="awg-acct-link awg-acct-billing" style="margin-left:6px;"><?php esc_html_e( 'Update card', 'authorwings-ai-tools' ); ?></button>
				</div>
			<?php endif; ?>
			<?php if ( is_array( $banner ) ) : ?>
				<div class="awg-acct-notice" role="status" style="margin:0 0 16px;padding:12px 16px;border-radius:10px;<?php echo $banner[0] === 'success' ? 'background:#e7f6ec;color:#0f5132;border:1px solid #b7dfc4;' : 'background:#eef5ff;color:#1d4ed8;border:1px solid #c7dbff;'; ?>">
					<?php echo esc_html( $banner[1] ); ?>
				</div>
			<?php endif; ?>

			<div class="awg-acct-card">
				<h2><?php esc_html_e( 'Your membership', 'authorwings-ai-tools' ); ?></h2>
				<p class="awg-acct__sub">
					<?php echo esc_html( $user->display_name ?: $user->user_login ); ?>
					<?php if ( $profile_email !== '' ) : ?><span class="awg-acct__sep">·</span> <?php echo esc_html( $profile_email ); ?><?php endif; ?>
					<span class="awg-acct__sep">·</span> <a href="<?php echo esc_url( $change_pw_url ); ?>"><?php esc_html_e( 'Change password', 'authorwings-ai-tools' ); ?></a>
				</p>

				<div class="awg-acct-row">
					<span class="awg-acct-row__label"><?php esc_html_e( 'Current plan', 'authorwings-ai-tools' ); ?></span>
					<span class="awg-acct-row__value">
						<?php echo esc_html( $plan_name ); ?>
						<span class="awg-acct-badge<?php echo $active_paid ? '' : ' awg-acct-badge--muted'; ?>"><?php echo esc_html( $status_label ); ?></span>
					</span>
				</div>

				<?php if ( $price_str !== '' ) : ?>
					<div class="awg-acct-row">
						<span class="awg-acct-row__label"><?php esc_html_e( 'Price', 'authorwings-ai-tools' ); ?></span>
						<span class="awg-acct-row__value"><?php echo esc_html( $price_str ); ?></span>
					</div>
				<?php endif; ?>

				<?php if ( $active_paid && $billing ) : ?>
					<div class="awg-acct-row">
						<span class="awg-acct-row__label"><?php esc_html_e( 'Billing', 'authorwings-ai-tools' ); ?></span>
						<span class="awg-acct-row__value"><?php echo esc_html( $billing === 'yearly' ? __( 'Yearly', 'authorwings-ai-tools' ) : __( 'Monthly', 'authorwings-ai-tools' ) ); ?></span>
					</div>
				<?php endif; ?>

				<?php if ( $active_paid && $end_date && strtotime( $end_date ) ) : ?>
					<div class="awg-acct-row">
						<span class="awg-acct-row__label"><?php echo esc_html( $pending_name !== '' ? __( 'Renews / switches', 'authorwings-ai-tools' ) : __( 'Next renewal', 'authorwings-ai-tools' ) ); ?></span>
						<span class="awg-acct-row__value"><?php echo esc_html( date_i18n( (string) get_option( 'date_format' ), strtotime( $end_date ) ) ); ?></span>
					</div>
				<?php endif; ?>

				<?php if ( $pending_name !== '' ) : ?>
					<div class="awg-acct-row">
						<span class="awg-acct-row__label"><?php esc_html_e( 'Scheduled change', 'authorwings-ai-tools' ); ?></span>
						<span class="awg-acct-row__value">
							<?php
							echo $pending_date !== ''
								? esc_html( sprintf(
									/* translators: 1: plan name, 2: date */
									__( 'Switches to %1$s on %2$s', 'authorwings-ai-tools' ),
									$pending_name,
									$pending_date
								) )
								: esc_html( sprintf(
									/* translators: %s: plan name */
									__( 'Switches to %s at period end', 'authorwings-ai-tools' ),
									$pending_name
								) );
							?>
						</span>
					</div>
				<?php endif; ?>

				<?php if ( $card_str !== '' ) : ?>
					<div class="awg-acct-row">
						<span class="awg-acct-row__label"><?php esc_html_e( 'Payment method', 'authorwings-ai-tools' ); ?></span>
						<span class="awg-acct-row__value">
							<?php echo esc_html( $card_str ); ?>
							<button type="button" class="awg-acct-link awg-acct-billing" style="margin-left:8px;"><?php esc_html_e( 'Update', 'authorwings-ai-tools' ); ?></button>
						</span>
					</div>
				<?php endif; ?>

				<div class="awg-acct-row" style="display:block;">
					<span class="awg-acct-row__label"><?php esc_html_e( 'AI generations this month', 'authorwings-ai-tools' ); ?></span>
					<span class="awg-acct-row__value" style="display:block;text-align:left;margin-top:2px;">
						<?php
						if ( $unlimited ) {
							echo esc_html( sprintf( /* translators: %d: number used */ __( '%d used', 'authorwings-ai-tools' ), $used ) )
								. ' <span class="awg-acct__unltd">' . esc_html__( 'Unlimited', 'authorwings-ai-tools' ) . '</span>';
						} else {
							echo esc_html( sprintf( __( '%1$d / %2$d used', 'authorwings-ai-tools' ), $used, max( 0, $limit ) ) );
						}
						?>
					</span>
					<?php if ( $has_meter ) : ?>
						<div class="awg-acct-meter"><div class="awg-acct-meter__fill<?php echo $at_limit ? ' is-full' : ( $near_limit ? ' is-warn' : '' ); ?>" style="width:<?php echo (int) $pct; ?>%;"></div></div>
					<?php endif; ?>
					<?php if ( ! $unlimited && $reset_str !== '' ) : ?>
						<span class="awg-acct-reset"><?php echo esc_html( sprintf( /* translators: %s: date */ __( 'Resets %s', 'authorwings-ai-tools' ), $reset_str ) ); ?></span>
					<?php endif; ?>
				</div>

				<?php if ( $nudge !== '' ) : ?>
					<div class="awg-acct-nudge">
						<span><?php echo esc_html( $nudge ); ?></span>
						<a class="awg-acct-nudge__cta" href="<?php echo esc_url( $nudge_url ); ?>"><?php echo esc_html( $nudge_cta ); ?></a>
					</div>
				<?php endif; ?>

				<div class="awg-acct-actions">
					<?php $awg_acct_tools_url = awg_aig_mem_tools_url(); ?>
					<?php if ( $awg_acct_tools_url ) : ?>
						<a class="awg-acct-btn awg-acct-btn--primary" href="<?php echo esc_url( $awg_acct_tools_url ); ?>"><?php esc_html_e( 'Open your AI tools', 'authorwings-ai-tools' ); ?></a>
					<?php endif; ?>
					<a class="awg-acct-btn<?php echo $awg_acct_tools_url ? '' : ' awg-acct-btn--primary'; ?>" href="<?php echo esc_url( awg_aig_mem_pricing_url() ); ?>">
						<?php echo $is_free ? esc_html__( 'Upgrade plan', 'authorwings-ai-tools' ) : esc_html__( 'Change plan', 'authorwings-ai-tools' ); ?>
					</a>
					<?php if ( $has_cust ) : ?>
						<button type="button" class="awg-acct-btn awg-acct-billing"><?php esc_html_e( 'Manage billing', 'authorwings-ai-tools' ); ?></button>
					<?php endif; ?>
					<?php if ( $active_paid && $sub_id ) : ?>
						<button type="button" class="awg-acct-btn awg-acct-btn--danger awg-acct-cancel"><?php esc_html_e( 'Cancel plan', 'authorwings-ai-tools' ); ?></button>
					<?php endif; ?>
				</div>

				<?php if ( $has_cust ) : ?>
					<p class="awg-acct__hint">
						<?php esc_html_e( 'Receipts and past invoices are available in', 'authorwings-ai-tools' ); ?>
						<button type="button" class="awg-acct-link awg-acct-billing"><?php esc_html_e( 'Manage billing', 'authorwings-ai-tools' ); ?></button>.
					</p>
				<?php endif; ?>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}

/**
 * [awg_tools] — public AI Tools landing.
 *
 * v6.1.3: the old login-gated membership hub was removed. This shortcode now
 * renders a simple, public grid of Tool Category cards. Each card links to that
 * category's real archive page (/tool-category/<slug>/), which lists the tools
 * inside; each tool then links to the page hosting its [awg_generator]
 * shortcode. There are no more in-hub deep-links (?awg_cat=, ?tool=), no usage
 * meter and no login gate here — access is still enforced server-side at
 * generation time, on the tool page itself.
 */
if ( ! function_exists( 'awg_aig_mem_render_tools_page' ) ) {
	function awg_aig_mem_render_tools_page(): string {
		$styles = awg_aig_mem_tools_styles();
		$tax    = ( class_exists( '\\AWG_AIG\\Plugin' ) && defined( '\\AWG_AIG\\Plugin::TAX' ) ) ? \AWG_AIG\Plugin::TAX : 'awg_tool_category';

		// Category-card layout (square | banner | cover), shared with the admin setting.
		$cat_layout = 'square';
		if ( class_exists( '\\AWG_AIG\\Plugin' ) ) {
			$aig = \AWG_AIG\Plugin::instance();
			if ( $aig && isset( $aig->settings ) && is_object( $aig->settings ) ) {
				$awg_set = $aig->settings->get();
				$mc      = isset( $awg_set['hub_cat_layout'] ) ? (string) $awg_set['hub_cat_layout'] : 'square';
				if ( in_array( $mc, array( 'square', 'banner', 'cover' ), true ) ) {
					$cat_layout = $mc;
				}
			}
		}

		$terms = get_terms( array(
			'taxonomy'   => $tax,
			'hide_empty' => true,
			'orderby'    => 'name',
			'order'      => 'ASC',
		) );
		if ( is_wp_error( $terms ) ) {
			$terms = array();
		}

		ob_start();
		echo $styles; // phpcs:ignore WordPress.Security.EscapeOutput
		?>
		<div class="awg-tools">
			<div class="awg-tools__head">
				<div>
					<h2><?php esc_html_e( 'AI Tools', 'authorwings-ai-tools' ); ?></h2>
				</div>
			</div>

			<?php if ( empty( $terms ) ) : ?>
				<p class="awg-tools__empty"><?php esc_html_e( 'No tools are available yet. Please check back soon.', 'authorwings-ai-tools' ); ?></p>
			<?php else : ?>
				<div class="awg-tools__cats">
					<?php foreach ( $terms as $term ) :
						$tcount  = (int) $term->count;
						$ticon   = (string) get_term_meta( $term->term_id, 'awg_cat_icon', true );
						$taccent = ltrim( (string) get_term_meta( $term->term_id, 'awg_cat_accent', true ), '#' );
						if ( ! preg_match( '/^[0-9a-fA-F]{6}$/', $taccent ) ) {
							$taccent = '7e9374';
						}
						$tparts = array_filter( array_map( 'sanitize_html_class', preg_split( '/\s+/', $ticon ) ?: array() ) );
						$ticon  = implode( ' ', $tparts );
						if ( $ticon === '' ) {
							$ticon = 'dashicons dashicons-category';
						} elseif ( strpos( $ticon, 'dashicons-' ) !== false && ! preg_match( '/(^|\s)dashicons(\s|$)/', $ticon ) ) {
							$ticon = 'dashicons ' . $ticon;
						}
						$cr    = (int) hexdec( substr( $taccent, 0, 2 ) );
						$cg    = (int) hexdec( substr( $taccent, 2, 2 ) );
						$cb    = (int) hexdec( substr( $taccent, 4, 2 ) );
						$chip  = sprintf( 'background:rgba(%d,%d,%d,.13);color:#%s', $cr, $cg, $cb, $taccent );
						$tdesc = trim( (string) $term->description );
						if ( $tdesc !== '' ) {
							$tdesc = wp_trim_words( $tdesc, 18, '…' );
						}
						$timg_id  = (int) get_term_meta( $term->term_id, 'awg_cat_image', true );
						$timg_url = $timg_id ? wp_get_attachment_image_url( $timg_id, 'medium' ) : '';
						$ccount   = sprintf( /* translators: %d: number of tools */ _n( '%d tool', '%d tools', $tcount, 'authorwings-ai-tools' ), $tcount );

						// Link straight to the category's real, public archive page.
						$term_link = get_term_link( $term );
						$curl      = ( ! is_wp_error( $term_link ) ) ? $term_link : home_url( '/' );
						?>
						<a class="awg-tools-cat<?php echo ( $timg_url && in_array( $cat_layout, array( 'banner', 'cover' ), true ) ) ? ' awg-card--' . esc_attr( $cat_layout ) : ''; ?>" href="<?php echo esc_url( $curl ); ?>">
							<?php if ( $timg_url && $cat_layout === 'cover' ) : ?>
								<img class="awg-hub-cover-img" src="<?php echo esc_url( $timg_url ); ?>" alt="" loading="lazy" />
								<span class="awg-tools-cat__badge awg-hub-badge-on"><span class="dashicons dashicons-portfolio" aria-hidden="true"></span><?php echo esc_html( $ccount ); ?></span>
								<span class="awg-hub-cover-scrim">
									<span class="awg-hub-cover-title"><?php echo esc_html( $term->name ); ?></span>
									<span class="awg-hub-cover-sub"><?php esc_html_e( 'Browse', 'authorwings-ai-tools' ); ?> &rarr;</span>
								</span>
							<?php elseif ( $timg_url && $cat_layout === 'banner' ) : ?>
								<span class="awg-hub-banner"><img src="<?php echo esc_url( $timg_url ); ?>" alt="" loading="lazy" /><span class="awg-tools-cat__badge awg-hub-badge-on"><span class="dashicons dashicons-portfolio" aria-hidden="true"></span><?php echo esc_html( $ccount ); ?></span></span>
								<span class="awg-hub-body">
									<span class="awg-tools-card__name"><?php echo esc_html( $term->name ); ?></span>
									<?php if ( $tdesc !== '' ) : ?><span class="awg-tools-card__desc"><?php echo esc_html( $tdesc ); ?></span><?php endif; ?>
									<span class="awg-tools-card__open awg-tools-cat__browse"><?php esc_html_e( 'Browse', 'authorwings-ai-tools' ); ?> &rarr;</span>
								</span>
							<?php else : ?>
								<span class="awg-tools-cat__top">
									<?php if ( $timg_url ) : ?>
										<span class="awg-tools-card__thumb"><img src="<?php echo esc_url( $timg_url ); ?>" alt="" loading="lazy" /></span>
									<?php else : ?>
										<span class="awg-tools-card__ic" style="<?php echo esc_attr( $chip ); ?>"><span class="<?php echo esc_attr( $ticon ); ?>" aria-hidden="true"></span></span>
									<?php endif; ?>
									<span class="awg-tools-cat__badge"><span class="dashicons dashicons-portfolio" aria-hidden="true"></span><?php echo esc_html( $ccount ); ?></span>
								</span>
								<span class="awg-tools-card__name"><?php echo esc_html( $term->name ); ?></span>
								<?php if ( $tdesc !== '' ) : ?><span class="awg-tools-card__desc"><?php echo esc_html( $tdesc ); ?></span><?php endif; ?>
								<span class="awg-tools-card__open awg-tools-cat__browse"><?php esc_html_e( 'Browse', 'authorwings-ai-tools' ); ?> &rarr;</span>
							<?php endif; ?>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}


/** Scoped styles for the AI tools hub, printed once per request. */
if ( ! function_exists( 'awg_aig_mem_tools_styles' ) ) {
	function awg_aig_mem_tools_styles(): string {
		static $done = false;
		if ( $done ) {
			return '';
		}
		$done = true;
		return '<style>'
			. '.awg-tools{max-width:900px;margin:0 auto;font:16px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#10243c}'
			. '.awg-tools h2{margin:0 0 4px;font-size:22px}'
			. '.awg-tools__head{display:flex;justify-content:space-between;align-items:flex-end;gap:20px;flex-wrap:wrap;margin:0 0 22px}'
			. '.awg-tools__plan{color:#5b6b7c;margin:0}'
			. '.awg-tools__usage{min-width:220px;flex:1;max-width:320px}'
			. '.awg-tools__usage-row{display:flex;justify-content:space-between;font-size:14px;color:#5b6b7c}'
			. '.awg-tools__usage-row b{color:#10243c}'
			. '.awg-tools__meter{height:8px;border-radius:999px;background:#eef1f4;overflow:hidden;margin-top:6px}'
			. '.awg-tools__meter-fill{height:100%;background:#10243c;transition:width .3s}'
			. '.awg-tools__meter-fill--warn{background:#e0922f}'
			. '.awg-tools__meter-fill--full{background:#d2502f}'
			. '.awg-tools__count.is-warn{color:#b26a00}'
			. '.awg-tools__count.is-full{color:#d2502f}'
			. '.awg-tools__unltd{display:inline-block;padding:2px 11px;border-radius:999px;background:#e7f6ec;color:#0f7a43;font-size:13px;font-weight:700}'
			. '.awg-tools__reset{display:block;font-size:12px;color:#8a97a4;margin-top:5px}'
			. '.awg-tools__nudge{display:inline-block;margin-top:7px;font-size:13px;font-weight:600;color:#b26a00;text-decoration:none}'
			. '.awg-tools__nudge:hover{text-decoration:underline}'
			. '.awg-tools__nudge.is-full{color:#d2502f}'
			. '.awg-tools__grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px}'
			. '.awg-tools__cats{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px}'
			. '.awg-tools-cat{display:flex;flex-direction:column;min-height:150px;background:#fff;border:1px solid #e8decf;border-radius:14px;padding:18px;text-decoration:none;color:#10243c;transition:box-shadow .15s,border-color .15s}'
			. 'a.awg-tools-cat:hover{border-color:#10243c;box-shadow:0 8px 20px rgba(16,36,60,.07)}'
			. 'a.awg-tools-cat:hover .awg-tools-card__open{gap:9px}'
			. '.awg-tools-cat__foot{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:auto;padding-top:14px}'
			. '.awg-tools-cat__count{font-size:13px;color:#5b6b7c;font-weight:600}'
			. '.awg-tools__alllink{margin:18px 0 0}'
			. '.awg-tools__alllink a{color:#5b6b7c;text-decoration:none;font-size:14px;font-weight:600}'
			. '.awg-tools__alllink a:hover{color:#10243c}'
			. '.awg-tools__crumbs{margin:0 0 6px}'
			. '.awg-tools__cathead{margin:0 0 18px}'
			. '.awg-tools__cattitle{margin:0 0 4px;font-size:19px}'
			. '.awg-tools__catdesc{margin:0;color:#5b6b7c;font-size:14px}'
			. '.awg-tools-card{display:flex;flex-direction:column;min-height:150px;background:#fff;border:1px solid #e8decf;border-radius:14px;padding:18px;text-decoration:none;color:#10243c;transition:box-shadow .15s,border-color .15s}'
			. 'a.awg-tools-card:hover{border-color:#10243c;box-shadow:0 8px 20px rgba(16,36,60,.07)}'
			. 'a.awg-tools-card:hover .awg-tools-card__open{gap:9px}'
			. '.awg-tools-card--locked{background:#faf7f1}'
			. '.awg-tools-card__ic{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin:0 0 14px;flex:none}'
			. '.awg-tools-card__ic .dashicons,.awg-tools-card__ic [class*="dashicons"]{font-size:24px;width:24px;height:24px;line-height:24px}'
			. '.awg-tools-card__ic--locked{background:#efece4;color:#9aa6b2}'
			. '.awg-tools-card__name{font-size:15.5px;font-weight:600;display:flex;align-items:center;gap:7px;line-height:1.35}'
			. '.awg-tools-card__desc{font-size:13px;line-height:1.45;color:#5b6b7c;margin-top:8px}'
			. '.awg-tools-card__open{font-size:14px;font-weight:600;color:#10243c;margin-top:auto;padding-top:14px;display:inline-flex;align-items:center;gap:5px;transition:gap .15s}'
			. '.awg-tools-card__foot{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:auto;padding-top:14px}'
			. '.awg-tools-badge{font-size:11px;font-weight:700;padding:2px 9px;border-radius:999px;background:#fdecd2;color:#8a5a00}'
			. '.awg-tools-up{font-size:14px;font-weight:600;color:#10243c;text-decoration:none}'
			. '.awg-tools-up:hover{text-decoration:underline}'
			. '.awg-tools-lock{width:14px;height:14px;color:#b9a98f;flex:none}'
			. '.awg-tools__back{display:inline-block;color:#5b6b7c;text-decoration:none;font-size:14px;margin:0 0 14px}'
			. '.awg-tools__back:hover{color:#10243c}'
			. '.awg-tools__single-title{margin:0 0 16px;font-size:24px}'
			. '.awg-tools__notice{margin:0 0 16px;padding:12px 16px;border-radius:10px;background:#eef5ff;color:#1d4ed8;border:1px solid #c7dbff}'
			. '.awg-tools__notice--ok{background:#e7f6ec;color:#0f5132;border-color:#b7dfc4}'
			. '.awg-tools__empty{color:#5b6b7c}'
			. '.awg-tools__gate{max-width:520px;margin:0 auto;text-align:center;background:#fff;border:1px solid #e8decf;border-radius:16px;padding:36px 28px}'
			. '.awg-tools__gate p{color:#5b6b7c}'
			. '.awg-tools__gate-actions{display:flex;gap:10px;justify-content:center;margin-top:18px}'
			. '.awg-tools__btn{display:inline-block;padding:11px 18px;border-radius:12px;border:1px solid #10243c;background:#fff;color:#10243c;font-weight:600;text-decoration:none}'
			. '.awg-tools__btn--primary{background:#10243c;color:#fff}'
			. '.awg-tools-cat__top{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 0 13px}'
			. '.awg-tools-cat__top .awg-tools-card__ic{margin:0}'
			. '.awg-tools-card__thumb{width:48px;height:48px;border-radius:11px;overflow:hidden;flex:none;background:#f1efe8}'
			. '.awg-tools-card__thumb img{width:100%;height:100%;object-fit:cover;display:block}'
			. '.awg-tools-card>.awg-tools-card__thumb{margin:0 0 14px}'
			. '.awg-tools-card__thumb--locked{filter:grayscale(.35);opacity:.85}'
			. '.awg-tools-cat__badge{display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:600;color:#506347;background:rgba(126,147,116,.15);padding:3px 10px;border-radius:999px;white-space:nowrap}'
			. '.awg-tools-cat__badge .dashicons{font-size:14px;width:14px;height:14px;line-height:14px}'
			. '.awg-tools-cat__browse{color:#506347}'
			. '.awg-card--banner{padding:0;overflow:hidden}'
			. '.awg-hub-banner{position:relative;display:block;height:104px;background:#eef1f4;flex:none}'
			. '.awg-hub-banner img{width:100%;height:100%;object-fit:cover;display:block}'
			. '.awg-hub-body{flex:1;display:flex;flex-direction:column;padding:14px 16px}'
			. '.awg-card--cover{position:relative;display:block;padding:0;overflow:hidden;min-height:158px}'
			. '.awg-hub-cover-img{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;display:block}'
			. '.awg-hub-cover-scrim{position:absolute;left:0;right:0;bottom:0;background:rgba(16,36,60,.66);padding:11px 14px;display:flex;flex-direction:column;gap:3px}'
			. '.awg-hub-cover-title{color:#fff;font-size:15px;font-weight:600;line-height:1.3}'
			. '.awg-hub-cover-sub{color:#dfe6ee;font-size:12.5px;font-weight:600}'
			. '.awg-hub-badge-on{position:absolute;top:8px;right:8px;color:#fff;background:rgba(16,36,60,.82)}'
			. '</style>';
	}
}

/**
 * [awg_account_menu] / authorwings/account-menu block.
 *
 * A self-contained header element:
 *   - Logged out: "Log in" + (only when registration is open) "Sign up".
 *   - Logged in:  an avatar button opening a dropdown with the plan badge, this
 *     month's usage, and quick links — My account, Upgrade / Change plan,
 *     Manage billing (members with a Stripe customer only), and Log out.
 *
 * Reuses the same URLs / membership / usage data as [awg_account]; the host
 * theme decides where it sits.
 */
if ( ! function_exists( 'awg_aig_mem_render_account_menu' ) ) {
	function awg_aig_mem_render_account_menu( $atts = [] ): string {
		static $instance = 0;
		$instance++;

		$account_url = awg_aig_mem_account_url() ?: home_url( '/' );

		// Small, dependency-free inline icons (own stroke renditions).
		$icon = static function ( string $name ): string {
			$paths = [
				'user'    => '<circle cx="12" cy="8" r="4"></circle><path d="M4 21c0-4 4-6 8-6s8 2 8 6"></path>',
				'tools'   => '<rect x="3" y="3" width="7" height="7" rx="1.5"></rect><rect x="14" y="3" width="7" height="7" rx="1.5"></rect><rect x="3" y="14" width="7" height="7" rx="1.5"></rect><rect x="14" y="14" width="7" height="7" rx="1.5"></rect>',
				'upgrade' => '<path d="M12 19V5"></path><path d="M6 11l6-6 6 6"></path>',
				'card'    => '<rect x="3" y="6" width="18" height="12" rx="2"></rect><path d="M3 10h18"></path>',
				'logout'  => '<path d="M9 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h3"></path><path d="M16 17l5-5-5-5"></path><path d="M21 12H9"></path>',
				'caret'   => '<path d="M6 9l6 6 6-6"></path>',
			];
			return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . ( $paths[ $name ] ?? '' ) . '</svg>';
		};

		// ---- Logged out ----
		if ( ! is_user_logged_in() ) {
			$login_url = wp_login_url( $account_url );
			ob_start();
			?>
			<div class="awg-am awg-am--guest">
				<a class="awg-am-btn" href="<?php echo esc_url( $login_url ); ?>"><?php esc_html_e( 'Log in', 'authorwings-ai-tools' ); ?></a>
				<?php
				if ( get_option( 'users_can_register' ) ) :
					$reg = wp_registration_url();
					$reg = $reg ? add_query_arg( 'redirect_to', rawurlencode( $account_url ), $reg ) : '';
					if ( $reg ) :
						?>
						<a class="awg-am-btn awg-am-btn--primary" href="<?php echo esc_url( $reg ); ?>"><?php esc_html_e( 'Sign up', 'authorwings-ai-tools' ); ?></a>
						<?php
					endif;
				endif;
				?>
			</div>
			<?php
			return (string) ob_get_clean();
		}

		// ---- Logged in ----
		if ( ! class_exists( '\\AWG_MEM\\Memberships', false ) ) {
			return '';
		}
		$plugin = \AWG_MEM\Plugin::instance();
		$uid    = get_current_user_id();
		$mem    = $plugin->memberships ? $plugin->memberships->get_effective_membership( $uid ) : null;
		$limits = $plugin->memberships ? $plugin->memberships->get_user_limits( $uid ) : [];
		$used   = $plugin->usage ? (int) $plugin->usage->get_total_for_user( $uid ) : 0;
		$user   = wp_get_current_user();

		$plan_name = (string) ( $mem['plan_name'] ?? __( 'Free', 'authorwings-ai-tools' ) );
		$plan_slug = (string) ( $mem['plan_slug'] ?? 'free' );
		$status    = (string) ( $mem['status'] ?? 'active' );
		$is_free   = ! empty( $mem['is_free'] ) || $plan_slug === 'free';
		$has_cust  = ! empty( $mem['stripe_customer_id'] );
		$active    = in_array( $status, [ 'active', 'trialing' ], true );

		$limit     = isset( $limits['ai_generations_per_month'] ) ? (int) $limits['ai_generations_per_month'] : 0;
		$unlimited = $limit < 0;
		$pct       = ( $unlimited || $limit <= 0 ) ? 0 : (int) min( 100, round( ( $used / max( 1, $limit ) ) * 100 ) );
		$has_meter  = ( ! $unlimited && $limit > 0 );
		$at_limit   = ( $has_meter && $used >= $limit );
		$near_limit = ( $has_meter && $pct >= 80 );

		$status_labels = [
			'active'         => __( 'Active', 'authorwings-ai-tools' ),
			'trialing'       => __( 'Trial', 'authorwings-ai-tools' ),
			'cancelled'      => __( 'Cancelled', 'authorwings-ai-tools' ),
			'expired'        => __( 'Expired', 'authorwings-ai-tools' ),
			'payment_failed' => __( 'Payment failed', 'authorwings-ai-tools' ),
		];
		$status_label = $status_labels[ $status ] ?? ucfirst( $status );
		$badge        = $is_free ? $plan_name : trim( $plan_name . ' · ' . $status_label );

		$display = ( $user && $user->exists() ) ? ( $user->display_name ?: $user->user_login ) : '';
		$initial = 'U';
		if ( $display !== '' ) {
			$initial = function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( $display, 0, 1 ) ) : strtoupper( substr( $display, 0, 1 ) );
		}

		$pricing_url = awg_aig_mem_pricing_url();
		$logout_url  = \AWG_MEM\URLs::logout( home_url( '/' ) );
		$panel_id    = 'awg-am-panel-' . $instance;

		ob_start();
		?>
		<div class="awg-am" data-awg-am>
			<button type="button" class="awg-am-trigger" aria-haspopup="true" aria-expanded="false" aria-controls="<?php echo esc_attr( $panel_id ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: member display name */ __( 'Account menu for %s', 'authorwings-ai-tools' ), $display ) ); ?>">
				<span class="awg-am-avatar" aria-hidden="true"><?php echo esc_html( $initial ); ?></span>
				<span class="awg-am-caret"><?php echo $icon( 'caret' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			</button>

			<div class="awg-am-panel" id="<?php echo esc_attr( $panel_id ); ?>" role="menu">
				<div class="awg-am-head">
					<span class="awg-am-avatar" aria-hidden="true"><?php echo esc_html( $initial ); ?></span>
					<div style="min-width:0">
						<div><span class="awg-am-name"><?php echo esc_html( $display ); ?></span><span class="awg-am-badge<?php echo ( $active && ! $is_free ) ? '' : ' awg-am-badge--muted'; ?>"><?php echo esc_html( $badge ); ?></span></div>
						<div class="awg-am-email"><?php echo esc_html( $user ? $user->user_email : '' ); ?></div>
					</div>
				</div>

				<div class="awg-am-usage">
					<div class="awg-am-usage__row">
						<span><?php esc_html_e( 'AI generations this month', 'authorwings-ai-tools' ); ?></span>
						<b><?php if ( $unlimited ) : ?><span class="awg-am-unltd"><?php esc_html_e( 'Unlimited', 'authorwings-ai-tools' ); ?></span><?php else : echo esc_html( $used . ' / ' . max( 0, $limit ) ); endif; ?></b>
					</div>
					<?php if ( $has_meter ) : ?>
						<div class="awg-am-meter"><div class="awg-am-meter__fill<?php echo $at_limit ? ' is-full' : ( $near_limit ? ' is-warn' : '' ); ?>" style="width:<?php echo (int) $pct; ?>%"></div></div>
					<?php endif; ?>
				</div>

				<div class="awg-am-items">
					<?php $awg_tools_url = awg_aig_mem_tools_url(); ?>
					<?php if ( $awg_tools_url ) : ?>
						<a class="awg-am-item" role="menuitem" href="<?php echo esc_url( $awg_tools_url ); ?>"><?php echo $icon( 'tools' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span class="awg-am-label"><?php esc_html_e( 'AI Tools', 'authorwings-ai-tools' ); ?></span></a>
					<?php endif; ?>
					<a class="awg-am-item" role="menuitem" href="<?php echo esc_url( $account_url ); ?>"><?php echo $icon( 'user' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span class="awg-am-label"><?php esc_html_e( 'My account', 'authorwings-ai-tools' ); ?></span></a>
					<a class="awg-am-item" role="menuitem" href="<?php echo esc_url( $pricing_url ); ?>"><?php echo $icon( 'upgrade' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span class="awg-am-label"><?php echo $is_free ? esc_html__( 'Upgrade plan', 'authorwings-ai-tools' ) : esc_html__( 'Change plan', 'authorwings-ai-tools' ); ?></span></a>
					<?php if ( $has_cust ) : ?>
						<button type="button" class="awg-am-item awg-am-billing" role="menuitem"><?php echo $icon( 'card' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span class="awg-am-label"><?php esc_html_e( 'Manage billing', 'authorwings-ai-tools' ); ?></span></button>
					<?php endif; ?>
					<div class="awg-am-sep" role="separator"></div>
					<a class="awg-am-item" role="menuitem" href="<?php echo esc_url( $logout_url ); ?>"><?php echo $icon( 'logout' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span class="awg-am-label"><?php esc_html_e( 'Log out', 'authorwings-ai-tools' ); ?></span></a>
				</div>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}

/**
 * True if the current (or given) user is an AuthorWings member who should be
 * kept out of wp-admin. Site managers (anyone who can manage options or edit
 * content) are never restricted.
 */
if ( ! function_exists( 'awg_aig_mem_is_restricted_user' ) ) {
	function awg_aig_mem_is_restricted_user( $user = null ): bool {
		if ( ! ( $user instanceof \WP_User ) ) {
			$user = wp_get_current_user();
		}
		if ( ! $user || ! $user->exists() ) {
			return false;
		}
		if ( user_can( $user, 'manage_options' ) || user_can( $user, 'edit_posts' ) ) {
			return false;
		}
		$awg_roles = [ 'awg_free_member', 'awg_basic_member', 'awg_pro_member', 'awg_publisher' ];
		foreach ( (array) $user->roles as $role ) {
			if ( in_array( $role, $awg_roles, true ) ) {
				return true;
			}
		}
		return false;
	}
}

/** Front-end landing for members: account page, else pricing, else site home. */
if ( ! function_exists( 'awg_aig_mem_member_home_url' ) ) {
	function awg_aig_mem_member_home_url(): string {
		$acct = awg_aig_mem_account_url();
		if ( $acct ) {
			return $acct;
		}
		return awg_aig_mem_pricing_url();
	}
}

/** Hide the front-end admin bar for restricted members. */
if ( ! function_exists( 'awg_aig_mem_admin_bar' ) ) {
	function awg_aig_mem_admin_bar( $show ) {
		return awg_aig_mem_is_restricted_user() ? false : $show;
	}
}

/**
 * Bounce restricted members out of wp-admin. AJAX (admin-ajax.php) is allowed
 * so the plugin's front-end AJAX keeps working; the Stripe webhook is a REST
 * route and is unaffected.
 */
if ( ! function_exists( 'awg_aig_mem_block_admin' ) ) {
	function awg_aig_mem_block_admin(): void {
		if ( ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) || ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
			return;
		}
		if ( ! awg_aig_mem_is_restricted_user() ) {
			return;
		}
		wp_safe_redirect( awg_aig_mem_member_home_url() );
		exit;
	}
}
